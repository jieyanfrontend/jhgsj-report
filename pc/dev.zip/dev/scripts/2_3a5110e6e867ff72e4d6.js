(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[2],{

/***/ "../node_modules/antd/es/message/style/index.css":
/*!*******************************************************!*\
  !*** ../node_modules/antd/es/message/style/index.css ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../css-loader!./index.css */ "../node_modules/css-loader/index.js!../node_modules/antd/es/message/style/index.css");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../style-loader/lib/addStyles.js */ "../node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(true) {
	module.hot.accept(/*! !../../../../css-loader!./index.css */ "../node_modules/css-loader/index.js!../node_modules/antd/es/message/style/index.css", function(__WEBPACK_OUTDATED_DEPENDENCIES__) { (function() {
		var newContent = __webpack_require__(/*! !../../../../css-loader!./index.css */ "../node_modules/css-loader/index.js!../node_modules/antd/es/message/style/index.css");

		if(typeof newContent === 'string') newContent = [[module.i, newContent, '']];

		var locals = (function(a, b) {
			var key, idx = 0;

			for(key in a) {
				if(!b || a[key] !== b[key]) return false;
				idx++;
			}

			for(key in b) idx--;

			return idx === 0;
		}(content.locals, newContent.locals));

		if(!locals) throw new Error('Aborting CSS HMR due to changed css-modules locals.');

		update(newContent);
	})(__WEBPACK_OUTDATED_DEPENDENCIES__); });

	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "../node_modules/antd/es/modal/style/index.css":
/*!*****************************************************!*\
  !*** ../node_modules/antd/es/modal/style/index.css ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../css-loader!./index.css */ "../node_modules/css-loader/index.js!../node_modules/antd/es/modal/style/index.css");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../style-loader/lib/addStyles.js */ "../node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(true) {
	module.hot.accept(/*! !../../../../css-loader!./index.css */ "../node_modules/css-loader/index.js!../node_modules/antd/es/modal/style/index.css", function(__WEBPACK_OUTDATED_DEPENDENCIES__) { (function() {
		var newContent = __webpack_require__(/*! !../../../../css-loader!./index.css */ "../node_modules/css-loader/index.js!../node_modules/antd/es/modal/style/index.css");

		if(typeof newContent === 'string') newContent = [[module.i, newContent, '']];

		var locals = (function(a, b) {
			var key, idx = 0;

			for(key in a) {
				if(!b || a[key] !== b[key]) return false;
				idx++;
			}

			for(key in b) idx--;

			return idx === 0;
		}(content.locals, newContent.locals));

		if(!locals) throw new Error('Aborting CSS HMR due to changed css-modules locals.');

		update(newContent);
	})(__WEBPACK_OUTDATED_DEPENDENCIES__); });

	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "../node_modules/antd/es/radio/style/index.css":
/*!*****************************************************!*\
  !*** ../node_modules/antd/es/radio/style/index.css ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../css-loader!./index.css */ "../node_modules/css-loader/index.js!../node_modules/antd/es/radio/style/index.css");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../style-loader/lib/addStyles.js */ "../node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(true) {
	module.hot.accept(/*! !../../../../css-loader!./index.css */ "../node_modules/css-loader/index.js!../node_modules/antd/es/radio/style/index.css", function(__WEBPACK_OUTDATED_DEPENDENCIES__) { (function() {
		var newContent = __webpack_require__(/*! !../../../../css-loader!./index.css */ "../node_modules/css-loader/index.js!../node_modules/antd/es/radio/style/index.css");

		if(typeof newContent === 'string') newContent = [[module.i, newContent, '']];

		var locals = (function(a, b) {
			var key, idx = 0;

			for(key in a) {
				if(!b || a[key] !== b[key]) return false;
				idx++;
			}

			for(key in b) idx--;

			return idx === 0;
		}(content.locals, newContent.locals));

		if(!locals) throw new Error('Aborting CSS HMR due to changed css-modules locals.');

		update(newContent);
	})(__WEBPACK_OUTDATED_DEPENDENCIES__); });

	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "../node_modules/antd/es/table/style/index.css":
/*!*****************************************************!*\
  !*** ../node_modules/antd/es/table/style/index.css ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../css-loader!./index.css */ "../node_modules/css-loader/index.js!../node_modules/antd/es/table/style/index.css");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../style-loader/lib/addStyles.js */ "../node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(true) {
	module.hot.accept(/*! !../../../../css-loader!./index.css */ "../node_modules/css-loader/index.js!../node_modules/antd/es/table/style/index.css", function(__WEBPACK_OUTDATED_DEPENDENCIES__) { (function() {
		var newContent = __webpack_require__(/*! !../../../../css-loader!./index.css */ "../node_modules/css-loader/index.js!../node_modules/antd/es/table/style/index.css");

		if(typeof newContent === 'string') newContent = [[module.i, newContent, '']];

		var locals = (function(a, b) {
			var key, idx = 0;

			for(key in a) {
				if(!b || a[key] !== b[key]) return false;
				idx++;
			}

			for(key in b) idx--;

			return idx === 0;
		}(content.locals, newContent.locals));

		if(!locals) throw new Error('Aborting CSS HMR due to changed css-modules locals.');

		update(newContent);
	})(__WEBPACK_OUTDATED_DEPENDENCIES__); });

	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "../node_modules/css-loader/index.js!../node_modules/antd/es/message/style/index.css":
/*!**********************************************************************************!*\
  !*** ../node_modules/css-loader!../node_modules/antd/es/message/style/index.css ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../css-loader/lib/css-base.js */ "../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "/* stylelint-disable at-rule-empty-line-before,at-rule-name-space-after,at-rule-no-unknown */\n/* stylelint-disable no-duplicate-selectors */\n/* stylelint-disable declaration-bang-space-before,no-duplicate-selectors */\n/* stylelint-disable declaration-bang-space-before,no-duplicate-selectors,string-no-newline */\n.ant-message {\n  font-family: \"Monospaced Number\", \"Chinese Quote\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"PingFang SC\", \"Hiragino Sans GB\", \"Microsoft YaHei\", \"Helvetica Neue\", Helvetica, Arial, sans-serif;\n  font-size: 14px;\n  line-height: 1.5;\n  color: rgba(0, 0, 0, 0.65);\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  margin: 0;\n  padding: 0;\n  list-style: none;\n  position: fixed;\n  z-index: 1010;\n  width: 100%;\n  top: 16px;\n  left: 0;\n  pointer-events: none;\n}\n.ant-message-notice {\n  padding: 8px;\n  text-align: center;\n}\n.ant-message-notice:first-child {\n  margin-top: -8px;\n}\n.ant-message-notice-content {\n  padding: 10px 16px;\n  border-radius: 4px;\n  -webkit-box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);\n          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);\n  background: #fff;\n  display: inline-block;\n  pointer-events: all;\n}\n.ant-message-success .anticon {\n  color: #52c41a;\n}\n.ant-message-error .anticon {\n  color: #f5222d;\n}\n.ant-message-warning .anticon {\n  color: #faad14;\n}\n.ant-message-info .anticon,\n.ant-message-loading .anticon {\n  color: #1890ff;\n}\n.ant-message .anticon {\n  margin-right: 8px;\n  font-size: 16px;\n  top: 1px;\n  position: relative;\n}\n.ant-message-notice.move-up-leave.move-up-leave-active {\n  -webkit-animation-name: MessageMoveOut;\n          animation-name: MessageMoveOut;\n  overflow: hidden;\n  -webkit-animation-duration: .3s;\n          animation-duration: .3s;\n}\n@-webkit-keyframes MessageMoveOut {\n  0% {\n    opacity: 1;\n    max-height: 150px;\n    padding: 8px;\n  }\n  100% {\n    opacity: 0;\n    max-height: 0;\n    padding: 0;\n  }\n}\n@keyframes MessageMoveOut {\n  0% {\n    opacity: 1;\n    max-height: 150px;\n    padding: 8px;\n  }\n  100% {\n    opacity: 0;\n    max-height: 0;\n    padding: 0;\n  }\n}\n", ""]);

// exports


/***/ }),

/***/ "../node_modules/css-loader/index.js!../node_modules/antd/es/modal/style/index.css":
/*!********************************************************************************!*\
  !*** ../node_modules/css-loader!../node_modules/antd/es/modal/style/index.css ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../css-loader/lib/css-base.js */ "../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "/* stylelint-disable at-rule-empty-line-before,at-rule-name-space-after,at-rule-no-unknown */\n/* stylelint-disable no-duplicate-selectors */\n/* stylelint-disable declaration-bang-space-before,no-duplicate-selectors */\n/* stylelint-disable declaration-bang-space-before,no-duplicate-selectors,string-no-newline */\n.ant-modal {\n  font-family: \"Monospaced Number\", \"Chinese Quote\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"PingFang SC\", \"Hiragino Sans GB\", \"Microsoft YaHei\", \"Helvetica Neue\", Helvetica, Arial, sans-serif;\n  font-size: 14px;\n  line-height: 1.5;\n  color: rgba(0, 0, 0, 0.65);\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  margin: 0;\n  padding: 0;\n  list-style: none;\n  position: relative;\n  width: auto;\n  margin: 0 auto;\n  top: 100px;\n  padding-bottom: 24px;\n}\n.ant-modal-wrap {\n  position: fixed;\n  overflow: auto;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  z-index: 1000;\n  -webkit-overflow-scrolling: touch;\n  outline: 0;\n}\n.ant-modal-title {\n  margin: 0;\n  font-size: 16px;\n  line-height: 22px;\n  font-weight: 500;\n  color: rgba(0, 0, 0, 0.85);\n}\n.ant-modal-content {\n  position: relative;\n  background-color: #fff;\n  border: 0;\n  border-radius: 4px;\n  background-clip: padding-box;\n  -webkit-box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);\n          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);\n}\n.ant-modal-close {\n  cursor: pointer;\n  border: 0;\n  background: transparent;\n  position: absolute;\n  right: 0;\n  top: 0;\n  z-index: 10;\n  font-weight: 700;\n  line-height: 1;\n  text-decoration: none;\n  -webkit-transition: color .3s;\n  transition: color .3s;\n  color: rgba(0, 0, 0, 0.45);\n  outline: 0;\n  padding: 0;\n}\n.ant-modal-close-x {\n  display: block;\n  font-style: normal;\n  vertical-align: baseline;\n  text-align: center;\n  text-transform: none;\n  text-rendering: auto;\n  width: 56px;\n  height: 56px;\n  line-height: 56px;\n  font-size: 16px;\n}\n.ant-modal-close-x:before {\n  content: \"\\E633\";\n  display: block;\n  font-family: \"anticon\" !important;\n}\n.ant-modal-close:focus,\n.ant-modal-close:hover {\n  color: #444;\n  text-decoration: none;\n}\n.ant-modal-header {\n  padding: 16px 24px;\n  border-radius: 4px 4px 0 0;\n  background: #fff;\n  color: rgba(0, 0, 0, 0.65);\n  border-bottom: 1px solid #e8e8e8;\n}\n.ant-modal-body {\n  padding: 24px;\n  font-size: 14px;\n  line-height: 1.5;\n  word-wrap: break-word;\n}\n.ant-modal-footer {\n  border-top: 1px solid #e8e8e8;\n  padding: 10px 16px;\n  text-align: right;\n  border-radius: 0 0 4px 4px;\n}\n.ant-modal-footer button + button {\n  margin-left: 8px;\n  margin-bottom: 0;\n}\n.ant-modal.zoom-enter,\n.ant-modal.zoom-appear {\n  -webkit-animation-duration: 0.3s;\n          animation-duration: 0.3s;\n  -webkit-transform: none;\n      -ms-transform: none;\n          transform: none;\n  opacity: 0;\n}\n.ant-modal-mask {\n  position: fixed;\n  top: 0;\n  right: 0;\n  left: 0;\n  bottom: 0;\n  background-color: #373737;\n  background-color: rgba(0, 0, 0, 0.65);\n  height: 100%;\n  z-index: 1000;\n  filter: alpha(opacity=50);\n}\n.ant-modal-mask-hidden {\n  display: none;\n}\n.ant-modal-open {\n  overflow: hidden;\n}\n@media (max-width: 768px) {\n  .ant-modal {\n    width: auto !important;\n    margin: 10px;\n  }\n  .vertical-center-modal .ant-modal {\n    -webkit-box-flex: 1;\n    -webkit-flex: 1;\n        -ms-flex: 1;\n            flex: 1;\n  }\n}\n.ant-confirm .ant-modal-header {\n  display: none;\n}\n.ant-confirm .ant-modal-close {\n  display: none;\n}\n.ant-confirm .ant-modal-body {\n  padding: 32px 32px 24px;\n}\n.ant-confirm-body-wrapper {\n  zoom: 1;\n}\n.ant-confirm-body-wrapper:before,\n.ant-confirm-body-wrapper:after {\n  content: \" \";\n  display: table;\n}\n.ant-confirm-body-wrapper:after {\n  clear: both;\n  visibility: hidden;\n  font-size: 0;\n  height: 0;\n}\n.ant-confirm-body .ant-confirm-title {\n  color: rgba(0, 0, 0, 0.85);\n  font-weight: 500;\n  font-size: 16px;\n  line-height: 22px;\n  display: block;\n  overflow: auto;\n}\n.ant-confirm-body .ant-confirm-content {\n  margin-left: 38px;\n  font-size: 14px;\n  color: rgba(0, 0, 0, 0.65);\n  margin-top: 8px;\n}\n.ant-confirm-body > .anticon {\n  font-size: 22px;\n  margin-right: 16px;\n  float: left;\n}\n.ant-confirm .ant-confirm-btns {\n  margin-top: 24px;\n  float: right;\n}\n.ant-confirm .ant-confirm-btns button + button {\n  margin-left: 8px;\n  margin-bottom: 0;\n}\n.ant-confirm-error .ant-confirm-body > .anticon {\n  color: #f5222d;\n}\n.ant-confirm-warning .ant-confirm-body > .anticon,\n.ant-confirm-confirm .ant-confirm-body > .anticon {\n  color: #faad14;\n}\n.ant-confirm-info .ant-confirm-body > .anticon {\n  color: #1890ff;\n}\n.ant-confirm-success .ant-confirm-body > .anticon {\n  color: #52c41a;\n}\n", ""]);

// exports


/***/ }),

/***/ "../node_modules/css-loader/index.js!../node_modules/antd/es/radio/style/index.css":
/*!********************************************************************************!*\
  !*** ../node_modules/css-loader!../node_modules/antd/es/radio/style/index.css ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../css-loader/lib/css-base.js */ "../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "/* stylelint-disable at-rule-empty-line-before,at-rule-name-space-after,at-rule-no-unknown */\n/* stylelint-disable no-duplicate-selectors */\n/* stylelint-disable declaration-bang-space-before,no-duplicate-selectors */\n/* stylelint-disable declaration-bang-space-before,no-duplicate-selectors,string-no-newline */\n.ant-radio-group {\n  font-family: \"Monospaced Number\", \"Chinese Quote\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"PingFang SC\", \"Hiragino Sans GB\", \"Microsoft YaHei\", \"Helvetica Neue\", Helvetica, Arial, sans-serif;\n  font-size: 14px;\n  line-height: 1.5;\n  color: rgba(0, 0, 0, 0.65);\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  margin: 0;\n  padding: 0;\n  list-style: none;\n  display: inline-block;\n  line-height: unset;\n}\n.ant-radio-wrapper {\n  font-family: \"Monospaced Number\", \"Chinese Quote\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"PingFang SC\", \"Hiragino Sans GB\", \"Microsoft YaHei\", \"Helvetica Neue\", Helvetica, Arial, sans-serif;\n  font-size: 14px;\n  line-height: 1.5;\n  color: rgba(0, 0, 0, 0.65);\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  margin: 0;\n  padding: 0;\n  list-style: none;\n  display: inline-block;\n  position: relative;\n  white-space: nowrap;\n  margin-right: 8px;\n  cursor: pointer;\n}\n.ant-radio {\n  font-family: \"Monospaced Number\", \"Chinese Quote\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"PingFang SC\", \"Hiragino Sans GB\", \"Microsoft YaHei\", \"Helvetica Neue\", Helvetica, Arial, sans-serif;\n  font-size: 14px;\n  line-height: 1.5;\n  color: rgba(0, 0, 0, 0.65);\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  margin: 0;\n  padding: 0;\n  list-style: none;\n  white-space: nowrap;\n  outline: none;\n  display: inline-block;\n  position: relative;\n  line-height: 1;\n  vertical-align: text-bottom;\n  cursor: pointer;\n}\n.ant-radio-wrapper:hover .ant-radio .ant-radio-inner,\n.ant-radio:hover .ant-radio-inner,\n.ant-radio-focused .ant-radio-inner {\n  border-color: #1890ff;\n}\n.ant-radio-checked:after {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n  border-radius: 50%;\n  border: 1px solid #1890ff;\n  content: '';\n  -webkit-animation: antRadioEffect 0.36s ease-in-out;\n          animation: antRadioEffect 0.36s ease-in-out;\n  -webkit-animation-fill-mode: both;\n          animation-fill-mode: both;\n  visibility: hidden;\n}\n.ant-radio:hover:after,\n.ant-radio-wrapper:hover .ant-radio:after {\n  visibility: visible;\n}\n.ant-radio-inner {\n  position: relative;\n  top: 0;\n  left: 0;\n  display: block;\n  width: 16px;\n  height: 16px;\n  border-width: 1px;\n  border-style: solid;\n  border-radius: 100px;\n  border-color: #d9d9d9;\n  background-color: #fff;\n  -webkit-transition: all 0.3s;\n  transition: all 0.3s;\n}\n.ant-radio-inner:after {\n  position: absolute;\n  width: 8px;\n  height: 8px;\n  left: 3px;\n  top: 3px;\n  border-radius: 4px;\n  display: table;\n  border-top: 0;\n  border-left: 0;\n  content: ' ';\n  background-color: #1890ff;\n  opacity: 0;\n  -webkit-transform: scale(0);\n      -ms-transform: scale(0);\n          transform: scale(0);\n  -webkit-transition: all 0.3s cubic-bezier(0.78, 0.14, 0.15, 0.86);\n  transition: all 0.3s cubic-bezier(0.78, 0.14, 0.15, 0.86);\n}\n.ant-radio-input {\n  position: absolute;\n  left: 0;\n  z-index: 1;\n  cursor: pointer;\n  opacity: 0;\n  top: 0;\n  bottom: 0;\n  right: 0;\n}\n.ant-radio-checked .ant-radio-inner {\n  border-color: #1890ff;\n}\n.ant-radio-checked .ant-radio-inner:after {\n  -webkit-transform: scale(0.875);\n      -ms-transform: scale(0.875);\n          transform: scale(0.875);\n  opacity: 1;\n  -webkit-transition: all 0.3s cubic-bezier(0.78, 0.14, 0.15, 0.86);\n  transition: all 0.3s cubic-bezier(0.78, 0.14, 0.15, 0.86);\n}\n.ant-radio-disabled .ant-radio-inner {\n  border-color: #d9d9d9 !important;\n  background-color: #f5f5f5;\n}\n.ant-radio-disabled .ant-radio-inner:after {\n  background-color: #ccc;\n}\n.ant-radio-disabled .ant-radio-input {\n  cursor: not-allowed;\n}\n.ant-radio-disabled + span {\n  color: rgba(0, 0, 0, 0.25);\n  cursor: not-allowed;\n}\nspan.ant-radio + * {\n  padding-left: 8px;\n  padding-right: 8px;\n}\n.ant-radio-button-wrapper {\n  margin: 0;\n  height: 32px;\n  line-height: 30px;\n  color: rgba(0, 0, 0, 0.65);\n  display: inline-block;\n  -webkit-transition: all 0.3s ease;\n  transition: all 0.3s ease;\n  cursor: pointer;\n  border: 1px solid #d9d9d9;\n  border-left: 0;\n  border-top-width: 1.02px;\n  background: #fff;\n  padding: 0 15px;\n  position: relative;\n}\n.ant-radio-button-wrapper a {\n  color: rgba(0, 0, 0, 0.65);\n}\n.ant-radio-button-wrapper > .ant-radio-button {\n  margin-left: 0;\n  display: block;\n  width: 0;\n  height: 0;\n}\n.ant-radio-group-large .ant-radio-button-wrapper {\n  height: 40px;\n  line-height: 38px;\n  font-size: 16px;\n}\n.ant-radio-group-small .ant-radio-button-wrapper {\n  height: 24px;\n  line-height: 22px;\n  padding: 0 7px;\n}\n.ant-radio-button-wrapper:not(:first-child)::before {\n  content: \"\";\n  display: block;\n  top: 0;\n  left: -1px;\n  width: 1px;\n  height: 100%;\n  position: absolute;\n  background-color: #d9d9d9;\n}\n.ant-radio-button-wrapper:first-child {\n  border-radius: 4px 0 0 4px;\n  border-left: 1px solid #d9d9d9;\n}\n.ant-radio-button-wrapper:last-child {\n  border-radius: 0 4px 4px 0;\n}\n.ant-radio-button-wrapper:first-child:last-child {\n  border-radius: 4px;\n}\n.ant-radio-button-wrapper:hover,\n.ant-radio-button-wrapper-focused {\n  color: #1890ff;\n  position: relative;\n}\n.ant-radio-button-wrapper .ant-radio-inner,\n.ant-radio-button-wrapper input[type=\"checkbox\"],\n.ant-radio-button-wrapper input[type=\"radio\"] {\n  opacity: 0;\n  width: 0;\n  height: 0;\n}\n.ant-radio-button-wrapper-checked {\n  background: #fff;\n  border-color: #1890ff;\n  color: #1890ff;\n  -webkit-box-shadow: -1px 0 0 0 #1890ff;\n          box-shadow: -1px 0 0 0 #1890ff;\n  z-index: 1;\n}\n.ant-radio-button-wrapper-checked::before {\n  background-color: #1890ff !important;\n  opacity: 0.1;\n}\n.ant-radio-button-wrapper-checked:first-child {\n  border-color: #1890ff;\n  -webkit-box-shadow: none !important;\n          box-shadow: none !important;\n}\n.ant-radio-button-wrapper-checked:hover {\n  border-color: #40a9ff;\n  -webkit-box-shadow: -1px 0 0 0 #40a9ff;\n          box-shadow: -1px 0 0 0 #40a9ff;\n  color: #40a9ff;\n}\n.ant-radio-button-wrapper-checked:active {\n  border-color: #096dd9;\n  -webkit-box-shadow: -1px 0 0 0 #096dd9;\n          box-shadow: -1px 0 0 0 #096dd9;\n  color: #096dd9;\n}\n.ant-radio-button-wrapper-disabled {\n  border-color: #d9d9d9;\n  background-color: #f5f5f5;\n  cursor: not-allowed;\n  color: rgba(0, 0, 0, 0.25);\n}\n.ant-radio-button-wrapper-disabled:first-child,\n.ant-radio-button-wrapper-disabled:hover {\n  border-color: #d9d9d9;\n  background-color: #f5f5f5;\n  color: rgba(0, 0, 0, 0.25);\n}\n.ant-radio-button-wrapper-disabled:first-child {\n  border-left-color: #d9d9d9;\n}\n.ant-radio-button-wrapper-disabled.ant-radio-button-wrapper-checked {\n  color: #fff;\n  background-color: #e6e6e6;\n  border-color: #d9d9d9;\n  -webkit-box-shadow: none;\n          box-shadow: none;\n}\n@-webkit-keyframes antRadioEffect {\n  0% {\n    -webkit-transform: scale(1);\n            transform: scale(1);\n    opacity: 0.5;\n  }\n  100% {\n    -webkit-transform: scale(1.6);\n            transform: scale(1.6);\n    opacity: 0;\n  }\n}\n@keyframes antRadioEffect {\n  0% {\n    -webkit-transform: scale(1);\n            transform: scale(1);\n    opacity: 0.5;\n  }\n  100% {\n    -webkit-transform: scale(1.6);\n            transform: scale(1.6);\n    opacity: 0;\n  }\n}\n", ""]);

// exports


/***/ }),

/***/ "../node_modules/css-loader/index.js!../node_modules/antd/es/table/style/index.css":
/*!********************************************************************************!*\
  !*** ../node_modules/css-loader!../node_modules/antd/es/table/style/index.css ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../css-loader/lib/css-base.js */ "../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "/* stylelint-disable at-rule-empty-line-before,at-rule-name-space-after,at-rule-no-unknown */\n/* stylelint-disable no-duplicate-selectors */\n/* stylelint-disable declaration-bang-space-before,no-duplicate-selectors */\n/* stylelint-disable declaration-bang-space-before,no-duplicate-selectors,string-no-newline */\n.ant-table-wrapper {\n  zoom: 1;\n}\n.ant-table-wrapper:before,\n.ant-table-wrapper:after {\n  content: \" \";\n  display: table;\n}\n.ant-table-wrapper:after {\n  clear: both;\n  visibility: hidden;\n  font-size: 0;\n  height: 0;\n}\n.ant-table {\n  font-family: \"Monospaced Number\", \"Chinese Quote\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"PingFang SC\", \"Hiragino Sans GB\", \"Microsoft YaHei\", \"Helvetica Neue\", Helvetica, Arial, sans-serif;\n  font-size: 14px;\n  line-height: 1.5;\n  color: rgba(0, 0, 0, 0.65);\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  margin: 0;\n  padding: 0;\n  list-style: none;\n  position: relative;\n  clear: both;\n}\n.ant-table-body {\n  -webkit-transition: opacity .3s;\n  transition: opacity .3s;\n}\n.ant-table table {\n  width: 100%;\n  border-collapse: separate;\n  border-spacing: 0;\n  text-align: left;\n  border-radius: 4px 4px 0 0;\n}\n.ant-table-thead > tr > th {\n  background: #fafafa;\n  -webkit-transition: background .3s ease;\n  transition: background .3s ease;\n  text-align: left;\n  color: rgba(0, 0, 0, 0.85);\n  font-weight: 500;\n  border-bottom: 1px solid #e8e8e8;\n}\n.ant-table-thead > tr > th[colspan] {\n  text-align: center;\n  border-bottom: 0;\n}\n.ant-table-thead > tr > th .anticon-filter,\n.ant-table-thead > tr > th .ant-table-filter-icon {\n  position: relative;\n  margin-left: 8px;\n  font-size: 14px;\n  cursor: pointer;\n  color: rgba(0, 0, 0, 0.45);\n  -webkit-transition: all .3s;\n  transition: all .3s;\n  width: 14px;\n  font-weight: normal;\n  vertical-align: text-bottom;\n}\n.ant-table-thead > tr > th .anticon-filter:hover,\n.ant-table-thead > tr > th .ant-table-filter-icon:hover {\n  color: rgba(0, 0, 0, 0.65);\n}\n.ant-table-thead > tr > th .ant-table-column-sorter + .anticon-filter {\n  margin-left: 4px;\n}\n.ant-table-thead > tr > th .ant-table-filter-selected.anticon-filter {\n  color: #1890ff;\n}\n.ant-table-thead > tr > th.ant-table-column-has-filters {\n  overflow: hidden;\n}\n.ant-table-thead > tr:first-child > th:first-child {\n  border-top-left-radius: 4px;\n}\n.ant-table-thead > tr:first-child > th:last-child {\n  border-top-right-radius: 4px;\n}\n.ant-table-tbody > tr > td {\n  border-bottom: 1px solid #e8e8e8;\n  -webkit-transition: all .3s;\n  transition: all .3s;\n}\n.ant-table-thead > tr,\n.ant-table-tbody > tr {\n  -webkit-transition: all .3s;\n  transition: all .3s;\n}\n.ant-table-thead > tr.ant-table-row-hover > td,\n.ant-table-tbody > tr.ant-table-row-hover > td,\n.ant-table-thead > tr:hover > td,\n.ant-table-tbody > tr:hover > td {\n  background: #e6f7ff;\n}\n.ant-table-thead > tr:hover {\n  background: none;\n}\n.ant-table-footer {\n  padding: 16px 16px;\n  background: #fafafa;\n  border-radius: 0 0 4px 4px;\n  position: relative;\n  border-top: 1px solid #e8e8e8;\n}\n.ant-table-footer:before {\n  content: '';\n  height: 1px;\n  background: #fafafa;\n  position: absolute;\n  top: -1px;\n  width: 100%;\n  left: 0;\n}\n.ant-table.ant-table-bordered .ant-table-footer {\n  border: 1px solid #e8e8e8;\n}\n.ant-table-title {\n  padding: 16px 0;\n  position: relative;\n  top: 1px;\n  border-radius: 4px 4px 0 0;\n}\n.ant-table.ant-table-bordered .ant-table-title {\n  border: 1px solid #e8e8e8;\n  padding-left: 16px;\n  padding-right: 16px;\n}\n.ant-table-title + .ant-table-content {\n  position: relative;\n  border-radius: 4px 4px 0 0;\n  overflow: hidden;\n}\n.ant-table-bordered .ant-table-title + .ant-table-content,\n.ant-table-bordered .ant-table-title + .ant-table-content table,\n.ant-table-bordered .ant-table-title + .ant-table-content .ant-table-thead > tr:first-child > th {\n  border-radius: 0;\n}\n.ant-table-without-column-header .ant-table-title + .ant-table-content,\n.ant-table-without-column-header table {\n  border-radius: 0;\n}\n.ant-table-tbody > tr.ant-table-row-selected td {\n  background: #fafafa;\n}\n.ant-table-thead > tr > th.ant-table-column-sort {\n  background: #f5f5f5;\n}\n.ant-table-thead > tr > th,\n.ant-table-tbody > tr > td {\n  padding: 16px 16px;\n  word-break: break-all;\n}\n.ant-table-thead > tr > th.ant-table-selection-column-custom {\n  padding-left: 16px;\n  padding-right: 0;\n}\n.ant-table-thead > tr > th.ant-table-selection-column,\n.ant-table-tbody > tr > td.ant-table-selection-column {\n  text-align: center;\n  min-width: 62px;\n  width: 62px;\n}\n.ant-table-thead > tr > th.ant-table-selection-column .ant-radio-wrapper,\n.ant-table-tbody > tr > td.ant-table-selection-column .ant-radio-wrapper {\n  margin-right: 0;\n}\n.ant-table-expand-icon-th,\n.ant-table-row-expand-icon-cell {\n  text-align: center;\n  min-width: 50px;\n  width: 50px;\n}\n.ant-table-header {\n  background: #fafafa;\n  overflow: hidden;\n}\n.ant-table-header table {\n  border-radius: 4px 4px 0 0;\n}\n.ant-table-loading {\n  position: relative;\n}\n.ant-table-loading .ant-table-body {\n  background: #fff;\n  opacity: 0.5;\n}\n.ant-table-loading .ant-table-spin-holder {\n  height: 20px;\n  line-height: 20px;\n  left: 50%;\n  top: 50%;\n  margin-left: -30px;\n  position: absolute;\n}\n.ant-table-loading .ant-table-with-pagination {\n  margin-top: -20px;\n}\n.ant-table-loading .ant-table-without-pagination {\n  margin-top: 10px;\n}\n.ant-table-column-sorter {\n  position: relative;\n  margin-left: 8px;\n  display: inline-block;\n  width: 14px;\n  height: 14px;\n  vertical-align: middle;\n  text-align: center;\n  font-weight: normal;\n  color: rgba(0, 0, 0, 0.45);\n}\n.ant-table-column-sorter-up,\n.ant-table-column-sorter-down {\n  line-height: 6px;\n  display: block;\n  width: 14px;\n  height: 6px;\n  cursor: pointer;\n  position: relative;\n}\n.ant-table-column-sorter-up:hover .anticon,\n.ant-table-column-sorter-down:hover .anticon {\n  color: #69c0ff;\n}\n.ant-table-column-sorter-up.on .anticon-caret-up,\n.ant-table-column-sorter-down.on .anticon-caret-up,\n.ant-table-column-sorter-up.on .anticon-caret-down,\n.ant-table-column-sorter-down.on .anticon-caret-down {\n  color: #1890ff;\n}\n.ant-table-column-sorter-up:after,\n.ant-table-column-sorter-down:after {\n  position: absolute;\n  content: '';\n  height: 30px;\n  width: 14px;\n  left: 0;\n}\n.ant-table-column-sorter-up:after {\n  bottom: 0;\n}\n.ant-table-column-sorter-down:after {\n  top: 0;\n}\n.ant-table-column-sorter .anticon-caret-up,\n.ant-table-column-sorter .anticon-caret-down {\n  display: inline-block;\n  font-size: 12px;\n  font-size: 8px \\9;\n  -webkit-transform: scale(0.66666667) rotate(0deg);\n      -ms-transform: scale(0.66666667) rotate(0deg);\n          transform: scale(0.66666667) rotate(0deg);\n  line-height: 4px;\n  height: 4px;\n  -webkit-transition: all .3s;\n  transition: all .3s;\n  position: relative;\n}\n:root .ant-table-column-sorter .anticon-caret-up,\n:root .ant-table-column-sorter .anticon-caret-down {\n  font-size: 12px;\n}\n.ant-table-column-sorter-down {\n  margin-top: 1.5px;\n}\n.ant-table-column-sorter .anticon-caret-down {\n  top: -1.5px;\n}\n.ant-table-bordered .ant-table-header > table,\n.ant-table-bordered .ant-table-body > table,\n.ant-table-bordered .ant-table-fixed-left table,\n.ant-table-bordered .ant-table-fixed-right table {\n  border: 1px solid #e8e8e8;\n  border-right: 0;\n  border-bottom: 0;\n}\n.ant-table-bordered.ant-table-empty .ant-table-placeholder {\n  border-left: 1px solid #e8e8e8;\n  border-right: 1px solid #e8e8e8;\n}\n.ant-table-bordered.ant-table-fixed-header .ant-table-header > table {\n  border-bottom: 0;\n}\n.ant-table-bordered.ant-table-fixed-header .ant-table-body > table {\n  border-top: 0;\n  border-top-left-radius: 0;\n  border-top-right-radius: 0;\n}\n.ant-table-bordered.ant-table-fixed-header .ant-table-body-inner > table {\n  border-top: 0;\n}\n.ant-table-bordered.ant-table-fixed-header .ant-table-placeholder {\n  border: 0;\n}\n.ant-table-bordered .ant-table-thead > tr > th {\n  border-bottom: 1px solid #e8e8e8;\n}\n.ant-table-bordered .ant-table-thead > tr > th,\n.ant-table-bordered .ant-table-tbody > tr > td {\n  border-right: 1px solid #e8e8e8;\n}\n.ant-table-placeholder {\n  position: relative;\n  padding: 16px 16px;\n  background: #fff;\n  border-bottom: 1px solid #e8e8e8;\n  text-align: center;\n  font-size: 14px;\n  color: rgba(0, 0, 0, 0.45);\n  z-index: 1;\n}\n.ant-table-placeholder .anticon {\n  margin-right: 4px;\n}\n.ant-table-pagination.ant-pagination {\n  margin: 16px 0;\n  float: right;\n}\n.ant-table-filter-dropdown {\n  min-width: 96px;\n  margin-left: -8px;\n  background: #fff;\n  border-radius: 4px;\n  -webkit-box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);\n          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);\n}\n.ant-table-filter-dropdown .ant-dropdown-menu {\n  border: 0;\n  -webkit-box-shadow: none;\n          box-shadow: none;\n  border-radius: 4px 4px 0 0;\n}\n.ant-table-filter-dropdown .ant-dropdown-menu-without-submenu {\n  max-height: 400px;\n  overflow-x: hidden;\n}\n.ant-table-filter-dropdown .ant-dropdown-menu-item > label + span {\n  padding-right: 0;\n}\n.ant-table-filter-dropdown .ant-dropdown-menu-sub {\n  border-radius: 4px;\n  -webkit-box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);\n          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);\n}\n.ant-table-filter-dropdown .ant-dropdown-menu .ant-dropdown-submenu-contain-selected .ant-dropdown-menu-submenu-title:after {\n  color: #1890ff;\n  font-weight: bold;\n  text-shadow: 0 0 2px #bae7ff;\n}\n.ant-table-filter-dropdown .ant-dropdown-menu-item {\n  overflow: hidden;\n}\n.ant-table-filter-dropdown > .ant-dropdown-menu > .ant-dropdown-menu-item:last-child,\n.ant-table-filter-dropdown > .ant-dropdown-menu > .ant-dropdown-menu-submenu:last-child .ant-dropdown-menu-submenu-title {\n  border-radius: 0;\n}\n.ant-table-filter-dropdown-btns {\n  overflow: hidden;\n  padding: 7px 8px;\n  border-top: 1px solid #e8e8e8;\n}\n.ant-table-filter-dropdown-link {\n  color: #1890ff;\n}\n.ant-table-filter-dropdown-link:hover {\n  color: #40a9ff;\n}\n.ant-table-filter-dropdown-link:active {\n  color: #096dd9;\n}\n.ant-table-filter-dropdown-link.confirm {\n  float: left;\n}\n.ant-table-filter-dropdown-link.clear {\n  float: right;\n}\n.ant-table-selection-select-all-custom {\n  margin-right: 4px !important;\n}\n.ant-table-selection .anticon-down {\n  color: rgba(0, 0, 0, 0.45);\n  -webkit-transition: all .3s;\n  transition: all .3s;\n}\n.ant-table-selection-menu {\n  min-width: 96px;\n  margin-top: 5px;\n  margin-left: -30px;\n  background: #fff;\n  border-radius: 4px;\n  -webkit-box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);\n          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);\n}\n.ant-table-selection-menu .ant-action-down {\n  color: rgba(0, 0, 0, 0.45);\n}\n.ant-table-selection-down {\n  cursor: pointer;\n  padding: 0;\n  display: inline-block;\n  line-height: 1;\n}\n.ant-table-selection-down:hover .anticon-down {\n  color: #666;\n}\n.ant-table-row-expand-icon {\n  cursor: pointer;\n  display: inline-block;\n  width: 17px;\n  height: 17px;\n  text-align: center;\n  line-height: 14px;\n  border: 1px solid #e8e8e8;\n  -webkit-user-select: none;\n     -moz-user-select: none;\n      -ms-user-select: none;\n          user-select: none;\n  background: #fff;\n}\n.ant-table-row-expanded:after {\n  content: '-';\n}\n.ant-table-row-collapsed:after {\n  content: '+';\n}\n.ant-table-row-spaced {\n  visibility: hidden;\n}\n.ant-table-row-spaced:after {\n  content: '.';\n}\n.ant-table-row[class*=\"ant-table-row-level-0\"] .ant-table-selection-column > span {\n  display: inline-block;\n}\ntr.ant-table-expanded-row,\ntr.ant-table-expanded-row:hover {\n  background: #fbfbfb;\n}\n.ant-table .ant-table-row-indent + .ant-table-row-expand-icon {\n  margin-right: 8px;\n}\n.ant-table-scroll {\n  overflow: auto;\n  overflow-x: hidden;\n}\n.ant-table-scroll table {\n  min-width: 100%;\n}\n.ant-table-body-inner {\n  height: 100%;\n}\n.ant-table-fixed-header > .ant-table-content > .ant-table-scroll > .ant-table-body {\n  position: relative;\n  background: #fff;\n}\n.ant-table-fixed-header .ant-table-body-inner {\n  overflow: scroll;\n}\n.ant-table-fixed-header .ant-table-scroll .ant-table-header {\n  overflow: scroll;\n  padding-bottom: 20px;\n  margin-bottom: -20px;\n}\n.ant-table-fixed-left,\n.ant-table-fixed-right {\n  position: absolute;\n  top: 0;\n  overflow: hidden;\n  -webkit-transition: -webkit-box-shadow 0.3s ease;\n  transition: -webkit-box-shadow 0.3s ease;\n  transition: box-shadow 0.3s ease;\n  transition: box-shadow 0.3s ease, -webkit-box-shadow 0.3s ease;\n  border-radius: 0;\n}\n.ant-table-fixed-left table,\n.ant-table-fixed-right table {\n  width: auto;\n  background: #fff;\n}\n.ant-table-fixed-header .ant-table-fixed-left .ant-table-body-outer .ant-table-fixed,\n.ant-table-fixed-header .ant-table-fixed-right .ant-table-body-outer .ant-table-fixed {\n  border-radius: 0;\n}\n.ant-table-fixed-left {\n  left: 0;\n  -webkit-box-shadow: 6px 0 6px -4px rgba(0, 0, 0, 0.15);\n          box-shadow: 6px 0 6px -4px rgba(0, 0, 0, 0.15);\n}\n.ant-table-fixed-left .ant-table-header {\n  overflow-y: hidden;\n}\n.ant-table-fixed-left .ant-table-body-inner {\n  margin-right: -20px;\n  padding-right: 20px;\n}\n.ant-table-fixed-header .ant-table-fixed-left .ant-table-body-inner {\n  padding-right: 0;\n}\n.ant-table-fixed-left,\n.ant-table-fixed-left table {\n  border-radius: 4px 0 0 0;\n}\n.ant-table-fixed-left .ant-table-thead > tr > th:last-child {\n  border-top-right-radius: 0;\n}\n.ant-table-fixed-right {\n  right: 0;\n  -webkit-box-shadow: -6px 0 6px -4px rgba(0, 0, 0, 0.15);\n          box-shadow: -6px 0 6px -4px rgba(0, 0, 0, 0.15);\n}\n.ant-table-fixed-right,\n.ant-table-fixed-right table {\n  border-radius: 0 4px 0 0;\n}\n.ant-table-fixed-right .ant-table-expanded-row {\n  color: transparent;\n  pointer-events: none;\n}\n.ant-table-fixed-right .ant-table-thead > tr > th:first-child {\n  border-top-left-radius: 0;\n}\n.ant-table.ant-table-scroll-position-left .ant-table-fixed-left {\n  -webkit-box-shadow: none;\n          box-shadow: none;\n}\n.ant-table.ant-table-scroll-position-right .ant-table-fixed-right {\n  -webkit-box-shadow: none;\n          box-shadow: none;\n}\n.ant-table-middle > .ant-table-title,\n.ant-table-middle > .ant-table-footer {\n  padding: 12px 8px;\n}\n.ant-table-middle > .ant-table-content > .ant-table-header > table > .ant-table-thead > tr > th,\n.ant-table-middle > .ant-table-content > .ant-table-body > table > .ant-table-thead > tr > th,\n.ant-table-middle > .ant-table-content > .ant-table-scroll > .ant-table-header > table > .ant-table-thead > tr > th,\n.ant-table-middle > .ant-table-content > .ant-table-scroll > .ant-table-body > table > .ant-table-thead > tr > th,\n.ant-table-middle > .ant-table-content > .ant-table-fixed-left > .ant-table-header > table > .ant-table-thead > tr > th,\n.ant-table-middle > .ant-table-content > .ant-table-fixed-right > .ant-table-header > table > .ant-table-thead > tr > th,\n.ant-table-middle > .ant-table-content > .ant-table-fixed-left > .ant-table-body-outer > .ant-table-body-inner > table > .ant-table-thead > tr > th,\n.ant-table-middle > .ant-table-content > .ant-table-fixed-right > .ant-table-body-outer > .ant-table-body-inner > table > .ant-table-thead > tr > th,\n.ant-table-middle > .ant-table-content > .ant-table-header > table > .ant-table-tbody > tr > td,\n.ant-table-middle > .ant-table-content > .ant-table-body > table > .ant-table-tbody > tr > td,\n.ant-table-middle > .ant-table-content > .ant-table-scroll > .ant-table-header > table > .ant-table-tbody > tr > td,\n.ant-table-middle > .ant-table-content > .ant-table-scroll > .ant-table-body > table > .ant-table-tbody > tr > td,\n.ant-table-middle > .ant-table-content > .ant-table-fixed-left > .ant-table-header > table > .ant-table-tbody > tr > td,\n.ant-table-middle > .ant-table-content > .ant-table-fixed-right > .ant-table-header > table > .ant-table-tbody > tr > td,\n.ant-table-middle > .ant-table-content > .ant-table-fixed-left > .ant-table-body-outer > .ant-table-body-inner > table > .ant-table-tbody > tr > td,\n.ant-table-middle > .ant-table-content > .ant-table-fixed-right > .ant-table-body-outer > .ant-table-body-inner > table > .ant-table-tbody > tr > td {\n  padding: 12px 8px;\n}\n.ant-table-small {\n  border: 1px solid #e8e8e8;\n  border-radius: 4px;\n}\n.ant-table-small > .ant-table-title,\n.ant-table-small > .ant-table-footer {\n  padding: 8px 8px;\n}\n.ant-table-small > .ant-table-title {\n  border-bottom: 1px solid #e8e8e8;\n  top: 0;\n}\n.ant-table-small > .ant-table-content > .ant-table-header > table,\n.ant-table-small > .ant-table-content > .ant-table-body > table,\n.ant-table-small > .ant-table-content > .ant-table-scroll > .ant-table-header > table,\n.ant-table-small > .ant-table-content > .ant-table-scroll > .ant-table-body > table,\n.ant-table-small > .ant-table-content > .ant-table-fixed-left > .ant-table-header > table,\n.ant-table-small > .ant-table-content > .ant-table-fixed-right > .ant-table-header > table,\n.ant-table-small > .ant-table-content > .ant-table-fixed-left > .ant-table-body-outer > .ant-table-body-inner > table,\n.ant-table-small > .ant-table-content > .ant-table-fixed-right > .ant-table-body-outer > .ant-table-body-inner > table {\n  border: 0;\n  padding: 0 8px;\n}\n.ant-table-small > .ant-table-content > .ant-table-header > table > .ant-table-thead > tr > th,\n.ant-table-small > .ant-table-content > .ant-table-body > table > .ant-table-thead > tr > th,\n.ant-table-small > .ant-table-content > .ant-table-scroll > .ant-table-header > table > .ant-table-thead > tr > th,\n.ant-table-small > .ant-table-content > .ant-table-scroll > .ant-table-body > table > .ant-table-thead > tr > th,\n.ant-table-small > .ant-table-content > .ant-table-fixed-left > .ant-table-header > table > .ant-table-thead > tr > th,\n.ant-table-small > .ant-table-content > .ant-table-fixed-right > .ant-table-header > table > .ant-table-thead > tr > th,\n.ant-table-small > .ant-table-content > .ant-table-fixed-left > .ant-table-body-outer > .ant-table-body-inner > table > .ant-table-thead > tr > th,\n.ant-table-small > .ant-table-content > .ant-table-fixed-right > .ant-table-body-outer > .ant-table-body-inner > table > .ant-table-thead > tr > th,\n.ant-table-small > .ant-table-content > .ant-table-header > table > .ant-table-tbody > tr > td,\n.ant-table-small > .ant-table-content > .ant-table-body > table > .ant-table-tbody > tr > td,\n.ant-table-small > .ant-table-content > .ant-table-scroll > .ant-table-header > table > .ant-table-tbody > tr > td,\n.ant-table-small > .ant-table-content > .ant-table-scroll > .ant-table-body > table > .ant-table-tbody > tr > td,\n.ant-table-small > .ant-table-content > .ant-table-fixed-left > .ant-table-header > table > .ant-table-tbody > tr > td,\n.ant-table-small > .ant-table-content > .ant-table-fixed-right > .ant-table-header > table > .ant-table-tbody > tr > td,\n.ant-table-small > .ant-table-content > .ant-table-fixed-left > .ant-table-body-outer > .ant-table-body-inner > table > .ant-table-tbody > tr > td,\n.ant-table-small > .ant-table-content > .ant-table-fixed-right > .ant-table-body-outer > .ant-table-body-inner > table > .ant-table-tbody > tr > td {\n  padding: 8px 8px;\n}\n.ant-table-small > .ant-table-content > .ant-table-header > table > .ant-table-thead > tr > th,\n.ant-table-small > .ant-table-content > .ant-table-body > table > .ant-table-thead > tr > th,\n.ant-table-small > .ant-table-content > .ant-table-scroll > .ant-table-header > table > .ant-table-thead > tr > th,\n.ant-table-small > .ant-table-content > .ant-table-scroll > .ant-table-body > table > .ant-table-thead > tr > th,\n.ant-table-small > .ant-table-content > .ant-table-fixed-left > .ant-table-header > table > .ant-table-thead > tr > th,\n.ant-table-small > .ant-table-content > .ant-table-fixed-right > .ant-table-header > table > .ant-table-thead > tr > th,\n.ant-table-small > .ant-table-content > .ant-table-fixed-left > .ant-table-body-outer > .ant-table-body-inner > table > .ant-table-thead > tr > th,\n.ant-table-small > .ant-table-content > .ant-table-fixed-right > .ant-table-body-outer > .ant-table-body-inner > table > .ant-table-thead > tr > th {\n  background: #fff;\n  border-bottom: 1px solid #e8e8e8;\n}\n.ant-table-small > .ant-table-content > .ant-table-scroll > .ant-table-header > table,\n.ant-table-small > .ant-table-content > .ant-table-scroll > .ant-table-body > table,\n.ant-table-small > .ant-table-content > .ant-table-fixed-left > .ant-table-header > table,\n.ant-table-small > .ant-table-content > .ant-table-fixed-right > .ant-table-header > table,\n.ant-table-small > .ant-table-content > .ant-table-fixed-left > .ant-table-body-outer > .ant-table-body-inner > table,\n.ant-table-small > .ant-table-content > .ant-table-fixed-right > .ant-table-body-outer > .ant-table-body-inner > table {\n  padding: 0;\n}\n.ant-table-small > .ant-table-content .ant-table-header {\n  background: #fff;\n}\n.ant-table-small > .ant-table-content .ant-table-placeholder,\n.ant-table-small > .ant-table-content .ant-table-row:last-child td {\n  border-bottom: 0;\n}\n.ant-table-small.ant-table-bordered {\n  border-right: 0;\n}\n.ant-table-small.ant-table-bordered .ant-table-title {\n  border: 0;\n  border-bottom: 1px solid #e8e8e8;\n  border-right: 1px solid #e8e8e8;\n}\n.ant-table-small.ant-table-bordered .ant-table-content {\n  border-right: 1px solid #e8e8e8;\n}\n.ant-table-small.ant-table-bordered .ant-table-footer {\n  border: 0;\n  border-top: 1px solid #e8e8e8;\n  border-right: 1px solid #e8e8e8;\n}\n.ant-table-small.ant-table-bordered .ant-table-footer:before {\n  display: none;\n}\n.ant-table-small.ant-table-bordered .ant-table-placeholder {\n  border-left: 0;\n  border-bottom: 0;\n}\n.ant-table-small.ant-table-bordered .ant-table-thead > tr > th:last-child,\n.ant-table-small.ant-table-bordered .ant-table-tbody > tr > td:last-child {\n  border-right: none;\n}\n", ""]);

// exports


/***/ }),

/***/ "../node_modules/css-loader/index.js??ref--5-1!./pages/setting/setting.css":
/*!************************************************************************!*\
  !*** ../node_modules/css-loader??ref--5-1!./pages/setting/setting.css ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../node_modules/css-loader/lib/css-base.js */ "../node_modules/css-loader/lib/css-base.js")(true);
// imports


// module
exports.push([module.i, ".setting_card-margin{\r\n    margin-bottom: 20px;\r\n}\r\n.setting_add-account{\r\n    margin-top: 20px;\r\n    width: 100%;\r\n}\r\n.setting_form{\r\n    width: 450px;\r\n    margin: 0 auto;\r\n}", "", {"version":3,"sources":["E:/frontend/jhgsj-report/pc/src/pages/setting/setting.css"],"names":[],"mappings":"AAAA;IACI,oBAAoB;CACvB;AACD;IACI,iBAAiB;IACjB,YAAY;CACf;AACD;IACI,aAAa;IACb,eAAe;CAClB","file":"setting.css","sourcesContent":[".card-margin{\r\n    margin-bottom: 20px;\r\n}\r\n.add-account{\r\n    margin-top: 20px;\r\n    width: 100%;\r\n}\r\n.form{\r\n    width: 450px;\r\n    margin: 0 auto;\r\n}"],"sourceRoot":""}]);

// exports
exports.locals = {
	"card-margin": "setting_card-margin",
	"add-account": "setting_add-account",
	"form": "setting_form"
};

/***/ }),

/***/ "../node_modules/dom-closest/index.js":
/*!********************************************!*\
  !*** ../node_modules/dom-closest/index.js ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/**
 * Module dependencies
 */

var matches = __webpack_require__(/*! dom-matches */ "../node_modules/dom-matches/index.js");

/**
 * @param element {Element}
 * @param selector {String}
 * @param context {Element}
 * @return {Element}
 */
module.exports = function (element, selector, context) {
  context = context || document;
  // guard against orphans
  element = { parentNode: element };

  while ((element = element.parentNode) && element !== context) {
    if (matches(element, selector)) {
      return element;
    }
  }
};


/***/ }),

/***/ "../node_modules/dom-matches/index.js":
/*!********************************************!*\
  !*** ../node_modules/dom-matches/index.js ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * Determine if a DOM element matches a CSS selector
 *
 * @param {Element} elem
 * @param {String} selector
 * @return {Boolean}
 * @api public
 */

function matches(elem, selector) {
  // Vendor-specific implementations of `Element.prototype.matches()`.
  var proto = window.Element.prototype;
  var nativeMatches = proto.matches ||
      proto.mozMatchesSelector ||
      proto.msMatchesSelector ||
      proto.oMatchesSelector ||
      proto.webkitMatchesSelector;

  if (!elem || elem.nodeType !== 1) {
    return false;
  }

  var parentElem = elem.parentNode;

  // use native 'matches'
  if (nativeMatches) {
    return nativeMatches.call(elem, selector);
  }

  // native support for `matches` is missing and a fallback is required
  var nodes = parentElem.querySelectorAll(selector);
  var len = nodes.length;

  for (var i = 0; i < len; i++) {
    if (nodes[i] === elem) {
      return true;
    }
  }

  return false;
}

/**
 * Expose `matches`
 */

module.exports = matches;


/***/ }),

/***/ "../node_modules/lodash/_Stack.js":
/*!****************************************!*\
  !*** ../node_modules/lodash/_Stack.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var ListCache = __webpack_require__(/*! ./_ListCache */ "../node_modules/lodash/_ListCache.js"),
    stackClear = __webpack_require__(/*! ./_stackClear */ "../node_modules/lodash/_stackClear.js"),
    stackDelete = __webpack_require__(/*! ./_stackDelete */ "../node_modules/lodash/_stackDelete.js"),
    stackGet = __webpack_require__(/*! ./_stackGet */ "../node_modules/lodash/_stackGet.js"),
    stackHas = __webpack_require__(/*! ./_stackHas */ "../node_modules/lodash/_stackHas.js"),
    stackSet = __webpack_require__(/*! ./_stackSet */ "../node_modules/lodash/_stackSet.js");

/**
 * Creates a stack cache object to store key-value pairs.
 *
 * @private
 * @constructor
 * @param {Array} [entries] The key-value pairs to cache.
 */
function Stack(entries) {
  var data = this.__data__ = new ListCache(entries);
  this.size = data.size;
}

// Add methods to `Stack`.
Stack.prototype.clear = stackClear;
Stack.prototype['delete'] = stackDelete;
Stack.prototype.get = stackGet;
Stack.prototype.has = stackHas;
Stack.prototype.set = stackSet;

module.exports = Stack;


/***/ }),

/***/ "../node_modules/lodash/_Uint8Array.js":
/*!*********************************************!*\
  !*** ../node_modules/lodash/_Uint8Array.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var root = __webpack_require__(/*! ./_root */ "../node_modules/lodash/_root.js");

/** Built-in value references. */
var Uint8Array = root.Uint8Array;

module.exports = Uint8Array;


/***/ }),

/***/ "../node_modules/lodash/_apply.js":
/*!****************************************!*\
  !*** ../node_modules/lodash/_apply.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * A faster alternative to `Function#apply`, this function invokes `func`
 * with the `this` binding of `thisArg` and the arguments of `args`.
 *
 * @private
 * @param {Function} func The function to invoke.
 * @param {*} thisArg The `this` binding of `func`.
 * @param {Array} args The arguments to invoke `func` with.
 * @returns {*} Returns the result of `func`.
 */
function apply(func, thisArg, args) {
  switch (args.length) {
    case 0: return func.call(thisArg);
    case 1: return func.call(thisArg, args[0]);
    case 2: return func.call(thisArg, args[0], args[1]);
    case 3: return func.call(thisArg, args[0], args[1], args[2]);
  }
  return func.apply(thisArg, args);
}

module.exports = apply;


/***/ }),

/***/ "../node_modules/lodash/_arrayLikeKeys.js":
/*!************************************************!*\
  !*** ../node_modules/lodash/_arrayLikeKeys.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseTimes = __webpack_require__(/*! ./_baseTimes */ "../node_modules/lodash/_baseTimes.js"),
    isArguments = __webpack_require__(/*! ./isArguments */ "../node_modules/lodash/isArguments.js"),
    isArray = __webpack_require__(/*! ./isArray */ "../node_modules/lodash/isArray.js"),
    isBuffer = __webpack_require__(/*! ./isBuffer */ "../node_modules/lodash/isBuffer.js"),
    isIndex = __webpack_require__(/*! ./_isIndex */ "../node_modules/lodash/_isIndex.js"),
    isTypedArray = __webpack_require__(/*! ./isTypedArray */ "../node_modules/lodash/isTypedArray.js");

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * Creates an array of the enumerable property names of the array-like `value`.
 *
 * @private
 * @param {*} value The value to query.
 * @param {boolean} inherited Specify returning inherited property names.
 * @returns {Array} Returns the array of property names.
 */
function arrayLikeKeys(value, inherited) {
  var isArr = isArray(value),
      isArg = !isArr && isArguments(value),
      isBuff = !isArr && !isArg && isBuffer(value),
      isType = !isArr && !isArg && !isBuff && isTypedArray(value),
      skipIndexes = isArr || isArg || isBuff || isType,
      result = skipIndexes ? baseTimes(value.length, String) : [],
      length = result.length;

  for (var key in value) {
    if ((inherited || hasOwnProperty.call(value, key)) &&
        !(skipIndexes && (
           // Safari 9 has enumerable `arguments.length` in strict mode.
           key == 'length' ||
           // Node.js 0.10 has enumerable non-index properties on buffers.
           (isBuff && (key == 'offset' || key == 'parent')) ||
           // PhantomJS 2 has enumerable non-index properties on typed arrays.
           (isType && (key == 'buffer' || key == 'byteLength' || key == 'byteOffset')) ||
           // Skip index properties.
           isIndex(key, length)
        ))) {
      result.push(key);
    }
  }
  return result;
}

module.exports = arrayLikeKeys;


/***/ }),

/***/ "../node_modules/lodash/_assignMergeValue.js":
/*!***************************************************!*\
  !*** ../node_modules/lodash/_assignMergeValue.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseAssignValue = __webpack_require__(/*! ./_baseAssignValue */ "../node_modules/lodash/_baseAssignValue.js"),
    eq = __webpack_require__(/*! ./eq */ "../node_modules/lodash/eq.js");

/**
 * This function is like `assignValue` except that it doesn't assign
 * `undefined` values.
 *
 * @private
 * @param {Object} object The object to modify.
 * @param {string} key The key of the property to assign.
 * @param {*} value The value to assign.
 */
function assignMergeValue(object, key, value) {
  if ((value !== undefined && !eq(object[key], value)) ||
      (value === undefined && !(key in object))) {
    baseAssignValue(object, key, value);
  }
}

module.exports = assignMergeValue;


/***/ }),

/***/ "../node_modules/lodash/_baseCreate.js":
/*!*********************************************!*\
  !*** ../node_modules/lodash/_baseCreate.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(/*! ./isObject */ "../node_modules/lodash/isObject.js");

/** Built-in value references. */
var objectCreate = Object.create;

/**
 * The base implementation of `_.create` without support for assigning
 * properties to the created object.
 *
 * @private
 * @param {Object} proto The object to inherit from.
 * @returns {Object} Returns the new object.
 */
var baseCreate = (function() {
  function object() {}
  return function(proto) {
    if (!isObject(proto)) {
      return {};
    }
    if (objectCreate) {
      return objectCreate(proto);
    }
    object.prototype = proto;
    var result = new object;
    object.prototype = undefined;
    return result;
  };
}());

module.exports = baseCreate;


/***/ }),

/***/ "../node_modules/lodash/_baseFor.js":
/*!******************************************!*\
  !*** ../node_modules/lodash/_baseFor.js ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var createBaseFor = __webpack_require__(/*! ./_createBaseFor */ "../node_modules/lodash/_createBaseFor.js");

/**
 * The base implementation of `baseForOwn` which iterates over `object`
 * properties returned by `keysFunc` and invokes `iteratee` for each property.
 * Iteratee functions may exit iteration early by explicitly returning `false`.
 *
 * @private
 * @param {Object} object The object to iterate over.
 * @param {Function} iteratee The function invoked per iteration.
 * @param {Function} keysFunc The function to get the keys of `object`.
 * @returns {Object} Returns `object`.
 */
var baseFor = createBaseFor();

module.exports = baseFor;


/***/ }),

/***/ "../node_modules/lodash/_baseIsTypedArray.js":
/*!***************************************************!*\
  !*** ../node_modules/lodash/_baseIsTypedArray.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseGetTag = __webpack_require__(/*! ./_baseGetTag */ "../node_modules/lodash/_baseGetTag.js"),
    isLength = __webpack_require__(/*! ./isLength */ "../node_modules/lodash/isLength.js"),
    isObjectLike = __webpack_require__(/*! ./isObjectLike */ "../node_modules/lodash/isObjectLike.js");

/** `Object#toString` result references. */
var argsTag = '[object Arguments]',
    arrayTag = '[object Array]',
    boolTag = '[object Boolean]',
    dateTag = '[object Date]',
    errorTag = '[object Error]',
    funcTag = '[object Function]',
    mapTag = '[object Map]',
    numberTag = '[object Number]',
    objectTag = '[object Object]',
    regexpTag = '[object RegExp]',
    setTag = '[object Set]',
    stringTag = '[object String]',
    weakMapTag = '[object WeakMap]';

var arrayBufferTag = '[object ArrayBuffer]',
    dataViewTag = '[object DataView]',
    float32Tag = '[object Float32Array]',
    float64Tag = '[object Float64Array]',
    int8Tag = '[object Int8Array]',
    int16Tag = '[object Int16Array]',
    int32Tag = '[object Int32Array]',
    uint8Tag = '[object Uint8Array]',
    uint8ClampedTag = '[object Uint8ClampedArray]',
    uint16Tag = '[object Uint16Array]',
    uint32Tag = '[object Uint32Array]';

/** Used to identify `toStringTag` values of typed arrays. */
var typedArrayTags = {};
typedArrayTags[float32Tag] = typedArrayTags[float64Tag] =
typedArrayTags[int8Tag] = typedArrayTags[int16Tag] =
typedArrayTags[int32Tag] = typedArrayTags[uint8Tag] =
typedArrayTags[uint8ClampedTag] = typedArrayTags[uint16Tag] =
typedArrayTags[uint32Tag] = true;
typedArrayTags[argsTag] = typedArrayTags[arrayTag] =
typedArrayTags[arrayBufferTag] = typedArrayTags[boolTag] =
typedArrayTags[dataViewTag] = typedArrayTags[dateTag] =
typedArrayTags[errorTag] = typedArrayTags[funcTag] =
typedArrayTags[mapTag] = typedArrayTags[numberTag] =
typedArrayTags[objectTag] = typedArrayTags[regexpTag] =
typedArrayTags[setTag] = typedArrayTags[stringTag] =
typedArrayTags[weakMapTag] = false;

/**
 * The base implementation of `_.isTypedArray` without Node.js optimizations.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a typed array, else `false`.
 */
function baseIsTypedArray(value) {
  return isObjectLike(value) &&
    isLength(value.length) && !!typedArrayTags[baseGetTag(value)];
}

module.exports = baseIsTypedArray;


/***/ }),

/***/ "../node_modules/lodash/_baseKeysIn.js":
/*!*********************************************!*\
  !*** ../node_modules/lodash/_baseKeysIn.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(/*! ./isObject */ "../node_modules/lodash/isObject.js"),
    isPrototype = __webpack_require__(/*! ./_isPrototype */ "../node_modules/lodash/_isPrototype.js"),
    nativeKeysIn = __webpack_require__(/*! ./_nativeKeysIn */ "../node_modules/lodash/_nativeKeysIn.js");

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * The base implementation of `_.keysIn` which doesn't treat sparse arrays as dense.
 *
 * @private
 * @param {Object} object The object to query.
 * @returns {Array} Returns the array of property names.
 */
function baseKeysIn(object) {
  if (!isObject(object)) {
    return nativeKeysIn(object);
  }
  var isProto = isPrototype(object),
      result = [];

  for (var key in object) {
    if (!(key == 'constructor' && (isProto || !hasOwnProperty.call(object, key)))) {
      result.push(key);
    }
  }
  return result;
}

module.exports = baseKeysIn;


/***/ }),

/***/ "../node_modules/lodash/_baseMerge.js":
/*!********************************************!*\
  !*** ../node_modules/lodash/_baseMerge.js ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var Stack = __webpack_require__(/*! ./_Stack */ "../node_modules/lodash/_Stack.js"),
    assignMergeValue = __webpack_require__(/*! ./_assignMergeValue */ "../node_modules/lodash/_assignMergeValue.js"),
    baseFor = __webpack_require__(/*! ./_baseFor */ "../node_modules/lodash/_baseFor.js"),
    baseMergeDeep = __webpack_require__(/*! ./_baseMergeDeep */ "../node_modules/lodash/_baseMergeDeep.js"),
    isObject = __webpack_require__(/*! ./isObject */ "../node_modules/lodash/isObject.js"),
    keysIn = __webpack_require__(/*! ./keysIn */ "../node_modules/lodash/keysIn.js"),
    safeGet = __webpack_require__(/*! ./_safeGet */ "../node_modules/lodash/_safeGet.js");

/**
 * The base implementation of `_.merge` without support for multiple sources.
 *
 * @private
 * @param {Object} object The destination object.
 * @param {Object} source The source object.
 * @param {number} srcIndex The index of `source`.
 * @param {Function} [customizer] The function to customize merged values.
 * @param {Object} [stack] Tracks traversed source values and their merged
 *  counterparts.
 */
function baseMerge(object, source, srcIndex, customizer, stack) {
  if (object === source) {
    return;
  }
  baseFor(source, function(srcValue, key) {
    if (isObject(srcValue)) {
      stack || (stack = new Stack);
      baseMergeDeep(object, source, key, srcIndex, baseMerge, customizer, stack);
    }
    else {
      var newValue = customizer
        ? customizer(safeGet(object, key), srcValue, (key + ''), object, source, stack)
        : undefined;

      if (newValue === undefined) {
        newValue = srcValue;
      }
      assignMergeValue(object, key, newValue);
    }
  }, keysIn);
}

module.exports = baseMerge;


/***/ }),

/***/ "../node_modules/lodash/_baseMergeDeep.js":
/*!************************************************!*\
  !*** ../node_modules/lodash/_baseMergeDeep.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var assignMergeValue = __webpack_require__(/*! ./_assignMergeValue */ "../node_modules/lodash/_assignMergeValue.js"),
    cloneBuffer = __webpack_require__(/*! ./_cloneBuffer */ "../node_modules/lodash/_cloneBuffer.js"),
    cloneTypedArray = __webpack_require__(/*! ./_cloneTypedArray */ "../node_modules/lodash/_cloneTypedArray.js"),
    copyArray = __webpack_require__(/*! ./_copyArray */ "../node_modules/lodash/_copyArray.js"),
    initCloneObject = __webpack_require__(/*! ./_initCloneObject */ "../node_modules/lodash/_initCloneObject.js"),
    isArguments = __webpack_require__(/*! ./isArguments */ "../node_modules/lodash/isArguments.js"),
    isArray = __webpack_require__(/*! ./isArray */ "../node_modules/lodash/isArray.js"),
    isArrayLikeObject = __webpack_require__(/*! ./isArrayLikeObject */ "../node_modules/lodash/isArrayLikeObject.js"),
    isBuffer = __webpack_require__(/*! ./isBuffer */ "../node_modules/lodash/isBuffer.js"),
    isFunction = __webpack_require__(/*! ./isFunction */ "../node_modules/lodash/isFunction.js"),
    isObject = __webpack_require__(/*! ./isObject */ "../node_modules/lodash/isObject.js"),
    isPlainObject = __webpack_require__(/*! ./isPlainObject */ "../node_modules/lodash/isPlainObject.js"),
    isTypedArray = __webpack_require__(/*! ./isTypedArray */ "../node_modules/lodash/isTypedArray.js"),
    safeGet = __webpack_require__(/*! ./_safeGet */ "../node_modules/lodash/_safeGet.js"),
    toPlainObject = __webpack_require__(/*! ./toPlainObject */ "../node_modules/lodash/toPlainObject.js");

/**
 * A specialized version of `baseMerge` for arrays and objects which performs
 * deep merges and tracks traversed objects enabling objects with circular
 * references to be merged.
 *
 * @private
 * @param {Object} object The destination object.
 * @param {Object} source The source object.
 * @param {string} key The key of the value to merge.
 * @param {number} srcIndex The index of `source`.
 * @param {Function} mergeFunc The function to merge values.
 * @param {Function} [customizer] The function to customize assigned values.
 * @param {Object} [stack] Tracks traversed source values and their merged
 *  counterparts.
 */
function baseMergeDeep(object, source, key, srcIndex, mergeFunc, customizer, stack) {
  var objValue = safeGet(object, key),
      srcValue = safeGet(source, key),
      stacked = stack.get(srcValue);

  if (stacked) {
    assignMergeValue(object, key, stacked);
    return;
  }
  var newValue = customizer
    ? customizer(objValue, srcValue, (key + ''), object, source, stack)
    : undefined;

  var isCommon = newValue === undefined;

  if (isCommon) {
    var isArr = isArray(srcValue),
        isBuff = !isArr && isBuffer(srcValue),
        isTyped = !isArr && !isBuff && isTypedArray(srcValue);

    newValue = srcValue;
    if (isArr || isBuff || isTyped) {
      if (isArray(objValue)) {
        newValue = objValue;
      }
      else if (isArrayLikeObject(objValue)) {
        newValue = copyArray(objValue);
      }
      else if (isBuff) {
        isCommon = false;
        newValue = cloneBuffer(srcValue, true);
      }
      else if (isTyped) {
        isCommon = false;
        newValue = cloneTypedArray(srcValue, true);
      }
      else {
        newValue = [];
      }
    }
    else if (isPlainObject(srcValue) || isArguments(srcValue)) {
      newValue = objValue;
      if (isArguments(objValue)) {
        newValue = toPlainObject(objValue);
      }
      else if (!isObject(objValue) || (srcIndex && isFunction(objValue))) {
        newValue = initCloneObject(srcValue);
      }
    }
    else {
      isCommon = false;
    }
  }
  if (isCommon) {
    // Recursively merge objects and arrays (susceptible to call stack limits).
    stack.set(srcValue, newValue);
    mergeFunc(newValue, srcValue, srcIndex, customizer, stack);
    stack['delete'](srcValue);
  }
  assignMergeValue(object, key, newValue);
}

module.exports = baseMergeDeep;


/***/ }),

/***/ "../node_modules/lodash/_baseRest.js":
/*!*******************************************!*\
  !*** ../node_modules/lodash/_baseRest.js ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var identity = __webpack_require__(/*! ./identity */ "../node_modules/lodash/identity.js"),
    overRest = __webpack_require__(/*! ./_overRest */ "../node_modules/lodash/_overRest.js"),
    setToString = __webpack_require__(/*! ./_setToString */ "../node_modules/lodash/_setToString.js");

/**
 * The base implementation of `_.rest` which doesn't validate or coerce arguments.
 *
 * @private
 * @param {Function} func The function to apply a rest parameter to.
 * @param {number} [start=func.length-1] The start position of the rest parameter.
 * @returns {Function} Returns the new function.
 */
function baseRest(func, start) {
  return setToString(overRest(func, start, identity), func + '');
}

module.exports = baseRest;


/***/ }),

/***/ "../node_modules/lodash/_baseSetToString.js":
/*!**************************************************!*\
  !*** ../node_modules/lodash/_baseSetToString.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var constant = __webpack_require__(/*! ./constant */ "../node_modules/lodash/constant.js"),
    defineProperty = __webpack_require__(/*! ./_defineProperty */ "../node_modules/lodash/_defineProperty.js"),
    identity = __webpack_require__(/*! ./identity */ "../node_modules/lodash/identity.js");

/**
 * The base implementation of `setToString` without support for hot loop shorting.
 *
 * @private
 * @param {Function} func The function to modify.
 * @param {Function} string The `toString` result.
 * @returns {Function} Returns `func`.
 */
var baseSetToString = !defineProperty ? identity : function(func, string) {
  return defineProperty(func, 'toString', {
    'configurable': true,
    'enumerable': false,
    'value': constant(string),
    'writable': true
  });
};

module.exports = baseSetToString;


/***/ }),

/***/ "../node_modules/lodash/_baseTimes.js":
/*!********************************************!*\
  !*** ../node_modules/lodash/_baseTimes.js ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * The base implementation of `_.times` without support for iteratee shorthands
 * or max array length checks.
 *
 * @private
 * @param {number} n The number of times to invoke `iteratee`.
 * @param {Function} iteratee The function invoked per iteration.
 * @returns {Array} Returns the array of results.
 */
function baseTimes(n, iteratee) {
  var index = -1,
      result = Array(n);

  while (++index < n) {
    result[index] = iteratee(index);
  }
  return result;
}

module.exports = baseTimes;


/***/ }),

/***/ "../node_modules/lodash/_baseUnary.js":
/*!********************************************!*\
  !*** ../node_modules/lodash/_baseUnary.js ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * The base implementation of `_.unary` without support for storing metadata.
 *
 * @private
 * @param {Function} func The function to cap arguments for.
 * @returns {Function} Returns the new capped function.
 */
function baseUnary(func) {
  return function(value) {
    return func(value);
  };
}

module.exports = baseUnary;


/***/ }),

/***/ "../node_modules/lodash/_cloneArrayBuffer.js":
/*!***************************************************!*\
  !*** ../node_modules/lodash/_cloneArrayBuffer.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var Uint8Array = __webpack_require__(/*! ./_Uint8Array */ "../node_modules/lodash/_Uint8Array.js");

/**
 * Creates a clone of `arrayBuffer`.
 *
 * @private
 * @param {ArrayBuffer} arrayBuffer The array buffer to clone.
 * @returns {ArrayBuffer} Returns the cloned array buffer.
 */
function cloneArrayBuffer(arrayBuffer) {
  var result = new arrayBuffer.constructor(arrayBuffer.byteLength);
  new Uint8Array(result).set(new Uint8Array(arrayBuffer));
  return result;
}

module.exports = cloneArrayBuffer;


/***/ }),

/***/ "../node_modules/lodash/_cloneBuffer.js":
/*!**********************************************!*\
  !*** ../node_modules/lodash/_cloneBuffer.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(module) {var root = __webpack_require__(/*! ./_root */ "../node_modules/lodash/_root.js");

/** Detect free variable `exports`. */
var freeExports = typeof exports == 'object' && exports && !exports.nodeType && exports;

/** Detect free variable `module`. */
var freeModule = freeExports && typeof module == 'object' && module && !module.nodeType && module;

/** Detect the popular CommonJS extension `module.exports`. */
var moduleExports = freeModule && freeModule.exports === freeExports;

/** Built-in value references. */
var Buffer = moduleExports ? root.Buffer : undefined,
    allocUnsafe = Buffer ? Buffer.allocUnsafe : undefined;

/**
 * Creates a clone of  `buffer`.
 *
 * @private
 * @param {Buffer} buffer The buffer to clone.
 * @param {boolean} [isDeep] Specify a deep clone.
 * @returns {Buffer} Returns the cloned buffer.
 */
function cloneBuffer(buffer, isDeep) {
  if (isDeep) {
    return buffer.slice();
  }
  var length = buffer.length,
      result = allocUnsafe ? allocUnsafe(length) : new buffer.constructor(length);

  buffer.copy(result);
  return result;
}

module.exports = cloneBuffer;

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../webpack/buildin/module.js */ "../node_modules/webpack/buildin/module.js")(module)))

/***/ }),

/***/ "../node_modules/lodash/_cloneTypedArray.js":
/*!**************************************************!*\
  !*** ../node_modules/lodash/_cloneTypedArray.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var cloneArrayBuffer = __webpack_require__(/*! ./_cloneArrayBuffer */ "../node_modules/lodash/_cloneArrayBuffer.js");

/**
 * Creates a clone of `typedArray`.
 *
 * @private
 * @param {Object} typedArray The typed array to clone.
 * @param {boolean} [isDeep] Specify a deep clone.
 * @returns {Object} Returns the cloned typed array.
 */
function cloneTypedArray(typedArray, isDeep) {
  var buffer = isDeep ? cloneArrayBuffer(typedArray.buffer) : typedArray.buffer;
  return new typedArray.constructor(buffer, typedArray.byteOffset, typedArray.length);
}

module.exports = cloneTypedArray;


/***/ }),

/***/ "../node_modules/lodash/_copyArray.js":
/*!********************************************!*\
  !*** ../node_modules/lodash/_copyArray.js ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * Copies the values of `source` to `array`.
 *
 * @private
 * @param {Array} source The array to copy values from.
 * @param {Array} [array=[]] The array to copy values to.
 * @returns {Array} Returns `array`.
 */
function copyArray(source, array) {
  var index = -1,
      length = source.length;

  array || (array = Array(length));
  while (++index < length) {
    array[index] = source[index];
  }
  return array;
}

module.exports = copyArray;


/***/ }),

/***/ "../node_modules/lodash/_copyObject.js":
/*!*********************************************!*\
  !*** ../node_modules/lodash/_copyObject.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var assignValue = __webpack_require__(/*! ./_assignValue */ "../node_modules/lodash/_assignValue.js"),
    baseAssignValue = __webpack_require__(/*! ./_baseAssignValue */ "../node_modules/lodash/_baseAssignValue.js");

/**
 * Copies properties of `source` to `object`.
 *
 * @private
 * @param {Object} source The object to copy properties from.
 * @param {Array} props The property identifiers to copy.
 * @param {Object} [object={}] The object to copy properties to.
 * @param {Function} [customizer] The function to customize copied values.
 * @returns {Object} Returns `object`.
 */
function copyObject(source, props, object, customizer) {
  var isNew = !object;
  object || (object = {});

  var index = -1,
      length = props.length;

  while (++index < length) {
    var key = props[index];

    var newValue = customizer
      ? customizer(object[key], source[key], key, object, source)
      : undefined;

    if (newValue === undefined) {
      newValue = source[key];
    }
    if (isNew) {
      baseAssignValue(object, key, newValue);
    } else {
      assignValue(object, key, newValue);
    }
  }
  return object;
}

module.exports = copyObject;


/***/ }),

/***/ "../node_modules/lodash/_createAssigner.js":
/*!*************************************************!*\
  !*** ../node_modules/lodash/_createAssigner.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseRest = __webpack_require__(/*! ./_baseRest */ "../node_modules/lodash/_baseRest.js"),
    isIterateeCall = __webpack_require__(/*! ./_isIterateeCall */ "../node_modules/lodash/_isIterateeCall.js");

/**
 * Creates a function like `_.assign`.
 *
 * @private
 * @param {Function} assigner The function to assign values.
 * @returns {Function} Returns the new assigner function.
 */
function createAssigner(assigner) {
  return baseRest(function(object, sources) {
    var index = -1,
        length = sources.length,
        customizer = length > 1 ? sources[length - 1] : undefined,
        guard = length > 2 ? sources[2] : undefined;

    customizer = (assigner.length > 3 && typeof customizer == 'function')
      ? (length--, customizer)
      : undefined;

    if (guard && isIterateeCall(sources[0], sources[1], guard)) {
      customizer = length < 3 ? undefined : customizer;
      length = 1;
    }
    object = Object(object);
    while (++index < length) {
      var source = sources[index];
      if (source) {
        assigner(object, source, index, customizer);
      }
    }
    return object;
  });
}

module.exports = createAssigner;


/***/ }),

/***/ "../node_modules/lodash/_createBaseFor.js":
/*!************************************************!*\
  !*** ../node_modules/lodash/_createBaseFor.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * Creates a base function for methods like `_.forIn` and `_.forOwn`.
 *
 * @private
 * @param {boolean} [fromRight] Specify iterating from right to left.
 * @returns {Function} Returns the new base function.
 */
function createBaseFor(fromRight) {
  return function(object, iteratee, keysFunc) {
    var index = -1,
        iterable = Object(object),
        props = keysFunc(object),
        length = props.length;

    while (length--) {
      var key = props[fromRight ? length : ++index];
      if (iteratee(iterable[key], key, iterable) === false) {
        break;
      }
    }
    return object;
  };
}

module.exports = createBaseFor;


/***/ }),

/***/ "../node_modules/lodash/_getPrototype.js":
/*!***********************************************!*\
  !*** ../node_modules/lodash/_getPrototype.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var overArg = __webpack_require__(/*! ./_overArg */ "../node_modules/lodash/_overArg.js");

/** Built-in value references. */
var getPrototype = overArg(Object.getPrototypeOf, Object);

module.exports = getPrototype;


/***/ }),

/***/ "../node_modules/lodash/_initCloneObject.js":
/*!**************************************************!*\
  !*** ../node_modules/lodash/_initCloneObject.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseCreate = __webpack_require__(/*! ./_baseCreate */ "../node_modules/lodash/_baseCreate.js"),
    getPrototype = __webpack_require__(/*! ./_getPrototype */ "../node_modules/lodash/_getPrototype.js"),
    isPrototype = __webpack_require__(/*! ./_isPrototype */ "../node_modules/lodash/_isPrototype.js");

/**
 * Initializes an object clone.
 *
 * @private
 * @param {Object} object The object to clone.
 * @returns {Object} Returns the initialized clone.
 */
function initCloneObject(object) {
  return (typeof object.constructor == 'function' && !isPrototype(object))
    ? baseCreate(getPrototype(object))
    : {};
}

module.exports = initCloneObject;


/***/ }),

/***/ "../node_modules/lodash/_isIterateeCall.js":
/*!*************************************************!*\
  !*** ../node_modules/lodash/_isIterateeCall.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var eq = __webpack_require__(/*! ./eq */ "../node_modules/lodash/eq.js"),
    isArrayLike = __webpack_require__(/*! ./isArrayLike */ "../node_modules/lodash/isArrayLike.js"),
    isIndex = __webpack_require__(/*! ./_isIndex */ "../node_modules/lodash/_isIndex.js"),
    isObject = __webpack_require__(/*! ./isObject */ "../node_modules/lodash/isObject.js");

/**
 * Checks if the given arguments are from an iteratee call.
 *
 * @private
 * @param {*} value The potential iteratee value argument.
 * @param {*} index The potential iteratee index or key argument.
 * @param {*} object The potential iteratee object argument.
 * @returns {boolean} Returns `true` if the arguments are from an iteratee call,
 *  else `false`.
 */
function isIterateeCall(value, index, object) {
  if (!isObject(object)) {
    return false;
  }
  var type = typeof index;
  if (type == 'number'
        ? (isArrayLike(object) && isIndex(index, object.length))
        : (type == 'string' && index in object)
      ) {
    return eq(object[index], value);
  }
  return false;
}

module.exports = isIterateeCall;


/***/ }),

/***/ "../node_modules/lodash/_isPrototype.js":
/*!**********************************************!*\
  !*** ../node_modules/lodash/_isPrototype.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/** Used for built-in method references. */
var objectProto = Object.prototype;

/**
 * Checks if `value` is likely a prototype object.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a prototype, else `false`.
 */
function isPrototype(value) {
  var Ctor = value && value.constructor,
      proto = (typeof Ctor == 'function' && Ctor.prototype) || objectProto;

  return value === proto;
}

module.exports = isPrototype;


/***/ }),

/***/ "../node_modules/lodash/_nativeKeysIn.js":
/*!***********************************************!*\
  !*** ../node_modules/lodash/_nativeKeysIn.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * This function is like
 * [`Object.keys`](http://ecma-international.org/ecma-262/7.0/#sec-object.keys)
 * except that it includes inherited enumerable properties.
 *
 * @private
 * @param {Object} object The object to query.
 * @returns {Array} Returns the array of property names.
 */
function nativeKeysIn(object) {
  var result = [];
  if (object != null) {
    for (var key in Object(object)) {
      result.push(key);
    }
  }
  return result;
}

module.exports = nativeKeysIn;


/***/ }),

/***/ "../node_modules/lodash/_nodeUtil.js":
/*!*******************************************!*\
  !*** ../node_modules/lodash/_nodeUtil.js ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(module) {var freeGlobal = __webpack_require__(/*! ./_freeGlobal */ "../node_modules/lodash/_freeGlobal.js");

/** Detect free variable `exports`. */
var freeExports = typeof exports == 'object' && exports && !exports.nodeType && exports;

/** Detect free variable `module`. */
var freeModule = freeExports && typeof module == 'object' && module && !module.nodeType && module;

/** Detect the popular CommonJS extension `module.exports`. */
var moduleExports = freeModule && freeModule.exports === freeExports;

/** Detect free variable `process` from Node.js. */
var freeProcess = moduleExports && freeGlobal.process;

/** Used to access faster Node.js helpers. */
var nodeUtil = (function() {
  try {
    return freeProcess && freeProcess.binding && freeProcess.binding('util');
  } catch (e) {}
}());

module.exports = nodeUtil;

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../webpack/buildin/module.js */ "../node_modules/webpack/buildin/module.js")(module)))

/***/ }),

/***/ "../node_modules/lodash/_overArg.js":
/*!******************************************!*\
  !*** ../node_modules/lodash/_overArg.js ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * Creates a unary function that invokes `func` with its argument transformed.
 *
 * @private
 * @param {Function} func The function to wrap.
 * @param {Function} transform The argument transform.
 * @returns {Function} Returns the new function.
 */
function overArg(func, transform) {
  return function(arg) {
    return func(transform(arg));
  };
}

module.exports = overArg;


/***/ }),

/***/ "../node_modules/lodash/_overRest.js":
/*!*******************************************!*\
  !*** ../node_modules/lodash/_overRest.js ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var apply = __webpack_require__(/*! ./_apply */ "../node_modules/lodash/_apply.js");

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeMax = Math.max;

/**
 * A specialized version of `baseRest` which transforms the rest array.
 *
 * @private
 * @param {Function} func The function to apply a rest parameter to.
 * @param {number} [start=func.length-1] The start position of the rest parameter.
 * @param {Function} transform The rest array transform.
 * @returns {Function} Returns the new function.
 */
function overRest(func, start, transform) {
  start = nativeMax(start === undefined ? (func.length - 1) : start, 0);
  return function() {
    var args = arguments,
        index = -1,
        length = nativeMax(args.length - start, 0),
        array = Array(length);

    while (++index < length) {
      array[index] = args[start + index];
    }
    index = -1;
    var otherArgs = Array(start + 1);
    while (++index < start) {
      otherArgs[index] = args[index];
    }
    otherArgs[start] = transform(array);
    return apply(func, this, otherArgs);
  };
}

module.exports = overRest;


/***/ }),

/***/ "../node_modules/lodash/_safeGet.js":
/*!******************************************!*\
  !*** ../node_modules/lodash/_safeGet.js ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * Gets the value at `key`, unless `key` is "__proto__".
 *
 * @private
 * @param {Object} object The object to query.
 * @param {string} key The key of the property to get.
 * @returns {*} Returns the property value.
 */
function safeGet(object, key) {
  return key == '__proto__'
    ? undefined
    : object[key];
}

module.exports = safeGet;


/***/ }),

/***/ "../node_modules/lodash/_setToString.js":
/*!**********************************************!*\
  !*** ../node_modules/lodash/_setToString.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseSetToString = __webpack_require__(/*! ./_baseSetToString */ "../node_modules/lodash/_baseSetToString.js"),
    shortOut = __webpack_require__(/*! ./_shortOut */ "../node_modules/lodash/_shortOut.js");

/**
 * Sets the `toString` method of `func` to return `string`.
 *
 * @private
 * @param {Function} func The function to modify.
 * @param {Function} string The `toString` result.
 * @returns {Function} Returns `func`.
 */
var setToString = shortOut(baseSetToString);

module.exports = setToString;


/***/ }),

/***/ "../node_modules/lodash/_shortOut.js":
/*!*******************************************!*\
  !*** ../node_modules/lodash/_shortOut.js ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/** Used to detect hot functions by number of calls within a span of milliseconds. */
var HOT_COUNT = 800,
    HOT_SPAN = 16;

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeNow = Date.now;

/**
 * Creates a function that'll short out and invoke `identity` instead
 * of `func` when it's called `HOT_COUNT` or more times in `HOT_SPAN`
 * milliseconds.
 *
 * @private
 * @param {Function} func The function to restrict.
 * @returns {Function} Returns the new shortable function.
 */
function shortOut(func) {
  var count = 0,
      lastCalled = 0;

  return function() {
    var stamp = nativeNow(),
        remaining = HOT_SPAN - (stamp - lastCalled);

    lastCalled = stamp;
    if (remaining > 0) {
      if (++count >= HOT_COUNT) {
        return arguments[0];
      }
    } else {
      count = 0;
    }
    return func.apply(undefined, arguments);
  };
}

module.exports = shortOut;


/***/ }),

/***/ "../node_modules/lodash/_stackClear.js":
/*!*********************************************!*\
  !*** ../node_modules/lodash/_stackClear.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var ListCache = __webpack_require__(/*! ./_ListCache */ "../node_modules/lodash/_ListCache.js");

/**
 * Removes all key-value entries from the stack.
 *
 * @private
 * @name clear
 * @memberOf Stack
 */
function stackClear() {
  this.__data__ = new ListCache;
  this.size = 0;
}

module.exports = stackClear;


/***/ }),

/***/ "../node_modules/lodash/_stackDelete.js":
/*!**********************************************!*\
  !*** ../node_modules/lodash/_stackDelete.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * Removes `key` and its value from the stack.
 *
 * @private
 * @name delete
 * @memberOf Stack
 * @param {string} key The key of the value to remove.
 * @returns {boolean} Returns `true` if the entry was removed, else `false`.
 */
function stackDelete(key) {
  var data = this.__data__,
      result = data['delete'](key);

  this.size = data.size;
  return result;
}

module.exports = stackDelete;


/***/ }),

/***/ "../node_modules/lodash/_stackGet.js":
/*!*******************************************!*\
  !*** ../node_modules/lodash/_stackGet.js ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * Gets the stack value for `key`.
 *
 * @private
 * @name get
 * @memberOf Stack
 * @param {string} key The key of the value to get.
 * @returns {*} Returns the entry value.
 */
function stackGet(key) {
  return this.__data__.get(key);
}

module.exports = stackGet;


/***/ }),

/***/ "../node_modules/lodash/_stackHas.js":
/*!*******************************************!*\
  !*** ../node_modules/lodash/_stackHas.js ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * Checks if a stack value for `key` exists.
 *
 * @private
 * @name has
 * @memberOf Stack
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */
function stackHas(key) {
  return this.__data__.has(key);
}

module.exports = stackHas;


/***/ }),

/***/ "../node_modules/lodash/_stackSet.js":
/*!*******************************************!*\
  !*** ../node_modules/lodash/_stackSet.js ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var ListCache = __webpack_require__(/*! ./_ListCache */ "../node_modules/lodash/_ListCache.js"),
    Map = __webpack_require__(/*! ./_Map */ "../node_modules/lodash/_Map.js"),
    MapCache = __webpack_require__(/*! ./_MapCache */ "../node_modules/lodash/_MapCache.js");

/** Used as the size to enable large array optimizations. */
var LARGE_ARRAY_SIZE = 200;

/**
 * Sets the stack `key` to `value`.
 *
 * @private
 * @name set
 * @memberOf Stack
 * @param {string} key The key of the value to set.
 * @param {*} value The value to set.
 * @returns {Object} Returns the stack cache instance.
 */
function stackSet(key, value) {
  var data = this.__data__;
  if (data instanceof ListCache) {
    var pairs = data.__data__;
    if (!Map || (pairs.length < LARGE_ARRAY_SIZE - 1)) {
      pairs.push([key, value]);
      this.size = ++data.size;
      return this;
    }
    data = this.__data__ = new MapCache(pairs);
  }
  data.set(key, value);
  this.size = data.size;
  return this;
}

module.exports = stackSet;


/***/ }),

/***/ "../node_modules/lodash/constant.js":
/*!******************************************!*\
  !*** ../node_modules/lodash/constant.js ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * Creates a function that returns `value`.
 *
 * @static
 * @memberOf _
 * @since 2.4.0
 * @category Util
 * @param {*} value The value to return from the new function.
 * @returns {Function} Returns the new constant function.
 * @example
 *
 * var objects = _.times(2, _.constant({ 'a': 1 }));
 *
 * console.log(objects);
 * // => [{ 'a': 1 }, { 'a': 1 }]
 *
 * console.log(objects[0] === objects[1]);
 * // => true
 */
function constant(value) {
  return function() {
    return value;
  };
}

module.exports = constant;


/***/ }),

/***/ "../node_modules/lodash/identity.js":
/*!******************************************!*\
  !*** ../node_modules/lodash/identity.js ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * This method returns the first argument it receives.
 *
 * @static
 * @since 0.1.0
 * @memberOf _
 * @category Util
 * @param {*} value Any value.
 * @returns {*} Returns `value`.
 * @example
 *
 * var object = { 'a': 1 };
 *
 * console.log(_.identity(object) === object);
 * // => true
 */
function identity(value) {
  return value;
}

module.exports = identity;


/***/ }),

/***/ "../node_modules/lodash/isArrayLike.js":
/*!*********************************************!*\
  !*** ../node_modules/lodash/isArrayLike.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var isFunction = __webpack_require__(/*! ./isFunction */ "../node_modules/lodash/isFunction.js"),
    isLength = __webpack_require__(/*! ./isLength */ "../node_modules/lodash/isLength.js");

/**
 * Checks if `value` is array-like. A value is considered array-like if it's
 * not a function and has a `value.length` that's an integer greater than or
 * equal to `0` and less than or equal to `Number.MAX_SAFE_INTEGER`.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is array-like, else `false`.
 * @example
 *
 * _.isArrayLike([1, 2, 3]);
 * // => true
 *
 * _.isArrayLike(document.body.children);
 * // => true
 *
 * _.isArrayLike('abc');
 * // => true
 *
 * _.isArrayLike(_.noop);
 * // => false
 */
function isArrayLike(value) {
  return value != null && isLength(value.length) && !isFunction(value);
}

module.exports = isArrayLike;


/***/ }),

/***/ "../node_modules/lodash/isArrayLikeObject.js":
/*!***************************************************!*\
  !*** ../node_modules/lodash/isArrayLikeObject.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var isArrayLike = __webpack_require__(/*! ./isArrayLike */ "../node_modules/lodash/isArrayLike.js"),
    isObjectLike = __webpack_require__(/*! ./isObjectLike */ "../node_modules/lodash/isObjectLike.js");

/**
 * This method is like `_.isArrayLike` except that it also checks if `value`
 * is an object.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an array-like object,
 *  else `false`.
 * @example
 *
 * _.isArrayLikeObject([1, 2, 3]);
 * // => true
 *
 * _.isArrayLikeObject(document.body.children);
 * // => true
 *
 * _.isArrayLikeObject('abc');
 * // => false
 *
 * _.isArrayLikeObject(_.noop);
 * // => false
 */
function isArrayLikeObject(value) {
  return isObjectLike(value) && isArrayLike(value);
}

module.exports = isArrayLikeObject;


/***/ }),

/***/ "../node_modules/lodash/isBuffer.js":
/*!******************************************!*\
  !*** ../node_modules/lodash/isBuffer.js ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(module) {var root = __webpack_require__(/*! ./_root */ "../node_modules/lodash/_root.js"),
    stubFalse = __webpack_require__(/*! ./stubFalse */ "../node_modules/lodash/stubFalse.js");

/** Detect free variable `exports`. */
var freeExports = typeof exports == 'object' && exports && !exports.nodeType && exports;

/** Detect free variable `module`. */
var freeModule = freeExports && typeof module == 'object' && module && !module.nodeType && module;

/** Detect the popular CommonJS extension `module.exports`. */
var moduleExports = freeModule && freeModule.exports === freeExports;

/** Built-in value references. */
var Buffer = moduleExports ? root.Buffer : undefined;

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeIsBuffer = Buffer ? Buffer.isBuffer : undefined;

/**
 * Checks if `value` is a buffer.
 *
 * @static
 * @memberOf _
 * @since 4.3.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a buffer, else `false`.
 * @example
 *
 * _.isBuffer(new Buffer(2));
 * // => true
 *
 * _.isBuffer(new Uint8Array(2));
 * // => false
 */
var isBuffer = nativeIsBuffer || stubFalse;

module.exports = isBuffer;

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../webpack/buildin/module.js */ "../node_modules/webpack/buildin/module.js")(module)))

/***/ }),

/***/ "../node_modules/lodash/isPlainObject.js":
/*!***********************************************!*\
  !*** ../node_modules/lodash/isPlainObject.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseGetTag = __webpack_require__(/*! ./_baseGetTag */ "../node_modules/lodash/_baseGetTag.js"),
    getPrototype = __webpack_require__(/*! ./_getPrototype */ "../node_modules/lodash/_getPrototype.js"),
    isObjectLike = __webpack_require__(/*! ./isObjectLike */ "../node_modules/lodash/isObjectLike.js");

/** `Object#toString` result references. */
var objectTag = '[object Object]';

/** Used for built-in method references. */
var funcProto = Function.prototype,
    objectProto = Object.prototype;

/** Used to resolve the decompiled source of functions. */
var funcToString = funcProto.toString;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/** Used to infer the `Object` constructor. */
var objectCtorString = funcToString.call(Object);

/**
 * Checks if `value` is a plain object, that is, an object created by the
 * `Object` constructor or one with a `[[Prototype]]` of `null`.
 *
 * @static
 * @memberOf _
 * @since 0.8.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a plain object, else `false`.
 * @example
 *
 * function Foo() {
 *   this.a = 1;
 * }
 *
 * _.isPlainObject(new Foo);
 * // => false
 *
 * _.isPlainObject([1, 2, 3]);
 * // => false
 *
 * _.isPlainObject({ 'x': 0, 'y': 0 });
 * // => true
 *
 * _.isPlainObject(Object.create(null));
 * // => true
 */
function isPlainObject(value) {
  if (!isObjectLike(value) || baseGetTag(value) != objectTag) {
    return false;
  }
  var proto = getPrototype(value);
  if (proto === null) {
    return true;
  }
  var Ctor = hasOwnProperty.call(proto, 'constructor') && proto.constructor;
  return typeof Ctor == 'function' && Ctor instanceof Ctor &&
    funcToString.call(Ctor) == objectCtorString;
}

module.exports = isPlainObject;


/***/ }),

/***/ "../node_modules/lodash/isTypedArray.js":
/*!**********************************************!*\
  !*** ../node_modules/lodash/isTypedArray.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseIsTypedArray = __webpack_require__(/*! ./_baseIsTypedArray */ "../node_modules/lodash/_baseIsTypedArray.js"),
    baseUnary = __webpack_require__(/*! ./_baseUnary */ "../node_modules/lodash/_baseUnary.js"),
    nodeUtil = __webpack_require__(/*! ./_nodeUtil */ "../node_modules/lodash/_nodeUtil.js");

/* Node.js helper references. */
var nodeIsTypedArray = nodeUtil && nodeUtil.isTypedArray;

/**
 * Checks if `value` is classified as a typed array.
 *
 * @static
 * @memberOf _
 * @since 3.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a typed array, else `false`.
 * @example
 *
 * _.isTypedArray(new Uint8Array);
 * // => true
 *
 * _.isTypedArray([]);
 * // => false
 */
var isTypedArray = nodeIsTypedArray ? baseUnary(nodeIsTypedArray) : baseIsTypedArray;

module.exports = isTypedArray;


/***/ }),

/***/ "../node_modules/lodash/keysIn.js":
/*!****************************************!*\
  !*** ../node_modules/lodash/keysIn.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayLikeKeys = __webpack_require__(/*! ./_arrayLikeKeys */ "../node_modules/lodash/_arrayLikeKeys.js"),
    baseKeysIn = __webpack_require__(/*! ./_baseKeysIn */ "../node_modules/lodash/_baseKeysIn.js"),
    isArrayLike = __webpack_require__(/*! ./isArrayLike */ "../node_modules/lodash/isArrayLike.js");

/**
 * Creates an array of the own and inherited enumerable property names of `object`.
 *
 * **Note:** Non-object values are coerced to objects.
 *
 * @static
 * @memberOf _
 * @since 3.0.0
 * @category Object
 * @param {Object} object The object to query.
 * @returns {Array} Returns the array of property names.
 * @example
 *
 * function Foo() {
 *   this.a = 1;
 *   this.b = 2;
 * }
 *
 * Foo.prototype.c = 3;
 *
 * _.keysIn(new Foo);
 * // => ['a', 'b', 'c'] (iteration order is not guaranteed)
 */
function keysIn(object) {
  return isArrayLike(object) ? arrayLikeKeys(object, true) : baseKeysIn(object);
}

module.exports = keysIn;


/***/ }),

/***/ "../node_modules/lodash/merge.js":
/*!***************************************!*\
  !*** ../node_modules/lodash/merge.js ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseMerge = __webpack_require__(/*! ./_baseMerge */ "../node_modules/lodash/_baseMerge.js"),
    createAssigner = __webpack_require__(/*! ./_createAssigner */ "../node_modules/lodash/_createAssigner.js");

/**
 * This method is like `_.assign` except that it recursively merges own and
 * inherited enumerable string keyed properties of source objects into the
 * destination object. Source properties that resolve to `undefined` are
 * skipped if a destination value exists. Array and plain object properties
 * are merged recursively. Other objects and value types are overridden by
 * assignment. Source objects are applied from left to right. Subsequent
 * sources overwrite property assignments of previous sources.
 *
 * **Note:** This method mutates `object`.
 *
 * @static
 * @memberOf _
 * @since 0.5.0
 * @category Object
 * @param {Object} object The destination object.
 * @param {...Object} [sources] The source objects.
 * @returns {Object} Returns `object`.
 * @example
 *
 * var object = {
 *   'a': [{ 'b': 2 }, { 'd': 4 }]
 * };
 *
 * var other = {
 *   'a': [{ 'c': 3 }, { 'e': 5 }]
 * };
 *
 * _.merge(object, other);
 * // => { 'a': [{ 'b': 2, 'c': 3 }, { 'd': 4, 'e': 5 }] }
 */
var merge = createAssigner(function(object, source, srcIndex) {
  baseMerge(object, source, srcIndex);
});

module.exports = merge;


/***/ }),

/***/ "../node_modules/lodash/stubFalse.js":
/*!*******************************************!*\
  !*** ../node_modules/lodash/stubFalse.js ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * This method returns `false`.
 *
 * @static
 * @memberOf _
 * @since 4.13.0
 * @category Util
 * @returns {boolean} Returns `false`.
 * @example
 *
 * _.times(2, _.stubFalse);
 * // => [false, false]
 */
function stubFalse() {
  return false;
}

module.exports = stubFalse;


/***/ }),

/***/ "../node_modules/lodash/toPlainObject.js":
/*!***********************************************!*\
  !*** ../node_modules/lodash/toPlainObject.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var copyObject = __webpack_require__(/*! ./_copyObject */ "../node_modules/lodash/_copyObject.js"),
    keysIn = __webpack_require__(/*! ./keysIn */ "../node_modules/lodash/keysIn.js");

/**
 * Converts `value` to a plain object flattening inherited enumerable string
 * keyed properties of `value` to own properties of the plain object.
 *
 * @static
 * @memberOf _
 * @since 3.0.0
 * @category Lang
 * @param {*} value The value to convert.
 * @returns {Object} Returns the converted plain object.
 * @example
 *
 * function Foo() {
 *   this.b = 2;
 * }
 *
 * Foo.prototype.c = 3;
 *
 * _.assign({ 'a': 1 }, new Foo);
 * // => { 'a': 1, 'b': 2 }
 *
 * _.assign({ 'a': 1 }, _.toPlainObject(new Foo));
 * // => { 'a': 1, 'b': 2, 'c': 3 }
 */
function toPlainObject(value) {
  return copyObject(value, keysIn(value));
}

module.exports = toPlainObject;


/***/ }),

/***/ "../node_modules/rc-dialog/es/Dialog.js":
/*!**********************************************!*\
  !*** ../node_modules/rc-dialog/es/Dialog.js ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! babel-runtime/helpers/extends */ "../node_modules/babel-runtime/helpers/extends.js");
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! babel-runtime/helpers/classCallCheck */ "../node_modules/babel-runtime/helpers/classCallCheck.js");
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! babel-runtime/helpers/possibleConstructorReturn */ "../node_modules/babel-runtime/helpers/possibleConstructorReturn.js");
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! babel-runtime/helpers/inherits */ "../node_modules/babel-runtime/helpers/inherits.js");
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-dom */ "../node_modules/react-dom/index.js");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var rc_util_es_KeyCode__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rc-util/es/KeyCode */ "../node_modules/rc-util/es/KeyCode.js");
/* harmony import */ var rc_animate__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rc-animate */ "../node_modules/rc-animate/es/Animate.js");
/* harmony import */ var _LazyRenderBox__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./LazyRenderBox */ "../node_modules/rc-dialog/es/LazyRenderBox.js");
/* harmony import */ var rc_util_es_getScrollBarSize__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rc-util/es/getScrollBarSize */ "../node_modules/rc-util/es/getScrollBarSize.js");










var uuid = 0;
var openCount = 0;
/* eslint react/no-is-mounted:0 */
function getScroll(w, top) {
    var ret = w['page' + (top ? 'Y' : 'X') + 'Offset'];
    var method = 'scroll' + (top ? 'Top' : 'Left');
    if (typeof ret !== 'number') {
        var d = w.document;
        ret = d.documentElement[method];
        if (typeof ret !== 'number') {
            ret = d.body[method];
        }
    }
    return ret;
}
function setTransformOrigin(node, value) {
    var style = node.style;
    ['Webkit', 'Moz', 'Ms', 'ms'].forEach(function (prefix) {
        style[prefix + 'TransformOrigin'] = value;
    });
    style['transformOrigin'] = value;
}
function offset(el) {
    var rect = el.getBoundingClientRect();
    var pos = {
        left: rect.left,
        top: rect.top
    };
    var doc = el.ownerDocument;
    var w = doc.defaultView || doc.parentWindow;
    pos.left += getScroll(w);
    pos.top += getScroll(w, true);
    return pos;
}

var Dialog = function (_React$Component) {
    babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3___default()(Dialog, _React$Component);

    function Dialog() {
        babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1___default()(this, Dialog);

        var _this = babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2___default()(this, _React$Component.apply(this, arguments));

        _this.onAnimateLeave = function () {
            var afterClose = _this.props.afterClose;
            // need demo?
            // https://github.com/react-component/dialog/pull/28

            if (_this.wrap) {
                _this.wrap.style.display = 'none';
            }
            _this.inTransition = false;
            _this.removeScrollingEffect();
            if (afterClose) {
                afterClose();
            }
        };
        _this.onMaskClick = function (e) {
            // android trigger click on open (fastclick??)
            if (Date.now() - _this.openTime < 300) {
                return;
            }
            if (e.target === e.currentTarget) {
                _this.close(e);
            }
        };
        _this.onKeyDown = function (e) {
            var props = _this.props;
            if (props.keyboard && e.keyCode === rc_util_es_KeyCode__WEBPACK_IMPORTED_MODULE_6__["default"].ESC) {
                _this.close(e);
            }
            // keep focus inside dialog
            if (props.visible) {
                if (e.keyCode === rc_util_es_KeyCode__WEBPACK_IMPORTED_MODULE_6__["default"].TAB) {
                    var activeElement = document.activeElement;
                    var dialogRoot = _this.wrap;
                    if (e.shiftKey) {
                        if (activeElement === dialogRoot) {
                            _this.sentinel.focus();
                        }
                    } else if (activeElement === _this.sentinel) {
                        dialogRoot.focus();
                    }
                }
            }
        };
        _this.getDialogElement = function () {
            var props = _this.props;
            var closable = props.closable;
            var prefixCls = props.prefixCls;
            var dest = {};
            if (props.width !== undefined) {
                dest.width = props.width;
            }
            if (props.height !== undefined) {
                dest.height = props.height;
            }
            var footer = void 0;
            if (props.footer) {
                footer = react__WEBPACK_IMPORTED_MODULE_4__["createElement"]("div", { className: prefixCls + '-footer', ref: _this.saveRef('footer') }, props.footer);
            }
            var header = void 0;
            if (props.title) {
                header = react__WEBPACK_IMPORTED_MODULE_4__["createElement"]("div", { className: prefixCls + '-header', ref: _this.saveRef('header') }, react__WEBPACK_IMPORTED_MODULE_4__["createElement"]("div", { className: prefixCls + '-title', id: _this.titleId }, props.title));
            }
            var closer = void 0;
            if (closable) {
                closer = react__WEBPACK_IMPORTED_MODULE_4__["createElement"]("button", { onClick: _this.close, "aria-label": "Close", className: prefixCls + '-close' }, react__WEBPACK_IMPORTED_MODULE_4__["createElement"]("span", { className: prefixCls + '-close-x' }));
            }
            var style = babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({}, props.style, dest);
            var transitionName = _this.getTransitionName();
            var dialogElement = react__WEBPACK_IMPORTED_MODULE_4__["createElement"](_LazyRenderBox__WEBPACK_IMPORTED_MODULE_8__["default"], { key: "dialog-element", role: "document", ref: _this.saveRef('dialog'), style: style, className: prefixCls + ' ' + (props.className || ''), visible: props.visible }, react__WEBPACK_IMPORTED_MODULE_4__["createElement"]("div", { className: prefixCls + '-content' }, closer, header, react__WEBPACK_IMPORTED_MODULE_4__["createElement"]("div", babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({ className: prefixCls + '-body', style: props.bodyStyle, ref: _this.saveRef('body') }, props.bodyProps), props.children), footer), react__WEBPACK_IMPORTED_MODULE_4__["createElement"]("div", { tabIndex: 0, ref: _this.saveRef('sentinel'), style: { width: 0, height: 0, overflow: 'hidden' } }, "sentinel"));
            return react__WEBPACK_IMPORTED_MODULE_4__["createElement"](rc_animate__WEBPACK_IMPORTED_MODULE_7__["default"], { key: "dialog", showProp: "visible", onLeave: _this.onAnimateLeave, transitionName: transitionName, component: "", transitionAppear: true }, props.visible || !props.destroyOnClose ? dialogElement : null);
        };
        _this.getZIndexStyle = function () {
            var style = {};
            var props = _this.props;
            if (props.zIndex !== undefined) {
                style.zIndex = props.zIndex;
            }
            return style;
        };
        _this.getWrapStyle = function () {
            return babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({}, _this.getZIndexStyle(), _this.props.wrapStyle);
        };
        _this.getMaskStyle = function () {
            return babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({}, _this.getZIndexStyle(), _this.props.maskStyle);
        };
        _this.getMaskElement = function () {
            var props = _this.props;
            var maskElement = void 0;
            if (props.mask) {
                var maskTransition = _this.getMaskTransitionName();
                maskElement = react__WEBPACK_IMPORTED_MODULE_4__["createElement"](_LazyRenderBox__WEBPACK_IMPORTED_MODULE_8__["default"], babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({ style: _this.getMaskStyle(), key: "mask", className: props.prefixCls + '-mask', hiddenClassName: props.prefixCls + '-mask-hidden', visible: props.visible }, props.maskProps));
                if (maskTransition) {
                    maskElement = react__WEBPACK_IMPORTED_MODULE_4__["createElement"](rc_animate__WEBPACK_IMPORTED_MODULE_7__["default"], { key: "mask", showProp: "visible", transitionAppear: true, component: "", transitionName: maskTransition }, maskElement);
                }
            }
            return maskElement;
        };
        _this.getMaskTransitionName = function () {
            var props = _this.props;
            var transitionName = props.maskTransitionName;
            var animation = props.maskAnimation;
            if (!transitionName && animation) {
                transitionName = props.prefixCls + '-' + animation;
            }
            return transitionName;
        };
        _this.getTransitionName = function () {
            var props = _this.props;
            var transitionName = props.transitionName;
            var animation = props.animation;
            if (!transitionName && animation) {
                transitionName = props.prefixCls + '-' + animation;
            }
            return transitionName;
        };
        _this.setScrollbar = function () {
            if (_this.bodyIsOverflowing && _this.scrollbarWidth !== undefined) {
                document.body.style.paddingRight = _this.scrollbarWidth + 'px';
            }
        };
        _this.addScrollingEffect = function () {
            openCount++;
            if (openCount !== 1) {
                return;
            }
            _this.checkScrollbar();
            _this.setScrollbar();
            document.body.style.overflow = 'hidden';
            // this.adjustDialog();
        };
        _this.removeScrollingEffect = function () {
            openCount--;
            if (openCount !== 0) {
                return;
            }
            document.body.style.overflow = '';
            _this.resetScrollbar();
            // this.resetAdjustments();
        };
        _this.close = function (e) {
            var onClose = _this.props.onClose;

            if (onClose) {
                onClose(e);
            }
        };
        _this.checkScrollbar = function () {
            var fullWindowWidth = window.innerWidth;
            if (!fullWindowWidth) {
                // workaround for missing window.innerWidth in IE8
                var documentElementRect = document.documentElement.getBoundingClientRect();
                fullWindowWidth = documentElementRect.right - Math.abs(documentElementRect.left);
            }
            _this.bodyIsOverflowing = document.body.clientWidth < fullWindowWidth;
            if (_this.bodyIsOverflowing) {
                _this.scrollbarWidth = Object(rc_util_es_getScrollBarSize__WEBPACK_IMPORTED_MODULE_9__["default"])();
            }
        };
        _this.resetScrollbar = function () {
            document.body.style.paddingRight = '';
        };
        _this.adjustDialog = function () {
            if (_this.wrap && _this.scrollbarWidth !== undefined) {
                var modalIsOverflowing = _this.wrap.scrollHeight > document.documentElement.clientHeight;
                _this.wrap.style.paddingLeft = (!_this.bodyIsOverflowing && modalIsOverflowing ? _this.scrollbarWidth : '') + 'px';
                _this.wrap.style.paddingRight = (_this.bodyIsOverflowing && !modalIsOverflowing ? _this.scrollbarWidth : '') + 'px';
            }
        };
        _this.resetAdjustments = function () {
            if (_this.wrap) {
                _this.wrap.style.paddingLeft = _this.wrap.style.paddingLeft = '';
            }
        };
        _this.saveRef = function (name) {
            return function (node) {
                _this[name] = node;
            };
        };
        return _this;
    }

    Dialog.prototype.componentWillMount = function componentWillMount() {
        this.inTransition = false;
        this.titleId = 'rcDialogTitle' + uuid++;
    };

    Dialog.prototype.componentDidMount = function componentDidMount() {
        this.componentDidUpdate({});
    };

    Dialog.prototype.componentDidUpdate = function componentDidUpdate(prevProps) {
        var props = this.props;
        var mousePosition = this.props.mousePosition;
        if (props.visible) {
            // first show
            if (!prevProps.visible) {
                this.openTime = Date.now();
                this.lastOutSideFocusNode = document.activeElement;
                this.addScrollingEffect();
                this.wrap.focus();
                var dialogNode = react_dom__WEBPACK_IMPORTED_MODULE_5__["findDOMNode"](this.dialog);
                if (mousePosition) {
                    var elOffset = offset(dialogNode);
                    setTransformOrigin(dialogNode, mousePosition.x - elOffset.left + 'px ' + (mousePosition.y - elOffset.top) + 'px');
                } else {
                    setTransformOrigin(dialogNode, '');
                }
            }
        } else if (prevProps.visible) {
            this.inTransition = true;
            if (props.mask && this.lastOutSideFocusNode) {
                try {
                    this.lastOutSideFocusNode.focus();
                } catch (e) {
                    this.lastOutSideFocusNode = null;
                }
                this.lastOutSideFocusNode = null;
            }
        }
    };

    Dialog.prototype.componentWillUnmount = function componentWillUnmount() {
        if (this.props.visible || this.inTransition) {
            this.removeScrollingEffect();
        }
    };

    Dialog.prototype.render = function render() {
        var props = this.props;
        var prefixCls = props.prefixCls,
            maskClosable = props.maskClosable;

        var style = this.getWrapStyle();
        // clear hide display
        // and only set display after async anim, not here for hide
        if (props.visible) {
            style.display = null;
        }
        return react__WEBPACK_IMPORTED_MODULE_4__["createElement"]("div", null, this.getMaskElement(), react__WEBPACK_IMPORTED_MODULE_4__["createElement"]("div", babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({ tabIndex: -1, onKeyDown: this.onKeyDown, className: prefixCls + '-wrap ' + (props.wrapClassName || ''), ref: this.saveRef('wrap'), onClick: maskClosable ? this.onMaskClick : undefined, role: "dialog", "aria-labelledby": props.title ? this.titleId : null, style: style }, props.wrapProps), this.getDialogElement()));
    };

    return Dialog;
}(react__WEBPACK_IMPORTED_MODULE_4__["Component"]);

/* harmony default export */ __webpack_exports__["default"] = (Dialog);

Dialog.defaultProps = {
    className: '',
    mask: true,
    visible: false,
    keyboard: true,
    closable: true,
    maskClosable: true,
    destroyOnClose: false,
    prefixCls: 'rc-dialog'
};

/***/ }),

/***/ "../node_modules/rc-dialog/es/DialogWrap.js":
/*!**************************************************!*\
  !*** ../node_modules/rc-dialog/es/DialogWrap.js ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! babel-runtime/helpers/extends */ "../node_modules/babel-runtime/helpers/extends.js");
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! babel-runtime/helpers/classCallCheck */ "../node_modules/babel-runtime/helpers/classCallCheck.js");
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! babel-runtime/helpers/possibleConstructorReturn */ "../node_modules/babel-runtime/helpers/possibleConstructorReturn.js");
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! babel-runtime/helpers/inherits */ "../node_modules/babel-runtime/helpers/inherits.js");
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-dom */ "../node_modules/react-dom/index.js");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _Dialog__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./Dialog */ "../node_modules/rc-dialog/es/Dialog.js");
/* harmony import */ var rc_util_es_ContainerRender__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rc-util/es/ContainerRender */ "../node_modules/rc-util/es/ContainerRender.js");
/* harmony import */ var rc_util_es_Portal__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rc-util/es/Portal */ "../node_modules/rc-util/es/Portal.js");









var IS_REACT_16 = 'createPortal' in react_dom__WEBPACK_IMPORTED_MODULE_5__;

var DialogWrap = function (_React$Component) {
    babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3___default()(DialogWrap, _React$Component);

    function DialogWrap() {
        babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1___default()(this, DialogWrap);

        var _this = babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2___default()(this, _React$Component.apply(this, arguments));

        _this.saveDialog = function (node) {
            _this._component = node;
        };
        _this.getComponent = function () {
            var extra = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

            return react__WEBPACK_IMPORTED_MODULE_4__["createElement"](_Dialog__WEBPACK_IMPORTED_MODULE_6__["default"], babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({ ref: _this.saveDialog }, _this.props, extra, { key: "dialog" }));
        };
        _this.getContainer = function () {
            if (_this.props.getContainer) {
                return _this.props.getContainer();
            }
            var container = document.createElement('div');
            document.body.appendChild(container);
            return container;
        };
        return _this;
    }

    DialogWrap.prototype.shouldComponentUpdate = function shouldComponentUpdate(_ref) {
        var visible = _ref.visible;

        return !!(this.props.visible || visible);
    };

    DialogWrap.prototype.componentWillUnmount = function componentWillUnmount() {
        if (IS_REACT_16) {
            return;
        }
        if (this.props.visible) {
            this.renderComponent({
                afterClose: this.removeContainer,
                onClose: function onClose() {},

                visible: false
            });
        } else {
            this.removeContainer();
        }
    };

    DialogWrap.prototype.render = function render() {
        var _this2 = this;

        var visible = this.props.visible;

        var portal = null;
        if (!IS_REACT_16) {
            return react__WEBPACK_IMPORTED_MODULE_4__["createElement"](rc_util_es_ContainerRender__WEBPACK_IMPORTED_MODULE_7__["default"], { parent: this, visible: visible, autoDestroy: false, getComponent: this.getComponent, getContainer: this.getContainer }, function (_ref2) {
                var renderComponent = _ref2.renderComponent,
                    removeContainer = _ref2.removeContainer;

                _this2.renderComponent = renderComponent;
                _this2.removeContainer = removeContainer;
                return null;
            });
        }
        if (visible || this._component) {
            portal = react__WEBPACK_IMPORTED_MODULE_4__["createElement"](rc_util_es_Portal__WEBPACK_IMPORTED_MODULE_8__["default"], { getContainer: this.getContainer }, this.getComponent());
        }
        return portal;
    };

    return DialogWrap;
}(react__WEBPACK_IMPORTED_MODULE_4__["Component"]);

DialogWrap.defaultProps = {
    visible: false
};
/* harmony default export */ __webpack_exports__["default"] = (DialogWrap);

/***/ }),

/***/ "../node_modules/rc-dialog/es/LazyRenderBox.js":
/*!*****************************************************!*\
  !*** ../node_modules/rc-dialog/es/LazyRenderBox.js ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! babel-runtime/helpers/extends */ "../node_modules/babel-runtime/helpers/extends.js");
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! babel-runtime/helpers/classCallCheck */ "../node_modules/babel-runtime/helpers/classCallCheck.js");
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! babel-runtime/helpers/possibleConstructorReturn */ "../node_modules/babel-runtime/helpers/possibleConstructorReturn.js");
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! babel-runtime/helpers/inherits */ "../node_modules/babel-runtime/helpers/inherits.js");
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);






var LazyRenderBox = function (_React$Component) {
    babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3___default()(LazyRenderBox, _React$Component);

    function LazyRenderBox() {
        babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1___default()(this, LazyRenderBox);

        return babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2___default()(this, _React$Component.apply(this, arguments));
    }

    LazyRenderBox.prototype.shouldComponentUpdate = function shouldComponentUpdate(nextProps) {
        return !!nextProps.hiddenClassName || !!nextProps.visible;
    };

    LazyRenderBox.prototype.render = function render() {
        var className = this.props.className;
        if (!!this.props.hiddenClassName && !this.props.visible) {
            className += " " + this.props.hiddenClassName;
        }
        var props = babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({}, this.props);
        delete props.hiddenClassName;
        delete props.visible;
        props.className = className;
        return react__WEBPACK_IMPORTED_MODULE_4__["createElement"]("div", babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({}, props));
    };

    return LazyRenderBox;
}(react__WEBPACK_IMPORTED_MODULE_4__["Component"]);

/* harmony default export */ __webpack_exports__["default"] = (LazyRenderBox);

/***/ }),

/***/ "../node_modules/rc-notification/es/Notice.js":
/*!****************************************************!*\
  !*** ../node_modules/rc-notification/es/Notice.js ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! babel-runtime/helpers/defineProperty */ "../node_modules/babel-runtime/helpers/defineProperty.js");
/* harmony import */ var babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! babel-runtime/helpers/classCallCheck */ "../node_modules/babel-runtime/helpers/classCallCheck.js");
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! babel-runtime/helpers/createClass */ "../node_modules/babel-runtime/helpers/createClass.js");
/* harmony import */ var babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! babel-runtime/helpers/possibleConstructorReturn */ "../node_modules/babel-runtime/helpers/possibleConstructorReturn.js");
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! babel-runtime/helpers/inherits */ "../node_modules/babel-runtime/helpers/inherits.js");
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! classnames */ "../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_7__);









var Notice = function (_Component) {
  babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_4___default()(Notice, _Component);

  function Notice() {
    var _ref;

    var _temp, _this, _ret;

    babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1___default()(this, Notice);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3___default()(this, (_ref = Notice.__proto__ || Object.getPrototypeOf(Notice)).call.apply(_ref, [this].concat(args))), _this), _this.close = function () {
      _this.clearCloseTimer();
      _this.props.onClose();
    }, _this.startCloseTimer = function () {
      if (_this.props.duration) {
        _this.closeTimer = setTimeout(function () {
          _this.close();
        }, _this.props.duration * 1000);
      }
    }, _this.clearCloseTimer = function () {
      if (_this.closeTimer) {
        clearTimeout(_this.closeTimer);
        _this.closeTimer = null;
      }
    }, _temp), babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3___default()(_this, _ret);
  }

  babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_2___default()(Notice, [{
    key: 'componentDidMount',
    value: function componentDidMount() {
      this.startCloseTimer();
    }
  }, {
    key: 'componentWillUnmount',
    value: function componentWillUnmount() {
      this.clearCloseTimer();
    }
  }, {
    key: 'render',
    value: function render() {
      var _className;

      var props = this.props;
      var componentClass = props.prefixCls + '-notice';
      var className = (_className = {}, babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(_className, '' + componentClass, 1), babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(_className, componentClass + '-closable', props.closable), babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(_className, props.className, !!props.className), _className);
      return react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement(
        'div',
        { className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(className), style: props.style, onMouseEnter: this.clearCloseTimer,
          onMouseLeave: this.startCloseTimer
        },
        react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement(
          'div',
          { className: componentClass + '-content' },
          props.children
        ),
        props.closable ? react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement(
          'a',
          { tabIndex: '0', onClick: this.close, className: componentClass + '-close' },
          react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement('span', { className: componentClass + '-close-x' })
        ) : null
      );
    }
  }]);

  return Notice;
}(react__WEBPACK_IMPORTED_MODULE_5__["Component"]);

Notice.propTypes = {
  duration: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.number,
  onClose: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.func,
  children: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.any
};
Notice.defaultProps = {
  onEnd: function onEnd() {},
  onClose: function onClose() {},

  duration: 1.5,
  style: {
    right: '50%'
  }
};
/* harmony default export */ __webpack_exports__["default"] = (Notice);

/***/ }),

/***/ "../node_modules/rc-notification/es/Notification.js":
/*!**********************************************************!*\
  !*** ../node_modules/rc-notification/es/Notification.js ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! babel-runtime/helpers/objectWithoutProperties */ "../node_modules/babel-runtime/helpers/objectWithoutProperties.js");
/* harmony import */ var babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! babel-runtime/helpers/defineProperty */ "../node_modules/babel-runtime/helpers/defineProperty.js");
/* harmony import */ var babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! babel-runtime/helpers/extends */ "../node_modules/babel-runtime/helpers/extends.js");
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! babel-runtime/helpers/classCallCheck */ "../node_modules/babel-runtime/helpers/classCallCheck.js");
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! babel-runtime/helpers/createClass */ "../node_modules/babel-runtime/helpers/createClass.js");
/* harmony import */ var babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! babel-runtime/helpers/possibleConstructorReturn */ "../node_modules/babel-runtime/helpers/possibleConstructorReturn.js");
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! babel-runtime/helpers/inherits */ "../node_modules/babel-runtime/helpers/inherits.js");
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-dom */ "../node_modules/react-dom/index.js");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var rc_animate__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rc-animate */ "../node_modules/rc-animate/es/Animate.js");
/* harmony import */ var rc_util_es_createChainedFunction__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rc-util/es/createChainedFunction */ "../node_modules/rc-util/es/createChainedFunction.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! classnames */ "../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _Notice__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./Notice */ "../node_modules/rc-notification/es/Notice.js");















var seed = 0;
var now = Date.now();

function getUuid() {
  return 'rcNotification_' + now + '_' + seed++;
}

var Notification = function (_Component) {
  babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_6___default()(Notification, _Component);

  function Notification() {
    var _ref;

    var _temp, _this, _ret;

    babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_3___default()(this, Notification);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5___default()(this, (_ref = Notification.__proto__ || Object.getPrototypeOf(Notification)).call.apply(_ref, [this].concat(args))), _this), _this.state = {
      notices: []
    }, _this.add = function (notice) {
      var key = notice.key = notice.key || getUuid();
      _this.setState(function (previousState) {
        var notices = previousState.notices;
        if (!notices.filter(function (v) {
          return v.key === key;
        }).length) {
          return {
            notices: notices.concat(notice)
          };
        }
      });
    }, _this.remove = function (key) {
      _this.setState(function (previousState) {
        return {
          notices: previousState.notices.filter(function (notice) {
            return notice.key !== key;
          })
        };
      });
    }, _temp), babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5___default()(_this, _ret);
  }

  babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_4___default()(Notification, [{
    key: 'getTransitionName',
    value: function getTransitionName() {
      var props = this.props;
      var transitionName = props.transitionName;
      if (!transitionName && props.animation) {
        transitionName = props.prefixCls + '-' + props.animation;
      }
      return transitionName;
    }
  }, {
    key: 'render',
    value: function render() {
      var _this2 = this,
          _className;

      var props = this.props;
      var noticeNodes = this.state.notices.map(function (notice) {
        var onClose = Object(rc_util_es_createChainedFunction__WEBPACK_IMPORTED_MODULE_11__["default"])(_this2.remove.bind(_this2, notice.key), notice.onClose);
        return react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(
          _Notice__WEBPACK_IMPORTED_MODULE_13__["default"],
          babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_2___default()({
            prefixCls: props.prefixCls
          }, notice, {
            onClose: onClose
          }),
          notice.content
        );
      });
      var className = (_className = {}, babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(_className, props.prefixCls, 1), babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(_className, props.className, !!props.className), _className);
      return react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(
        'div',
        { className: classnames__WEBPACK_IMPORTED_MODULE_12___default()(className), style: props.style },
        react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(
          rc_animate__WEBPACK_IMPORTED_MODULE_10__["default"],
          { transitionName: this.getTransitionName() },
          noticeNodes
        )
      );
    }
  }]);

  return Notification;
}(react__WEBPACK_IMPORTED_MODULE_7__["Component"]);

Notification.propTypes = {
  prefixCls: prop_types__WEBPACK_IMPORTED_MODULE_8___default.a.string,
  transitionName: prop_types__WEBPACK_IMPORTED_MODULE_8___default.a.string,
  animation: prop_types__WEBPACK_IMPORTED_MODULE_8___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_8___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_8___default.a.object]),
  style: prop_types__WEBPACK_IMPORTED_MODULE_8___default.a.object
};
Notification.defaultProps = {
  prefixCls: 'rc-notification',
  animation: 'fade',
  style: {
    top: 65,
    left: '50%'
  }
};


Notification.newInstance = function newNotificationInstance(properties, callback) {
  var _ref2 = properties || {},
      getContainer = _ref2.getContainer,
      props = babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_0___default()(_ref2, ['getContainer']);

  var div = document.createElement('div');
  if (getContainer) {
    var root = getContainer();
    root.appendChild(div);
  } else {
    document.body.appendChild(div);
  }
  var called = false;
  function ref(notification) {
    if (called) {
      return;
    }
    called = true;
    callback({
      notice: function notice(noticeProps) {
        notification.add(noticeProps);
      },
      removeNotice: function removeNotice(key) {
        notification.remove(key);
      },

      component: notification,
      destroy: function destroy() {
        react_dom__WEBPACK_IMPORTED_MODULE_9___default.a.unmountComponentAtNode(div);
        div.parentNode.removeChild(div);
      }
    });
  }
  react_dom__WEBPACK_IMPORTED_MODULE_9___default.a.render(react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(Notification, babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_2___default()({}, props, { ref: ref })), div);
};

/* harmony default export */ __webpack_exports__["default"] = (Notification);

/***/ }),

/***/ "../node_modules/rc-notification/es/index.js":
/*!***************************************************!*\
  !*** ../node_modules/rc-notification/es/index.js ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Notification__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Notification */ "../node_modules/rc-notification/es/Notification.js");

/* harmony default export */ __webpack_exports__["default"] = (_Notification__WEBPACK_IMPORTED_MODULE_0__["default"]);

/***/ }),

/***/ "../node_modules/rc-table/es/BaseTable.js":
/*!************************************************!*\
  !*** ../node_modules/rc-table/es/BaseTable.js ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! babel-runtime/helpers/extends */ "../node_modules/babel-runtime/helpers/extends.js");
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! babel-runtime/helpers/classCallCheck */ "../node_modules/babel-runtime/helpers/classCallCheck.js");
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! babel-runtime/helpers/possibleConstructorReturn */ "../node_modules/babel-runtime/helpers/possibleConstructorReturn.js");
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! babel-runtime/helpers/inherits */ "../node_modules/babel-runtime/helpers/inherits.js");
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var mini_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! mini-store */ "../node_modules/mini-store/lib/index.js");
/* harmony import */ var mini_store__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(mini_store__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _ColGroup__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./ColGroup */ "../node_modules/rc-table/es/ColGroup.js");
/* harmony import */ var _TableHeader__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./TableHeader */ "../node_modules/rc-table/es/TableHeader.js");
/* harmony import */ var _TableRow__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./TableRow */ "../node_modules/rc-table/es/TableRow.js");
/* harmony import */ var _ExpandableRow__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./ExpandableRow */ "../node_modules/rc-table/es/ExpandableRow.js");












var BaseTable = function (_React$Component) {
  babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3___default()(BaseTable, _React$Component);

  function BaseTable() {
    var _temp, _this, _ret;

    babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1___default()(this, BaseTable);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2___default()(this, _React$Component.call.apply(_React$Component, [this].concat(args))), _this), _this.handleRowHover = function (isHover, key) {
      _this.props.store.setState({
        currentHoverKey: isHover ? key : null
      });
    }, _this.renderRows = function (renderData, indent) {
      var ancestorKeys = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : [];
      var table = _this.context.table;
      var columnManager = table.columnManager,
          components = table.components;
      var _table$props = table.props,
          prefixCls = _table$props.prefixCls,
          childrenColumnName = _table$props.childrenColumnName,
          rowClassName = _table$props.rowClassName,
          rowRef = _table$props.rowRef,
          onRowClick = _table$props.onRowClick,
          onRowDoubleClick = _table$props.onRowDoubleClick,
          onRowContextMenu = _table$props.onRowContextMenu,
          onRowMouseEnter = _table$props.onRowMouseEnter,
          onRowMouseLeave = _table$props.onRowMouseLeave,
          onRow = _table$props.onRow;
      var _this$props = _this.props,
          getRowKey = _this$props.getRowKey,
          fixed = _this$props.fixed,
          expander = _this$props.expander,
          isAnyColumnsFixed = _this$props.isAnyColumnsFixed;


      var rows = [];

      var _loop = function _loop(i) {
        var record = renderData[i];
        var key = getRowKey(record, i);
        var className = typeof rowClassName === 'string' ? rowClassName : rowClassName(record, i, indent);

        var onHoverProps = {};
        if (columnManager.isAnyColumnsFixed()) {
          onHoverProps.onHover = _this.handleRowHover;
        }

        var leafColumns = void 0;
        if (fixed === 'left') {
          leafColumns = columnManager.leftLeafColumns();
        } else if (fixed === 'right') {
          leafColumns = columnManager.rightLeafColumns();
        } else {
          leafColumns = columnManager.leafColumns();
        }

        var rowPrefixCls = prefixCls + '-row';

        var row = react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
          _ExpandableRow__WEBPACK_IMPORTED_MODULE_10__["default"],
          babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({}, expander.props, {
            fixed: fixed,
            index: i,
            prefixCls: rowPrefixCls,
            record: record,
            key: key,
            rowKey: key,
            onRowClick: onRowClick,
            needIndentSpaced: expander.needIndentSpaced,
            onExpandedChange: expander.handleExpandChange
          }),
          function (expandableRow) {
            return (// eslint-disable-line
              react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_TableRow__WEBPACK_IMPORTED_MODULE_9__["default"], babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({
                fixed: fixed,
                indent: indent,
                className: className,
                record: record,
                index: i,
                prefixCls: rowPrefixCls,
                childrenColumnName: childrenColumnName,
                columns: leafColumns,
                onRow: onRow,
                onRowDoubleClick: onRowDoubleClick,
                onRowContextMenu: onRowContextMenu,
                onRowMouseEnter: onRowMouseEnter,
                onRowMouseLeave: onRowMouseLeave
              }, onHoverProps, {
                rowKey: key,
                ancestorKeys: ancestorKeys,
                ref: rowRef(record, i, indent),
                components: components,
                isAnyColumnsFixed: isAnyColumnsFixed
              }, expandableRow))
            );
          }
        );

        rows.push(row);

        expander.renderRows(_this.renderRows, rows, record, i, indent, fixed, key, ancestorKeys);
      };

      for (var i = 0; i < renderData.length; i++) {
        _loop(i);
      }
      return rows;
    }, _temp), babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2___default()(_this, _ret);
  }

  BaseTable.prototype.render = function render() {
    var table = this.context.table;
    var components = table.components;
    var _table$props2 = table.props,
        prefixCls = _table$props2.prefixCls,
        scroll = _table$props2.scroll,
        data = _table$props2.data,
        getBodyWrapper = _table$props2.getBodyWrapper;
    var _props = this.props,
        expander = _props.expander,
        tableClassName = _props.tableClassName,
        hasHead = _props.hasHead,
        hasBody = _props.hasBody,
        fixed = _props.fixed,
        columns = _props.columns;

    var tableStyle = {};

    if (!fixed && scroll.x) {
      // not set width, then use content fixed width
      if (scroll.x === true) {
        tableStyle.tableLayout = 'fixed';
      } else {
        tableStyle.width = scroll.x;
      }
    }

    var Table = hasBody ? components.table : 'table';
    var BodyWrapper = components.body.wrapper;

    var body = void 0;
    if (hasBody) {
      body = react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
        BodyWrapper,
        { className: prefixCls + '-tbody' },
        this.renderRows(data, 0)
      );
      if (getBodyWrapper) {
        body = getBodyWrapper(body);
      }
    }

    return react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
      Table,
      { className: tableClassName, style: tableStyle, key: 'table' },
      react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_ColGroup__WEBPACK_IMPORTED_MODULE_7__["default"], { columns: columns, fixed: fixed }),
      hasHead && react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_TableHeader__WEBPACK_IMPORTED_MODULE_8__["default"], { expander: expander, columns: columns, fixed: fixed }),
      body
    );
  };

  return BaseTable;
}(react__WEBPACK_IMPORTED_MODULE_4___default.a.Component);

BaseTable.propTypes = {
  fixed: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.bool]),
  columns: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.array.isRequired,
  tableClassName: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.string.isRequired,
  hasHead: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.bool.isRequired,
  hasBody: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.bool.isRequired,
  store: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.object.isRequired,
  expander: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.object.isRequired,
  getRowKey: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.func,
  isAnyColumnsFixed: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.bool
};
BaseTable.contextTypes = {
  table: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.any
};


/* harmony default export */ __webpack_exports__["default"] = (Object(mini_store__WEBPACK_IMPORTED_MODULE_6__["connect"])()(BaseTable));

/***/ }),

/***/ "../node_modules/rc-table/es/BodyTable.js":
/*!************************************************!*\
  !*** ../node_modules/rc-table/es/BodyTable.js ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return BodyTable; });
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! babel-runtime/helpers/extends */ "../node_modules/babel-runtime/helpers/extends.js");
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./utils */ "../node_modules/rc-table/es/utils.js");
/* harmony import */ var _BaseTable__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./BaseTable */ "../node_modules/rc-table/es/BaseTable.js");






function BodyTable(props, _ref) {
  var table = _ref.table;
  var _table$props = table.props,
      prefixCls = _table$props.prefixCls,
      scroll = _table$props.scroll;
  var columns = props.columns,
      fixed = props.fixed,
      tableClassName = props.tableClassName,
      getRowKey = props.getRowKey,
      handleBodyScroll = props.handleBodyScroll,
      handleWheel = props.handleWheel,
      expander = props.expander,
      isAnyColumnsFixed = props.isAnyColumnsFixed;
  var saveRef = table.saveRef;
  var useFixedHeader = table.props.useFixedHeader;

  var bodyStyle = babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({}, table.props.bodyStyle);
  var innerBodyStyle = {};

  if (scroll.x || fixed) {
    bodyStyle.overflowX = bodyStyle.overflowX || 'auto';
    // Fix weired webkit render bug
    // https://github.com/ant-design/ant-design/issues/7783
    bodyStyle.WebkitTransform = 'translate3d (0, 0, 0)';
  }

  if (scroll.y) {
    // maxHeight will make fixed-Table scrolling not working
    // so we only set maxHeight to body-Table here
    if (fixed) {
      innerBodyStyle.maxHeight = bodyStyle.maxHeight || scroll.y;
      innerBodyStyle.overflowY = bodyStyle.overflowY || 'scroll';
    } else {
      bodyStyle.maxHeight = bodyStyle.maxHeight || scroll.y;
    }
    bodyStyle.overflowY = bodyStyle.overflowY || 'scroll';
    useFixedHeader = true;

    // Add negative margin bottom for scroll bar overflow bug
    var scrollbarWidth = Object(_utils__WEBPACK_IMPORTED_MODULE_3__["measureScrollbar"])();
    if (scrollbarWidth > 0 && fixed) {
      bodyStyle.marginBottom = '-' + scrollbarWidth + 'px';
      bodyStyle.paddingBottom = '0px';
    }
  }

  var baseTable = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_BaseTable__WEBPACK_IMPORTED_MODULE_4__["default"], {
    tableClassName: tableClassName,
    hasHead: !useFixedHeader,
    hasBody: true,
    fixed: fixed,
    columns: columns,
    expander: expander,
    getRowKey: getRowKey,
    isAnyColumnsFixed: isAnyColumnsFixed
  });

  if (fixed && columns.length) {
    var refName = void 0;
    if (columns[0].fixed === 'left' || columns[0].fixed === true) {
      refName = 'fixedColumnsBodyLeft';
    } else if (columns[0].fixed === 'right') {
      refName = 'fixedColumnsBodyRight';
    }
    delete bodyStyle.overflowX;
    delete bodyStyle.overflowY;
    return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(
      'div',
      { key: 'bodyTable', className: prefixCls + '-body-outer', style: babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({}, bodyStyle) },
      react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(
        'div',
        {
          className: prefixCls + '-body-inner',
          style: innerBodyStyle,
          ref: saveRef(refName),
          onWheel: handleWheel,
          onScroll: handleBodyScroll
        },
        baseTable
      )
    );
  }

  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(
    'div',
    {
      key: 'bodyTable',
      className: prefixCls + '-body',
      style: bodyStyle,
      ref: saveRef('bodyTable'),
      onWheel: handleWheel,
      onScroll: handleBodyScroll
    },
    baseTable
  );
}

BodyTable.propTypes = {
  fixed: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.bool]),
  columns: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.array.isRequired,
  tableClassName: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string.isRequired,
  handleWheel: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.func.isRequired,
  handleBodyScroll: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.func.isRequired,
  getRowKey: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.func.isRequired,
  expander: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.object.isRequired,
  isAnyColumnsFixed: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.bool
};

BodyTable.contextTypes = {
  table: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.any
};

/***/ }),

/***/ "../node_modules/rc-table/es/ColGroup.js":
/*!***********************************************!*\
  !*** ../node_modules/rc-table/es/ColGroup.js ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ColGroup; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);



function ColGroup(props, _ref) {
  var table = _ref.table;
  var _table$props = table.props,
      prefixCls = _table$props.prefixCls,
      expandIconAsCell = _table$props.expandIconAsCell;
  var fixed = props.fixed;


  var cols = [];

  if (expandIconAsCell && fixed !== 'right') {
    cols.push(react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('col', { className: prefixCls + '-expand-icon-col', key: 'rc-table-expand-icon-col' }));
  }

  var leafColumns = void 0;

  if (fixed === 'left') {
    leafColumns = table.columnManager.leftLeafColumns();
  } else if (fixed === 'right') {
    leafColumns = table.columnManager.rightLeafColumns();
  } else {
    leafColumns = table.columnManager.leafColumns();
  }
  cols = cols.concat(leafColumns.map(function (c) {
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('col', { key: c.key || c.dataIndex, style: { width: c.width, minWidth: c.width } });
  }));

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
    'colgroup',
    null,
    cols
  );
}

ColGroup.propTypes = {
  fixed: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string
};

ColGroup.contextTypes = {
  table: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.any
};

/***/ }),

/***/ "../node_modules/rc-table/es/Column.js":
/*!*********************************************!*\
  !*** ../node_modules/rc-table/es/Column.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);


function Column() {}

Column.propTypes = {
  className: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  colSpan: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  title: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.node,
  dataIndex: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  width: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string]),
  fixed: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.oneOf([true, 'left', 'right']),
  render: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  onCellClick: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  onCell: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  onHeaderCell: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func
};

/* harmony default export */ __webpack_exports__["default"] = (Column);

/***/ }),

/***/ "../node_modules/rc-table/es/ColumnGroup.js":
/*!**************************************************!*\
  !*** ../node_modules/rc-table/es/ColumnGroup.js ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! babel-runtime/helpers/classCallCheck */ "../node_modules/babel-runtime/helpers/classCallCheck.js");
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! babel-runtime/helpers/possibleConstructorReturn */ "../node_modules/babel-runtime/helpers/possibleConstructorReturn.js");
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! babel-runtime/helpers/inherits */ "../node_modules/babel-runtime/helpers/inherits.js");
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_4__);






var ColumnGroup = function (_Component) {
  babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2___default()(ColumnGroup, _Component);

  function ColumnGroup() {
    babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default()(this, ColumnGroup);

    return babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_1___default()(this, _Component.apply(this, arguments));
  }

  return ColumnGroup;
}(react__WEBPACK_IMPORTED_MODULE_3__["Component"]);

ColumnGroup.propTypes = {
  title: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.node
};
ColumnGroup.isTableColumnGroup = true;
/* harmony default export */ __webpack_exports__["default"] = (ColumnGroup);

/***/ }),

/***/ "../node_modules/rc-table/es/ColumnManager.js":
/*!****************************************************!*\
  !*** ../node_modules/rc-table/es/ColumnManager.js ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! babel-runtime/helpers/extends */ "../node_modules/babel-runtime/helpers/extends.js");
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! babel-runtime/helpers/classCallCheck */ "../node_modules/babel-runtime/helpers/classCallCheck.js");
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);




var ColumnManager = function () {
  function ColumnManager(columns, elements) {
    babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1___default()(this, ColumnManager);

    this._cached = {};

    this.columns = columns || this.normalize(elements);
  }

  ColumnManager.prototype.isAnyColumnsFixed = function isAnyColumnsFixed() {
    var _this = this;

    return this._cache('isAnyColumnsFixed', function () {
      return _this.columns.some(function (column) {
        return !!column.fixed;
      });
    });
  };

  ColumnManager.prototype.isAnyColumnsLeftFixed = function isAnyColumnsLeftFixed() {
    var _this2 = this;

    return this._cache('isAnyColumnsLeftFixed', function () {
      return _this2.columns.some(function (column) {
        return column.fixed === 'left' || column.fixed === true;
      });
    });
  };

  ColumnManager.prototype.isAnyColumnsRightFixed = function isAnyColumnsRightFixed() {
    var _this3 = this;

    return this._cache('isAnyColumnsRightFixed', function () {
      return _this3.columns.some(function (column) {
        return column.fixed === 'right';
      });
    });
  };

  ColumnManager.prototype.leftColumns = function leftColumns() {
    var _this4 = this;

    return this._cache('leftColumns', function () {
      return _this4.groupedColumns().filter(function (column) {
        return column.fixed === 'left' || column.fixed === true;
      });
    });
  };

  ColumnManager.prototype.rightColumns = function rightColumns() {
    var _this5 = this;

    return this._cache('rightColumns', function () {
      return _this5.groupedColumns().filter(function (column) {
        return column.fixed === 'right';
      });
    });
  };

  ColumnManager.prototype.leafColumns = function leafColumns() {
    var _this6 = this;

    return this._cache('leafColumns', function () {
      return _this6._leafColumns(_this6.columns);
    });
  };

  ColumnManager.prototype.leftLeafColumns = function leftLeafColumns() {
    var _this7 = this;

    return this._cache('leftLeafColumns', function () {
      return _this7._leafColumns(_this7.leftColumns());
    });
  };

  ColumnManager.prototype.rightLeafColumns = function rightLeafColumns() {
    var _this8 = this;

    return this._cache('rightLeafColumns', function () {
      return _this8._leafColumns(_this8.rightColumns());
    });
  };

  // add appropriate rowspan and colspan to column


  ColumnManager.prototype.groupedColumns = function groupedColumns() {
    var _this9 = this;

    return this._cache('groupedColumns', function () {
      var _groupColumns = function _groupColumns(columns) {
        var currentRow = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
        var parentColumn = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
        var rows = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : [];

        // track how many rows we got
        rows[currentRow] = rows[currentRow] || [];
        var grouped = [];
        var setRowSpan = function setRowSpan(column) {
          var rowSpan = rows.length - currentRow;
          if (column && !column.children && // parent columns are supposed to be one row
          rowSpan > 1 && (!column.rowSpan || column.rowSpan < rowSpan)) {
            column.rowSpan = rowSpan;
          }
        };
        columns.forEach(function (column, index) {
          var newColumn = babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({}, column);
          rows[currentRow].push(newColumn);
          parentColumn.colSpan = parentColumn.colSpan || 0;
          if (newColumn.children && newColumn.children.length > 0) {
            newColumn.children = _groupColumns(newColumn.children, currentRow + 1, newColumn, rows);
            parentColumn.colSpan += newColumn.colSpan;
          } else {
            parentColumn.colSpan++;
          }
          // update rowspan to all same row columns
          for (var i = 0; i < rows[currentRow].length - 1; ++i) {
            setRowSpan(rows[currentRow][i]);
          }
          // last column, update rowspan immediately
          if (index + 1 === columns.length) {
            setRowSpan(newColumn);
          }
          grouped.push(newColumn);
        });
        return grouped;
      };
      return _groupColumns(_this9.columns);
    });
  };

  ColumnManager.prototype.normalize = function normalize(elements) {
    var _this10 = this;

    var columns = [];
    react__WEBPACK_IMPORTED_MODULE_2___default.a.Children.forEach(elements, function (element) {
      if (!react__WEBPACK_IMPORTED_MODULE_2___default.a.isValidElement(element)) {
        return;
      }
      var column = babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({}, element.props);
      if (element.key) {
        column.key = element.key;
      }
      if (element.type.isTableColumnGroup) {
        column.children = _this10.normalize(column.children);
      }
      columns.push(column);
    });
    return columns;
  };

  ColumnManager.prototype.reset = function reset(columns, elements) {
    this.columns = columns || this.normalize(elements);
    this._cached = {};
  };

  ColumnManager.prototype._cache = function _cache(name, fn) {
    if (name in this._cached) {
      return this._cached[name];
    }
    this._cached[name] = fn();
    return this._cached[name];
  };

  ColumnManager.prototype._leafColumns = function _leafColumns(columns) {
    var _this11 = this;

    var leafColumns = [];
    columns.forEach(function (column) {
      if (!column.children) {
        leafColumns.push(column);
      } else {
        leafColumns.push.apply(leafColumns, _this11._leafColumns(column.children));
      }
    });
    return leafColumns;
  };

  return ColumnManager;
}();

/* harmony default export */ __webpack_exports__["default"] = (ColumnManager);

/***/ }),

/***/ "../node_modules/rc-table/es/ExpandIcon.js":
/*!*************************************************!*\
  !*** ../node_modules/rc-table/es/ExpandIcon.js ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! babel-runtime/helpers/classCallCheck */ "../node_modules/babel-runtime/helpers/classCallCheck.js");
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! babel-runtime/helpers/possibleConstructorReturn */ "../node_modules/babel-runtime/helpers/possibleConstructorReturn.js");
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! babel-runtime/helpers/inherits */ "../node_modules/babel-runtime/helpers/inherits.js");
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var shallowequal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! shallowequal */ "../node_modules/shallowequal/index.js");
/* harmony import */ var shallowequal__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(shallowequal__WEBPACK_IMPORTED_MODULE_5__);







var ExpandIcon = function (_React$Component) {
  babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2___default()(ExpandIcon, _React$Component);

  function ExpandIcon() {
    babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default()(this, ExpandIcon);

    return babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_1___default()(this, _React$Component.apply(this, arguments));
  }

  ExpandIcon.prototype.shouldComponentUpdate = function shouldComponentUpdate(nextProps) {
    return !shallowequal__WEBPACK_IMPORTED_MODULE_5___default()(nextProps, this.props);
  };

  ExpandIcon.prototype.render = function render() {
    var _props = this.props,
        expandable = _props.expandable,
        prefixCls = _props.prefixCls,
        onExpand = _props.onExpand,
        needIndentSpaced = _props.needIndentSpaced,
        expanded = _props.expanded,
        record = _props.record;

    if (expandable) {
      var expandClassName = expanded ? 'expanded' : 'collapsed';
      return react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement('span', {
        className: prefixCls + '-expand-icon ' + prefixCls + '-' + expandClassName,
        onClick: function onClick(e) {
          return onExpand(record, e);
        }
      });
    } else if (needIndentSpaced) {
      return react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement('span', { className: prefixCls + '-expand-icon ' + prefixCls + '-spaced' });
    }
    return null;
  };

  return ExpandIcon;
}(react__WEBPACK_IMPORTED_MODULE_3___default.a.Component);

ExpandIcon.propTypes = {
  record: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.object,
  prefixCls: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.string,
  expandable: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.any,
  expanded: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.bool,
  needIndentSpaced: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.bool,
  onExpand: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.func
};
/* harmony default export */ __webpack_exports__["default"] = (ExpandIcon);

/***/ }),

/***/ "../node_modules/rc-table/es/ExpandableRow.js":
/*!****************************************************!*\
  !*** ../node_modules/rc-table/es/ExpandableRow.js ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! babel-runtime/helpers/classCallCheck */ "../node_modules/babel-runtime/helpers/classCallCheck.js");
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! babel-runtime/helpers/possibleConstructorReturn */ "../node_modules/babel-runtime/helpers/possibleConstructorReturn.js");
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! babel-runtime/helpers/inherits */ "../node_modules/babel-runtime/helpers/inherits.js");
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var mini_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! mini-store */ "../node_modules/mini-store/lib/index.js");
/* harmony import */ var mini_store__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(mini_store__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _ExpandIcon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./ExpandIcon */ "../node_modules/rc-table/es/ExpandIcon.js");








var ExpandableRow = function (_React$Component) {
  babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2___default()(ExpandableRow, _React$Component);

  function ExpandableRow() {
    var _temp, _this, _ret;

    babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default()(this, ExpandableRow);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_1___default()(this, _React$Component.call.apply(_React$Component, [this].concat(args))), _this), _this.hasExpandIcon = function (columnIndex) {
      var expandRowByClick = _this.props.expandRowByClick;

      return !_this.expandIconAsCell && !expandRowByClick && columnIndex === _this.expandIconColumnIndex;
    }, _this.handleExpandChange = function (record, event) {
      var _this$props = _this.props,
          onExpandedChange = _this$props.onExpandedChange,
          expanded = _this$props.expanded,
          rowKey = _this$props.rowKey;

      if (_this.expandable) {
        onExpandedChange(!expanded, record, event, rowKey);
      }
    }, _this.handleRowClick = function (record, index, event) {
      var _this$props2 = _this.props,
          expandRowByClick = _this$props2.expandRowByClick,
          onRowClick = _this$props2.onRowClick;

      if (expandRowByClick) {
        _this.handleExpandChange(record, event);
      }
      if (onRowClick) {
        onRowClick(record, index, event);
      }
    }, _this.renderExpandIcon = function () {
      var _this$props3 = _this.props,
          prefixCls = _this$props3.prefixCls,
          expanded = _this$props3.expanded,
          record = _this$props3.record,
          needIndentSpaced = _this$props3.needIndentSpaced;


      return react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_ExpandIcon__WEBPACK_IMPORTED_MODULE_6__["default"], {
        expandable: _this.expandable,
        prefixCls: prefixCls,
        onExpand: _this.handleExpandChange,
        needIndentSpaced: needIndentSpaced,
        expanded: expanded,
        record: record
      });
    }, _this.renderExpandIconCell = function (cells) {
      if (!_this.expandIconAsCell) {
        return;
      }
      var prefixCls = _this.props.prefixCls;


      cells.push(react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(
        'td',
        { className: prefixCls + '-expand-icon-cell', key: 'rc-table-expand-icon-cell' },
        _this.renderExpandIcon()
      ));
    }, _temp), babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_1___default()(_this, _ret);
  }

  ExpandableRow.prototype.componentWillUnmount = function componentWillUnmount() {
    this.handleDestroy();
  };

  ExpandableRow.prototype.handleDestroy = function handleDestroy() {
    var _props = this.props,
        onExpandedChange = _props.onExpandedChange,
        rowKey = _props.rowKey,
        record = _props.record;

    if (this.expandable) {
      onExpandedChange(false, record, null, rowKey, true);
    }
  };

  ExpandableRow.prototype.render = function render() {
    var _props2 = this.props,
        childrenColumnName = _props2.childrenColumnName,
        expandedRowRender = _props2.expandedRowRender,
        indentSize = _props2.indentSize,
        record = _props2.record,
        fixed = _props2.fixed;


    this.expandIconAsCell = fixed !== 'right' ? this.props.expandIconAsCell : false;
    this.expandIconColumnIndex = fixed !== 'right' ? this.props.expandIconColumnIndex : -1;
    var childrenData = record[childrenColumnName];
    this.expandable = !!(childrenData || expandedRowRender);

    var expandableRowProps = {
      indentSize: indentSize,
      onRowClick: this.handleRowClick,
      hasExpandIcon: this.hasExpandIcon,
      renderExpandIcon: this.renderExpandIcon,
      renderExpandIconCell: this.renderExpandIconCell
    };

    return this.props.children(expandableRowProps);
  };

  return ExpandableRow;
}(react__WEBPACK_IMPORTED_MODULE_3___default.a.Component);

ExpandableRow.propTypes = {
  prefixCls: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.string.isRequired,
  rowKey: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.number]).isRequired,
  fixed: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.bool]),
  record: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.object.isRequired,
  indentSize: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.number,
  needIndentSpaced: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.bool.isRequired,
  expandRowByClick: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.bool,
  expanded: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.bool.isRequired,
  expandIconAsCell: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.bool,
  expandIconColumnIndex: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.number,
  childrenColumnName: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.string,
  expandedRowRender: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.func,
  onExpandedChange: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.func.isRequired,
  onRowClick: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.func,
  children: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.func.isRequired
};


/* harmony default export */ __webpack_exports__["default"] = (Object(mini_store__WEBPACK_IMPORTED_MODULE_5__["connect"])(function (_ref, _ref2) {
  var expandedRowKeys = _ref.expandedRowKeys;
  var rowKey = _ref2.rowKey;
  return {
    expanded: !!~expandedRowKeys.indexOf(rowKey)
  };
})(ExpandableRow));

/***/ }),

/***/ "../node_modules/rc-table/es/ExpandableTable.js":
/*!******************************************************!*\
  !*** ../node_modules/rc-table/es/ExpandableTable.js ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! babel-runtime/helpers/extends */ "../node_modules/babel-runtime/helpers/extends.js");
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! babel-runtime/helpers/classCallCheck */ "../node_modules/babel-runtime/helpers/classCallCheck.js");
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! babel-runtime/helpers/possibleConstructorReturn */ "../node_modules/babel-runtime/helpers/possibleConstructorReturn.js");
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! babel-runtime/helpers/inherits */ "../node_modules/babel-runtime/helpers/inherits.js");
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var mini_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! mini-store */ "../node_modules/mini-store/lib/index.js");
/* harmony import */ var mini_store__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(mini_store__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_lifecycles_compat__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-lifecycles-compat */ "../node_modules/react-lifecycles-compat/react-lifecycles-compat.es.js");
/* harmony import */ var _TableRow__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./TableRow */ "../node_modules/rc-table/es/TableRow.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./utils */ "../node_modules/rc-table/es/utils.js");











var ExpandableTable = function (_React$Component) {
  babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3___default()(ExpandableTable, _React$Component);

  function ExpandableTable(props) {
    babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1___default()(this, ExpandableTable);

    var _this = babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2___default()(this, _React$Component.call(this, props));

    _initialiseProps.call(_this);

    var data = props.data,
        childrenColumnName = props.childrenColumnName,
        defaultExpandAllRows = props.defaultExpandAllRows,
        expandedRowKeys = props.expandedRowKeys,
        defaultExpandedRowKeys = props.defaultExpandedRowKeys,
        getRowKey = props.getRowKey;


    var finnalExpandedRowKeys = [];
    var rows = [].concat(data);

    if (defaultExpandAllRows) {
      for (var i = 0; i < rows.length; i++) {
        var row = rows[i];
        finnalExpandedRowKeys.push(getRowKey(row, i));
        rows = rows.concat(row[childrenColumnName] || []);
      }
    } else {
      finnalExpandedRowKeys = expandedRowKeys || defaultExpandedRowKeys;
    }

    _this.columnManager = props.columnManager;
    _this.store = props.store;

    _this.store.setState({
      expandedRowsHeight: {},
      expandedRowKeys: finnalExpandedRowKeys
    });
    return _this;
  }

  ExpandableTable.prototype.componentDidUpdate = function componentDidUpdate() {
    if ('expandedRowKeys' in this.props) {
      this.store.setState({
        expandedRowKeys: this.props.expandedRowKeys
      });
    }
  };

  ExpandableTable.prototype.renderExpandedRow = function renderExpandedRow(record, index, _render, className, ancestorKeys, indent, fixed) {
    var _props = this.props,
        prefixCls = _props.prefixCls,
        expandIconAsCell = _props.expandIconAsCell,
        indentSize = _props.indentSize;

    var colCount = void 0;
    if (fixed === 'left') {
      colCount = this.columnManager.leftLeafColumns().length;
    } else if (fixed === 'right') {
      colCount = this.columnManager.rightLeafColumns().length;
    } else {
      colCount = this.columnManager.leafColumns().length;
    }
    var columns = [{
      key: 'extra-row',
      render: function render() {
        return {
          props: {
            colSpan: colCount
          },
          children: fixed !== 'right' ? _render(record, index, indent) : '&nbsp;'
        };
      }
    }];
    if (expandIconAsCell && fixed !== 'right') {
      columns.unshift({
        key: 'expand-icon-placeholder',
        render: function render() {
          return null;
        }
      });
    }
    var parentKey = ancestorKeys[ancestorKeys.length - 1];
    var rowKey = parentKey + '-extra-row';
    var components = {
      body: {
        row: 'tr',
        cell: 'td'
      }
    };

    return react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_TableRow__WEBPACK_IMPORTED_MODULE_8__["default"], {
      key: rowKey,
      columns: columns,
      className: className,
      rowKey: rowKey,
      ancestorKeys: ancestorKeys,
      prefixCls: prefixCls + '-expanded-row',
      indentSize: indentSize,
      indent: indent,
      fixed: fixed,
      components: components,
      expandedRow: true
    });
  };

  ExpandableTable.prototype.render = function render() {
    var _props2 = this.props,
        data = _props2.data,
        childrenColumnName = _props2.childrenColumnName,
        children = _props2.children;

    var needIndentSpaced = data.some(function (record) {
      return record[childrenColumnName];
    });

    return children({
      props: this.props,
      needIndentSpaced: needIndentSpaced,
      renderRows: this.renderRows,
      handleExpandChange: this.handleExpandChange,
      renderExpandIndentCell: this.renderExpandIndentCell
    });
  };

  return ExpandableTable;
}(react__WEBPACK_IMPORTED_MODULE_4___default.a.Component);

ExpandableTable.propTypes = {
  expandIconAsCell: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.bool,
  expandedRowKeys: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.array,
  expandedRowClassName: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.func,
  defaultExpandAllRows: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.bool,
  defaultExpandedRowKeys: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.array,
  expandIconColumnIndex: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.number,
  expandedRowRender: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.func,
  childrenColumnName: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.string,
  indentSize: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.number,
  onExpand: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.func,
  onExpandedRowsChange: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.func,
  columnManager: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.object.isRequired,
  store: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.object.isRequired,
  prefixCls: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.string.isRequired,
  data: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.array,
  children: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.func.isRequired,
  getRowKey: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.func.isRequired
};
ExpandableTable.defaultProps = {
  expandIconAsCell: false,
  expandedRowClassName: function expandedRowClassName() {
    return '';
  },
  expandIconColumnIndex: 0,
  defaultExpandAllRows: false,
  defaultExpandedRowKeys: [],
  childrenColumnName: 'children',
  indentSize: 15,
  onExpand: function onExpand() {},
  onExpandedRowsChange: function onExpandedRowsChange() {}
};

var _initialiseProps = function _initialiseProps() {
  var _this2 = this;

  this.handleExpandChange = function (expanded, record, event, rowKey) {
    var destroy = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : false;

    if (event) {
      event.preventDefault();
      event.stopPropagation();
    }

    var _props3 = _this2.props,
        onExpandedRowsChange = _props3.onExpandedRowsChange,
        onExpand = _props3.onExpand;

    var _store$getState = _this2.store.getState(),
        expandedRowKeys = _store$getState.expandedRowKeys;

    if (expanded) {
      // row was expaned
      expandedRowKeys = [].concat(expandedRowKeys, [rowKey]);
    } else {
      // row was collapse
      var expandedRowIndex = expandedRowKeys.indexOf(rowKey);
      if (expandedRowIndex !== -1) {
        expandedRowKeys = Object(_utils__WEBPACK_IMPORTED_MODULE_9__["remove"])(expandedRowKeys, rowKey);
      }
    }

    if (!_this2.props.expandedRowKeys) {
      _this2.store.setState({ expandedRowKeys: expandedRowKeys });
    }

    onExpandedRowsChange(expandedRowKeys);
    if (!destroy) {
      onExpand(expanded, record);
    }
  };

  this.renderExpandIndentCell = function (rows, fixed) {
    var _props4 = _this2.props,
        prefixCls = _props4.prefixCls,
        expandIconAsCell = _props4.expandIconAsCell;

    if (!expandIconAsCell || fixed === 'right' || !rows.length) {
      return;
    }

    var iconColumn = {
      key: 'rc-table-expand-icon-cell',
      className: prefixCls + '-expand-icon-th',
      title: '',
      rowSpan: rows.length
    };

    rows[0].unshift(babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({}, iconColumn, { column: iconColumn }));
  };

  this.renderRows = function (renderRows, rows, record, index, indent, fixed, parentKey, ancestorKeys) {
    var _props5 = _this2.props,
        expandedRowClassName = _props5.expandedRowClassName,
        expandedRowRender = _props5.expandedRowRender,
        childrenColumnName = _props5.childrenColumnName;

    var childrenData = record[childrenColumnName];
    var nextAncestorKeys = [].concat(ancestorKeys, [parentKey]);
    var nextIndent = indent + 1;

    if (expandedRowRender) {
      rows.push(_this2.renderExpandedRow(record, index, expandedRowRender, expandedRowClassName(record, index, indent), nextAncestorKeys, nextIndent, fixed));
    }

    if (childrenData) {
      rows.push.apply(rows, renderRows(childrenData, nextIndent, nextAncestorKeys));
    }
  };
};

Object(react_lifecycles_compat__WEBPACK_IMPORTED_MODULE_7__["polyfill"])(ExpandableTable);

/* harmony default export */ __webpack_exports__["default"] = (Object(mini_store__WEBPACK_IMPORTED_MODULE_6__["connect"])()(ExpandableTable));

/***/ }),

/***/ "../node_modules/rc-table/es/HeadTable.js":
/*!************************************************!*\
  !*** ../node_modules/rc-table/es/HeadTable.js ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return HeadTable; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./utils */ "../node_modules/rc-table/es/utils.js");
/* harmony import */ var _BaseTable__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./BaseTable */ "../node_modules/rc-table/es/BaseTable.js");





function HeadTable(props, _ref) {
  var table = _ref.table;
  var _table$props = table.props,
      prefixCls = _table$props.prefixCls,
      scroll = _table$props.scroll,
      showHeader = _table$props.showHeader;
  var columns = props.columns,
      fixed = props.fixed,
      tableClassName = props.tableClassName,
      handleBodyScrollLeft = props.handleBodyScrollLeft,
      expander = props.expander;
  var saveRef = table.saveRef;
  var useFixedHeader = table.props.useFixedHeader;

  var headStyle = {};

  if (scroll.y) {
    useFixedHeader = true;
    // Add negative margin bottom for scroll bar overflow bug
    var scrollbarWidth = Object(_utils__WEBPACK_IMPORTED_MODULE_2__["measureScrollbar"])('horizontal');
    if (scrollbarWidth > 0 && !fixed) {
      headStyle.marginBottom = '-' + scrollbarWidth + 'px';
      headStyle.paddingBottom = '0px';
    }
  }

  if (!useFixedHeader || !showHeader) {
    return null;
  }

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
    'div',
    {
      key: 'headTable',
      ref: fixed ? null : saveRef('headTable'),
      className: prefixCls + '-header',
      style: headStyle,
      onScroll: handleBodyScrollLeft
    },
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_BaseTable__WEBPACK_IMPORTED_MODULE_3__["default"], {
      tableClassName: tableClassName,
      hasHead: true,
      hasBody: false,
      fixed: fixed,
      columns: columns,
      expander: expander
    })
  );
}

HeadTable.propTypes = {
  fixed: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool]),
  columns: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.array.isRequired,
  tableClassName: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string.isRequired,
  handleBodyScrollLeft: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func.isRequired,
  expander: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object.isRequired
};

HeadTable.contextTypes = {
  table: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.any
};

/***/ }),

/***/ "../node_modules/rc-table/es/Table.js":
/*!********************************************!*\
  !*** ../node_modules/rc-table/es/Table.js ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! babel-runtime/helpers/extends */ "../node_modules/babel-runtime/helpers/extends.js");
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! babel-runtime/helpers/classCallCheck */ "../node_modules/babel-runtime/helpers/classCallCheck.js");
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! babel-runtime/helpers/possibleConstructorReturn */ "../node_modules/babel-runtime/helpers/possibleConstructorReturn.js");
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! babel-runtime/helpers/inherits */ "../node_modules/babel-runtime/helpers/inherits.js");
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var shallowequal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! shallowequal */ "../node_modules/shallowequal/index.js");
/* harmony import */ var shallowequal__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(shallowequal__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var rc_util_es_Dom_addEventListener__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rc-util/es/Dom/addEventListener */ "../node_modules/rc-util/es/Dom/addEventListener.js");
/* harmony import */ var mini_store__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! mini-store */ "../node_modules/mini-store/lib/index.js");
/* harmony import */ var mini_store__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(mini_store__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var lodash_merge__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! lodash/merge */ "../node_modules/lodash/merge.js");
/* harmony import */ var lodash_merge__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(lodash_merge__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var component_classes__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! component-classes */ "../node_modules/component-classes/index.js");
/* harmony import */ var component_classes__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(component_classes__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_lifecycles_compat__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! react-lifecycles-compat */ "../node_modules/react-lifecycles-compat/react-lifecycles-compat.es.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./utils */ "../node_modules/rc-table/es/utils.js");
/* harmony import */ var _ColumnManager__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./ColumnManager */ "../node_modules/rc-table/es/ColumnManager.js");
/* harmony import */ var _HeadTable__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./HeadTable */ "../node_modules/rc-table/es/HeadTable.js");
/* harmony import */ var _BodyTable__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./BodyTable */ "../node_modules/rc-table/es/BodyTable.js");
/* harmony import */ var _ExpandableTable__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./ExpandableTable */ "../node_modules/rc-table/es/ExpandableTable.js");


















var Table = function (_React$Component) {
  babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3___default()(Table, _React$Component);

  Table.getDerivedStateFromProps = function getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps.columns && nextProps.columns !== prevState.columns) {
      return {
        columns: nextProps.columns,
        children: null
      };
    } else if (nextProps.children !== prevState.children) {
      return {
        columns: null,
        children: nextProps.children
      };
    }
    return null;
  };

  function Table(props) {
    babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1___default()(this, Table);

    var _this = babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2___default()(this, _React$Component.call(this, props));

    _this.state = {};

    _this.getRowKey = function (record, index) {
      var rowKey = _this.props.rowKey;
      var key = typeof rowKey === 'function' ? rowKey(record, index) : record[rowKey];
      Object(_utils__WEBPACK_IMPORTED_MODULE_12__["warningOnce"])(key !== undefined, 'Each record in table should have a unique `key` prop,' + 'or set `rowKey` to an unique primary key.');
      return key === undefined ? index : key;
    };

    _this.handleWindowResize = function () {
      _this.syncFixedTableRowHeight();
      _this.setScrollPositionClassName();
    };

    _this.syncFixedTableRowHeight = function () {
      var tableRect = _this.tableNode.getBoundingClientRect();
      // If tableNode's height less than 0, suppose it is hidden and don't recalculate rowHeight.
      // see: https://github.com/ant-design/ant-design/issues/4836
      if (tableRect.height !== undefined && tableRect.height <= 0) {
        return;
      }
      var prefixCls = _this.props.prefixCls;

      var headRows = _this.headTable ? _this.headTable.querySelectorAll('thead') : _this.bodyTable.querySelectorAll('thead');
      var bodyRows = _this.bodyTable.querySelectorAll('.' + prefixCls + '-row') || [];
      var fixedColumnsHeadRowsHeight = [].map.call(headRows, function (row) {
        return row.getBoundingClientRect().height || 'auto';
      });
      var fixedColumnsBodyRowsHeight = [].map.call(bodyRows, function (row) {
        return row.getBoundingClientRect().height || 'auto';
      });
      var state = _this.store.getState();
      if (shallowequal__WEBPACK_IMPORTED_MODULE_6___default()(state.fixedColumnsHeadRowsHeight, fixedColumnsHeadRowsHeight) && shallowequal__WEBPACK_IMPORTED_MODULE_6___default()(state.fixedColumnsBodyRowsHeight, fixedColumnsBodyRowsHeight)) {
        return;
      }

      _this.store.setState({
        fixedColumnsHeadRowsHeight: fixedColumnsHeadRowsHeight,
        fixedColumnsBodyRowsHeight: fixedColumnsBodyRowsHeight
      });
    };

    _this.handleBodyScrollLeft = function (e) {
      // Fix https://github.com/ant-design/ant-design/issues/7635
      if (e.currentTarget !== e.target) {
        return;
      }
      var target = e.target;
      var _this$props$scroll = _this.props.scroll,
          scroll = _this$props$scroll === undefined ? {} : _this$props$scroll;
      var headTable = _this.headTable,
          bodyTable = _this.bodyTable;

      if (target.scrollLeft !== _this.lastScrollLeft && scroll.x) {
        if (target === bodyTable && headTable) {
          headTable.scrollLeft = target.scrollLeft;
        } else if (target === headTable && bodyTable) {
          bodyTable.scrollLeft = target.scrollLeft;
        }
        _this.setScrollPositionClassName();
      }
      // Remember last scrollLeft for scroll direction detecting.
      _this.lastScrollLeft = target.scrollLeft;
    };

    _this.handleBodyScrollTop = function (e) {
      var target = e.target;
      // Fix https://github.com/ant-design/ant-design/issues/9033
      if (e.currentTarget !== target) {
        return;
      }
      var _this$props$scroll2 = _this.props.scroll,
          scroll = _this$props$scroll2 === undefined ? {} : _this$props$scroll2;
      var headTable = _this.headTable,
          bodyTable = _this.bodyTable,
          fixedColumnsBodyLeft = _this.fixedColumnsBodyLeft,
          fixedColumnsBodyRight = _this.fixedColumnsBodyRight;

      if (target.scrollTop !== _this.lastScrollTop && scroll.y && target !== headTable) {
        var scrollTop = target.scrollTop;
        if (fixedColumnsBodyLeft && target !== fixedColumnsBodyLeft) {
          fixedColumnsBodyLeft.scrollTop = scrollTop;
        }
        if (fixedColumnsBodyRight && target !== fixedColumnsBodyRight) {
          fixedColumnsBodyRight.scrollTop = scrollTop;
        }
        if (bodyTable && target !== bodyTable) {
          bodyTable.scrollTop = scrollTop;
        }
      }
      // Remember last scrollTop for scroll direction detecting.
      _this.lastScrollTop = target.scrollTop;
    };

    _this.handleBodyScroll = function (e) {
      _this.handleBodyScrollLeft(e);
      _this.handleBodyScrollTop(e);
    };

    _this.handleWheel = function (event) {
      var _this$props$scroll3 = _this.props.scroll,
          scroll = _this$props$scroll3 === undefined ? {} : _this$props$scroll3;

      if (window.navigator.userAgent.match(/Trident\/7\./) && scroll.y) {
        event.preventDefault();
        var wd = event.deltaY;
        var target = event.target;
        var bodyTable = _this.bodyTable,
            fixedColumnsBodyLeft = _this.fixedColumnsBodyLeft,
            fixedColumnsBodyRight = _this.fixedColumnsBodyRight;

        var scrollTop = 0;

        if (_this.lastScrollTop) {
          scrollTop = _this.lastScrollTop + wd;
        } else {
          scrollTop = wd;
        }

        if (fixedColumnsBodyLeft && target !== fixedColumnsBodyLeft) {
          fixedColumnsBodyLeft.scrollTop = scrollTop;
        }
        if (fixedColumnsBodyRight && target !== fixedColumnsBodyRight) {
          fixedColumnsBodyRight.scrollTop = scrollTop;
        }
        if (bodyTable && target !== bodyTable) {
          bodyTable.scrollTop = scrollTop;
        }
      }
    };

    _this.saveRef = function (name) {
      return function (node) {
        _this[name] = node;
      };
    };

    ['onRowClick', 'onRowDoubleClick', 'onRowContextMenu', 'onRowMouseEnter', 'onRowMouseLeave'].forEach(function (name) {
      Object(_utils__WEBPACK_IMPORTED_MODULE_12__["warningOnce"])(props[name] === undefined, name + ' is deprecated, please use onRow instead.');
    });

    Object(_utils__WEBPACK_IMPORTED_MODULE_12__["warningOnce"])(props.getBodyWrapper === undefined, 'getBodyWrapper is deprecated, please use custom components instead.');

    _this.columnManager = new _ColumnManager__WEBPACK_IMPORTED_MODULE_13__["default"](props.columns, props.children);

    _this.store = Object(mini_store__WEBPACK_IMPORTED_MODULE_8__["create"])({
      currentHoverKey: null,
      fixedColumnsHeadRowsHeight: [],
      fixedColumnsBodyRowsHeight: []
    });

    _this.setScrollPosition('left');

    _this.debouncedWindowResize = Object(_utils__WEBPACK_IMPORTED_MODULE_12__["debounce"])(_this.handleWindowResize, 150);
    return _this;
  }

  Table.prototype.getChildContext = function getChildContext() {
    return {
      table: {
        props: this.props,
        columnManager: this.columnManager,
        saveRef: this.saveRef,
        components: lodash_merge__WEBPACK_IMPORTED_MODULE_9___default()({
          table: 'table',
          header: {
            wrapper: 'thead',
            row: 'tr',
            cell: 'th'
          },
          body: {
            wrapper: 'tbody',
            row: 'tr',
            cell: 'td'
          }
        }, this.props.components)
      }
    };
  };

  Table.prototype.componentDidMount = function componentDidMount() {
    if (this.columnManager.isAnyColumnsFixed()) {
      this.handleWindowResize();
      this.resizeEvent = Object(rc_util_es_Dom_addEventListener__WEBPACK_IMPORTED_MODULE_7__["default"])(window, 'resize', this.debouncedWindowResize);
    }
  };

  Table.prototype.componentDidUpdate = function componentDidUpdate(prevProps) {
    if (this.columnManager.isAnyColumnsFixed()) {
      this.handleWindowResize();
      if (!this.resizeEvent) {
        this.resizeEvent = Object(rc_util_es_Dom_addEventListener__WEBPACK_IMPORTED_MODULE_7__["default"])(window, 'resize', this.debouncedWindowResize);
      }
    }
    // when table changes to empty, reset scrollLeft
    if (prevProps.data.length > 0 && this.props.data.length === 0 && this.hasScrollX()) {
      this.resetScrollX();
    }
  };

  Table.prototype.componentWillUnmount = function componentWillUnmount() {
    if (this.resizeEvent) {
      this.resizeEvent.remove();
    }
    if (this.debouncedWindowResize) {
      this.debouncedWindowResize.cancel();
    }
  };

  Table.prototype.setScrollPosition = function setScrollPosition(position) {
    this.scrollPosition = position;
    if (this.tableNode) {
      var prefixCls = this.props.prefixCls;

      if (position === 'both') {
        component_classes__WEBPACK_IMPORTED_MODULE_10___default()(this.tableNode).remove(new RegExp('^' + prefixCls + '-scroll-position-.+$')).add(prefixCls + '-scroll-position-left').add(prefixCls + '-scroll-position-right');
      } else {
        component_classes__WEBPACK_IMPORTED_MODULE_10___default()(this.tableNode).remove(new RegExp('^' + prefixCls + '-scroll-position-.+$')).add(prefixCls + '-scroll-position-' + position);
      }
    }
  };

  Table.prototype.setScrollPositionClassName = function setScrollPositionClassName() {
    var node = this.bodyTable;
    var scrollToLeft = node.scrollLeft === 0;
    var scrollToRight = node.scrollLeft + 1 >= node.children[0].getBoundingClientRect().width - node.getBoundingClientRect().width;
    if (scrollToLeft && scrollToRight) {
      this.setScrollPosition('both');
    } else if (scrollToLeft) {
      this.setScrollPosition('left');
    } else if (scrollToRight) {
      this.setScrollPosition('right');
    } else if (this.scrollPosition !== 'middle') {
      this.setScrollPosition('middle');
    }
  };

  Table.prototype.resetScrollX = function resetScrollX() {
    if (this.headTable) {
      this.headTable.scrollLeft = 0;
    }
    if (this.bodyTable) {
      this.bodyTable.scrollLeft = 0;
    }
  };

  Table.prototype.hasScrollX = function hasScrollX() {
    var _props$scroll = this.props.scroll,
        scroll = _props$scroll === undefined ? {} : _props$scroll;

    return 'x' in scroll;
  };

  Table.prototype.renderMainTable = function renderMainTable() {
    var _props = this.props,
        scroll = _props.scroll,
        prefixCls = _props.prefixCls;

    var isAnyColumnsFixed = this.columnManager.isAnyColumnsFixed();
    var scrollable = isAnyColumnsFixed || scroll.x || scroll.y;

    var table = [this.renderTable({
      columns: this.columnManager.groupedColumns(),
      isAnyColumnsFixed: isAnyColumnsFixed
    }), this.renderEmptyText(), this.renderFooter()];

    return scrollable ? react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
      'div',
      { className: prefixCls + '-scroll' },
      table
    ) : table;
  };

  Table.prototype.renderLeftFixedTable = function renderLeftFixedTable() {
    var prefixCls = this.props.prefixCls;


    return react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
      'div',
      { className: prefixCls + '-fixed-left' },
      this.renderTable({
        columns: this.columnManager.leftColumns(),
        fixed: 'left'
      })
    );
  };

  Table.prototype.renderRightFixedTable = function renderRightFixedTable() {
    var prefixCls = this.props.prefixCls;


    return react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
      'div',
      { className: prefixCls + '-fixed-right' },
      this.renderTable({
        columns: this.columnManager.rightColumns(),
        fixed: 'right'
      })
    );
  };

  Table.prototype.renderTable = function renderTable(options) {
    var columns = options.columns,
        fixed = options.fixed,
        isAnyColumnsFixed = options.isAnyColumnsFixed;
    var _props2 = this.props,
        prefixCls = _props2.prefixCls,
        _props2$scroll = _props2.scroll,
        scroll = _props2$scroll === undefined ? {} : _props2$scroll;

    var tableClassName = scroll.x || fixed ? prefixCls + '-fixed' : '';

    var headTable = react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_HeadTable__WEBPACK_IMPORTED_MODULE_14__["default"], {
      key: 'head',
      columns: columns,
      fixed: fixed,
      tableClassName: tableClassName,
      handleBodyScrollLeft: this.handleBodyScrollLeft,
      expander: this.expander
    });

    var bodyTable = react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_BodyTable__WEBPACK_IMPORTED_MODULE_15__["default"], {
      key: 'body',
      columns: columns,
      fixed: fixed,
      tableClassName: tableClassName,
      getRowKey: this.getRowKey,
      handleWheel: this.handleWheel,
      handleBodyScroll: this.handleBodyScroll,
      expander: this.expander,
      isAnyColumnsFixed: isAnyColumnsFixed
    });

    return [headTable, bodyTable];
  };

  Table.prototype.renderTitle = function renderTitle() {
    var _props3 = this.props,
        title = _props3.title,
        prefixCls = _props3.prefixCls;

    return title ? react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
      'div',
      { className: prefixCls + '-title', key: 'title' },
      title(this.props.data)
    ) : null;
  };

  Table.prototype.renderFooter = function renderFooter() {
    var _props4 = this.props,
        footer = _props4.footer,
        prefixCls = _props4.prefixCls;

    return footer ? react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
      'div',
      { className: prefixCls + '-footer', key: 'footer' },
      footer(this.props.data)
    ) : null;
  };

  Table.prototype.renderEmptyText = function renderEmptyText() {
    var _props5 = this.props,
        emptyText = _props5.emptyText,
        prefixCls = _props5.prefixCls,
        data = _props5.data;

    if (data.length) {
      return null;
    }
    var emptyClassName = prefixCls + '-placeholder';
    return react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
      'div',
      { className: emptyClassName, key: 'emptyText' },
      typeof emptyText === 'function' ? emptyText() : emptyText
    );
  };

  Table.prototype.render = function render() {
    var _this2 = this;

    var props = this.props;
    var prefixCls = props.prefixCls;

    if (this.state.columns) {
      this.columnManager.reset(props.columns);
    } else if (this.state.children) {
      this.columnManager.reset(null, props.children);
    }

    var className = props.prefixCls;
    if (props.className) {
      className += ' ' + props.className;
    }
    if (props.useFixedHeader || props.scroll && props.scroll.y) {
      className += ' ' + prefixCls + '-fixed-header';
    }
    if (this.scrollPosition === 'both') {
      className += ' ' + prefixCls + '-scroll-position-left ' + prefixCls + '-scroll-position-right';
    } else {
      className += ' ' + prefixCls + '-scroll-position-' + this.scrollPosition;
    }
    var hasLeftFixed = this.columnManager.isAnyColumnsLeftFixed();
    var hasRightFixed = this.columnManager.isAnyColumnsRightFixed();

    return react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
      mini_store__WEBPACK_IMPORTED_MODULE_8__["Provider"],
      { store: this.store },
      react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
        _ExpandableTable__WEBPACK_IMPORTED_MODULE_16__["default"],
        babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({}, props, { columnManager: this.columnManager, getRowKey: this.getRowKey }),
        function (expander) {
          _this2.expander = expander;
          return react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
            'div',
            {
              ref: _this2.saveRef('tableNode'),
              className: className,
              style: props.style,
              id: props.id
            },
            _this2.renderTitle(),
            react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
              'div',
              { className: prefixCls + '-content' },
              _this2.renderMainTable(),
              hasLeftFixed && _this2.renderLeftFixedTable(),
              hasRightFixed && _this2.renderRightFixedTable()
            )
          );
        }
      )
    );
  };

  return Table;
}(react__WEBPACK_IMPORTED_MODULE_4___default.a.Component);

Table.propTypes = babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({
  data: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.array,
  useFixedHeader: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.bool,
  columns: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.array,
  prefixCls: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.string,
  bodyStyle: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.object,
  style: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.object,
  rowKey: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.func]),
  rowClassName: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.func]),
  onRow: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.func,
  onHeaderRow: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.func,
  onRowClick: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.func,
  onRowDoubleClick: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.func,
  onRowContextMenu: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.func,
  onRowMouseEnter: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.func,
  onRowMouseLeave: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.func,
  showHeader: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.bool,
  title: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.func,
  id: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.string,
  footer: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.func,
  emptyText: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.node, prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.func]),
  scroll: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.object,
  rowRef: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.func,
  getBodyWrapper: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.func,
  children: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.node,
  components: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.shape({
    table: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.any,
    header: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.shape({
      wrapper: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.any,
      row: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.any,
      cell: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.any
    }),
    body: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.shape({
      wrapper: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.any,
      row: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.any,
      cell: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.any
    })
  })
}, _ExpandableTable__WEBPACK_IMPORTED_MODULE_16__["default"].PropTypes);
Table.childContextTypes = {
  table: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.any,
  components: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.any
};
Table.defaultProps = {
  data: [],
  useFixedHeader: false,
  rowKey: 'key',
  rowClassName: function rowClassName() {
    return '';
  },
  onRow: function onRow() {},
  onHeaderRow: function onHeaderRow() {},

  prefixCls: 'rc-table',
  bodyStyle: {},
  style: {},
  showHeader: true,
  scroll: {},
  rowRef: function rowRef() {
    return null;
  },
  emptyText: function emptyText() {
    return 'No Data';
  }
};


Object(react_lifecycles_compat__WEBPACK_IMPORTED_MODULE_11__["polyfill"])(Table);

/* harmony default export */ __webpack_exports__["default"] = (Table);

/***/ }),

/***/ "../node_modules/rc-table/es/TableCell.js":
/*!************************************************!*\
  !*** ../node_modules/rc-table/es/TableCell.js ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! babel-runtime/helpers/extends */ "../node_modules/babel-runtime/helpers/extends.js");
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! babel-runtime/helpers/classCallCheck */ "../node_modules/babel-runtime/helpers/classCallCheck.js");
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! babel-runtime/helpers/possibleConstructorReturn */ "../node_modules/babel-runtime/helpers/possibleConstructorReturn.js");
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! babel-runtime/helpers/inherits */ "../node_modules/babel-runtime/helpers/inherits.js");
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var lodash_get__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! lodash/get */ "../node_modules/lodash/get.js");
/* harmony import */ var lodash_get__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(lodash_get__WEBPACK_IMPORTED_MODULE_6__);








function isInvalidRenderCellText(text) {
  return text && !react__WEBPACK_IMPORTED_MODULE_4___default.a.isValidElement(text) && Object.prototype.toString.call(text) === '[object Object]';
}

var TableCell = function (_React$Component) {
  babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3___default()(TableCell, _React$Component);

  function TableCell() {
    var _temp, _this, _ret;

    babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1___default()(this, TableCell);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2___default()(this, _React$Component.call.apply(_React$Component, [this].concat(args))), _this), _this.handleClick = function (e) {
      var _this$props = _this.props,
          record = _this$props.record,
          onCellClick = _this$props.column.onCellClick;

      if (onCellClick) {
        onCellClick(record, e);
      }
    }, _temp), babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2___default()(_this, _ret);
  }

  TableCell.prototype.render = function render() {
    var _props = this.props,
        record = _props.record,
        indentSize = _props.indentSize,
        prefixCls = _props.prefixCls,
        indent = _props.indent,
        index = _props.index,
        expandIcon = _props.expandIcon,
        column = _props.column,
        BodyCell = _props.component;
    var dataIndex = column.dataIndex,
        render = column.render,
        _column$className = column.className,
        className = _column$className === undefined ? '' : _column$className;

    // We should return undefined if no dataIndex is specified, but in order to
    // be compatible with object-path's behavior, we return the record object instead.

    var text = void 0;
    if (typeof dataIndex === 'number') {
      text = lodash_get__WEBPACK_IMPORTED_MODULE_6___default()(record, dataIndex);
    } else if (!dataIndex || dataIndex.length === 0) {
      text = record;
    } else {
      text = lodash_get__WEBPACK_IMPORTED_MODULE_6___default()(record, dataIndex);
    }
    var tdProps = {};
    var colSpan = void 0;
    var rowSpan = void 0;

    if (render) {
      text = render(text, record, index);
      if (isInvalidRenderCellText(text)) {
        tdProps = text.props || tdProps;
        colSpan = tdProps.colSpan;
        rowSpan = tdProps.rowSpan;
        text = text.children;
      }
    }

    if (column.onCell) {
      tdProps = babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({}, tdProps, column.onCell(record));
    }

    // Fix https://github.com/ant-design/ant-design/issues/1202
    if (isInvalidRenderCellText(text)) {
      text = null;
    }

    var indentText = expandIcon ? react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement('span', {
      style: { paddingLeft: indentSize * indent + 'px' },
      className: prefixCls + '-indent indent-level-' + indent
    }) : null;

    if (rowSpan === 0 || colSpan === 0) {
      return null;
    }

    if (column.align) {
      tdProps.style = { textAlign: column.align };
    }

    return react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
      BodyCell,
      babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({ className: className, onClick: this.handleClick }, tdProps),
      indentText,
      expandIcon,
      text
    );
  };

  return TableCell;
}(react__WEBPACK_IMPORTED_MODULE_4___default.a.Component);

TableCell.propTypes = {
  record: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.object,
  prefixCls: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.string,
  index: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.number,
  indent: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.number,
  indentSize: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.number,
  column: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.object,
  expandIcon: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.node,
  component: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.any
};
/* harmony default export */ __webpack_exports__["default"] = (TableCell);

/***/ }),

/***/ "../node_modules/rc-table/es/TableHeader.js":
/*!**************************************************!*\
  !*** ../node_modules/rc-table/es/TableHeader.js ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return TableHeader; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _TableHeaderRow__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./TableHeaderRow */ "../node_modules/rc-table/es/TableHeaderRow.js");




function getHeaderRows(columns) {
  var currentRow = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
  var rows = arguments[2];

  rows = rows || [];
  rows[currentRow] = rows[currentRow] || [];

  columns.forEach(function (column) {
    if (column.rowSpan && rows.length < column.rowSpan) {
      while (rows.length < column.rowSpan) {
        rows.push([]);
      }
    }
    var cell = {
      key: column.key,
      className: column.className || '',
      children: column.title,
      column: column
    };
    if (column.children) {
      getHeaderRows(column.children, currentRow + 1, rows);
    }
    if ('colSpan' in column) {
      cell.colSpan = column.colSpan;
    }
    if ('rowSpan' in column) {
      cell.rowSpan = column.rowSpan;
    }
    if (cell.colSpan !== 0) {
      rows[currentRow].push(cell);
    }
  });
  return rows.filter(function (row) {
    return row.length > 0;
  });
}

function TableHeader(props, _ref) {
  var table = _ref.table;
  var components = table.components;
  var _table$props = table.props,
      prefixCls = _table$props.prefixCls,
      showHeader = _table$props.showHeader,
      onHeaderRow = _table$props.onHeaderRow;
  var expander = props.expander,
      columns = props.columns,
      fixed = props.fixed;


  if (!showHeader) {
    return null;
  }

  var rows = getHeaderRows(columns);

  expander.renderExpandIndentCell(rows, fixed);

  var HeaderWrapper = components.header.wrapper;

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
    HeaderWrapper,
    { className: prefixCls + '-thead' },
    rows.map(function (row, index) {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_TableHeaderRow__WEBPACK_IMPORTED_MODULE_2__["default"], {
        key: index,
        index: index,
        fixed: fixed,
        columns: columns,
        rows: rows,
        row: row,
        components: components,
        onHeaderRow: onHeaderRow
      });
    })
  );
}

TableHeader.propTypes = {
  fixed: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  columns: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.array.isRequired,
  expander: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object.isRequired,
  onHeaderRow: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func
};

TableHeader.contextTypes = {
  table: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.any
};

/***/ }),

/***/ "../node_modules/rc-table/es/TableHeaderRow.js":
/*!*****************************************************!*\
  !*** ../node_modules/rc-table/es/TableHeaderRow.js ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! babel-runtime/helpers/objectWithoutProperties */ "../node_modules/babel-runtime/helpers/objectWithoutProperties.js");
/* harmony import */ var babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! babel-runtime/helpers/extends */ "../node_modules/babel-runtime/helpers/extends.js");
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var mini_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! mini-store */ "../node_modules/mini-store/lib/index.js");
/* harmony import */ var mini_store__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(mini_store__WEBPACK_IMPORTED_MODULE_4__);






function TableHeaderRow(_ref) {
  var row = _ref.row,
      index = _ref.index,
      height = _ref.height,
      components = _ref.components,
      onHeaderRow = _ref.onHeaderRow;

  var HeaderRow = components.header.row;
  var HeaderCell = components.header.cell;
  var rowProps = onHeaderRow(row.map(function (cell) {
    return cell.column;
  }), index);
  var customStyle = rowProps ? rowProps.style : {};
  var style = babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_1___default()({ height: height }, customStyle);

  return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
    HeaderRow,
    babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_1___default()({}, rowProps, { style: style }),
    row.map(function (cell, i) {
      var column = cell.column,
          cellProps = babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_0___default()(cell, ['column']);

      var customProps = column.onHeaderCell ? column.onHeaderCell(column) : {};
      if (column.align) {
        cellProps.style = { textAlign: column.align };
      }
      return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(HeaderCell, babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_1___default()({}, cellProps, customProps, { key: column.key || column.dataIndex || i }));
    })
  );
}

TableHeaderRow.propTypes = {
  row: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.array,
  index: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.number,
  height: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.number]),
  components: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.any,
  onHeaderRow: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.func
};

function getRowHeight(state, props) {
  var fixedColumnsHeadRowsHeight = state.fixedColumnsHeadRowsHeight;
  var columns = props.columns,
      rows = props.rows,
      fixed = props.fixed;

  var headerHeight = fixedColumnsHeadRowsHeight[0];

  if (!fixed) {
    return null;
  }

  if (headerHeight && columns) {
    if (headerHeight === 'auto') {
      return 'auto';
    }
    return headerHeight / rows.length;
  }
  return null;
}

/* harmony default export */ __webpack_exports__["default"] = (Object(mini_store__WEBPACK_IMPORTED_MODULE_4__["connect"])(function (state, props) {
  return {
    height: getRowHeight(state, props)
  };
})(TableHeaderRow));

/***/ }),

/***/ "../node_modules/rc-table/es/TableRow.js":
/*!***********************************************!*\
  !*** ../node_modules/rc-table/es/TableRow.js ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! babel-runtime/helpers/extends */ "../node_modules/babel-runtime/helpers/extends.js");
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! babel-runtime/helpers/classCallCheck */ "../node_modules/babel-runtime/helpers/classCallCheck.js");
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! babel-runtime/helpers/possibleConstructorReturn */ "../node_modules/babel-runtime/helpers/possibleConstructorReturn.js");
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! babel-runtime/helpers/inherits */ "../node_modules/babel-runtime/helpers/inherits.js");
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-dom */ "../node_modules/react-dom/index.js");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var mini_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! mini-store */ "../node_modules/mini-store/lib/index.js");
/* harmony import */ var mini_store__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(mini_store__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_lifecycles_compat__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-lifecycles-compat */ "../node_modules/react-lifecycles-compat/react-lifecycles-compat.es.js");
/* harmony import */ var _TableCell__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./TableCell */ "../node_modules/rc-table/es/TableCell.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./utils */ "../node_modules/rc-table/es/utils.js");












var TableRow = function (_React$Component) {
  babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3___default()(TableRow, _React$Component);

  TableRow.getDerivedStateFromProps = function getDerivedStateFromProps(nextProps, prevState) {
    if (prevState.visible || !prevState.visible && nextProps.visible) {
      return {
        shouldRender: true,
        visible: nextProps.visible
      };
    }
    return {
      visible: nextProps.visible
    };
  };

  function TableRow(props) {
    babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1___default()(this, TableRow);

    var _this = babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2___default()(this, _React$Component.call(this, props));

    _this.onRowClick = function (event) {
      var _this$props = _this.props,
          record = _this$props.record,
          index = _this$props.index,
          onRowClick = _this$props.onRowClick;

      if (onRowClick) {
        onRowClick(record, index, event);
      }
    };

    _this.onRowDoubleClick = function (event) {
      var _this$props2 = _this.props,
          record = _this$props2.record,
          index = _this$props2.index,
          onRowDoubleClick = _this$props2.onRowDoubleClick;

      if (onRowDoubleClick) {
        onRowDoubleClick(record, index, event);
      }
    };

    _this.onContextMenu = function (event) {
      var _this$props3 = _this.props,
          record = _this$props3.record,
          index = _this$props3.index,
          onRowContextMenu = _this$props3.onRowContextMenu;

      if (onRowContextMenu) {
        onRowContextMenu(record, index, event);
      }
    };

    _this.onMouseEnter = function (event) {
      var _this$props4 = _this.props,
          record = _this$props4.record,
          index = _this$props4.index,
          onRowMouseEnter = _this$props4.onRowMouseEnter,
          onHover = _this$props4.onHover,
          rowKey = _this$props4.rowKey;

      onHover(true, rowKey);
      if (onRowMouseEnter) {
        onRowMouseEnter(record, index, event);
      }
    };

    _this.onMouseLeave = function (event) {
      var _this$props5 = _this.props,
          record = _this$props5.record,
          index = _this$props5.index,
          onRowMouseLeave = _this$props5.onRowMouseLeave,
          onHover = _this$props5.onHover,
          rowKey = _this$props5.rowKey;

      onHover(false, rowKey);
      if (onRowMouseLeave) {
        onRowMouseLeave(record, index, event);
      }
    };

    _this.shouldRender = props.visible;

    _this.state = {};
    return _this;
  }

  TableRow.prototype.componentDidMount = function componentDidMount() {
    if (this.state.shouldRender) {
      this.saveRowRef();
    }
  };

  TableRow.prototype.shouldComponentUpdate = function shouldComponentUpdate(nextProps) {
    return !!(this.props.visible || nextProps.visible);
  };

  TableRow.prototype.componentDidUpdate = function componentDidUpdate() {
    if (this.state.shouldRender && !this.rowRef) {
      this.saveRowRef();
    }
  };

  TableRow.prototype.setExpanedRowHeight = function setExpanedRowHeight() {
    var _extends2;

    var _props = this.props,
        store = _props.store,
        rowKey = _props.rowKey;

    var _store$getState = store.getState(),
        expandedRowsHeight = _store$getState.expandedRowsHeight;

    var height = this.rowRef.getBoundingClientRect().height;
    expandedRowsHeight = babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({}, expandedRowsHeight, (_extends2 = {}, _extends2[rowKey] = height, _extends2));
    store.setState({ expandedRowsHeight: expandedRowsHeight });
  };

  TableRow.prototype.setRowHeight = function setRowHeight() {
    var _props2 = this.props,
        store = _props2.store,
        index = _props2.index;

    var fixedColumnsBodyRowsHeight = store.getState().fixedColumnsBodyRowsHeight.slice();
    var height = this.rowRef.getBoundingClientRect().height;
    fixedColumnsBodyRowsHeight[index] = height;
    store.setState({ fixedColumnsBodyRowsHeight: fixedColumnsBodyRowsHeight });
  };

  TableRow.prototype.getStyle = function getStyle() {
    var _props3 = this.props,
        height = _props3.height,
        visible = _props3.visible;


    if (height && height !== this.style.height) {
      this.style = babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({}, this.style, { height: height });
    }

    if (!visible && !this.style.display) {
      this.style = babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({}, this.style, { display: 'none' });
    }

    return this.style;
  };

  TableRow.prototype.saveRowRef = function saveRowRef() {
    this.rowRef = react_dom__WEBPACK_IMPORTED_MODULE_5___default.a.findDOMNode(this);

    var _props4 = this.props,
        isAnyColumnsFixed = _props4.isAnyColumnsFixed,
        fixed = _props4.fixed,
        expandedRow = _props4.expandedRow,
        ancestorKeys = _props4.ancestorKeys;


    if (!isAnyColumnsFixed) {
      return;
    }

    if (!fixed && expandedRow) {
      this.setExpanedRowHeight();
    }

    if (!fixed && ancestorKeys.length >= 0) {
      this.setRowHeight();
    }
  };

  TableRow.prototype.render = function render() {
    if (!this.state.shouldRender) {
      return null;
    }

    var _props5 = this.props,
        prefixCls = _props5.prefixCls,
        columns = _props5.columns,
        record = _props5.record,
        index = _props5.index,
        onRow = _props5.onRow,
        indent = _props5.indent,
        indentSize = _props5.indentSize,
        hovered = _props5.hovered,
        height = _props5.height,
        visible = _props5.visible,
        components = _props5.components,
        hasExpandIcon = _props5.hasExpandIcon,
        renderExpandIcon = _props5.renderExpandIcon,
        renderExpandIconCell = _props5.renderExpandIconCell;


    var BodyRow = components.body.row;
    var BodyCell = components.body.cell;

    var className = this.props.className;


    if (hovered) {
      className += ' ' + prefixCls + '-hover';
    }

    var cells = [];

    renderExpandIconCell(cells);

    for (var i = 0; i < columns.length; i++) {
      var column = columns[i];

      Object(_utils__WEBPACK_IMPORTED_MODULE_10__["warningOnce"])(column.onCellClick === undefined, 'column[onCellClick] is deprecated, please use column[onCell] instead.');

      cells.push(react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_TableCell__WEBPACK_IMPORTED_MODULE_9__["default"], {
        prefixCls: prefixCls,
        record: record,
        indentSize: indentSize,
        indent: indent,
        index: index,
        column: column,
        key: column.key || column.dataIndex,
        expandIcon: hasExpandIcon(i) && renderExpandIcon(),
        component: BodyCell
      }));
    }

    var rowClassName = (prefixCls + ' ' + className + ' ' + prefixCls + '-level-' + indent).trim();

    var rowProps = onRow(record, index);
    var customStyle = rowProps ? rowProps.style : {};
    var style = { height: height };

    if (!visible) {
      style.display = 'none';
    }

    style = babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({}, style, customStyle);

    return react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
      BodyRow,
      babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({
        onClick: this.onRowClick,
        onDoubleClick: this.onRowDoubleClick,
        onMouseEnter: this.onMouseEnter,
        onMouseLeave: this.onMouseLeave,
        onContextMenu: this.onContextMenu,
        className: rowClassName
      }, rowProps, {
        style: style
      }),
      cells
    );
  };

  return TableRow;
}(react__WEBPACK_IMPORTED_MODULE_4___default.a.Component);

TableRow.propTypes = {
  onRow: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.func,
  onRowClick: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.func,
  onRowDoubleClick: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.func,
  onRowContextMenu: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.func,
  onRowMouseEnter: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.func,
  onRowMouseLeave: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.func,
  record: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.object,
  prefixCls: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.string,
  onHover: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.func,
  columns: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.array,
  height: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.number]),
  index: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.number,
  rowKey: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.number]).isRequired,
  className: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.string,
  indent: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.number,
  indentSize: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.number,
  hasExpandIcon: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.func,
  hovered: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.bool.isRequired,
  visible: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.bool.isRequired,
  store: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.object.isRequired,
  fixed: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.bool]),
  renderExpandIcon: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.func,
  renderExpandIconCell: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.func,
  components: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.any,
  expandedRow: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.bool,
  isAnyColumnsFixed: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.bool,
  ancestorKeys: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.array.isRequired
};
TableRow.defaultProps = {
  onRow: function onRow() {},
  onHover: function onHover() {},
  hasExpandIcon: function hasExpandIcon() {},
  renderExpandIcon: function renderExpandIcon() {},
  renderExpandIconCell: function renderExpandIconCell() {}
};


function getRowHeight(state, props) {
  var expandedRowsHeight = state.expandedRowsHeight,
      fixedColumnsBodyRowsHeight = state.fixedColumnsBodyRowsHeight;
  var fixed = props.fixed,
      index = props.index,
      rowKey = props.rowKey;


  if (!fixed) {
    return null;
  }

  if (expandedRowsHeight[rowKey]) {
    return expandedRowsHeight[rowKey];
  }

  if (fixedColumnsBodyRowsHeight[index]) {
    return fixedColumnsBodyRowsHeight[index];
  }

  return null;
}

Object(react_lifecycles_compat__WEBPACK_IMPORTED_MODULE_8__["polyfill"])(TableRow);

/* harmony default export */ __webpack_exports__["default"] = (Object(mini_store__WEBPACK_IMPORTED_MODULE_7__["connect"])(function (state, props) {
  var currentHoverKey = state.currentHoverKey,
      expandedRowKeys = state.expandedRowKeys;
  var rowKey = props.rowKey,
      ancestorKeys = props.ancestorKeys;

  var visible = ancestorKeys.length === 0 || ancestorKeys.every(function (k) {
    return ~expandedRowKeys.indexOf(k);
  });

  return {
    visible: visible,
    hovered: currentHoverKey === rowKey,
    height: getRowHeight(state, props)
  };
})(TableRow));

/***/ }),

/***/ "../node_modules/rc-table/es/index.js":
/*!********************************************!*\
  !*** ../node_modules/rc-table/es/index.js ***!
  \********************************************/
/*! exports provided: default, Column, ColumnGroup */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Table__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Table */ "../node_modules/rc-table/es/Table.js");
/* harmony import */ var _Column__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Column */ "../node_modules/rc-table/es/Column.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Column", function() { return _Column__WEBPACK_IMPORTED_MODULE_1__["default"]; });

/* harmony import */ var _ColumnGroup__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ColumnGroup */ "../node_modules/rc-table/es/ColumnGroup.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ColumnGroup", function() { return _ColumnGroup__WEBPACK_IMPORTED_MODULE_2__["default"]; });





_Table__WEBPACK_IMPORTED_MODULE_0__["default"].Column = _Column__WEBPACK_IMPORTED_MODULE_1__["default"];
_Table__WEBPACK_IMPORTED_MODULE_0__["default"].ColumnGroup = _ColumnGroup__WEBPACK_IMPORTED_MODULE_2__["default"];

/* harmony default export */ __webpack_exports__["default"] = (_Table__WEBPACK_IMPORTED_MODULE_0__["default"]);


/***/ }),

/***/ "../node_modules/rc-table/es/utils.js":
/*!********************************************!*\
  !*** ../node_modules/rc-table/es/utils.js ***!
  \********************************************/
/*! exports provided: measureScrollbar, debounce, warningOnce, remove */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "measureScrollbar", function() { return measureScrollbar; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "debounce", function() { return debounce; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "warningOnce", function() { return warningOnce; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "remove", function() { return remove; });
/* harmony import */ var warning__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! warning */ "../node_modules/warning/browser.js");
/* harmony import */ var warning__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(warning__WEBPACK_IMPORTED_MODULE_0__);


var scrollbarSize = void 0;

// Measure scrollbar width for padding body during modal show/hide
var scrollbarMeasure = {
  position: 'absolute',
  top: '-9999px',
  width: '50px',
  height: '50px',
  overflow: 'scroll'
};

function measureScrollbar() {
  var direction = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'vertical';

  if (typeof document === 'undefined' || typeof window === 'undefined') {
    return 0;
  }
  if (scrollbarSize) {
    return scrollbarSize;
  }
  var scrollDiv = document.createElement('div');
  Object.keys(scrollbarMeasure).forEach(function (scrollProp) {
    scrollDiv.style[scrollProp] = scrollbarMeasure[scrollProp];
  });
  document.body.appendChild(scrollDiv);
  var size = 0;
  if (direction === 'vertical') {
    size = scrollDiv.offsetWidth - scrollDiv.clientWidth;
  } else if (direction === 'horizontal') {
    size = scrollDiv.offsetHeight - scrollDiv.clientHeight;
  }

  document.body.removeChild(scrollDiv);
  scrollbarSize = size;
  return scrollbarSize;
}

function debounce(func, wait, immediate) {
  var timeout = void 0;
  function debounceFunc() {
    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    var context = this;
    // https://fb.me/react-event-pooling
    if (args[0] && args[0].persist) {
      args[0].persist();
    }
    var later = function later() {
      timeout = null;
      if (!immediate) {
        func.apply(context, args);
      }
    };
    var callNow = immediate && !timeout;
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
    if (callNow) {
      func.apply(context, args);
    }
  }
  debounceFunc.cancel = function cancel() {
    if (timeout) {
      clearTimeout(timeout);
      timeout = null;
    }
  };
  return debounceFunc;
}

var warned = {};
function warningOnce(condition, format, args) {
  if (!warned[format]) {
    warning__WEBPACK_IMPORTED_MODULE_0___default()(condition, format, args);
    warned[format] = !condition;
  }
}

function remove(array, item) {
  var index = array.indexOf(item);
  var front = array.slice(0, index);
  var last = array.slice(index + 1, array.length);
  return front.concat(last);
}

/***/ }),

/***/ "../node_modules/rc-util/es/getScrollBarSize.js":
/*!******************************************************!*\
  !*** ../node_modules/rc-util/es/getScrollBarSize.js ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return getScrollBarSize; });
var cached = void 0;

function getScrollBarSize(fresh) {
  if (fresh || cached === undefined) {
    var inner = document.createElement('div');
    inner.style.width = '100%';
    inner.style.height = '200px';

    var outer = document.createElement('div');
    var outerStyle = outer.style;

    outerStyle.position = 'absolute';
    outerStyle.top = 0;
    outerStyle.left = 0;
    outerStyle.pointerEvents = 'none';
    outerStyle.visibility = 'hidden';
    outerStyle.width = '200px';
    outerStyle.height = '150px';
    outerStyle.overflow = 'hidden';

    outer.appendChild(inner);

    document.body.appendChild(outer);

    var widthContained = inner.offsetWidth;
    outer.style.overflow = 'scroll';
    var widthScroll = inner.offsetWidth;

    if (widthContained === widthScroll) {
      widthScroll = outer.clientWidth;
    }

    document.body.removeChild(outer);

    cached = widthContained - widthScroll;
  }
  return cached;
}

/***/ }),

/***/ "./pages/setting/setting.css":
/*!***********************************!*\
  !*** ./pages/setting/setting.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../node_modules/css-loader??ref--5-1!./setting.css */ "../node_modules/css-loader/index.js??ref--5-1!./pages/setting/setting.css");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../node_modules/style-loader/lib/addStyles.js */ "../node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(true) {
	module.hot.accept(/*! !../../../node_modules/css-loader??ref--5-1!./setting.css */ "../node_modules/css-loader/index.js??ref--5-1!./pages/setting/setting.css", function(__WEBPACK_OUTDATED_DEPENDENCIES__) { (function() {
		var newContent = __webpack_require__(/*! !../../../node_modules/css-loader??ref--5-1!./setting.css */ "../node_modules/css-loader/index.js??ref--5-1!./pages/setting/setting.css");

		if(typeof newContent === 'string') newContent = [[module.i, newContent, '']];

		var locals = (function(a, b) {
			var key, idx = 0;

			for(key in a) {
				if(!b || a[key] !== b[key]) return false;
				idx++;
			}

			for(key in b) idx--;

			return idx === 0;
		}(content.locals, newContent.locals));

		if(!locals) throw new Error('Aborting CSS HMR due to changed css-modules locals.');

		update(newContent);
	})(__WEBPACK_OUTDATED_DEPENDENCIES__); });

	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./pages/setting/setting.js":
/*!**********************************!*\
  !*** ./pages/setting/setting.js ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(module) {

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _icon = __webpack_require__(/*! antd/es/icon */ "../node_modules/antd/es/icon/index.js");

var _icon2 = _interopRequireDefault(_icon);

var _card = __webpack_require__(/*! antd/es/card */ "../node_modules/antd/es/card/index.js");

var _card2 = _interopRequireDefault(_card);

var _table = __webpack_require__(/*! antd/es/table */ "../node_modules/antd/es/table/index.js");

var _table2 = _interopRequireDefault(_table);

var _modal = __webpack_require__(/*! antd/es/modal */ "../node_modules/antd/es/modal/index.js");

var _modal2 = _interopRequireDefault(_modal);

var _form = __webpack_require__(/*! antd/es/form */ "../node_modules/antd/es/form/index.js");

var _form2 = _interopRequireDefault(_form);

var _input = __webpack_require__(/*! antd/es/input */ "../node_modules/antd/es/input/index.js");

var _input2 = _interopRequireDefault(_input);

var _button = __webpack_require__(/*! antd/es/button */ "../node_modules/antd/es/button/index.js");

var _button2 = _interopRequireDefault(_button);

var _message2 = __webpack_require__(/*! antd/es/message */ "../node_modules/antd/es/message/index.js");

var _message3 = _interopRequireDefault(_message2);

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

__webpack_require__(/*! antd/es/icon/style/css */ "../node_modules/antd/es/icon/style/css.js");

__webpack_require__(/*! antd/es/card/style/css */ "../node_modules/antd/es/card/style/css.js");

__webpack_require__(/*! antd/es/table/style/css */ "../node_modules/antd/es/table/style/css.js");

__webpack_require__(/*! antd/es/modal/style/css */ "../node_modules/antd/es/modal/style/css.js");

__webpack_require__(/*! antd/es/form/style/css */ "../node_modules/antd/es/form/style/css.js");

__webpack_require__(/*! antd/es/input/style/css */ "../node_modules/antd/es/input/style/css.js");

__webpack_require__(/*! antd/es/button/style/css */ "../node_modules/antd/es/button/style/css.js");

__webpack_require__(/*! antd/es/message/style/css */ "../node_modules/antd/es/message/style/css.js");

var _react = __webpack_require__(/*! react */ "../node_modules/react/index.js");

var _react2 = _interopRequireDefault(_react);

var _setting = __webpack_require__(/*! ./setting.css */ "./pages/setting/setting.css");

var _setting2 = _interopRequireDefault(_setting);

var _request = __webpack_require__(/*! ../../helpers/request */ "./helpers/request.js");

var _request2 = _interopRequireDefault(_request);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(function () {
  var enterModule = __webpack_require__(/*! react-hot-loader */ "../node_modules/react-hot-loader/index.js").enterModule;

  enterModule && enterModule(module);
})();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Setting = function (_React$Component) {
  _inherits(Setting, _React$Component);

  function Setting() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, Setting);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Setting.__proto__ || Object.getPrototypeOf(Setting)).call.apply(_ref, [this].concat(args))), _this), _this.state = {
      visible: false,
      admin: [],
      assist: [],
      id: null
    }, _this.hasErrors = function (errors) {
      return Object.keys(errors).some(function (key) {
        return errors[key];
      });
    }, _this.handleAdd = function () {
      _this.setState({
        visible: true
      }, function () {
        _this.props.form.validateFields();
      });
    }, _this.closeModal = function () {
      _this.setState({
        visible: false,
        id: ''
      });
    }, _this.getAccountList = function () {
      (0, _request2.default)({
        url: '/api/web_account_list',
        data: {},
        success: function success(_ref2) {
          var data = _ref2.data;

          var admin = [],
              assist = [];
          data.map(function (per) {
            if (per.type === 0) {
              admin.push(per);
            } else if (per.type === 1) {
              assist.push(per);
            }
          });
          _this.setState({
            admin: admin,
            assist: assist
          });
        }
      });
    }, _this.setAccount = function () {
      var user = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

      _this.setState({
        id: user.id,
        visible: true
      }, function () {
        _this.props.form.validateFields();
        if (user) {
          _this.props.form.setFieldsValue({
            name: user.name,
            user: user.the_user
          });
        }
      });
    }, _this.renewAccountPassword = function (id) {
      var values = _this.props.form.getFieldsValue();
      (0, _request2.default)({
        url: '/api/web_modify',
        data: {
          id: id,
          type: 1,
          the_password: values['password']
        },
        success: function success(_ref3) {
          var data = _ref3.data;

          _this.closeModal();
        }
      });
    }, _this.deleteAccount = function (id) {
      (0, _request2.default)({
        url: '/api/web_modify',
        data: {
          id: id,
          type: 0
        },
        success: function success(_ref4) {
          var data = _ref4.data;

          _this.getAccountList();
        }
      });
    }, _this.modalEnsure = function () {
      var id = _this.state.id;
      if (id) {
        _this.renewAccountPassword(id);
      } else {
        _this.requestAdd();
      }
    }, _this.requestAdd = function () {
      var _this$props$form$getF = _this.props.form.getFieldsValue(),
          name = _this$props$form$getF.name,
          user = _this$props$form$getF.user,
          password = _this$props$form$getF.password;

      (0, _request2.default)({
        url: '/api/web_register',
        data: {
          name: name,
          user: user,
          password: password
        },
        success: function success() {
          _this.closeModal();
          _this.getAccountList();
        },
        fail: function fail(res) {
          _message3.default.error(res.msg);
        }
      });
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(Setting, [{
    key: 'render',
    value: function render() {
      var _this2 = this;

      var _state = this.state,
          visible = _state.visible,
          admin = _state.admin,
          assist = _state.assist,
          id = _state.id;
      var _props$form = this.props.form,
          getFieldDecorator = _props$form.getFieldDecorator,
          getFieldsError = _props$form.getFieldsError,
          isFieldTouched = _props$form.isFieldTouched,
          getFieldError = _props$form.getFieldError;

      var userErr = isFieldTouched('name') && getFieldError('name');
      var accountErr = isFieldTouched('user') && getFieldError('user');
      var passwordErr = isFieldTouched('password') && getFieldError('password');
      var modalFooter = _react2.default.createElement(
        'footer',
        null,
        _react2.default.createElement(
          _button2.default,
          { onClick: this.closeModal },
          '\u53D6\u6D88'
        ),
        _react2.default.createElement(
          _button2.default,
          { type: 'primary', onClick: this.modalEnsure, disabled: this.hasErrors(getFieldsError()) },
          '\u786E\u8BA4'
        )
      );
      var AddModal = _react2.default.createElement(
        _modal2.default,
        { width: 650, title: id ? '修改账号密码' : '新增审核员账号', destroyOnClose: true, visible: visible, footer: modalFooter, onCancel: this.closeModal },
        _react2.default.createElement(
          _form2.default,
          { className: _setting2.default.form },
          _react2.default.createElement(
            _form2.default.Item,
            { label: '\u59D3\u540D', help: userErr ? userErr : null, validateStatus: userErr ? 'error' : '' },
            getFieldDecorator('name', {
              rules: [{
                required: true,
                message: '姓名不能为空'
              }]
            })(_react2.default.createElement(_input2.default, { size: 'large', disabled: !!id }))
          ),
          _react2.default.createElement(
            _form2.default.Item,
            { label: '\u767B\u9646\u8D26\u53F7', help: accountErr ? userErr : null, validateStatus: accountErr ? 'error' : '' },
            getFieldDecorator('user', {
              rules: [{
                required: true,
                message: '账号不能为空'
              }]
            })(_react2.default.createElement(_input2.default, { size: 'large', disabled: !!id }))
          ),
          _react2.default.createElement(
            _form2.default.Item,
            { label: '\u5BC6\u7801', help: passwordErr ? userErr : null, validateStatus: passwordErr ? 'error' : '' },
            getFieldDecorator('password', {
              rules: [{
                required: true,
                message: '密码不能为空'
              }]
            })(_react2.default.createElement(_input2.default, { size: 'large' }))
          )
        )
      );
      var adminColumns = [{
        title: '姓名',
        dataIndex: 'name'
      }, {
        title: '登陆账号',
        dataIndex: 'the_user'
      }, {
        title: '添加时间',
        dataIndex: 'create_time',
        render: function render(text) {
          return _react2.default.createElement(
            'span',
            null,
            text || '-'
          );
        }
      }, {
        title: '上次登陆时间',
        dataIndex: 'last_time',
        render: function render(text) {
          return _react2.default.createElement(
            'span',
            null,
            text || '-'
          );
        }
      }, {
        title: '操作',
        render: function render(text, record) {
          return _react2.default.createElement(
            'span',
            null,
            _react2.default.createElement(
              'a',
              { onClick: function onClick() {
                  return _this2.setAccount(record);
                } },
              '\u4FEE\u6539'
            )
          );
        }
      }];
      var assistColumns = [{
        title: '姓名',
        dataIndex: 'name'
      }, {
        title: '登陆账号',
        dataIndex: 'the_user'
      }, {
        title: '添加时间',
        dataIndex: 'create_time',
        render: function render(text) {
          return _react2.default.createElement(
            'span',
            null,
            text || '-'
          );
        }
      }, {
        title: '上次登陆时间',
        dataIndex: 'last_time',
        render: function render(text) {
          return _react2.default.createElement(
            'span',
            null,
            text || '-'
          );
        }
      }, {
        title: '操作',
        render: function render(text, record) {
          return _react2.default.createElement(
            'span',
            null,
            admin.length < 1 ? _react2.default.createElement(
              'a',
              { onClick: function onClick() {
                  return _this2.setAccount(record);
                } },
              '\u4FEE\u6539'
            ) : null,
            admin.length > 0 ? _react2.default.createElement(
              'a',
              { onClick: function onClick() {
                  return _this2.deleteAccount(record.id);
                } },
              '\u5220\u9664'
            ) : null
          );
        }
      }];
      return _react2.default.createElement(
        'div',
        null,
        admin.length < 1 ? null : _react2.default.createElement(
          _card2.default,
          {
            title: '\u7BA1\u7406\u5458',
            className: _setting2.default["card-margin"] },
          _react2.default.createElement(_table2.default, { columns: adminColumns, dataSource: admin, pagination: false, rowKey: 'id' })
        ),
        _react2.default.createElement(
          _card2.default,
          {
            title: '\u5BA1\u6838\u5458'
          },
          _react2.default.createElement(_table2.default, { columns: assistColumns, dataSource: assist, pagination: false, rowKey: 'id' }),
          admin.length < 1 ? null : _react2.default.createElement(
            _button2.default,
            { className: _setting2.default['add-account'], size: 'large', onClick: this.handleAdd },
            _react2.default.createElement(_icon2.default, { type: 'plus' }),
            '\u6DFB\u52A0'
          )
        ),
        AddModal
      );
    }
  }, {
    key: 'componentDidMount',
    value: function componentDidMount() {
      this.props.form.validateFields();
      this.getAccountList();
    }
  }, {
    key: '__reactstandin__regenerateByEval',
    value: function __reactstandin__regenerateByEval(key, code) {
      this[key] = eval(code);
    }
  }]);

  return Setting;
}(_react2.default.Component);

var SettingForm = _form2.default.create()(Setting);
var _default = SettingForm;
exports.default = _default;
;

(function () {
  var reactHotLoader = __webpack_require__(/*! react-hot-loader */ "../node_modules/react-hot-loader/index.js").default;

  var leaveModule = __webpack_require__(/*! react-hot-loader */ "../node_modules/react-hot-loader/index.js").leaveModule;

  if (!reactHotLoader) {
    return;
  }

  reactHotLoader.register(Setting, 'Setting', 'E:/frontend/jhgsj-report/pc/src/pages/setting/setting.js');
  reactHotLoader.register(SettingForm, 'SettingForm', 'E:/frontend/jhgsj-report/pc/src/pages/setting/setting.js');
  reactHotLoader.register(_default, 'default', 'E:/frontend/jhgsj-report/pc/src/pages/setting/setting.js');
  leaveModule(module);
})();

;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/webpack/buildin/module.js */ "../node_modules/webpack/buildin/module.js")(module)))

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2FudGQvZXMvbWVzc2FnZS9zdHlsZS9pbmRleC5jc3M/YjhhOCIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2FudGQvZXMvbW9kYWwvc3R5bGUvaW5kZXguY3NzPzU5N2UiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9hbnRkL2VzL3JhZGlvL3N0eWxlL2luZGV4LmNzcz85MjI4Iiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvYW50ZC9lcy90YWJsZS9zdHlsZS9pbmRleC5jc3M/ZDdiZiIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2FudGQvZXMvbWVzc2FnZS9zdHlsZS9pbmRleC5jc3MiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9hbnRkL2VzL21vZGFsL3N0eWxlL2luZGV4LmNzcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2FudGQvZXMvcmFkaW8vc3R5bGUvaW5kZXguY3NzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvYW50ZC9lcy90YWJsZS9zdHlsZS9pbmRleC5jc3MiLCJ3ZWJwYWNrOi8vLy4vcGFnZXMvc2V0dGluZy9zZXR0aW5nLmNzcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2RvbS1jbG9zZXN0L2luZGV4LmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvZG9tLW1hdGNoZXMvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9sb2Rhc2gvX1N0YWNrLmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvbG9kYXNoL19VaW50OEFycmF5LmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvbG9kYXNoL19hcHBseS5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2xvZGFzaC9fYXJyYXlMaWtlS2V5cy5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2xvZGFzaC9fYXNzaWduTWVyZ2VWYWx1ZS5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2xvZGFzaC9fYmFzZUNyZWF0ZS5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2xvZGFzaC9fYmFzZUZvci5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2xvZGFzaC9fYmFzZUlzVHlwZWRBcnJheS5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2xvZGFzaC9fYmFzZUtleXNJbi5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2xvZGFzaC9fYmFzZU1lcmdlLmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvbG9kYXNoL19iYXNlTWVyZ2VEZWVwLmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvbG9kYXNoL19iYXNlUmVzdC5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2xvZGFzaC9fYmFzZVNldFRvU3RyaW5nLmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvbG9kYXNoL19iYXNlVGltZXMuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9sb2Rhc2gvX2Jhc2VVbmFyeS5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2xvZGFzaC9fY2xvbmVBcnJheUJ1ZmZlci5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2xvZGFzaC9fY2xvbmVCdWZmZXIuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9sb2Rhc2gvX2Nsb25lVHlwZWRBcnJheS5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2xvZGFzaC9fY29weUFycmF5LmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvbG9kYXNoL19jb3B5T2JqZWN0LmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvbG9kYXNoL19jcmVhdGVBc3NpZ25lci5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2xvZGFzaC9fY3JlYXRlQmFzZUZvci5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2xvZGFzaC9fZ2V0UHJvdG90eXBlLmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvbG9kYXNoL19pbml0Q2xvbmVPYmplY3QuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9sb2Rhc2gvX2lzSXRlcmF0ZWVDYWxsLmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvbG9kYXNoL19pc1Byb3RvdHlwZS5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2xvZGFzaC9fbmF0aXZlS2V5c0luLmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvbG9kYXNoL19ub2RlVXRpbC5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2xvZGFzaC9fb3ZlckFyZy5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2xvZGFzaC9fb3ZlclJlc3QuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9sb2Rhc2gvX3NhZmVHZXQuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9sb2Rhc2gvX3NldFRvU3RyaW5nLmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvbG9kYXNoL19zaG9ydE91dC5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2xvZGFzaC9fc3RhY2tDbGVhci5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2xvZGFzaC9fc3RhY2tEZWxldGUuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9sb2Rhc2gvX3N0YWNrR2V0LmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvbG9kYXNoL19zdGFja0hhcy5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2xvZGFzaC9fc3RhY2tTZXQuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9sb2Rhc2gvY29uc3RhbnQuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9sb2Rhc2gvaWRlbnRpdHkuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9sb2Rhc2gvaXNBcnJheUxpa2UuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9sb2Rhc2gvaXNBcnJheUxpa2VPYmplY3QuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9sb2Rhc2gvaXNCdWZmZXIuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9sb2Rhc2gvaXNQbGFpbk9iamVjdC5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2xvZGFzaC9pc1R5cGVkQXJyYXkuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9sb2Rhc2gva2V5c0luLmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvbG9kYXNoL21lcmdlLmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvbG9kYXNoL3N0dWJGYWxzZS5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2xvZGFzaC90b1BsYWluT2JqZWN0LmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvcmMtZGlhbG9nL2VzL0RpYWxvZy5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL3JjLWRpYWxvZy9lcy9EaWFsb2dXcmFwLmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvcmMtZGlhbG9nL2VzL0xhenlSZW5kZXJCb3guanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9yYy1ub3RpZmljYXRpb24vZXMvTm90aWNlLmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvcmMtbm90aWZpY2F0aW9uL2VzL05vdGlmaWNhdGlvbi5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL3JjLW5vdGlmaWNhdGlvbi9lcy9pbmRleC5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL3JjLXRhYmxlL2VzL0Jhc2VUYWJsZS5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL3JjLXRhYmxlL2VzL0JvZHlUYWJsZS5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL3JjLXRhYmxlL2VzL0NvbEdyb3VwLmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvcmMtdGFibGUvZXMvQ29sdW1uLmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvcmMtdGFibGUvZXMvQ29sdW1uR3JvdXAuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9yYy10YWJsZS9lcy9Db2x1bW5NYW5hZ2VyLmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvcmMtdGFibGUvZXMvRXhwYW5kSWNvbi5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL3JjLXRhYmxlL2VzL0V4cGFuZGFibGVSb3cuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9yYy10YWJsZS9lcy9FeHBhbmRhYmxlVGFibGUuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9yYy10YWJsZS9lcy9IZWFkVGFibGUuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9yYy10YWJsZS9lcy9UYWJsZS5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL3JjLXRhYmxlL2VzL1RhYmxlQ2VsbC5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL3JjLXRhYmxlL2VzL1RhYmxlSGVhZGVyLmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvcmMtdGFibGUvZXMvVGFibGVIZWFkZXJSb3cuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9yYy10YWJsZS9lcy9UYWJsZVJvdy5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL3JjLXRhYmxlL2VzL2luZGV4LmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvcmMtdGFibGUvZXMvdXRpbHMuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9yYy11dGlsL2VzL2dldFNjcm9sbEJhclNpemUuanMiLCJ3ZWJwYWNrOi8vLy4vcGFnZXMvc2V0dGluZy9zZXR0aW5nLmNzcz81ZDI1Iiwid2VicGFjazovLy8uL3BhZ2VzL3NldHRpbmcvc2V0dGluZy5qcyJdLCJuYW1lcyI6WyJTZXR0aW5nIiwic3RhdGUiLCJ2aXNpYmxlIiwiYWRtaW4iLCJhc3Npc3QiLCJpZCIsImhhc0Vycm9ycyIsImVycm9ycyIsIk9iamVjdCIsImtleXMiLCJzb21lIiwia2V5IiwiaGFuZGxlQWRkIiwic2V0U3RhdGUiLCJwcm9wcyIsImZvcm0iLCJ2YWxpZGF0ZUZpZWxkcyIsImNsb3NlTW9kYWwiLCJnZXRBY2NvdW50TGlzdCIsInVybCIsImRhdGEiLCJzdWNjZXNzIiwibWFwIiwicGVyIiwidHlwZSIsInB1c2giLCJzZXRBY2NvdW50IiwidXNlciIsInNldEZpZWxkc1ZhbHVlIiwibmFtZSIsInRoZV91c2VyIiwicmVuZXdBY2NvdW50UGFzc3dvcmQiLCJ2YWx1ZXMiLCJnZXRGaWVsZHNWYWx1ZSIsInRoZV9wYXNzd29yZCIsImRlbGV0ZUFjY291bnQiLCJtb2RhbEVuc3VyZSIsInJlcXVlc3RBZGQiLCJwYXNzd29yZCIsImZhaWwiLCJyZXMiLCJlcnJvciIsIm1zZyIsImdldEZpZWxkRGVjb3JhdG9yIiwiZ2V0RmllbGRzRXJyb3IiLCJpc0ZpZWxkVG91Y2hlZCIsImdldEZpZWxkRXJyb3IiLCJ1c2VyRXJyIiwiYWNjb3VudEVyciIsInBhc3N3b3JkRXJyIiwibW9kYWxGb290ZXIiLCJBZGRNb2RhbCIsInJ1bGVzIiwicmVxdWlyZWQiLCJtZXNzYWdlIiwiYWRtaW5Db2x1bW5zIiwidGl0bGUiLCJkYXRhSW5kZXgiLCJyZW5kZXIiLCJ0ZXh0IiwicmVjb3JkIiwiYXNzaXN0Q29sdW1ucyIsImxlbmd0aCIsIkNvbXBvbmVudCIsIlNldHRpbmdGb3JtIiwiY3JlYXRlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTs7OztBQUlBLGVBQWU7O0FBRWY7QUFDQTs7QUFFQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBLEdBQUc7O0FBRUg7O0FBRUE7QUFDQSxFQUFFOztBQUVGLGdDQUFnQyxVQUFVLEVBQUU7QUFDNUMsQzs7Ozs7Ozs7Ozs7O0FDM0NBOztBQUVBOztBQUVBO0FBQ0E7Ozs7QUFJQSxlQUFlOztBQUVmO0FBQ0E7O0FBRUE7O0FBRUE7O0FBRUE7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQSxHQUFHOztBQUVIOztBQUVBO0FBQ0EsRUFBRTs7QUFFRixnQ0FBZ0MsVUFBVSxFQUFFO0FBQzVDLEM7Ozs7Ozs7Ozs7OztBQzNDQTs7QUFFQTs7QUFFQTtBQUNBOzs7O0FBSUEsZUFBZTs7QUFFZjtBQUNBOztBQUVBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0EsR0FBRzs7QUFFSDs7QUFFQTtBQUNBLEVBQUU7O0FBRUYsZ0NBQWdDLFVBQVUsRUFBRTtBQUM1QyxDOzs7Ozs7Ozs7Ozs7QUMzQ0E7O0FBRUE7O0FBRUE7QUFDQTs7OztBQUlBLGVBQWU7O0FBRWY7QUFDQTs7QUFFQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBLEdBQUc7O0FBRUg7O0FBRUE7QUFDQSxFQUFFOztBQUVGLGdDQUFnQyxVQUFVLEVBQUU7QUFDNUMsQzs7Ozs7Ozs7Ozs7QUM1Q0E7QUFDQTs7O0FBR0E7QUFDQSxvV0FBcVcsaU9BQWlPLG9CQUFvQixxQkFBcUIsK0JBQStCLG1DQUFtQyxtQ0FBbUMsY0FBYyxlQUFlLHFCQUFxQixvQkFBb0Isa0JBQWtCLGdCQUFnQixjQUFjLFlBQVkseUJBQXlCLEdBQUcsdUJBQXVCLGlCQUFpQix1QkFBdUIsR0FBRyxtQ0FBbUMscUJBQXFCLEdBQUcsK0JBQStCLHVCQUF1Qix1QkFBdUIsdURBQXVELHVEQUF1RCxxQkFBcUIsMEJBQTBCLHdCQUF3QixHQUFHLGlDQUFpQyxtQkFBbUIsR0FBRywrQkFBK0IsbUJBQW1CLEdBQUcsaUNBQWlDLG1CQUFtQixHQUFHLDhEQUE4RCxtQkFBbUIsR0FBRyx5QkFBeUIsc0JBQXNCLG9CQUFvQixhQUFhLHVCQUF1QixHQUFHLDBEQUEwRCwyQ0FBMkMsMkNBQTJDLHFCQUFxQixvQ0FBb0Msb0NBQW9DLEdBQUcscUNBQXFDLFFBQVEsaUJBQWlCLHdCQUF3QixtQkFBbUIsS0FBSyxVQUFVLGlCQUFpQixvQkFBb0IsaUJBQWlCLEtBQUssR0FBRyw2QkFBNkIsUUFBUSxpQkFBaUIsd0JBQXdCLG1CQUFtQixLQUFLLFVBQVUsaUJBQWlCLG9CQUFvQixpQkFBaUIsS0FBSyxHQUFHOztBQUV6cUU7Ozs7Ozs7Ozs7OztBQ1BBO0FBQ0E7OztBQUdBO0FBQ0Esa1dBQW1XLGlPQUFpTyxvQkFBb0IscUJBQXFCLCtCQUErQixtQ0FBbUMsbUNBQW1DLGNBQWMsZUFBZSxxQkFBcUIsdUJBQXVCLGdCQUFnQixtQkFBbUIsZUFBZSx5QkFBeUIsR0FBRyxtQkFBbUIsb0JBQW9CLG1CQUFtQixXQUFXLGFBQWEsY0FBYyxZQUFZLGtCQUFrQixzQ0FBc0MsZUFBZSxHQUFHLG9CQUFvQixjQUFjLG9CQUFvQixzQkFBc0IscUJBQXFCLCtCQUErQixHQUFHLHNCQUFzQix1QkFBdUIsMkJBQTJCLGNBQWMsdUJBQXVCLGlDQUFpQyx1REFBdUQsdURBQXVELEdBQUcsb0JBQW9CLG9CQUFvQixjQUFjLDRCQUE0Qix1QkFBdUIsYUFBYSxXQUFXLGdCQUFnQixxQkFBcUIsbUJBQW1CLDBCQUEwQixrQ0FBa0MsMEJBQTBCLCtCQUErQixlQUFlLGVBQWUsR0FBRyxzQkFBc0IsbUJBQW1CLHVCQUF1Qiw2QkFBNkIsdUJBQXVCLHlCQUF5Qix5QkFBeUIsZ0JBQWdCLGlCQUFpQixzQkFBc0Isb0JBQW9CLEdBQUcsNkJBQTZCLHdCQUF3QixtQkFBbUIsd0NBQXdDLEdBQUcsbURBQW1ELGdCQUFnQiwwQkFBMEIsR0FBRyxxQkFBcUIsdUJBQXVCLCtCQUErQixxQkFBcUIsK0JBQStCLHFDQUFxQyxHQUFHLG1CQUFtQixrQkFBa0Isb0JBQW9CLHFCQUFxQiwwQkFBMEIsR0FBRyxxQkFBcUIsa0NBQWtDLHVCQUF1QixzQkFBc0IsK0JBQStCLEdBQUcscUNBQXFDLHFCQUFxQixxQkFBcUIsR0FBRyxrREFBa0QscUNBQXFDLHFDQUFxQyw0QkFBNEIsNEJBQTRCLDRCQUE0QixlQUFlLEdBQUcsbUJBQW1CLG9CQUFvQixXQUFXLGFBQWEsWUFBWSxjQUFjLDhCQUE4QiwwQ0FBMEMsaUJBQWlCLGtCQUFrQiw4QkFBOEIsR0FBRywwQkFBMEIsa0JBQWtCLEdBQUcsbUJBQW1CLHFCQUFxQixHQUFHLDZCQUE2QixnQkFBZ0IsNkJBQTZCLG1CQUFtQixLQUFLLHVDQUF1QywwQkFBMEIsc0JBQXNCLHNCQUFzQixzQkFBc0IsS0FBSyxHQUFHLGtDQUFrQyxrQkFBa0IsR0FBRyxpQ0FBaUMsa0JBQWtCLEdBQUcsZ0NBQWdDLDRCQUE0QixHQUFHLDZCQUE2QixZQUFZLEdBQUcsc0VBQXNFLG1CQUFtQixtQkFBbUIsR0FBRyxtQ0FBbUMsZ0JBQWdCLHVCQUF1QixpQkFBaUIsY0FBYyxHQUFHLHdDQUF3QywrQkFBK0IscUJBQXFCLG9CQUFvQixzQkFBc0IsbUJBQW1CLG1CQUFtQixHQUFHLDBDQUEwQyxzQkFBc0Isb0JBQW9CLCtCQUErQixvQkFBb0IsR0FBRyxnQ0FBZ0Msb0JBQW9CLHVCQUF1QixnQkFBZ0IsR0FBRyxrQ0FBa0MscUJBQXFCLGlCQUFpQixHQUFHLGtEQUFrRCxxQkFBcUIscUJBQXFCLEdBQUcsbURBQW1ELG1CQUFtQixHQUFHLHlHQUF5RyxtQkFBbUIsR0FBRyxrREFBa0QsbUJBQW1CLEdBQUcscURBQXFELG1CQUFtQixHQUFHOztBQUU5dko7Ozs7Ozs7Ozs7OztBQ1BBO0FBQ0E7OztBQUdBO0FBQ0Esd1dBQXlXLGlPQUFpTyxvQkFBb0IscUJBQXFCLCtCQUErQixtQ0FBbUMsbUNBQW1DLGNBQWMsZUFBZSxxQkFBcUIsMEJBQTBCLHVCQUF1QixHQUFHLHNCQUFzQixpT0FBaU8sb0JBQW9CLHFCQUFxQiwrQkFBK0IsbUNBQW1DLG1DQUFtQyxjQUFjLGVBQWUscUJBQXFCLDBCQUEwQix1QkFBdUIsd0JBQXdCLHNCQUFzQixvQkFBb0IsR0FBRyxjQUFjLGlPQUFpTyxvQkFBb0IscUJBQXFCLCtCQUErQixtQ0FBbUMsbUNBQW1DLGNBQWMsZUFBZSxxQkFBcUIsd0JBQXdCLGtCQUFrQiwwQkFBMEIsdUJBQXVCLG1CQUFtQixnQ0FBZ0Msb0JBQW9CLEdBQUcsa0lBQWtJLDBCQUEwQixHQUFHLDRCQUE0Qix1QkFBdUIsV0FBVyxZQUFZLGdCQUFnQixpQkFBaUIsdUJBQXVCLDhCQUE4QixnQkFBZ0Isd0RBQXdELHdEQUF3RCxzQ0FBc0Msc0NBQXNDLHVCQUF1QixHQUFHLHNFQUFzRSx3QkFBd0IsR0FBRyxvQkFBb0IsdUJBQXVCLFdBQVcsWUFBWSxtQkFBbUIsZ0JBQWdCLGlCQUFpQixzQkFBc0Isd0JBQXdCLHlCQUF5QiwwQkFBMEIsMkJBQTJCLGlDQUFpQyx5QkFBeUIsR0FBRywwQkFBMEIsdUJBQXVCLGVBQWUsZ0JBQWdCLGNBQWMsYUFBYSx1QkFBdUIsbUJBQW1CLGtCQUFrQixtQkFBbUIsaUJBQWlCLDhCQUE4QixlQUFlLGdDQUFnQyxnQ0FBZ0MsZ0NBQWdDLHNFQUFzRSw4REFBOEQsR0FBRyxvQkFBb0IsdUJBQXVCLFlBQVksZUFBZSxvQkFBb0IsZUFBZSxXQUFXLGNBQWMsYUFBYSxHQUFHLHVDQUF1QywwQkFBMEIsR0FBRyw2Q0FBNkMsb0NBQW9DLG9DQUFvQyxvQ0FBb0MsZUFBZSxzRUFBc0UsOERBQThELEdBQUcsd0NBQXdDLHFDQUFxQyw4QkFBOEIsR0FBRyw4Q0FBOEMsMkJBQTJCLEdBQUcsd0NBQXdDLHdCQUF3QixHQUFHLDhCQUE4QiwrQkFBK0Isd0JBQXdCLEdBQUcsc0JBQXNCLHNCQUFzQix1QkFBdUIsR0FBRyw2QkFBNkIsY0FBYyxpQkFBaUIsc0JBQXNCLCtCQUErQiwwQkFBMEIsc0NBQXNDLDhCQUE4QixvQkFBb0IsOEJBQThCLG1CQUFtQiw2QkFBNkIscUJBQXFCLG9CQUFvQix1QkFBdUIsR0FBRywrQkFBK0IsK0JBQStCLEdBQUcsaURBQWlELG1CQUFtQixtQkFBbUIsYUFBYSxjQUFjLEdBQUcsb0RBQW9ELGlCQUFpQixzQkFBc0Isb0JBQW9CLEdBQUcsb0RBQW9ELGlCQUFpQixzQkFBc0IsbUJBQW1CLEdBQUcsdURBQXVELGtCQUFrQixtQkFBbUIsV0FBVyxlQUFlLGVBQWUsaUJBQWlCLHVCQUF1Qiw4QkFBOEIsR0FBRyx5Q0FBeUMsK0JBQStCLG1DQUFtQyxHQUFHLHdDQUF3QywrQkFBK0IsR0FBRyxvREFBb0QsdUJBQXVCLEdBQUcsdUVBQXVFLG1CQUFtQix1QkFBdUIsR0FBRyxxSkFBcUosZUFBZSxhQUFhLGNBQWMsR0FBRyxxQ0FBcUMscUJBQXFCLDBCQUEwQixtQkFBbUIsMkNBQTJDLDJDQUEyQyxlQUFlLEdBQUcsNkNBQTZDLHlDQUF5QyxpQkFBaUIsR0FBRyxpREFBaUQsMEJBQTBCLHdDQUF3Qyx3Q0FBd0MsR0FBRywyQ0FBMkMsMEJBQTBCLDJDQUEyQywyQ0FBMkMsbUJBQW1CLEdBQUcsNENBQTRDLDBCQUEwQiwyQ0FBMkMsMkNBQTJDLG1CQUFtQixHQUFHLHNDQUFzQywwQkFBMEIsOEJBQThCLHdCQUF3QiwrQkFBK0IsR0FBRyw2RkFBNkYsMEJBQTBCLDhCQUE4QiwrQkFBK0IsR0FBRyxrREFBa0QsK0JBQStCLEdBQUcsdUVBQXVFLGdCQUFnQiw4QkFBOEIsMEJBQTBCLDZCQUE2Qiw2QkFBNkIsR0FBRyxxQ0FBcUMsUUFBUSxrQ0FBa0Msa0NBQWtDLG1CQUFtQixLQUFLLFVBQVUsb0NBQW9DLG9DQUFvQyxpQkFBaUIsS0FBSyxHQUFHLDZCQUE2QixRQUFRLGtDQUFrQyxrQ0FBa0MsbUJBQW1CLEtBQUssVUFBVSxvQ0FBb0Msb0NBQW9DLGlCQUFpQixLQUFLLEdBQUc7O0FBRW5wUDs7Ozs7Ozs7Ozs7O0FDUEE7QUFDQTs7O0FBR0E7QUFDQSwwV0FBMlcsWUFBWSxHQUFHLHdEQUF3RCxtQkFBbUIsbUJBQW1CLEdBQUcsNEJBQTRCLGdCQUFnQix1QkFBdUIsaUJBQWlCLGNBQWMsR0FBRyxjQUFjLGlPQUFpTyxvQkFBb0IscUJBQXFCLCtCQUErQixtQ0FBbUMsbUNBQW1DLGNBQWMsZUFBZSxxQkFBcUIsdUJBQXVCLGdCQUFnQixHQUFHLG1CQUFtQixvQ0FBb0MsNEJBQTRCLEdBQUcsb0JBQW9CLGdCQUFnQiw4QkFBOEIsc0JBQXNCLHFCQUFxQiwrQkFBK0IsR0FBRyw4QkFBOEIsd0JBQXdCLDRDQUE0QyxvQ0FBb0MscUJBQXFCLCtCQUErQixxQkFBcUIscUNBQXFDLEdBQUcsdUNBQXVDLHVCQUF1QixxQkFBcUIsR0FBRyxrR0FBa0csdUJBQXVCLHFCQUFxQixvQkFBb0Isb0JBQW9CLCtCQUErQixnQ0FBZ0Msd0JBQXdCLGdCQUFnQix3QkFBd0IsZ0NBQWdDLEdBQUcsOEdBQThHLCtCQUErQixHQUFHLHlFQUF5RSxxQkFBcUIsR0FBRyx3RUFBd0UsbUJBQW1CLEdBQUcsMkRBQTJELHFCQUFxQixHQUFHLHNEQUFzRCxnQ0FBZ0MsR0FBRyxxREFBcUQsaUNBQWlDLEdBQUcsOEJBQThCLHFDQUFxQyxnQ0FBZ0Msd0JBQXdCLEdBQUcsaURBQWlELGdDQUFnQyx3QkFBd0IsR0FBRyx5S0FBeUssd0JBQXdCLEdBQUcsK0JBQStCLHFCQUFxQixHQUFHLHFCQUFxQix1QkFBdUIsd0JBQXdCLCtCQUErQix1QkFBdUIsa0NBQWtDLEdBQUcsNEJBQTRCLGdCQUFnQixnQkFBZ0Isd0JBQXdCLHVCQUF1QixjQUFjLGdCQUFnQixZQUFZLEdBQUcsbURBQW1ELDhCQUE4QixHQUFHLG9CQUFvQixvQkFBb0IsdUJBQXVCLGFBQWEsK0JBQStCLEdBQUcsa0RBQWtELDhCQUE4Qix1QkFBdUIsd0JBQXdCLEdBQUcseUNBQXlDLHVCQUF1QiwrQkFBK0IscUJBQXFCLEdBQUcsa09BQWtPLHFCQUFxQixHQUFHLG1IQUFtSCxxQkFBcUIsR0FBRyxtREFBbUQsd0JBQXdCLEdBQUcsb0RBQW9ELHdCQUF3QixHQUFHLDJEQUEyRCx1QkFBdUIsMEJBQTBCLEdBQUcsZ0VBQWdFLHVCQUF1QixxQkFBcUIsR0FBRyxpSEFBaUgsdUJBQXVCLG9CQUFvQixnQkFBZ0IsR0FBRyx1SkFBdUosb0JBQW9CLEdBQUcsK0RBQStELHVCQUF1QixvQkFBb0IsZ0JBQWdCLEdBQUcscUJBQXFCLHdCQUF3QixxQkFBcUIsR0FBRywyQkFBMkIsK0JBQStCLEdBQUcsc0JBQXNCLHVCQUF1QixHQUFHLHNDQUFzQyxxQkFBcUIsaUJBQWlCLEdBQUcsNkNBQTZDLGlCQUFpQixzQkFBc0IsY0FBYyxhQUFhLHVCQUF1Qix1QkFBdUIsR0FBRyxpREFBaUQsc0JBQXNCLEdBQUcsb0RBQW9ELHFCQUFxQixHQUFHLDRCQUE0Qix1QkFBdUIscUJBQXFCLDBCQUEwQixnQkFBZ0IsaUJBQWlCLDJCQUEyQix1QkFBdUIsd0JBQXdCLCtCQUErQixHQUFHLCtEQUErRCxxQkFBcUIsbUJBQW1CLGdCQUFnQixnQkFBZ0Isb0JBQW9CLHVCQUF1QixHQUFHLDZGQUE2RixtQkFBbUIsR0FBRyxxTkFBcU4sbUJBQW1CLEdBQUcsMkVBQTJFLHVCQUF1QixnQkFBZ0IsaUJBQWlCLGdCQUFnQixZQUFZLEdBQUcscUNBQXFDLGNBQWMsR0FBRyx1Q0FBdUMsV0FBVyxHQUFHLDZGQUE2RiwwQkFBMEIsb0JBQW9CLHVCQUF1QixzREFBc0Qsc0RBQXNELHNEQUFzRCxxQkFBcUIsZ0JBQWdCLGdDQUFnQyx3QkFBd0IsdUJBQXVCLEdBQUcseUdBQXlHLG9CQUFvQixHQUFHLGlDQUFpQyxzQkFBc0IsR0FBRyxnREFBZ0QsZ0JBQWdCLEdBQUcsb01BQW9NLDhCQUE4QixvQkFBb0IscUJBQXFCLEdBQUcsOERBQThELG1DQUFtQyxvQ0FBb0MsR0FBRyx3RUFBd0UscUJBQXFCLEdBQUcsc0VBQXNFLGtCQUFrQiw4QkFBOEIsK0JBQStCLEdBQUcsNEVBQTRFLGtCQUFrQixHQUFHLHFFQUFxRSxjQUFjLEdBQUcsa0RBQWtELHFDQUFxQyxHQUFHLG1HQUFtRyxvQ0FBb0MsR0FBRywwQkFBMEIsdUJBQXVCLHVCQUF1QixxQkFBcUIscUNBQXFDLHVCQUF1QixvQkFBb0IsK0JBQStCLGVBQWUsR0FBRyxtQ0FBbUMsc0JBQXNCLEdBQUcsd0NBQXdDLG1CQUFtQixpQkFBaUIsR0FBRyw4QkFBOEIsb0JBQW9CLHNCQUFzQixxQkFBcUIsdUJBQXVCLHNEQUFzRCxzREFBc0QsR0FBRyxpREFBaUQsY0FBYyw2QkFBNkIsNkJBQTZCLCtCQUErQixHQUFHLGlFQUFpRSxzQkFBc0IsdUJBQXVCLEdBQUcscUVBQXFFLHFCQUFxQixHQUFHLHFEQUFxRCx1QkFBdUIsc0RBQXNELHNEQUFzRCxHQUFHLCtIQUErSCxtQkFBbUIsc0JBQXNCLGlDQUFpQyxHQUFHLHNEQUFzRCxxQkFBcUIsR0FBRyxtTkFBbU4scUJBQXFCLEdBQUcsbUNBQW1DLHFCQUFxQixxQkFBcUIsa0NBQWtDLEdBQUcsbUNBQW1DLG1CQUFtQixHQUFHLHlDQUF5QyxtQkFBbUIsR0FBRywwQ0FBMEMsbUJBQW1CLEdBQUcsMkNBQTJDLGdCQUFnQixHQUFHLHlDQUF5QyxpQkFBaUIsR0FBRywwQ0FBMEMsaUNBQWlDLEdBQUcsc0NBQXNDLCtCQUErQixnQ0FBZ0Msd0JBQXdCLEdBQUcsNkJBQTZCLG9CQUFvQixvQkFBb0IsdUJBQXVCLHFCQUFxQix1QkFBdUIsc0RBQXNELHNEQUFzRCxHQUFHLDhDQUE4QywrQkFBK0IsR0FBRyw2QkFBNkIsb0JBQW9CLGVBQWUsMEJBQTBCLG1CQUFtQixHQUFHLGlEQUFpRCxnQkFBZ0IsR0FBRyw4QkFBOEIsb0JBQW9CLDBCQUEwQixnQkFBZ0IsaUJBQWlCLHVCQUF1QixzQkFBc0IsOEJBQThCLDhCQUE4Qiw4QkFBOEIsOEJBQThCLDhCQUE4QixxQkFBcUIsR0FBRyxpQ0FBaUMsaUJBQWlCLEdBQUcsa0NBQWtDLGlCQUFpQixHQUFHLHlCQUF5Qix1QkFBdUIsR0FBRywrQkFBK0IsaUJBQWlCLEdBQUcsdUZBQXVGLDBCQUEwQixHQUFHLCtEQUErRCx3QkFBd0IsR0FBRyxpRUFBaUUsc0JBQXNCLEdBQUcscUJBQXFCLG1CQUFtQix1QkFBdUIsR0FBRywyQkFBMkIsb0JBQW9CLEdBQUcseUJBQXlCLGlCQUFpQixHQUFHLHNGQUFzRix1QkFBdUIscUJBQXFCLEdBQUcsaURBQWlELHFCQUFxQixHQUFHLCtEQUErRCxxQkFBcUIseUJBQXlCLHlCQUF5QixHQUFHLGtEQUFrRCx1QkFBdUIsV0FBVyxxQkFBcUIscURBQXFELDZDQUE2QyxxQ0FBcUMsbUVBQW1FLHFCQUFxQixHQUFHLDhEQUE4RCxnQkFBZ0IscUJBQXFCLEdBQUcsZ0xBQWdMLHFCQUFxQixHQUFHLHlCQUF5QixZQUFZLDJEQUEyRCwyREFBMkQsR0FBRywyQ0FBMkMsdUJBQXVCLEdBQUcsK0NBQStDLHdCQUF3Qix3QkFBd0IsR0FBRyx1RUFBdUUscUJBQXFCLEdBQUcsdURBQXVELDZCQUE2QixHQUFHLCtEQUErRCwrQkFBK0IsR0FBRywwQkFBMEIsYUFBYSw0REFBNEQsNERBQTRELEdBQUcseURBQXlELDZCQUE2QixHQUFHLGtEQUFrRCx1QkFBdUIseUJBQXlCLEdBQUcsaUVBQWlFLDhCQUE4QixHQUFHLG1FQUFtRSw2QkFBNkIsNkJBQTZCLEdBQUcscUVBQXFFLDZCQUE2Qiw2QkFBNkIsR0FBRyxnRkFBZ0Ysc0JBQXNCLEdBQUcsNjVEQUE2NUQsc0JBQXNCLEdBQUcsb0JBQW9CLDhCQUE4Qix1QkFBdUIsR0FBRyw4RUFBOEUscUJBQXFCLEdBQUcsdUNBQXVDLHFDQUFxQyxXQUFXLEdBQUcsK3RCQUErdEIsY0FBYyxtQkFBbUIsR0FBRyw2NERBQTY0RCxxQkFBcUIsR0FBRyx1OEJBQXU4QixxQkFBcUIscUNBQXFDLEdBQUcseWxCQUF5bEIsZUFBZSxHQUFHLDJEQUEyRCxxQkFBcUIsR0FBRyxxSUFBcUkscUJBQXFCLEdBQUcsdUNBQXVDLG9CQUFvQixHQUFHLHdEQUF3RCxjQUFjLHFDQUFxQyxvQ0FBb0MsR0FBRywwREFBMEQsb0NBQW9DLEdBQUcseURBQXlELGNBQWMsa0NBQWtDLG9DQUFvQyxHQUFHLGdFQUFnRSxrQkFBa0IsR0FBRyw4REFBOEQsbUJBQW1CLHFCQUFxQixHQUFHLHlKQUF5Six1QkFBdUIsR0FBRzs7QUFFeHVyQjs7Ozs7Ozs7Ozs7O0FDUEE7QUFDQTs7O0FBR0E7QUFDQSw4Q0FBK0MsNEJBQTRCLEtBQUsseUJBQXlCLHlCQUF5QixvQkFBb0IsS0FBSyxrQkFBa0IscUJBQXFCLHVCQUF1QixLQUFLLFFBQVEsZ0hBQWdILFlBQVksTUFBTSxLQUFLLFlBQVksV0FBVyxLQUFLLEtBQUssVUFBVSxVQUFVLDREQUE0RCw0QkFBNEIsS0FBSyxpQkFBaUIseUJBQXlCLG9CQUFvQixLQUFLLFVBQVUscUJBQXFCLHVCQUF1QixLQUFLLG1CQUFtQjs7QUFFaHBCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxFOzs7Ozs7Ozs7OztBQ1pBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBLG1CQUFtQjtBQUNuQixvQkFBb0I7QUFDcEIsbUJBQW1CO0FBQ25CLFlBQVk7QUFDWjtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7O0FBRWI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7O0FDdEJBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQixXQUFXLE9BQU87QUFDbEIsWUFBWTtBQUNaO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBLGlCQUFpQixTQUFTO0FBQzFCO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBOzs7Ozs7Ozs7Ozs7QUNoREE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLE1BQU07QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7Ozs7Ozs7Ozs7OztBQzFCQTs7QUFFQTtBQUNBOztBQUVBOzs7Ozs7Ozs7Ozs7QUNMQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyxTQUFTO0FBQ3BCLFdBQVcsRUFBRTtBQUNiLFdBQVcsTUFBTTtBQUNqQixhQUFhLEVBQUU7QUFDZjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7Ozs7Ozs7Ozs7O0FDcEJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLEVBQUU7QUFDYixXQUFXLFFBQVE7QUFDbkIsYUFBYSxNQUFNO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOzs7Ozs7Ozs7Ozs7QUNoREE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyxPQUFPO0FBQ2xCLFdBQVcsT0FBTztBQUNsQixXQUFXLEVBQUU7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7Ozs7Ozs7Ozs7O0FDbkJBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsT0FBTztBQUNsQixhQUFhLE9BQU87QUFDcEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7QUFFRDs7Ozs7Ozs7Ozs7O0FDN0JBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsT0FBTztBQUNsQixXQUFXLFNBQVM7QUFDcEIsV0FBVyxTQUFTO0FBQ3BCLGFBQWEsT0FBTztBQUNwQjtBQUNBOztBQUVBOzs7Ozs7Ozs7Ozs7QUNmQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsRUFBRTtBQUNiLGFBQWEsUUFBUTtBQUNyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOzs7Ozs7Ozs7Ozs7QUMzREE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsT0FBTztBQUNsQixhQUFhLE1BQU07QUFDbkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7Ozs7Ozs7Ozs7OztBQ2hDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsT0FBTztBQUNsQixXQUFXLE9BQU87QUFDbEIsV0FBVyxPQUFPO0FBQ2xCLFdBQVcsU0FBUztBQUNwQixXQUFXLE9BQU87QUFDbEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7O0FBRUE7Ozs7Ozs7Ozs7OztBQ3pDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyxPQUFPO0FBQ2xCLFdBQVcsT0FBTztBQUNsQixXQUFXLE9BQU87QUFDbEIsV0FBVyxPQUFPO0FBQ2xCLFdBQVcsU0FBUztBQUNwQixXQUFXLFNBQVM7QUFDcEIsV0FBVyxPQUFPO0FBQ2xCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOzs7Ozs7Ozs7Ozs7QUM3RkE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyxTQUFTO0FBQ3BCLFdBQVcsT0FBTztBQUNsQixhQUFhLFNBQVM7QUFDdEI7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7Ozs7Ozs7Ozs7OztBQ2hCQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLFNBQVM7QUFDcEIsV0FBVyxTQUFTO0FBQ3BCLGFBQWEsU0FBUztBQUN0QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDs7QUFFQTs7Ozs7Ozs7Ozs7O0FDckJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLE9BQU87QUFDbEIsV0FBVyxTQUFTO0FBQ3BCLGFBQWEsTUFBTTtBQUNuQjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOzs7Ozs7Ozs7Ozs7QUNuQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLFNBQVM7QUFDcEIsYUFBYSxTQUFTO0FBQ3RCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7Ozs7Ozs7Ozs7O0FDYkE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLFlBQVk7QUFDdkIsYUFBYSxZQUFZO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7Ozs7Ozs7Ozs7O0FDZkE7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyxPQUFPO0FBQ2xCLFdBQVcsUUFBUTtBQUNuQixhQUFhLE9BQU87QUFDcEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBOzs7Ozs7Ozs7Ozs7O0FDbENBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyxPQUFPO0FBQ2xCLFdBQVcsUUFBUTtBQUNuQixhQUFhLE9BQU87QUFDcEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7Ozs7Ozs7Ozs7O0FDZkE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLE1BQU07QUFDakIsV0FBVyxNQUFNO0FBQ2pCLGFBQWEsTUFBTTtBQUNuQjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7Ozs7Ozs7Ozs7OztBQ25CQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyxPQUFPO0FBQ2xCLFdBQVcsTUFBTTtBQUNqQixXQUFXLE9BQU8sV0FBVztBQUM3QixXQUFXLFNBQVM7QUFDcEIsYUFBYSxPQUFPO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBLHdCQUF3Qjs7QUFFeEI7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7Ozs7Ozs7Ozs7OztBQ3ZDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyxTQUFTO0FBQ3BCLGFBQWEsU0FBUztBQUN0QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIOztBQUVBOzs7Ozs7Ozs7Ozs7QUNwQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkIsYUFBYSxTQUFTO0FBQ3RCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7Ozs7Ozs7Ozs7O0FDeEJBOztBQUVBO0FBQ0E7O0FBRUE7Ozs7Ozs7Ozs7OztBQ0xBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsT0FBTztBQUNsQixhQUFhLE9BQU87QUFDcEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOzs7Ozs7Ozs7Ozs7QUNqQkE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLEVBQUU7QUFDYixXQUFXLEVBQUU7QUFDYixXQUFXLEVBQUU7QUFDYixhQUFhLFFBQVE7QUFDckI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOzs7Ozs7Ozs7Ozs7QUM3QkE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsRUFBRTtBQUNiLGFBQWEsUUFBUTtBQUNyQjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBOzs7Ozs7Ozs7Ozs7QUNqQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyxPQUFPO0FBQ2xCLGFBQWEsTUFBTTtBQUNuQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7Ozs7Ozs7Ozs7O0FDbkJBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsQ0FBQzs7QUFFRDs7Ozs7Ozs7Ozs7OztBQ3JCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsU0FBUztBQUNwQixXQUFXLFNBQVM7QUFDcEIsYUFBYSxTQUFTO0FBQ3RCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7Ozs7Ozs7Ozs7O0FDZEE7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsU0FBUztBQUNwQixXQUFXLE9BQU87QUFDbEIsV0FBVyxTQUFTO0FBQ3BCLGFBQWEsU0FBUztBQUN0QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7Ozs7Ozs7Ozs7O0FDbkNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyxPQUFPO0FBQ2xCLFdBQVcsT0FBTztBQUNsQixhQUFhLEVBQUU7QUFDZjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7Ozs7Ozs7Ozs7OztBQ2RBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLFNBQVM7QUFDcEIsV0FBVyxTQUFTO0FBQ3BCLGFBQWEsU0FBUztBQUN0QjtBQUNBOztBQUVBOzs7Ozs7Ozs7Ozs7QUNiQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLFNBQVM7QUFDcEIsYUFBYSxTQUFTO0FBQ3RCO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7Ozs7Ozs7Ozs7OztBQ3BDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOzs7Ozs7Ozs7Ozs7QUNkQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLE9BQU87QUFDbEIsYUFBYSxRQUFRO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTs7Ozs7Ozs7Ozs7O0FDakJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsT0FBTztBQUNsQixhQUFhLEVBQUU7QUFDZjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7Ozs7Ozs7Ozs7O0FDYkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyxPQUFPO0FBQ2xCLGFBQWEsUUFBUTtBQUNyQjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7Ozs7Ozs7Ozs7O0FDYkE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyxPQUFPO0FBQ2xCLFdBQVcsRUFBRTtBQUNiLGFBQWEsT0FBTztBQUNwQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7Ozs7Ozs7Ozs7O0FDakNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyxFQUFFO0FBQ2IsYUFBYSxTQUFTO0FBQ3RCO0FBQ0E7QUFDQSx3Q0FBd0MsU0FBUztBQUNqRDtBQUNBO0FBQ0EsV0FBVyxTQUFTLEdBQUcsU0FBUztBQUNoQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7Ozs7Ozs7Ozs7OztBQ3pCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsRUFBRTtBQUNiLGFBQWEsRUFBRTtBQUNmO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7Ozs7Ozs7Ozs7OztBQ3BCQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsRUFBRTtBQUNiLGFBQWEsUUFBUTtBQUNyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOzs7Ozs7Ozs7Ozs7QUNoQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyxFQUFFO0FBQ2IsYUFBYSxRQUFRO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7Ozs7Ozs7Ozs7O0FDaENBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyxFQUFFO0FBQ2IsYUFBYSxRQUFRO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7Ozs7Ozs7Ozs7OztBQ3JDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsRUFBRTtBQUNiLGFBQWEsUUFBUTtBQUNyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IsaUJBQWlCO0FBQ3JDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7Ozs7Ozs7Ozs7OztBQzdEQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsRUFBRTtBQUNiLGFBQWEsUUFBUTtBQUNyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7Ozs7Ozs7Ozs7OztBQzFCQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyxPQUFPO0FBQ2xCLGFBQWEsTUFBTTtBQUNuQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7Ozs7Ozs7Ozs7OztBQy9CQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsT0FBTztBQUNsQixXQUFXLFVBQVU7QUFDckIsYUFBYSxPQUFPO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBLFlBQVksU0FBUyxHQUFHLFNBQVM7QUFDakM7QUFDQTtBQUNBO0FBQ0EsWUFBWSxTQUFTLEdBQUcsU0FBUztBQUNqQztBQUNBO0FBQ0E7QUFDQSxVQUFVLFFBQVEsaUJBQWlCLEdBQUcsaUJBQWlCO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBLENBQUM7O0FBRUQ7Ozs7Ozs7Ozs7OztBQ3RDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWEsUUFBUTtBQUNyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOzs7Ozs7Ozs7Ozs7QUNqQkE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyxFQUFFO0FBQ2IsYUFBYSxPQUFPO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhLFNBQVM7QUFDdEIsVUFBVTtBQUNWO0FBQ0EsYUFBYSxTQUFTO0FBQ3RCLFVBQVU7QUFDVjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDL0JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQjtBQUNyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxRkFBcUQsaUVBQWlFO0FBQ3RIO0FBQ0E7QUFDQTtBQUNBLHFGQUFxRCxpRUFBaUUsOERBQThCLHFEQUFxRDtBQUN6TTtBQUNBO0FBQ0E7QUFDQSx3RkFBd0QsK0VBQStFLCtEQUErQixvQ0FBb0M7QUFDMU07QUFDQSwrRkFBbUM7QUFDbkM7QUFDQSw2SUFBb0Usb0tBQW9LLDhEQUE4QixvQ0FBb0MsbUpBQXVELHFGQUFxRiwwR0FBMEUsc0RBQXNELDBDQUEwQyxFQUFFO0FBQ2xtQiw0SEFBaUQsMklBQTJJO0FBQzVMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMEZBQThCO0FBQzlCO0FBQ0E7QUFDQSwwRkFBOEI7QUFDOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ05BQTJFLDRKQUE0SjtBQUN2TztBQUNBLDJJQUFnRSwwR0FBMEc7QUFDMUs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxrQ0FBa0M7QUFDbEM7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd09BQTRHLDhRQUE4UTtBQUMxWDs7QUFFQTtBQUNBLENBQUM7O0FBRUQ7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3BUQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSw4TEFBeUQsd0JBQXdCLHVCQUF1QixnQkFBZ0I7QUFDeEg7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4Q0FBOEM7O0FBRTlDO0FBQ0EsYUFBYTtBQUNiLFNBQVM7QUFDVDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0EsNElBQXlELHVIQUF1SDtBQUNoTDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0EscUlBQWtELGtDQUFrQztBQUNwRjtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBLDJFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3hGQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkZBQStCO0FBQy9CO0FBQ0E7QUFDQTtBQUNBLGlKQUFxRDtBQUNyRDs7QUFFQTtBQUNBLENBQUM7O0FBRUQsOEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbENBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDMkI7QUFDM0I7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7O0FBRUE7O0FBRUEsbUVBQW1FLGFBQWE7QUFDaEY7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxzQ0FBc0M7QUFDdEM7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0EsV0FBVyx5Q0FBeUM7QUFDcEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLDJFQUEyRTtBQUN0Riw4RUFBdUMseUNBQXlDO0FBQ2hGO0FBQ0E7QUFDQTtBQUNBLEdBQUc7O0FBRUg7QUFDQSxDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRCQUE0QjtBQUM1QixnQ0FBZ0M7O0FBRWhDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1RTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM5RkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDMkI7QUFDM0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTs7QUFFQTs7QUFFQSxtRUFBbUUsYUFBYTtBQUNoRjtBQUNBOztBQUVBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUCxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQSxPQUFPO0FBQ1AsS0FBSztBQUNMOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQSxPQUFPO0FBQ1Asc0NBQXNDO0FBQ3RDO0FBQ0E7QUFDQSxTQUFTLCtGQUF1RDtBQUNoRTtBQUNBO0FBQ0EsV0FBVywyQ0FBMkM7QUFDdEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHOztBQUVIO0FBQ0EsQ0FBQzs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFHQTtBQUNBLDhCQUE4QjtBQUM5QjtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBLE9BQU87O0FBRVA7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBLDBNQUErRCxVQUFVLFdBQVc7QUFDcEY7O0FBRUEsNkU7Ozs7Ozs7Ozs7Ozs7O0FDOUpBO0FBQ0Esc0g7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDa0I7QUFDbEI7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBOztBQUVBLG1FQUFtRSxhQUFhO0FBQ2hGO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFHQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQSxTQUFTO0FBQ1Q7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0EsaUZBQXFCO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWU7QUFDZjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZUFBZTtBQUNmO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBOztBQUVBLHFCQUFxQix1QkFBdUI7QUFDNUM7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVMsa0NBQWtDO0FBQzNDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsT0FBTyw2REFBNkQ7QUFDcEUscUhBQXFDLGlDQUFpQztBQUN0RSxtSUFBbUQscURBQXFEO0FBQ3hHO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLENBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBR0Esd0k7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNwTUE7QUFDQTtBQUNBO0FBQzJCO0FBQzNCOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSx5RkFBNkI7QUFDN0I7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHOztBQUVIO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU8sdUlBQTJFLGNBQWM7QUFDaEc7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNwSEE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUdBOztBQUVBO0FBQ0EsaUZBQTBDLDZFQUE2RTtBQUN2SDs7QUFFQTs7QUFFQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBLDhFQUF1QyxvQ0FBb0Msb0NBQW9DLEVBQUU7QUFDakgsR0FBRzs7QUFFSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxFOzs7Ozs7Ozs7Ozs7Ozs7QUMzQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLHVFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2pCQTtBQUNBO0FBQ0E7QUFDb0I7QUFDcEI7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQSxDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0QkE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQLEtBQUs7QUFDTDs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUCxLQUFLO0FBQ0w7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1AsS0FBSztBQUNMOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQLEtBQUs7QUFDTDs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUCxLQUFLO0FBQ0w7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsS0FBSztBQUNMOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLEtBQUs7QUFDTDs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7O0FBRUE7OztBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUdBQXFDO0FBQ3JDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EseUJBQXlCLGlDQUFpQztBQUMxRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMEZBQThCO0FBQzlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7O0FBRUE7QUFDQSxDQUFDOztBQUVELDhFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDekxBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUCxLQUFLO0FBQ0wsaUZBQTBDLGlFQUFpRTtBQUMzRztBQUNBO0FBQ0E7O0FBRUE7QUFDQSxDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0REE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNrQjtBQUNsQjs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7O0FBRUEsbUVBQW1FLGFBQWE7QUFDaEY7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTs7O0FBR0E7QUFDQTtBQUNBLFNBQVMsK0VBQStFO0FBQ3hGO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQSxDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUMsa0I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQy9JRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDa0I7QUFDQztBQUNuQjtBQUNpQjs7QUFFakI7QUFDQTs7QUFFQTtBQUNBOztBQUVBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBR0E7QUFDQTs7QUFFQTtBQUNBLHFCQUFxQixpQkFBaUI7QUFDdEM7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0EsNEJBQTRCO0FBQzVCO0FBQ0EsS0FBSztBQUNMO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYLGdGQUFnRjtBQUNoRjtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLEtBQUs7O0FBRUw7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMOztBQUVBO0FBQ0EsQ0FBQzs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQ0FBa0M7QUFDbEM7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLDZCQUE2QixtQ0FBbUM7QUFDaEU7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLDJGQUErQixlQUFlLHFCQUFxQjtBQUNuRTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQSw4STs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM1UEE7QUFDQTtBQUMyQjtBQUMzQjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2pFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQzJCO0FBQzNCO0FBQ0E7QUFDbUI7QUFDYTtBQUNoQztBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0RBQXdEO0FBQ3hEO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseURBQXlEO0FBQ3pEO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EseURBQXlEOztBQUV6RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxLQUFLOztBQUVMOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSzs7QUFFTDs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBLEtBQUs7QUFDTDtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsaURBQWlEOztBQUVqRDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsS0FBSzs7QUFFTDtBQUNBO0FBQ0EsT0FBTyxtQ0FBbUM7QUFDMUM7QUFDQTtBQUNBOztBQUVBO0FBQ0E7OztBQUdBO0FBQ0E7QUFDQSxPQUFPLHVDQUF1QztBQUM5QztBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTs7QUFFQTtBQUNBOzs7QUFHQTtBQUNBO0FBQ0EsT0FBTyx3Q0FBd0M7QUFDL0M7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrREFBa0Q7O0FBRWxEOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSzs7QUFFTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7O0FBRUw7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsT0FBTyxnREFBZ0Q7QUFDdkQ7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxPQUFPLGtEQUFrRDtBQUN6RDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPLDhDQUE4QztBQUNyRDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLE9BQU8sb0JBQW9CO0FBQzNCO0FBQ0E7QUFDQSwrRUFBbUIsVUFBVSwrREFBK0Q7QUFDNUY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBLGVBQWUsb0NBQW9DO0FBQ25EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLENBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsR0FBRztBQUNILENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCw0QkFBNEI7QUFDNUIsd0NBQXdDOztBQUV4QztBQUNBLGVBQWU7QUFDZixXQUFXO0FBQ1g7QUFDQSxZQUFZO0FBQ1o7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTs7O0FBR0E7O0FBRUEsc0U7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ25pQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTs7QUFFQSxtRUFBbUUsYUFBYTtBQUNoRjtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsdUZBQTJCO0FBQzNCOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsY0FBYywwQ0FBMEM7QUFDeEQ7QUFDQSxLQUFLOztBQUVMO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLHVCQUF1QjtBQUN2Qjs7QUFFQTtBQUNBO0FBQ0EsNEVBQWdCLGtEQUFrRDtBQUNsRTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsQ0FBQzs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdkhBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBLEdBQUc7QUFDSDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBR0E7QUFDQTtBQUNBOztBQUVBOztBQUVBOztBQUVBOztBQUVBO0FBQ0E7QUFDQSxLQUFLLGtDQUFrQztBQUN2QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUCxLQUFLO0FBQ0w7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDMUZBO0FBQ0E7QUFDQTtBQUNBO0FBQ2tCOztBQUVsQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQSxvRkFBd0IsaUJBQWlCOztBQUV6QztBQUNBO0FBQ0EsMkVBQWUsYUFBYSxlQUFlO0FBQzNDO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsMkJBQTJCO0FBQzNCO0FBQ0EsMkpBQXdELDJCQUEyQiwyQ0FBMkM7QUFDOUgsS0FBSztBQUNMO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUMsbUI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdEVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ2tCO0FBQ0M7QUFDbkI7QUFDc0I7O0FBRXRCO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0EsZ0dBQW9DLHFDQUFxQztBQUN6RSxvQkFBb0IseUNBQXlDO0FBQzdEOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQix5REFBeUQ7QUFDN0U7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0EsMEZBQThCLGVBQWUsaUJBQWlCO0FBQzlEOztBQUVBO0FBQ0EsMEZBQThCLGVBQWUsa0JBQWtCO0FBQy9EOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFHQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBR0E7QUFDQTs7QUFFQTs7O0FBR0E7QUFDQTtBQUNBOztBQUVBOztBQUVBOztBQUVBLG1CQUFtQixvQkFBb0I7QUFDdkM7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7O0FBRUE7O0FBRUE7QUFDQTtBQUNBLGlCQUFpQjs7QUFFakI7QUFDQTtBQUNBOztBQUVBLG1GQUF1Qjs7QUFFdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLENBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCO0FBQzVCLGdDQUFnQztBQUNoQyw0Q0FBNEM7QUFDNUMsa0RBQWtEO0FBQ2xEO0FBQ0E7OztBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBR0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxHQUFHOztBQUVIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDLGE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDeFZEO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1BBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxtRUFBbUUsYUFBYTtBQUNoRjtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEM7Ozs7Ozs7Ozs7Ozs7QUN0RkE7QUFBQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLEM7Ozs7Ozs7Ozs7OztBQ3BDQTs7QUFFQTs7QUFFQTtBQUNBOzs7O0FBSUEsZUFBZTs7QUFFZjtBQUNBOztBQUVBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0EsR0FBRzs7QUFFSDs7QUFFQTtBQUNBLEVBQUU7O0FBRUYsZ0NBQWdDLFVBQVUsRUFBRTtBQUM1QyxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzVDQTs7OztBQUVBOzs7O0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7OztJQUNNQSxPOzs7Ozs7Ozs7Ozs7Ozt3TEFDSkMsSyxHQUFRO0FBQ05DLGVBQVMsS0FESDtBQUVOQyxhQUFPLEVBRkQ7QUFHTkMsY0FBUSxFQUhGO0FBSU5DLFVBQUk7QUFKRSxLLFFBNEhSQyxTLEdBQVksVUFBQ0MsTUFBRCxFQUFZO0FBQ3RCLGFBQU9DLE9BQU9DLElBQVAsQ0FBWUYsTUFBWixFQUFvQkcsSUFBcEIsQ0FBeUI7QUFBQSxlQUFPSCxPQUFPSSxHQUFQLENBQVA7QUFBQSxPQUF6QixDQUFQO0FBQ0QsSyxRQUNEQyxTLEdBQVksWUFBTTtBQUNoQixZQUFLQyxRQUFMLENBQWM7QUFDWlgsaUJBQVM7QUFERyxPQUFkLEVBRUcsWUFBTTtBQUNQLGNBQUtZLEtBQUwsQ0FBV0MsSUFBWCxDQUFnQkMsY0FBaEI7QUFDRCxPQUpEO0FBS0QsSyxRQUNEQyxVLEdBQWEsWUFBTTtBQUNqQixZQUFLSixRQUFMLENBQWM7QUFDWlgsaUJBQVMsS0FERztBQUVaRyxZQUFHO0FBRlMsT0FBZDtBQUlELEssUUFDRGEsYyxHQUFpQixZQUFNO0FBQ3JCLDZCQUFRO0FBQ05DLGFBQUssdUJBREM7QUFFTkMsY0FBSyxFQUZDO0FBR05DLGlCQUFTLHdCQUFjO0FBQUEsY0FBWEQsSUFBVyxTQUFYQSxJQUFXOztBQUNyQixjQUFJakIsUUFBUSxFQUFaO0FBQUEsY0FDRUMsU0FBUyxFQURYO0FBRUFnQixlQUFLRSxHQUFMLENBQVMsZUFBTztBQUNkLGdCQUFHQyxJQUFJQyxJQUFKLEtBQWEsQ0FBaEIsRUFBa0I7QUFDaEJyQixvQkFBTXNCLElBQU4sQ0FBV0YsR0FBWDtBQUNELGFBRkQsTUFFTSxJQUFHQSxJQUFJQyxJQUFKLEtBQWEsQ0FBaEIsRUFBbUI7QUFDdkJwQixxQkFBT3FCLElBQVAsQ0FBWUYsR0FBWjtBQUNEO0FBQ0YsV0FORDtBQU9BLGdCQUFLVixRQUFMLENBQWM7QUFDWlYsd0JBRFk7QUFFWkM7QUFGWSxXQUFkO0FBSUQ7QUFqQkssT0FBUjtBQW1CRCxLLFFBQ0RzQixVLEdBQWEsWUFBZTtBQUFBLFVBQWRDLElBQWMsdUVBQVAsRUFBTzs7QUFDeEIsWUFBS2QsUUFBTCxDQUFjO0FBQ1pSLFlBQUlzQixLQUFLdEIsRUFERztBQUVaSCxpQkFBUztBQUZHLE9BQWQsRUFHRyxZQUFNO0FBQ1AsY0FBS1ksS0FBTCxDQUFXQyxJQUFYLENBQWdCQyxjQUFoQjtBQUNBLFlBQUdXLElBQUgsRUFBUTtBQUNOLGdCQUFLYixLQUFMLENBQVdDLElBQVgsQ0FBZ0JhLGNBQWhCLENBQStCO0FBQzdCQyxrQkFBTUYsS0FBS0UsSUFEa0I7QUFFN0JGLGtCQUFNQSxLQUFLRztBQUZrQixXQUEvQjtBQUlEO0FBQ0YsT0FYRDtBQVlILEssUUFDREMsb0IsR0FBdUIsVUFBQzFCLEVBQUQsRUFBUTtBQUM3QixVQUFJMkIsU0FBUyxNQUFLbEIsS0FBTCxDQUFXQyxJQUFYLENBQWdCa0IsY0FBaEIsRUFBYjtBQUNFLDZCQUFRO0FBQ05kLGFBQUssaUJBREM7QUFFTkMsY0FBSztBQUNIZixnQkFERztBQUVIbUIsZ0JBQU0sQ0FGSDtBQUdIVSx3QkFBY0YsT0FBTyxVQUFQO0FBSFgsU0FGQztBQU9OWCxpQkFBUyx3QkFBYztBQUFBLGNBQVhELElBQVcsU0FBWEEsSUFBVzs7QUFDckIsZ0JBQUtILFVBQUw7QUFDRDtBQVRLLE9BQVI7QUFXSCxLLFFBQ0RrQixhLEdBQWdCLFVBQUM5QixFQUFELEVBQVE7QUFDdEIsNkJBQVE7QUFDTmMsYUFBSyxpQkFEQztBQUVOQyxjQUFNO0FBQ0pmLGdCQURJO0FBRUptQixnQkFBTTtBQUZGLFNBRkE7QUFNTkgsaUJBQVMsd0JBQWM7QUFBQSxjQUFYRCxJQUFXLFNBQVhBLElBQVc7O0FBQ3JCLGdCQUFLRixjQUFMO0FBQ0Q7QUFSSyxPQUFSO0FBVUQsSyxRQUNEa0IsVyxHQUFjLFlBQU07QUFDbEIsVUFBSS9CLEtBQUssTUFBS0osS0FBTCxDQUFXSSxFQUFwQjtBQUNBLFVBQUdBLEVBQUgsRUFBTTtBQUNKLGNBQUswQixvQkFBTCxDQUEwQjFCLEVBQTFCO0FBQ0QsT0FGRCxNQUVLO0FBQ0gsY0FBS2dDLFVBQUw7QUFDRDtBQUNGLEssUUFDREEsVSxHQUFhLFlBQU07QUFBQSxrQ0FDYyxNQUFLdkIsS0FBTCxDQUFXQyxJQUFYLENBQWdCa0IsY0FBaEIsRUFEZDtBQUFBLFVBQ1hKLElBRFcseUJBQ1hBLElBRFc7QUFBQSxVQUNMRixJQURLLHlCQUNMQSxJQURLO0FBQUEsVUFDQ1csUUFERCx5QkFDQ0EsUUFERDs7QUFFakIsNkJBQVE7QUFDTm5CLGFBQUssbUJBREM7QUFFTkMsY0FBTTtBQUNKUyxvQkFESTtBQUVKRixvQkFGSTtBQUdKVztBQUhJLFNBRkE7QUFPTmpCLGlCQUFTLG1CQUFNO0FBQ2IsZ0JBQUtKLFVBQUw7QUFDQSxnQkFBS0MsY0FBTDtBQUNELFNBVks7QUFXTnFCLGNBQU0sY0FBQ0MsR0FBRCxFQUFTO0FBQ2IsNEJBQVFDLEtBQVIsQ0FBY0QsSUFBSUUsR0FBbEI7QUFDRDtBQWJLLE9BQVI7QUFlRCxLOzs7Ozs2QkE1Tk87QUFBQTs7QUFBQSxtQkFDK0IsS0FBS3pDLEtBRHBDO0FBQUEsVUFDQUMsT0FEQSxVQUNBQSxPQURBO0FBQUEsVUFDU0MsS0FEVCxVQUNTQSxLQURUO0FBQUEsVUFDZ0JDLE1BRGhCLFVBQ2dCQSxNQURoQjtBQUFBLFVBQ3dCQyxFQUR4QixVQUN3QkEsRUFEeEI7QUFBQSx3QkFFcUUsS0FBS1MsS0FBTCxDQUFXQyxJQUZoRjtBQUFBLFVBRUE0QixpQkFGQSxlQUVBQSxpQkFGQTtBQUFBLFVBRW1CQyxjQUZuQixlQUVtQkEsY0FGbkI7QUFBQSxVQUVtQ0MsY0FGbkMsZUFFbUNBLGNBRm5DO0FBQUEsVUFFbURDLGFBRm5ELGVBRW1EQSxhQUZuRDs7QUFHTixVQUFJQyxVQUFVRixlQUFlLE1BQWYsS0FBMEJDLGNBQWMsTUFBZCxDQUF4QztBQUNBLFVBQUlFLGFBQWFILGVBQWUsTUFBZixLQUEwQkMsY0FBYyxNQUFkLENBQTNDO0FBQ0EsVUFBSUcsY0FBY0osZUFBZSxVQUFmLEtBQThCQyxjQUFjLFVBQWQsQ0FBaEQ7QUFDQSxVQUFNSSxjQUNKO0FBQUE7QUFBQTtBQUNFO0FBQUE7QUFBQSxZQUFRLFNBQVMsS0FBS2pDLFVBQXRCO0FBQUE7QUFBQSxTQURGO0FBRUU7QUFBQTtBQUFBLFlBQVEsTUFBSyxTQUFiLEVBQXVCLFNBQVMsS0FBS21CLFdBQXJDLEVBQWtELFVBQVUsS0FBSzlCLFNBQUwsQ0FBZXNDLGdCQUFmLENBQTVEO0FBQUE7QUFBQTtBQUZGLE9BREY7QUFNQSxVQUFJTyxXQUNGO0FBQUE7QUFBQSxVQUFPLE9BQU8sR0FBZCxFQUFtQixPQUFPOUMsS0FBSyxRQUFMLEdBQWdCLFNBQTFDLEVBQXFELGdCQUFnQixJQUFyRSxFQUEyRSxTQUFTSCxPQUFwRixFQUE2RixRQUFRZ0QsV0FBckcsRUFBa0gsVUFBVSxLQUFLakMsVUFBakk7QUFDSTtBQUFBO0FBQUEsWUFBTSxXQUFXLGtCQUFhRixJQUE5QjtBQUNFO0FBQUEsMkJBQU0sSUFBTjtBQUFBLGNBQVcsT0FBTSxjQUFqQixFQUFzQixNQUFNZ0MsVUFBVUEsT0FBVixHQUFvQixJQUFoRCxFQUFzRCxnQkFBZ0JBLFVBQVUsT0FBVixHQUFtQixFQUF6RjtBQUNHSiw4QkFBa0IsTUFBbEIsRUFBMEI7QUFDekJTLHFCQUFPLENBQUM7QUFDTkMsMEJBQVUsSUFESjtBQUVOQyx5QkFBUztBQUZILGVBQUQ7QUFEa0IsYUFBMUIsRUFNQyxpREFBTyxNQUFLLE9BQVosRUFBb0IsVUFBVSxDQUFDLENBQUNqRCxFQUFoQyxHQU5EO0FBREgsV0FERjtBQVdFO0FBQUEsMkJBQU0sSUFBTjtBQUFBLGNBQVcsT0FBTSwwQkFBakIsRUFBd0IsTUFBTTJDLGFBQWFELE9BQWIsR0FBdUIsSUFBckQsRUFBMkQsZ0JBQWdCQyxhQUFhLE9BQWIsR0FBc0IsRUFBakc7QUFDR0wsOEJBQWtCLE1BQWxCLEVBQTJCO0FBQzFCUyxxQkFBTyxDQUFDO0FBQ05DLDBCQUFVLElBREo7QUFFTkMseUJBQVM7QUFGSCxlQUFEO0FBRG1CLGFBQTNCLEVBTUMsaURBQU8sTUFBSyxPQUFaLEVBQW9CLFVBQVUsQ0FBQyxDQUFDakQsRUFBaEMsR0FORDtBQURILFdBWEY7QUFxQkU7QUFBQSwyQkFBTSxJQUFOO0FBQUEsY0FBVyxPQUFNLGNBQWpCLEVBQXNCLE1BQU00QyxjQUFjRixPQUFkLEdBQXdCLElBQXBELEVBQTBELGdCQUFnQkUsY0FBYyxPQUFkLEdBQXVCLEVBQWpHO0FBQ0dOLDhCQUFrQixVQUFsQixFQUE4QjtBQUM3QlMscUJBQU8sQ0FBQztBQUNOQywwQkFBVSxJQURKO0FBRU5DLHlCQUFTO0FBRkgsZUFBRDtBQURzQixhQUE5QixFQU1DLGlEQUFPLE1BQUssT0FBWixHQU5EO0FBREg7QUFyQkY7QUFESixPQURGO0FBb0NBLFVBQU1DLGVBQWUsQ0FBQztBQUNwQkMsZUFBTyxJQURhO0FBRXBCQyxtQkFBVztBQUZTLE9BQUQsRUFHbEI7QUFDREQsZUFBTyxNQUROO0FBRURDLG1CQUFXO0FBRlYsT0FIa0IsRUFNbEI7QUFDREQsZUFBTyxNQUROO0FBRURDLG1CQUFXLGFBRlY7QUFHREMsZ0JBQVE7QUFBQSxpQkFBUTtBQUFBO0FBQUE7QUFBT0Msb0JBQVE7QUFBZixXQUFSO0FBQUE7QUFIUCxPQU5rQixFQVVuQjtBQUNBSCxlQUFPLFFBRFA7QUFFQUMsbUJBQVcsV0FGWDtBQUdBQyxnQkFBUTtBQUFBLGlCQUFRO0FBQUE7QUFBQTtBQUFPQyxvQkFBUTtBQUFmLFdBQVI7QUFBQTtBQUhSLE9BVm1CLEVBY2xCO0FBQ0RILGVBQU8sSUFETjtBQUVERSxnQkFBUSxnQkFBQ0MsSUFBRCxFQUFPQyxNQUFQO0FBQUEsaUJBQW1CO0FBQUE7QUFBQTtBQUN6QjtBQUFBO0FBQUEsZ0JBQUcsU0FBUztBQUFBLHlCQUFNLE9BQUtsQyxVQUFMLENBQWdCa0MsTUFBaEIsQ0FBTjtBQUFBLGlCQUFaO0FBQUE7QUFBQTtBQUR5QixXQUFuQjtBQUFBO0FBRlAsT0Fka0IsQ0FBckI7QUFvQkEsVUFBTUMsZ0JBQWdCLENBQUM7QUFDckJMLGVBQU8sSUFEYztBQUVyQkMsbUJBQVc7QUFGVSxPQUFELEVBR25CO0FBQ0RELGVBQU8sTUFETjtBQUVEQyxtQkFBVztBQUZWLE9BSG1CLEVBTW5CO0FBQ0RELGVBQU8sTUFETjtBQUVEQyxtQkFBVyxhQUZWO0FBR0RDLGdCQUFRO0FBQUEsaUJBQVE7QUFBQTtBQUFBO0FBQU9DLG9CQUFRO0FBQWYsV0FBUjtBQUFBO0FBSFAsT0FObUIsRUFVcEI7QUFDQUgsZUFBTyxRQURQO0FBRUFDLG1CQUFXLFdBRlg7QUFHQUMsZ0JBQVE7QUFBQSxpQkFBUTtBQUFBO0FBQUE7QUFBT0Msb0JBQVE7QUFBZixXQUFSO0FBQUE7QUFIUixPQVZvQixFQWNuQjtBQUNESCxlQUFPLElBRE47QUFFREUsZ0JBQVEsZ0JBQUNDLElBQUQsRUFBT0MsTUFBUDtBQUFBLGlCQUFtQjtBQUFBO0FBQUE7QUFDeEJ6RCxrQkFBTTJELE1BQU4sR0FBZSxDQUFmLEdBQW9CO0FBQUE7QUFBQSxnQkFBRyxTQUFTO0FBQUEseUJBQU0sT0FBS3BDLFVBQUwsQ0FBZ0JrQyxNQUFoQixDQUFOO0FBQUEsaUJBQVo7QUFBQTtBQUFBLGFBQXBCLEdBQXlFLElBRGpEO0FBRXhCekQsa0JBQU0yRCxNQUFOLEdBQWUsQ0FBZixHQUFvQjtBQUFBO0FBQUEsZ0JBQUcsU0FBUztBQUFBLHlCQUFNLE9BQUszQixhQUFMLENBQW1CeUIsT0FBT3ZELEVBQTFCLENBQU47QUFBQSxpQkFBWjtBQUFBO0FBQUEsYUFBcEIsR0FBK0U7QUFGdkQsV0FBbkI7QUFBQTtBQUZQLE9BZG1CLENBQXRCO0FBcUJBLGFBQ0U7QUFBQTtBQUFBO0FBRUlGLGNBQU0yRCxNQUFOLEdBQWUsQ0FBZixHQUFtQixJQUFuQixHQUNFO0FBQUE7QUFBQTtBQUNFLG1CQUFNLG9CQURSO0FBRUUsdUJBQVcsa0JBQWEsYUFBYixDQUZiO0FBR0UsMkRBQU8sU0FBU1AsWUFBaEIsRUFBOEIsWUFBWXBELEtBQTFDLEVBQWlELFlBQVksS0FBN0QsRUFBb0UsUUFBTyxJQUEzRTtBQUhGLFNBSE47QUFVRTtBQUFBO0FBQUE7QUFDRSxtQkFBTTtBQURSO0FBR0UsMkRBQU8sU0FBUzBELGFBQWhCLEVBQStCLFlBQVl6RCxNQUEzQyxFQUFtRCxZQUFZLEtBQS9ELEVBQXNFLFFBQU8sSUFBN0UsR0FIRjtBQUlHRCxnQkFBTTJELE1BQU4sR0FBZSxDQUFmLEdBQW1CLElBQW5CLEdBQ0M7QUFBQTtBQUFBLGNBQVEsV0FBVyxrQkFBYSxhQUFiLENBQW5CLEVBQWdELE1BQUssT0FBckQsRUFBNkQsU0FBUyxLQUFLbEQsU0FBM0U7QUFDRSw0REFBTSxNQUFLLE1BQVgsR0FERjtBQUFBO0FBQUE7QUFMSixTQVZGO0FBb0JHdUM7QUFwQkgsT0FERjtBQXdCRDs7O3dDQUNrQjtBQUNqQixXQUFLckMsS0FBTCxDQUFXQyxJQUFYLENBQWdCQyxjQUFoQjtBQUNBLFdBQUtFLGNBQUw7QUFDRDs7Ozs7Ozs7O0VBNUhtQixnQkFBTTZDLFM7O0FBcU81QixJQUFJQyxjQUFjLGVBQUtDLE1BQUwsR0FBY2pFLE9BQWQsQ0FBbEI7ZUFDZWdFLFc7Ozs7Ozs7Ozs7Ozs7MEJBdE9UaEUsTzswQkFxT0ZnRSxXIiwiZmlsZSI6InNjcmlwdHMvMl8zYTUxMTBlNmU4NjdmZjcyZTRkNi5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxudmFyIGNvbnRlbnQgPSByZXF1aXJlKFwiISEuLi8uLi8uLi8uLi9jc3MtbG9hZGVyL2luZGV4LmpzIS4vaW5kZXguY3NzXCIpO1xuXG5pZih0eXBlb2YgY29udGVudCA9PT0gJ3N0cmluZycpIGNvbnRlbnQgPSBbW21vZHVsZS5pZCwgY29udGVudCwgJyddXTtcblxudmFyIHRyYW5zZm9ybTtcbnZhciBpbnNlcnRJbnRvO1xuXG5cblxudmFyIG9wdGlvbnMgPSB7XCJobXJcIjp0cnVlfVxuXG5vcHRpb25zLnRyYW5zZm9ybSA9IHRyYW5zZm9ybVxub3B0aW9ucy5pbnNlcnRJbnRvID0gdW5kZWZpbmVkO1xuXG52YXIgdXBkYXRlID0gcmVxdWlyZShcIiEuLi8uLi8uLi8uLi9zdHlsZS1sb2FkZXIvbGliL2FkZFN0eWxlcy5qc1wiKShjb250ZW50LCBvcHRpb25zKTtcblxuaWYoY29udGVudC5sb2NhbHMpIG1vZHVsZS5leHBvcnRzID0gY29udGVudC5sb2NhbHM7XG5cbmlmKG1vZHVsZS5ob3QpIHtcblx0bW9kdWxlLmhvdC5hY2NlcHQoXCIhIS4uLy4uLy4uLy4uL2Nzcy1sb2FkZXIvaW5kZXguanMhLi9pbmRleC5jc3NcIiwgZnVuY3Rpb24oKSB7XG5cdFx0dmFyIG5ld0NvbnRlbnQgPSByZXF1aXJlKFwiISEuLi8uLi8uLi8uLi9jc3MtbG9hZGVyL2luZGV4LmpzIS4vaW5kZXguY3NzXCIpO1xuXG5cdFx0aWYodHlwZW9mIG5ld0NvbnRlbnQgPT09ICdzdHJpbmcnKSBuZXdDb250ZW50ID0gW1ttb2R1bGUuaWQsIG5ld0NvbnRlbnQsICcnXV07XG5cblx0XHR2YXIgbG9jYWxzID0gKGZ1bmN0aW9uKGEsIGIpIHtcblx0XHRcdHZhciBrZXksIGlkeCA9IDA7XG5cblx0XHRcdGZvcihrZXkgaW4gYSkge1xuXHRcdFx0XHRpZighYiB8fCBhW2tleV0gIT09IGJba2V5XSkgcmV0dXJuIGZhbHNlO1xuXHRcdFx0XHRpZHgrKztcblx0XHRcdH1cblxuXHRcdFx0Zm9yKGtleSBpbiBiKSBpZHgtLTtcblxuXHRcdFx0cmV0dXJuIGlkeCA9PT0gMDtcblx0XHR9KGNvbnRlbnQubG9jYWxzLCBuZXdDb250ZW50LmxvY2FscykpO1xuXG5cdFx0aWYoIWxvY2FscykgdGhyb3cgbmV3IEVycm9yKCdBYm9ydGluZyBDU1MgSE1SIGR1ZSB0byBjaGFuZ2VkIGNzcy1tb2R1bGVzIGxvY2Fscy4nKTtcblxuXHRcdHVwZGF0ZShuZXdDb250ZW50KTtcblx0fSk7XG5cblx0bW9kdWxlLmhvdC5kaXNwb3NlKGZ1bmN0aW9uKCkgeyB1cGRhdGUoKTsgfSk7XG59IiwiXG52YXIgY29udGVudCA9IHJlcXVpcmUoXCIhIS4uLy4uLy4uLy4uL2Nzcy1sb2FkZXIvaW5kZXguanMhLi9pbmRleC5jc3NcIik7XG5cbmlmKHR5cGVvZiBjb250ZW50ID09PSAnc3RyaW5nJykgY29udGVudCA9IFtbbW9kdWxlLmlkLCBjb250ZW50LCAnJ11dO1xuXG52YXIgdHJhbnNmb3JtO1xudmFyIGluc2VydEludG87XG5cblxuXG52YXIgb3B0aW9ucyA9IHtcImhtclwiOnRydWV9XG5cbm9wdGlvbnMudHJhbnNmb3JtID0gdHJhbnNmb3JtXG5vcHRpb25zLmluc2VydEludG8gPSB1bmRlZmluZWQ7XG5cbnZhciB1cGRhdGUgPSByZXF1aXJlKFwiIS4uLy4uLy4uLy4uL3N0eWxlLWxvYWRlci9saWIvYWRkU3R5bGVzLmpzXCIpKGNvbnRlbnQsIG9wdGlvbnMpO1xuXG5pZihjb250ZW50LmxvY2FscykgbW9kdWxlLmV4cG9ydHMgPSBjb250ZW50LmxvY2FscztcblxuaWYobW9kdWxlLmhvdCkge1xuXHRtb2R1bGUuaG90LmFjY2VwdChcIiEhLi4vLi4vLi4vLi4vY3NzLWxvYWRlci9pbmRleC5qcyEuL2luZGV4LmNzc1wiLCBmdW5jdGlvbigpIHtcblx0XHR2YXIgbmV3Q29udGVudCA9IHJlcXVpcmUoXCIhIS4uLy4uLy4uLy4uL2Nzcy1sb2FkZXIvaW5kZXguanMhLi9pbmRleC5jc3NcIik7XG5cblx0XHRpZih0eXBlb2YgbmV3Q29udGVudCA9PT0gJ3N0cmluZycpIG5ld0NvbnRlbnQgPSBbW21vZHVsZS5pZCwgbmV3Q29udGVudCwgJyddXTtcblxuXHRcdHZhciBsb2NhbHMgPSAoZnVuY3Rpb24oYSwgYikge1xuXHRcdFx0dmFyIGtleSwgaWR4ID0gMDtcblxuXHRcdFx0Zm9yKGtleSBpbiBhKSB7XG5cdFx0XHRcdGlmKCFiIHx8IGFba2V5XSAhPT0gYltrZXldKSByZXR1cm4gZmFsc2U7XG5cdFx0XHRcdGlkeCsrO1xuXHRcdFx0fVxuXG5cdFx0XHRmb3Ioa2V5IGluIGIpIGlkeC0tO1xuXG5cdFx0XHRyZXR1cm4gaWR4ID09PSAwO1xuXHRcdH0oY29udGVudC5sb2NhbHMsIG5ld0NvbnRlbnQubG9jYWxzKSk7XG5cblx0XHRpZighbG9jYWxzKSB0aHJvdyBuZXcgRXJyb3IoJ0Fib3J0aW5nIENTUyBITVIgZHVlIHRvIGNoYW5nZWQgY3NzLW1vZHVsZXMgbG9jYWxzLicpO1xuXG5cdFx0dXBkYXRlKG5ld0NvbnRlbnQpO1xuXHR9KTtcblxuXHRtb2R1bGUuaG90LmRpc3Bvc2UoZnVuY3Rpb24oKSB7IHVwZGF0ZSgpOyB9KTtcbn0iLCJcbnZhciBjb250ZW50ID0gcmVxdWlyZShcIiEhLi4vLi4vLi4vLi4vY3NzLWxvYWRlci9pbmRleC5qcyEuL2luZGV4LmNzc1wiKTtcblxuaWYodHlwZW9mIGNvbnRlbnQgPT09ICdzdHJpbmcnKSBjb250ZW50ID0gW1ttb2R1bGUuaWQsIGNvbnRlbnQsICcnXV07XG5cbnZhciB0cmFuc2Zvcm07XG52YXIgaW5zZXJ0SW50bztcblxuXG5cbnZhciBvcHRpb25zID0ge1wiaG1yXCI6dHJ1ZX1cblxub3B0aW9ucy50cmFuc2Zvcm0gPSB0cmFuc2Zvcm1cbm9wdGlvbnMuaW5zZXJ0SW50byA9IHVuZGVmaW5lZDtcblxudmFyIHVwZGF0ZSA9IHJlcXVpcmUoXCIhLi4vLi4vLi4vLi4vc3R5bGUtbG9hZGVyL2xpYi9hZGRTdHlsZXMuanNcIikoY29udGVudCwgb3B0aW9ucyk7XG5cbmlmKGNvbnRlbnQubG9jYWxzKSBtb2R1bGUuZXhwb3J0cyA9IGNvbnRlbnQubG9jYWxzO1xuXG5pZihtb2R1bGUuaG90KSB7XG5cdG1vZHVsZS5ob3QuYWNjZXB0KFwiISEuLi8uLi8uLi8uLi9jc3MtbG9hZGVyL2luZGV4LmpzIS4vaW5kZXguY3NzXCIsIGZ1bmN0aW9uKCkge1xuXHRcdHZhciBuZXdDb250ZW50ID0gcmVxdWlyZShcIiEhLi4vLi4vLi4vLi4vY3NzLWxvYWRlci9pbmRleC5qcyEuL2luZGV4LmNzc1wiKTtcblxuXHRcdGlmKHR5cGVvZiBuZXdDb250ZW50ID09PSAnc3RyaW5nJykgbmV3Q29udGVudCA9IFtbbW9kdWxlLmlkLCBuZXdDb250ZW50LCAnJ11dO1xuXG5cdFx0dmFyIGxvY2FscyA9IChmdW5jdGlvbihhLCBiKSB7XG5cdFx0XHR2YXIga2V5LCBpZHggPSAwO1xuXG5cdFx0XHRmb3Ioa2V5IGluIGEpIHtcblx0XHRcdFx0aWYoIWIgfHwgYVtrZXldICE9PSBiW2tleV0pIHJldHVybiBmYWxzZTtcblx0XHRcdFx0aWR4Kys7XG5cdFx0XHR9XG5cblx0XHRcdGZvcihrZXkgaW4gYikgaWR4LS07XG5cblx0XHRcdHJldHVybiBpZHggPT09IDA7XG5cdFx0fShjb250ZW50LmxvY2FscywgbmV3Q29udGVudC5sb2NhbHMpKTtcblxuXHRcdGlmKCFsb2NhbHMpIHRocm93IG5ldyBFcnJvcignQWJvcnRpbmcgQ1NTIEhNUiBkdWUgdG8gY2hhbmdlZCBjc3MtbW9kdWxlcyBsb2NhbHMuJyk7XG5cblx0XHR1cGRhdGUobmV3Q29udGVudCk7XG5cdH0pO1xuXG5cdG1vZHVsZS5ob3QuZGlzcG9zZShmdW5jdGlvbigpIHsgdXBkYXRlKCk7IH0pO1xufSIsIlxudmFyIGNvbnRlbnQgPSByZXF1aXJlKFwiISEuLi8uLi8uLi8uLi9jc3MtbG9hZGVyL2luZGV4LmpzIS4vaW5kZXguY3NzXCIpO1xuXG5pZih0eXBlb2YgY29udGVudCA9PT0gJ3N0cmluZycpIGNvbnRlbnQgPSBbW21vZHVsZS5pZCwgY29udGVudCwgJyddXTtcblxudmFyIHRyYW5zZm9ybTtcbnZhciBpbnNlcnRJbnRvO1xuXG5cblxudmFyIG9wdGlvbnMgPSB7XCJobXJcIjp0cnVlfVxuXG5vcHRpb25zLnRyYW5zZm9ybSA9IHRyYW5zZm9ybVxub3B0aW9ucy5pbnNlcnRJbnRvID0gdW5kZWZpbmVkO1xuXG52YXIgdXBkYXRlID0gcmVxdWlyZShcIiEuLi8uLi8uLi8uLi9zdHlsZS1sb2FkZXIvbGliL2FkZFN0eWxlcy5qc1wiKShjb250ZW50LCBvcHRpb25zKTtcblxuaWYoY29udGVudC5sb2NhbHMpIG1vZHVsZS5leHBvcnRzID0gY29udGVudC5sb2NhbHM7XG5cbmlmKG1vZHVsZS5ob3QpIHtcblx0bW9kdWxlLmhvdC5hY2NlcHQoXCIhIS4uLy4uLy4uLy4uL2Nzcy1sb2FkZXIvaW5kZXguanMhLi9pbmRleC5jc3NcIiwgZnVuY3Rpb24oKSB7XG5cdFx0dmFyIG5ld0NvbnRlbnQgPSByZXF1aXJlKFwiISEuLi8uLi8uLi8uLi9jc3MtbG9hZGVyL2luZGV4LmpzIS4vaW5kZXguY3NzXCIpO1xuXG5cdFx0aWYodHlwZW9mIG5ld0NvbnRlbnQgPT09ICdzdHJpbmcnKSBuZXdDb250ZW50ID0gW1ttb2R1bGUuaWQsIG5ld0NvbnRlbnQsICcnXV07XG5cblx0XHR2YXIgbG9jYWxzID0gKGZ1bmN0aW9uKGEsIGIpIHtcblx0XHRcdHZhciBrZXksIGlkeCA9IDA7XG5cblx0XHRcdGZvcihrZXkgaW4gYSkge1xuXHRcdFx0XHRpZighYiB8fCBhW2tleV0gIT09IGJba2V5XSkgcmV0dXJuIGZhbHNlO1xuXHRcdFx0XHRpZHgrKztcblx0XHRcdH1cblxuXHRcdFx0Zm9yKGtleSBpbiBiKSBpZHgtLTtcblxuXHRcdFx0cmV0dXJuIGlkeCA9PT0gMDtcblx0XHR9KGNvbnRlbnQubG9jYWxzLCBuZXdDb250ZW50LmxvY2FscykpO1xuXG5cdFx0aWYoIWxvY2FscykgdGhyb3cgbmV3IEVycm9yKCdBYm9ydGluZyBDU1MgSE1SIGR1ZSB0byBjaGFuZ2VkIGNzcy1tb2R1bGVzIGxvY2Fscy4nKTtcblxuXHRcdHVwZGF0ZShuZXdDb250ZW50KTtcblx0fSk7XG5cblx0bW9kdWxlLmhvdC5kaXNwb3NlKGZ1bmN0aW9uKCkgeyB1cGRhdGUoKTsgfSk7XG59IiwiZXhwb3J0cyA9IG1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIi4uLy4uLy4uLy4uL2Nzcy1sb2FkZXIvbGliL2Nzcy1iYXNlLmpzXCIpKGZhbHNlKTtcbi8vIGltcG9ydHNcblxuXG4vLyBtb2R1bGVcbmV4cG9ydHMucHVzaChbbW9kdWxlLmlkLCBcIi8qIHN0eWxlbGludC1kaXNhYmxlIGF0LXJ1bGUtZW1wdHktbGluZS1iZWZvcmUsYXQtcnVsZS1uYW1lLXNwYWNlLWFmdGVyLGF0LXJ1bGUtbm8tdW5rbm93biAqL1xcbi8qIHN0eWxlbGludC1kaXNhYmxlIG5vLWR1cGxpY2F0ZS1zZWxlY3RvcnMgKi9cXG4vKiBzdHlsZWxpbnQtZGlzYWJsZSBkZWNsYXJhdGlvbi1iYW5nLXNwYWNlLWJlZm9yZSxuby1kdXBsaWNhdGUtc2VsZWN0b3JzICovXFxuLyogc3R5bGVsaW50LWRpc2FibGUgZGVjbGFyYXRpb24tYmFuZy1zcGFjZS1iZWZvcmUsbm8tZHVwbGljYXRlLXNlbGVjdG9ycyxzdHJpbmctbm8tbmV3bGluZSAqL1xcbi5hbnQtbWVzc2FnZSB7XFxuICBmb250LWZhbWlseTogXFxcIk1vbm9zcGFjZWQgTnVtYmVyXFxcIiwgXFxcIkNoaW5lc2UgUXVvdGVcXFwiLCAtYXBwbGUtc3lzdGVtLCBCbGlua01hY1N5c3RlbUZvbnQsIFxcXCJTZWdvZSBVSVxcXCIsIFJvYm90bywgXFxcIlBpbmdGYW5nIFNDXFxcIiwgXFxcIkhpcmFnaW5vIFNhbnMgR0JcXFwiLCBcXFwiTWljcm9zb2Z0IFlhSGVpXFxcIiwgXFxcIkhlbHZldGljYSBOZXVlXFxcIiwgSGVsdmV0aWNhLCBBcmlhbCwgc2Fucy1zZXJpZjtcXG4gIGZvbnQtc2l6ZTogMTRweDtcXG4gIGxpbmUtaGVpZ2h0OiAxLjU7XFxuICBjb2xvcjogcmdiYSgwLCAwLCAwLCAwLjY1KTtcXG4gIC13ZWJraXQtYm94LXNpemluZzogYm9yZGVyLWJveDtcXG4gICAgICAgICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcXG4gIG1hcmdpbjogMDtcXG4gIHBhZGRpbmc6IDA7XFxuICBsaXN0LXN0eWxlOiBub25lO1xcbiAgcG9zaXRpb246IGZpeGVkO1xcbiAgei1pbmRleDogMTAxMDtcXG4gIHdpZHRoOiAxMDAlO1xcbiAgdG9wOiAxNnB4O1xcbiAgbGVmdDogMDtcXG4gIHBvaW50ZXItZXZlbnRzOiBub25lO1xcbn1cXG4uYW50LW1lc3NhZ2Utbm90aWNlIHtcXG4gIHBhZGRpbmc6IDhweDtcXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcXG59XFxuLmFudC1tZXNzYWdlLW5vdGljZTpmaXJzdC1jaGlsZCB7XFxuICBtYXJnaW4tdG9wOiAtOHB4O1xcbn1cXG4uYW50LW1lc3NhZ2Utbm90aWNlLWNvbnRlbnQge1xcbiAgcGFkZGluZzogMTBweCAxNnB4O1xcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiAwIDRweCAxMnB4IHJnYmEoMCwgMCwgMCwgMC4xNSk7XFxuICAgICAgICAgIGJveC1zaGFkb3c6IDAgNHB4IDEycHggcmdiYSgwLCAwLCAwLCAwLjE1KTtcXG4gIGJhY2tncm91bmQ6ICNmZmY7XFxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XFxuICBwb2ludGVyLWV2ZW50czogYWxsO1xcbn1cXG4uYW50LW1lc3NhZ2Utc3VjY2VzcyAuYW50aWNvbiB7XFxuICBjb2xvcjogIzUyYzQxYTtcXG59XFxuLmFudC1tZXNzYWdlLWVycm9yIC5hbnRpY29uIHtcXG4gIGNvbG9yOiAjZjUyMjJkO1xcbn1cXG4uYW50LW1lc3NhZ2Utd2FybmluZyAuYW50aWNvbiB7XFxuICBjb2xvcjogI2ZhYWQxNDtcXG59XFxuLmFudC1tZXNzYWdlLWluZm8gLmFudGljb24sXFxuLmFudC1tZXNzYWdlLWxvYWRpbmcgLmFudGljb24ge1xcbiAgY29sb3I6ICMxODkwZmY7XFxufVxcbi5hbnQtbWVzc2FnZSAuYW50aWNvbiB7XFxuICBtYXJnaW4tcmlnaHQ6IDhweDtcXG4gIGZvbnQtc2l6ZTogMTZweDtcXG4gIHRvcDogMXB4O1xcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xcbn1cXG4uYW50LW1lc3NhZ2Utbm90aWNlLm1vdmUtdXAtbGVhdmUubW92ZS11cC1sZWF2ZS1hY3RpdmUge1xcbiAgLXdlYmtpdC1hbmltYXRpb24tbmFtZTogTWVzc2FnZU1vdmVPdXQ7XFxuICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBNZXNzYWdlTW92ZU91dDtcXG4gIG92ZXJmbG93OiBoaWRkZW47XFxuICAtd2Via2l0LWFuaW1hdGlvbi1kdXJhdGlvbjogLjNzO1xcbiAgICAgICAgICBhbmltYXRpb24tZHVyYXRpb246IC4zcztcXG59XFxuQC13ZWJraXQta2V5ZnJhbWVzIE1lc3NhZ2VNb3ZlT3V0IHtcXG4gIDAlIHtcXG4gICAgb3BhY2l0eTogMTtcXG4gICAgbWF4LWhlaWdodDogMTUwcHg7XFxuICAgIHBhZGRpbmc6IDhweDtcXG4gIH1cXG4gIDEwMCUge1xcbiAgICBvcGFjaXR5OiAwO1xcbiAgICBtYXgtaGVpZ2h0OiAwO1xcbiAgICBwYWRkaW5nOiAwO1xcbiAgfVxcbn1cXG5Aa2V5ZnJhbWVzIE1lc3NhZ2VNb3ZlT3V0IHtcXG4gIDAlIHtcXG4gICAgb3BhY2l0eTogMTtcXG4gICAgbWF4LWhlaWdodDogMTUwcHg7XFxuICAgIHBhZGRpbmc6IDhweDtcXG4gIH1cXG4gIDEwMCUge1xcbiAgICBvcGFjaXR5OiAwO1xcbiAgICBtYXgtaGVpZ2h0OiAwO1xcbiAgICBwYWRkaW5nOiAwO1xcbiAgfVxcbn1cXG5cIiwgXCJcIl0pO1xuXG4vLyBleHBvcnRzXG4iLCJleHBvcnRzID0gbW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiLi4vLi4vLi4vLi4vY3NzLWxvYWRlci9saWIvY3NzLWJhc2UuanNcIikoZmFsc2UpO1xuLy8gaW1wb3J0c1xuXG5cbi8vIG1vZHVsZVxuZXhwb3J0cy5wdXNoKFttb2R1bGUuaWQsIFwiLyogc3R5bGVsaW50LWRpc2FibGUgYXQtcnVsZS1lbXB0eS1saW5lLWJlZm9yZSxhdC1ydWxlLW5hbWUtc3BhY2UtYWZ0ZXIsYXQtcnVsZS1uby11bmtub3duICovXFxuLyogc3R5bGVsaW50LWRpc2FibGUgbm8tZHVwbGljYXRlLXNlbGVjdG9ycyAqL1xcbi8qIHN0eWxlbGludC1kaXNhYmxlIGRlY2xhcmF0aW9uLWJhbmctc3BhY2UtYmVmb3JlLG5vLWR1cGxpY2F0ZS1zZWxlY3RvcnMgKi9cXG4vKiBzdHlsZWxpbnQtZGlzYWJsZSBkZWNsYXJhdGlvbi1iYW5nLXNwYWNlLWJlZm9yZSxuby1kdXBsaWNhdGUtc2VsZWN0b3JzLHN0cmluZy1uby1uZXdsaW5lICovXFxuLmFudC1tb2RhbCB7XFxuICBmb250LWZhbWlseTogXFxcIk1vbm9zcGFjZWQgTnVtYmVyXFxcIiwgXFxcIkNoaW5lc2UgUXVvdGVcXFwiLCAtYXBwbGUtc3lzdGVtLCBCbGlua01hY1N5c3RlbUZvbnQsIFxcXCJTZWdvZSBVSVxcXCIsIFJvYm90bywgXFxcIlBpbmdGYW5nIFNDXFxcIiwgXFxcIkhpcmFnaW5vIFNhbnMgR0JcXFwiLCBcXFwiTWljcm9zb2Z0IFlhSGVpXFxcIiwgXFxcIkhlbHZldGljYSBOZXVlXFxcIiwgSGVsdmV0aWNhLCBBcmlhbCwgc2Fucy1zZXJpZjtcXG4gIGZvbnQtc2l6ZTogMTRweDtcXG4gIGxpbmUtaGVpZ2h0OiAxLjU7XFxuICBjb2xvcjogcmdiYSgwLCAwLCAwLCAwLjY1KTtcXG4gIC13ZWJraXQtYm94LXNpemluZzogYm9yZGVyLWJveDtcXG4gICAgICAgICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcXG4gIG1hcmdpbjogMDtcXG4gIHBhZGRpbmc6IDA7XFxuICBsaXN0LXN0eWxlOiBub25lO1xcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xcbiAgd2lkdGg6IGF1dG87XFxuICBtYXJnaW46IDAgYXV0bztcXG4gIHRvcDogMTAwcHg7XFxuICBwYWRkaW5nLWJvdHRvbTogMjRweDtcXG59XFxuLmFudC1tb2RhbC13cmFwIHtcXG4gIHBvc2l0aW9uOiBmaXhlZDtcXG4gIG92ZXJmbG93OiBhdXRvO1xcbiAgdG9wOiAwO1xcbiAgcmlnaHQ6IDA7XFxuICBib3R0b206IDA7XFxuICBsZWZ0OiAwO1xcbiAgei1pbmRleDogMTAwMDtcXG4gIC13ZWJraXQtb3ZlcmZsb3ctc2Nyb2xsaW5nOiB0b3VjaDtcXG4gIG91dGxpbmU6IDA7XFxufVxcbi5hbnQtbW9kYWwtdGl0bGUge1xcbiAgbWFyZ2luOiAwO1xcbiAgZm9udC1zaXplOiAxNnB4O1xcbiAgbGluZS1oZWlnaHQ6IDIycHg7XFxuICBmb250LXdlaWdodDogNTAwO1xcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC44NSk7XFxufVxcbi5hbnQtbW9kYWwtY29udGVudCB7XFxuICBwb3NpdGlvbjogcmVsYXRpdmU7XFxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xcbiAgYm9yZGVyOiAwO1xcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xcbiAgYmFja2dyb3VuZC1jbGlwOiBwYWRkaW5nLWJveDtcXG4gIC13ZWJraXQtYm94LXNoYWRvdzogMCA0cHggMTJweCByZ2JhKDAsIDAsIDAsIDAuMTUpO1xcbiAgICAgICAgICBib3gtc2hhZG93OiAwIDRweCAxMnB4IHJnYmEoMCwgMCwgMCwgMC4xNSk7XFxufVxcbi5hbnQtbW9kYWwtY2xvc2Uge1xcbiAgY3Vyc29yOiBwb2ludGVyO1xcbiAgYm9yZGVyOiAwO1xcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XFxuICBwb3NpdGlvbjogYWJzb2x1dGU7XFxuICByaWdodDogMDtcXG4gIHRvcDogMDtcXG4gIHotaW5kZXg6IDEwO1xcbiAgZm9udC13ZWlnaHQ6IDcwMDtcXG4gIGxpbmUtaGVpZ2h0OiAxO1xcbiAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xcbiAgLXdlYmtpdC10cmFuc2l0aW9uOiBjb2xvciAuM3M7XFxuICB0cmFuc2l0aW9uOiBjb2xvciAuM3M7XFxuICBjb2xvcjogcmdiYSgwLCAwLCAwLCAwLjQ1KTtcXG4gIG91dGxpbmU6IDA7XFxuICBwYWRkaW5nOiAwO1xcbn1cXG4uYW50LW1vZGFsLWNsb3NlLXgge1xcbiAgZGlzcGxheTogYmxvY2s7XFxuICBmb250LXN0eWxlOiBub3JtYWw7XFxuICB2ZXJ0aWNhbC1hbGlnbjogYmFzZWxpbmU7XFxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XFxuICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcXG4gIHRleHQtcmVuZGVyaW5nOiBhdXRvO1xcbiAgd2lkdGg6IDU2cHg7XFxuICBoZWlnaHQ6IDU2cHg7XFxuICBsaW5lLWhlaWdodDogNTZweDtcXG4gIGZvbnQtc2l6ZTogMTZweDtcXG59XFxuLmFudC1tb2RhbC1jbG9zZS14OmJlZm9yZSB7XFxuICBjb250ZW50OiBcXFwiXFxcXEU2MzNcXFwiO1xcbiAgZGlzcGxheTogYmxvY2s7XFxuICBmb250LWZhbWlseTogXFxcImFudGljb25cXFwiICFpbXBvcnRhbnQ7XFxufVxcbi5hbnQtbW9kYWwtY2xvc2U6Zm9jdXMsXFxuLmFudC1tb2RhbC1jbG9zZTpob3ZlciB7XFxuICBjb2xvcjogIzQ0NDtcXG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcXG59XFxuLmFudC1tb2RhbC1oZWFkZXIge1xcbiAgcGFkZGluZzogMTZweCAyNHB4O1xcbiAgYm9yZGVyLXJhZGl1czogNHB4IDRweCAwIDA7XFxuICBiYWNrZ3JvdW5kOiAjZmZmO1xcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC42NSk7XFxuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2U4ZThlODtcXG59XFxuLmFudC1tb2RhbC1ib2R5IHtcXG4gIHBhZGRpbmc6IDI0cHg7XFxuICBmb250LXNpemU6IDE0cHg7XFxuICBsaW5lLWhlaWdodDogMS41O1xcbiAgd29yZC13cmFwOiBicmVhay13b3JkO1xcbn1cXG4uYW50LW1vZGFsLWZvb3RlciB7XFxuICBib3JkZXItdG9wOiAxcHggc29saWQgI2U4ZThlODtcXG4gIHBhZGRpbmc6IDEwcHggMTZweDtcXG4gIHRleHQtYWxpZ246IHJpZ2h0O1xcbiAgYm9yZGVyLXJhZGl1czogMCAwIDRweCA0cHg7XFxufVxcbi5hbnQtbW9kYWwtZm9vdGVyIGJ1dHRvbiArIGJ1dHRvbiB7XFxuICBtYXJnaW4tbGVmdDogOHB4O1xcbiAgbWFyZ2luLWJvdHRvbTogMDtcXG59XFxuLmFudC1tb2RhbC56b29tLWVudGVyLFxcbi5hbnQtbW9kYWwuem9vbS1hcHBlYXIge1xcbiAgLXdlYmtpdC1hbmltYXRpb24tZHVyYXRpb246IDAuM3M7XFxuICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogMC4zcztcXG4gIC13ZWJraXQtdHJhbnNmb3JtOiBub25lO1xcbiAgICAgIC1tcy10cmFuc2Zvcm06IG5vbmU7XFxuICAgICAgICAgIHRyYW5zZm9ybTogbm9uZTtcXG4gIG9wYWNpdHk6IDA7XFxufVxcbi5hbnQtbW9kYWwtbWFzayB7XFxuICBwb3NpdGlvbjogZml4ZWQ7XFxuICB0b3A6IDA7XFxuICByaWdodDogMDtcXG4gIGxlZnQ6IDA7XFxuICBib3R0b206IDA7XFxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMzczNzM3O1xcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiYSgwLCAwLCAwLCAwLjY1KTtcXG4gIGhlaWdodDogMTAwJTtcXG4gIHotaW5kZXg6IDEwMDA7XFxuICBmaWx0ZXI6IGFscGhhKG9wYWNpdHk9NTApO1xcbn1cXG4uYW50LW1vZGFsLW1hc2staGlkZGVuIHtcXG4gIGRpc3BsYXk6IG5vbmU7XFxufVxcbi5hbnQtbW9kYWwtb3BlbiB7XFxuICBvdmVyZmxvdzogaGlkZGVuO1xcbn1cXG5AbWVkaWEgKG1heC13aWR0aDogNzY4cHgpIHtcXG4gIC5hbnQtbW9kYWwge1xcbiAgICB3aWR0aDogYXV0byAhaW1wb3J0YW50O1xcbiAgICBtYXJnaW46IDEwcHg7XFxuICB9XFxuICAudmVydGljYWwtY2VudGVyLW1vZGFsIC5hbnQtbW9kYWwge1xcbiAgICAtd2Via2l0LWJveC1mbGV4OiAxO1xcbiAgICAtd2Via2l0LWZsZXg6IDE7XFxuICAgICAgICAtbXMtZmxleDogMTtcXG4gICAgICAgICAgICBmbGV4OiAxO1xcbiAgfVxcbn1cXG4uYW50LWNvbmZpcm0gLmFudC1tb2RhbC1oZWFkZXIge1xcbiAgZGlzcGxheTogbm9uZTtcXG59XFxuLmFudC1jb25maXJtIC5hbnQtbW9kYWwtY2xvc2Uge1xcbiAgZGlzcGxheTogbm9uZTtcXG59XFxuLmFudC1jb25maXJtIC5hbnQtbW9kYWwtYm9keSB7XFxuICBwYWRkaW5nOiAzMnB4IDMycHggMjRweDtcXG59XFxuLmFudC1jb25maXJtLWJvZHktd3JhcHBlciB7XFxuICB6b29tOiAxO1xcbn1cXG4uYW50LWNvbmZpcm0tYm9keS13cmFwcGVyOmJlZm9yZSxcXG4uYW50LWNvbmZpcm0tYm9keS13cmFwcGVyOmFmdGVyIHtcXG4gIGNvbnRlbnQ6IFxcXCIgXFxcIjtcXG4gIGRpc3BsYXk6IHRhYmxlO1xcbn1cXG4uYW50LWNvbmZpcm0tYm9keS13cmFwcGVyOmFmdGVyIHtcXG4gIGNsZWFyOiBib3RoO1xcbiAgdmlzaWJpbGl0eTogaGlkZGVuO1xcbiAgZm9udC1zaXplOiAwO1xcbiAgaGVpZ2h0OiAwO1xcbn1cXG4uYW50LWNvbmZpcm0tYm9keSAuYW50LWNvbmZpcm0tdGl0bGUge1xcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC44NSk7XFxuICBmb250LXdlaWdodDogNTAwO1xcbiAgZm9udC1zaXplOiAxNnB4O1xcbiAgbGluZS1oZWlnaHQ6IDIycHg7XFxuICBkaXNwbGF5OiBibG9jaztcXG4gIG92ZXJmbG93OiBhdXRvO1xcbn1cXG4uYW50LWNvbmZpcm0tYm9keSAuYW50LWNvbmZpcm0tY29udGVudCB7XFxuICBtYXJnaW4tbGVmdDogMzhweDtcXG4gIGZvbnQtc2l6ZTogMTRweDtcXG4gIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuNjUpO1xcbiAgbWFyZ2luLXRvcDogOHB4O1xcbn1cXG4uYW50LWNvbmZpcm0tYm9keSA+IC5hbnRpY29uIHtcXG4gIGZvbnQtc2l6ZTogMjJweDtcXG4gIG1hcmdpbi1yaWdodDogMTZweDtcXG4gIGZsb2F0OiBsZWZ0O1xcbn1cXG4uYW50LWNvbmZpcm0gLmFudC1jb25maXJtLWJ0bnMge1xcbiAgbWFyZ2luLXRvcDogMjRweDtcXG4gIGZsb2F0OiByaWdodDtcXG59XFxuLmFudC1jb25maXJtIC5hbnQtY29uZmlybS1idG5zIGJ1dHRvbiArIGJ1dHRvbiB7XFxuICBtYXJnaW4tbGVmdDogOHB4O1xcbiAgbWFyZ2luLWJvdHRvbTogMDtcXG59XFxuLmFudC1jb25maXJtLWVycm9yIC5hbnQtY29uZmlybS1ib2R5ID4gLmFudGljb24ge1xcbiAgY29sb3I6ICNmNTIyMmQ7XFxufVxcbi5hbnQtY29uZmlybS13YXJuaW5nIC5hbnQtY29uZmlybS1ib2R5ID4gLmFudGljb24sXFxuLmFudC1jb25maXJtLWNvbmZpcm0gLmFudC1jb25maXJtLWJvZHkgPiAuYW50aWNvbiB7XFxuICBjb2xvcjogI2ZhYWQxNDtcXG59XFxuLmFudC1jb25maXJtLWluZm8gLmFudC1jb25maXJtLWJvZHkgPiAuYW50aWNvbiB7XFxuICBjb2xvcjogIzE4OTBmZjtcXG59XFxuLmFudC1jb25maXJtLXN1Y2Nlc3MgLmFudC1jb25maXJtLWJvZHkgPiAuYW50aWNvbiB7XFxuICBjb2xvcjogIzUyYzQxYTtcXG59XFxuXCIsIFwiXCJdKTtcblxuLy8gZXhwb3J0c1xuIiwiZXhwb3J0cyA9IG1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIi4uLy4uLy4uLy4uL2Nzcy1sb2FkZXIvbGliL2Nzcy1iYXNlLmpzXCIpKGZhbHNlKTtcbi8vIGltcG9ydHNcblxuXG4vLyBtb2R1bGVcbmV4cG9ydHMucHVzaChbbW9kdWxlLmlkLCBcIi8qIHN0eWxlbGludC1kaXNhYmxlIGF0LXJ1bGUtZW1wdHktbGluZS1iZWZvcmUsYXQtcnVsZS1uYW1lLXNwYWNlLWFmdGVyLGF0LXJ1bGUtbm8tdW5rbm93biAqL1xcbi8qIHN0eWxlbGludC1kaXNhYmxlIG5vLWR1cGxpY2F0ZS1zZWxlY3RvcnMgKi9cXG4vKiBzdHlsZWxpbnQtZGlzYWJsZSBkZWNsYXJhdGlvbi1iYW5nLXNwYWNlLWJlZm9yZSxuby1kdXBsaWNhdGUtc2VsZWN0b3JzICovXFxuLyogc3R5bGVsaW50LWRpc2FibGUgZGVjbGFyYXRpb24tYmFuZy1zcGFjZS1iZWZvcmUsbm8tZHVwbGljYXRlLXNlbGVjdG9ycyxzdHJpbmctbm8tbmV3bGluZSAqL1xcbi5hbnQtcmFkaW8tZ3JvdXAge1xcbiAgZm9udC1mYW1pbHk6IFxcXCJNb25vc3BhY2VkIE51bWJlclxcXCIsIFxcXCJDaGluZXNlIFF1b3RlXFxcIiwgLWFwcGxlLXN5c3RlbSwgQmxpbmtNYWNTeXN0ZW1Gb250LCBcXFwiU2Vnb2UgVUlcXFwiLCBSb2JvdG8sIFxcXCJQaW5nRmFuZyBTQ1xcXCIsIFxcXCJIaXJhZ2lubyBTYW5zIEdCXFxcIiwgXFxcIk1pY3Jvc29mdCBZYUhlaVxcXCIsIFxcXCJIZWx2ZXRpY2EgTmV1ZVxcXCIsIEhlbHZldGljYSwgQXJpYWwsIHNhbnMtc2VyaWY7XFxuICBmb250LXNpemU6IDE0cHg7XFxuICBsaW5lLWhlaWdodDogMS41O1xcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC42NSk7XFxuICAtd2Via2l0LWJveC1zaXppbmc6IGJvcmRlci1ib3g7XFxuICAgICAgICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XFxuICBtYXJnaW46IDA7XFxuICBwYWRkaW5nOiAwO1xcbiAgbGlzdC1zdHlsZTogbm9uZTtcXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcXG4gIGxpbmUtaGVpZ2h0OiB1bnNldDtcXG59XFxuLmFudC1yYWRpby13cmFwcGVyIHtcXG4gIGZvbnQtZmFtaWx5OiBcXFwiTW9ub3NwYWNlZCBOdW1iZXJcXFwiLCBcXFwiQ2hpbmVzZSBRdW90ZVxcXCIsIC1hcHBsZS1zeXN0ZW0sIEJsaW5rTWFjU3lzdGVtRm9udCwgXFxcIlNlZ29lIFVJXFxcIiwgUm9ib3RvLCBcXFwiUGluZ0ZhbmcgU0NcXFwiLCBcXFwiSGlyYWdpbm8gU2FucyBHQlxcXCIsIFxcXCJNaWNyb3NvZnQgWWFIZWlcXFwiLCBcXFwiSGVsdmV0aWNhIE5ldWVcXFwiLCBIZWx2ZXRpY2EsIEFyaWFsLCBzYW5zLXNlcmlmO1xcbiAgZm9udC1zaXplOiAxNHB4O1xcbiAgbGluZS1oZWlnaHQ6IDEuNTtcXG4gIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuNjUpO1xcbiAgLXdlYmtpdC1ib3gtc2l6aW5nOiBib3JkZXItYm94O1xcbiAgICAgICAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xcbiAgbWFyZ2luOiAwO1xcbiAgcGFkZGluZzogMDtcXG4gIGxpc3Qtc3R5bGU6IG5vbmU7XFxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XFxuICBwb3NpdGlvbjogcmVsYXRpdmU7XFxuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xcbiAgbWFyZ2luLXJpZ2h0OiA4cHg7XFxuICBjdXJzb3I6IHBvaW50ZXI7XFxufVxcbi5hbnQtcmFkaW8ge1xcbiAgZm9udC1mYW1pbHk6IFxcXCJNb25vc3BhY2VkIE51bWJlclxcXCIsIFxcXCJDaGluZXNlIFF1b3RlXFxcIiwgLWFwcGxlLXN5c3RlbSwgQmxpbmtNYWNTeXN0ZW1Gb250LCBcXFwiU2Vnb2UgVUlcXFwiLCBSb2JvdG8sIFxcXCJQaW5nRmFuZyBTQ1xcXCIsIFxcXCJIaXJhZ2lubyBTYW5zIEdCXFxcIiwgXFxcIk1pY3Jvc29mdCBZYUhlaVxcXCIsIFxcXCJIZWx2ZXRpY2EgTmV1ZVxcXCIsIEhlbHZldGljYSwgQXJpYWwsIHNhbnMtc2VyaWY7XFxuICBmb250LXNpemU6IDE0cHg7XFxuICBsaW5lLWhlaWdodDogMS41O1xcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC42NSk7XFxuICAtd2Via2l0LWJveC1zaXppbmc6IGJvcmRlci1ib3g7XFxuICAgICAgICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XFxuICBtYXJnaW46IDA7XFxuICBwYWRkaW5nOiAwO1xcbiAgbGlzdC1zdHlsZTogbm9uZTtcXG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XFxuICBvdXRsaW5lOiBub25lO1xcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xcbiAgbGluZS1oZWlnaHQ6IDE7XFxuICB2ZXJ0aWNhbC1hbGlnbjogdGV4dC1ib3R0b207XFxuICBjdXJzb3I6IHBvaW50ZXI7XFxufVxcbi5hbnQtcmFkaW8td3JhcHBlcjpob3ZlciAuYW50LXJhZGlvIC5hbnQtcmFkaW8taW5uZXIsXFxuLmFudC1yYWRpbzpob3ZlciAuYW50LXJhZGlvLWlubmVyLFxcbi5hbnQtcmFkaW8tZm9jdXNlZCAuYW50LXJhZGlvLWlubmVyIHtcXG4gIGJvcmRlci1jb2xvcjogIzE4OTBmZjtcXG59XFxuLmFudC1yYWRpby1jaGVja2VkOmFmdGVyIHtcXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcXG4gIHRvcDogMDtcXG4gIGxlZnQ6IDA7XFxuICB3aWR0aDogMTAwJTtcXG4gIGhlaWdodDogMTAwJTtcXG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcXG4gIGJvcmRlcjogMXB4IHNvbGlkICMxODkwZmY7XFxuICBjb250ZW50OiAnJztcXG4gIC13ZWJraXQtYW5pbWF0aW9uOiBhbnRSYWRpb0VmZmVjdCAwLjM2cyBlYXNlLWluLW91dDtcXG4gICAgICAgICAgYW5pbWF0aW9uOiBhbnRSYWRpb0VmZmVjdCAwLjM2cyBlYXNlLWluLW91dDtcXG4gIC13ZWJraXQtYW5pbWF0aW9uLWZpbGwtbW9kZTogYm90aDtcXG4gICAgICAgICAgYW5pbWF0aW9uLWZpbGwtbW9kZTogYm90aDtcXG4gIHZpc2liaWxpdHk6IGhpZGRlbjtcXG59XFxuLmFudC1yYWRpbzpob3ZlcjphZnRlcixcXG4uYW50LXJhZGlvLXdyYXBwZXI6aG92ZXIgLmFudC1yYWRpbzphZnRlciB7XFxuICB2aXNpYmlsaXR5OiB2aXNpYmxlO1xcbn1cXG4uYW50LXJhZGlvLWlubmVyIHtcXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcXG4gIHRvcDogMDtcXG4gIGxlZnQ6IDA7XFxuICBkaXNwbGF5OiBibG9jaztcXG4gIHdpZHRoOiAxNnB4O1xcbiAgaGVpZ2h0OiAxNnB4O1xcbiAgYm9yZGVyLXdpZHRoOiAxcHg7XFxuICBib3JkZXItc3R5bGU6IHNvbGlkO1xcbiAgYm9yZGVyLXJhZGl1czogMTAwcHg7XFxuICBib3JkZXItY29sb3I6ICNkOWQ5ZDk7XFxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xcbiAgLXdlYmtpdC10cmFuc2l0aW9uOiBhbGwgMC4zcztcXG4gIHRyYW5zaXRpb246IGFsbCAwLjNzO1xcbn1cXG4uYW50LXJhZGlvLWlubmVyOmFmdGVyIHtcXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcXG4gIHdpZHRoOiA4cHg7XFxuICBoZWlnaHQ6IDhweDtcXG4gIGxlZnQ6IDNweDtcXG4gIHRvcDogM3B4O1xcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xcbiAgZGlzcGxheTogdGFibGU7XFxuICBib3JkZXItdG9wOiAwO1xcbiAgYm9yZGVyLWxlZnQ6IDA7XFxuICBjb250ZW50OiAnICc7XFxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMTg5MGZmO1xcbiAgb3BhY2l0eTogMDtcXG4gIC13ZWJraXQtdHJhbnNmb3JtOiBzY2FsZSgwKTtcXG4gICAgICAtbXMtdHJhbnNmb3JtOiBzY2FsZSgwKTtcXG4gICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgwKTtcXG4gIC13ZWJraXQtdHJhbnNpdGlvbjogYWxsIDAuM3MgY3ViaWMtYmV6aWVyKDAuNzgsIDAuMTQsIDAuMTUsIDAuODYpO1xcbiAgdHJhbnNpdGlvbjogYWxsIDAuM3MgY3ViaWMtYmV6aWVyKDAuNzgsIDAuMTQsIDAuMTUsIDAuODYpO1xcbn1cXG4uYW50LXJhZGlvLWlucHV0IHtcXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcXG4gIGxlZnQ6IDA7XFxuICB6LWluZGV4OiAxO1xcbiAgY3Vyc29yOiBwb2ludGVyO1xcbiAgb3BhY2l0eTogMDtcXG4gIHRvcDogMDtcXG4gIGJvdHRvbTogMDtcXG4gIHJpZ2h0OiAwO1xcbn1cXG4uYW50LXJhZGlvLWNoZWNrZWQgLmFudC1yYWRpby1pbm5lciB7XFxuICBib3JkZXItY29sb3I6ICMxODkwZmY7XFxufVxcbi5hbnQtcmFkaW8tY2hlY2tlZCAuYW50LXJhZGlvLWlubmVyOmFmdGVyIHtcXG4gIC13ZWJraXQtdHJhbnNmb3JtOiBzY2FsZSgwLjg3NSk7XFxuICAgICAgLW1zLXRyYW5zZm9ybTogc2NhbGUoMC44NzUpO1xcbiAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDAuODc1KTtcXG4gIG9wYWNpdHk6IDE7XFxuICAtd2Via2l0LXRyYW5zaXRpb246IGFsbCAwLjNzIGN1YmljLWJlemllcigwLjc4LCAwLjE0LCAwLjE1LCAwLjg2KTtcXG4gIHRyYW5zaXRpb246IGFsbCAwLjNzIGN1YmljLWJlemllcigwLjc4LCAwLjE0LCAwLjE1LCAwLjg2KTtcXG59XFxuLmFudC1yYWRpby1kaXNhYmxlZCAuYW50LXJhZGlvLWlubmVyIHtcXG4gIGJvcmRlci1jb2xvcjogI2Q5ZDlkOSAhaW1wb3J0YW50O1xcbiAgYmFja2dyb3VuZC1jb2xvcjogI2Y1ZjVmNTtcXG59XFxuLmFudC1yYWRpby1kaXNhYmxlZCAuYW50LXJhZGlvLWlubmVyOmFmdGVyIHtcXG4gIGJhY2tncm91bmQtY29sb3I6ICNjY2M7XFxufVxcbi5hbnQtcmFkaW8tZGlzYWJsZWQgLmFudC1yYWRpby1pbnB1dCB7XFxuICBjdXJzb3I6IG5vdC1hbGxvd2VkO1xcbn1cXG4uYW50LXJhZGlvLWRpc2FibGVkICsgc3BhbiB7XFxuICBjb2xvcjogcmdiYSgwLCAwLCAwLCAwLjI1KTtcXG4gIGN1cnNvcjogbm90LWFsbG93ZWQ7XFxufVxcbnNwYW4uYW50LXJhZGlvICsgKiB7XFxuICBwYWRkaW5nLWxlZnQ6IDhweDtcXG4gIHBhZGRpbmctcmlnaHQ6IDhweDtcXG59XFxuLmFudC1yYWRpby1idXR0b24td3JhcHBlciB7XFxuICBtYXJnaW46IDA7XFxuICBoZWlnaHQ6IDMycHg7XFxuICBsaW5lLWhlaWdodDogMzBweDtcXG4gIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuNjUpO1xcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xcbiAgLXdlYmtpdC10cmFuc2l0aW9uOiBhbGwgMC4zcyBlYXNlO1xcbiAgdHJhbnNpdGlvbjogYWxsIDAuM3MgZWFzZTtcXG4gIGN1cnNvcjogcG9pbnRlcjtcXG4gIGJvcmRlcjogMXB4IHNvbGlkICNkOWQ5ZDk7XFxuICBib3JkZXItbGVmdDogMDtcXG4gIGJvcmRlci10b3Atd2lkdGg6IDEuMDJweDtcXG4gIGJhY2tncm91bmQ6ICNmZmY7XFxuICBwYWRkaW5nOiAwIDE1cHg7XFxuICBwb3NpdGlvbjogcmVsYXRpdmU7XFxufVxcbi5hbnQtcmFkaW8tYnV0dG9uLXdyYXBwZXIgYSB7XFxuICBjb2xvcjogcmdiYSgwLCAwLCAwLCAwLjY1KTtcXG59XFxuLmFudC1yYWRpby1idXR0b24td3JhcHBlciA+IC5hbnQtcmFkaW8tYnV0dG9uIHtcXG4gIG1hcmdpbi1sZWZ0OiAwO1xcbiAgZGlzcGxheTogYmxvY2s7XFxuICB3aWR0aDogMDtcXG4gIGhlaWdodDogMDtcXG59XFxuLmFudC1yYWRpby1ncm91cC1sYXJnZSAuYW50LXJhZGlvLWJ1dHRvbi13cmFwcGVyIHtcXG4gIGhlaWdodDogNDBweDtcXG4gIGxpbmUtaGVpZ2h0OiAzOHB4O1xcbiAgZm9udC1zaXplOiAxNnB4O1xcbn1cXG4uYW50LXJhZGlvLWdyb3VwLXNtYWxsIC5hbnQtcmFkaW8tYnV0dG9uLXdyYXBwZXIge1xcbiAgaGVpZ2h0OiAyNHB4O1xcbiAgbGluZS1oZWlnaHQ6IDIycHg7XFxuICBwYWRkaW5nOiAwIDdweDtcXG59XFxuLmFudC1yYWRpby1idXR0b24td3JhcHBlcjpub3QoOmZpcnN0LWNoaWxkKTo6YmVmb3JlIHtcXG4gIGNvbnRlbnQ6IFxcXCJcXFwiO1xcbiAgZGlzcGxheTogYmxvY2s7XFxuICB0b3A6IDA7XFxuICBsZWZ0OiAtMXB4O1xcbiAgd2lkdGg6IDFweDtcXG4gIGhlaWdodDogMTAwJTtcXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcXG4gIGJhY2tncm91bmQtY29sb3I6ICNkOWQ5ZDk7XFxufVxcbi5hbnQtcmFkaW8tYnV0dG9uLXdyYXBwZXI6Zmlyc3QtY2hpbGQge1xcbiAgYm9yZGVyLXJhZGl1czogNHB4IDAgMCA0cHg7XFxuICBib3JkZXItbGVmdDogMXB4IHNvbGlkICNkOWQ5ZDk7XFxufVxcbi5hbnQtcmFkaW8tYnV0dG9uLXdyYXBwZXI6bGFzdC1jaGlsZCB7XFxuICBib3JkZXItcmFkaXVzOiAwIDRweCA0cHggMDtcXG59XFxuLmFudC1yYWRpby1idXR0b24td3JhcHBlcjpmaXJzdC1jaGlsZDpsYXN0LWNoaWxkIHtcXG4gIGJvcmRlci1yYWRpdXM6IDRweDtcXG59XFxuLmFudC1yYWRpby1idXR0b24td3JhcHBlcjpob3ZlcixcXG4uYW50LXJhZGlvLWJ1dHRvbi13cmFwcGVyLWZvY3VzZWQge1xcbiAgY29sb3I6ICMxODkwZmY7XFxuICBwb3NpdGlvbjogcmVsYXRpdmU7XFxufVxcbi5hbnQtcmFkaW8tYnV0dG9uLXdyYXBwZXIgLmFudC1yYWRpby1pbm5lcixcXG4uYW50LXJhZGlvLWJ1dHRvbi13cmFwcGVyIGlucHV0W3R5cGU9XFxcImNoZWNrYm94XFxcIl0sXFxuLmFudC1yYWRpby1idXR0b24td3JhcHBlciBpbnB1dFt0eXBlPVxcXCJyYWRpb1xcXCJdIHtcXG4gIG9wYWNpdHk6IDA7XFxuICB3aWR0aDogMDtcXG4gIGhlaWdodDogMDtcXG59XFxuLmFudC1yYWRpby1idXR0b24td3JhcHBlci1jaGVja2VkIHtcXG4gIGJhY2tncm91bmQ6ICNmZmY7XFxuICBib3JkZXItY29sb3I6ICMxODkwZmY7XFxuICBjb2xvcjogIzE4OTBmZjtcXG4gIC13ZWJraXQtYm94LXNoYWRvdzogLTFweCAwIDAgMCAjMTg5MGZmO1xcbiAgICAgICAgICBib3gtc2hhZG93OiAtMXB4IDAgMCAwICMxODkwZmY7XFxuICB6LWluZGV4OiAxO1xcbn1cXG4uYW50LXJhZGlvLWJ1dHRvbi13cmFwcGVyLWNoZWNrZWQ6OmJlZm9yZSB7XFxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMTg5MGZmICFpbXBvcnRhbnQ7XFxuICBvcGFjaXR5OiAwLjE7XFxufVxcbi5hbnQtcmFkaW8tYnV0dG9uLXdyYXBwZXItY2hlY2tlZDpmaXJzdC1jaGlsZCB7XFxuICBib3JkZXItY29sb3I6ICMxODkwZmY7XFxuICAtd2Via2l0LWJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcXG4gICAgICAgICAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xcbn1cXG4uYW50LXJhZGlvLWJ1dHRvbi13cmFwcGVyLWNoZWNrZWQ6aG92ZXIge1xcbiAgYm9yZGVyLWNvbG9yOiAjNDBhOWZmO1xcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiAtMXB4IDAgMCAwICM0MGE5ZmY7XFxuICAgICAgICAgIGJveC1zaGFkb3c6IC0xcHggMCAwIDAgIzQwYTlmZjtcXG4gIGNvbG9yOiAjNDBhOWZmO1xcbn1cXG4uYW50LXJhZGlvLWJ1dHRvbi13cmFwcGVyLWNoZWNrZWQ6YWN0aXZlIHtcXG4gIGJvcmRlci1jb2xvcjogIzA5NmRkOTtcXG4gIC13ZWJraXQtYm94LXNoYWRvdzogLTFweCAwIDAgMCAjMDk2ZGQ5O1xcbiAgICAgICAgICBib3gtc2hhZG93OiAtMXB4IDAgMCAwICMwOTZkZDk7XFxuICBjb2xvcjogIzA5NmRkOTtcXG59XFxuLmFudC1yYWRpby1idXR0b24td3JhcHBlci1kaXNhYmxlZCB7XFxuICBib3JkZXItY29sb3I6ICNkOWQ5ZDk7XFxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjVmNWY1O1xcbiAgY3Vyc29yOiBub3QtYWxsb3dlZDtcXG4gIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuMjUpO1xcbn1cXG4uYW50LXJhZGlvLWJ1dHRvbi13cmFwcGVyLWRpc2FibGVkOmZpcnN0LWNoaWxkLFxcbi5hbnQtcmFkaW8tYnV0dG9uLXdyYXBwZXItZGlzYWJsZWQ6aG92ZXIge1xcbiAgYm9yZGVyLWNvbG9yOiAjZDlkOWQ5O1xcbiAgYmFja2dyb3VuZC1jb2xvcjogI2Y1ZjVmNTtcXG4gIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuMjUpO1xcbn1cXG4uYW50LXJhZGlvLWJ1dHRvbi13cmFwcGVyLWRpc2FibGVkOmZpcnN0LWNoaWxkIHtcXG4gIGJvcmRlci1sZWZ0LWNvbG9yOiAjZDlkOWQ5O1xcbn1cXG4uYW50LXJhZGlvLWJ1dHRvbi13cmFwcGVyLWRpc2FibGVkLmFudC1yYWRpby1idXR0b24td3JhcHBlci1jaGVja2VkIHtcXG4gIGNvbG9yOiAjZmZmO1xcbiAgYmFja2dyb3VuZC1jb2xvcjogI2U2ZTZlNjtcXG4gIGJvcmRlci1jb2xvcjogI2Q5ZDlkOTtcXG4gIC13ZWJraXQtYm94LXNoYWRvdzogbm9uZTtcXG4gICAgICAgICAgYm94LXNoYWRvdzogbm9uZTtcXG59XFxuQC13ZWJraXQta2V5ZnJhbWVzIGFudFJhZGlvRWZmZWN0IHtcXG4gIDAlIHtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHNjYWxlKDEpO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMSk7XFxuICAgIG9wYWNpdHk6IDAuNTtcXG4gIH1cXG4gIDEwMCUge1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogc2NhbGUoMS42KTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEuNik7XFxuICAgIG9wYWNpdHk6IDA7XFxuICB9XFxufVxcbkBrZXlmcmFtZXMgYW50UmFkaW9FZmZlY3Qge1xcbiAgMCUge1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogc2NhbGUoMSk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTtcXG4gICAgb3BhY2l0eTogMC41O1xcbiAgfVxcbiAgMTAwJSB7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiBzY2FsZSgxLjYpO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMS42KTtcXG4gICAgb3BhY2l0eTogMDtcXG4gIH1cXG59XFxuXCIsIFwiXCJdKTtcblxuLy8gZXhwb3J0c1xuIiwiZXhwb3J0cyA9IG1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIi4uLy4uLy4uLy4uL2Nzcy1sb2FkZXIvbGliL2Nzcy1iYXNlLmpzXCIpKGZhbHNlKTtcbi8vIGltcG9ydHNcblxuXG4vLyBtb2R1bGVcbmV4cG9ydHMucHVzaChbbW9kdWxlLmlkLCBcIi8qIHN0eWxlbGludC1kaXNhYmxlIGF0LXJ1bGUtZW1wdHktbGluZS1iZWZvcmUsYXQtcnVsZS1uYW1lLXNwYWNlLWFmdGVyLGF0LXJ1bGUtbm8tdW5rbm93biAqL1xcbi8qIHN0eWxlbGludC1kaXNhYmxlIG5vLWR1cGxpY2F0ZS1zZWxlY3RvcnMgKi9cXG4vKiBzdHlsZWxpbnQtZGlzYWJsZSBkZWNsYXJhdGlvbi1iYW5nLXNwYWNlLWJlZm9yZSxuby1kdXBsaWNhdGUtc2VsZWN0b3JzICovXFxuLyogc3R5bGVsaW50LWRpc2FibGUgZGVjbGFyYXRpb24tYmFuZy1zcGFjZS1iZWZvcmUsbm8tZHVwbGljYXRlLXNlbGVjdG9ycyxzdHJpbmctbm8tbmV3bGluZSAqL1xcbi5hbnQtdGFibGUtd3JhcHBlciB7XFxuICB6b29tOiAxO1xcbn1cXG4uYW50LXRhYmxlLXdyYXBwZXI6YmVmb3JlLFxcbi5hbnQtdGFibGUtd3JhcHBlcjphZnRlciB7XFxuICBjb250ZW50OiBcXFwiIFxcXCI7XFxuICBkaXNwbGF5OiB0YWJsZTtcXG59XFxuLmFudC10YWJsZS13cmFwcGVyOmFmdGVyIHtcXG4gIGNsZWFyOiBib3RoO1xcbiAgdmlzaWJpbGl0eTogaGlkZGVuO1xcbiAgZm9udC1zaXplOiAwO1xcbiAgaGVpZ2h0OiAwO1xcbn1cXG4uYW50LXRhYmxlIHtcXG4gIGZvbnQtZmFtaWx5OiBcXFwiTW9ub3NwYWNlZCBOdW1iZXJcXFwiLCBcXFwiQ2hpbmVzZSBRdW90ZVxcXCIsIC1hcHBsZS1zeXN0ZW0sIEJsaW5rTWFjU3lzdGVtRm9udCwgXFxcIlNlZ29lIFVJXFxcIiwgUm9ib3RvLCBcXFwiUGluZ0ZhbmcgU0NcXFwiLCBcXFwiSGlyYWdpbm8gU2FucyBHQlxcXCIsIFxcXCJNaWNyb3NvZnQgWWFIZWlcXFwiLCBcXFwiSGVsdmV0aWNhIE5ldWVcXFwiLCBIZWx2ZXRpY2EsIEFyaWFsLCBzYW5zLXNlcmlmO1xcbiAgZm9udC1zaXplOiAxNHB4O1xcbiAgbGluZS1oZWlnaHQ6IDEuNTtcXG4gIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuNjUpO1xcbiAgLXdlYmtpdC1ib3gtc2l6aW5nOiBib3JkZXItYm94O1xcbiAgICAgICAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xcbiAgbWFyZ2luOiAwO1xcbiAgcGFkZGluZzogMDtcXG4gIGxpc3Qtc3R5bGU6IG5vbmU7XFxuICBwb3NpdGlvbjogcmVsYXRpdmU7XFxuICBjbGVhcjogYm90aDtcXG59XFxuLmFudC10YWJsZS1ib2R5IHtcXG4gIC13ZWJraXQtdHJhbnNpdGlvbjogb3BhY2l0eSAuM3M7XFxuICB0cmFuc2l0aW9uOiBvcGFjaXR5IC4zcztcXG59XFxuLmFudC10YWJsZSB0YWJsZSB7XFxuICB3aWR0aDogMTAwJTtcXG4gIGJvcmRlci1jb2xsYXBzZTogc2VwYXJhdGU7XFxuICBib3JkZXItc3BhY2luZzogMDtcXG4gIHRleHQtYWxpZ246IGxlZnQ7XFxuICBib3JkZXItcmFkaXVzOiA0cHggNHB4IDAgMDtcXG59XFxuLmFudC10YWJsZS10aGVhZCA+IHRyID4gdGgge1xcbiAgYmFja2dyb3VuZDogI2ZhZmFmYTtcXG4gIC13ZWJraXQtdHJhbnNpdGlvbjogYmFja2dyb3VuZCAuM3MgZWFzZTtcXG4gIHRyYW5zaXRpb246IGJhY2tncm91bmQgLjNzIGVhc2U7XFxuICB0ZXh0LWFsaWduOiBsZWZ0O1xcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC44NSk7XFxuICBmb250LXdlaWdodDogNTAwO1xcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlOGU4ZTg7XFxufVxcbi5hbnQtdGFibGUtdGhlYWQgPiB0ciA+IHRoW2NvbHNwYW5dIHtcXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcXG4gIGJvcmRlci1ib3R0b206IDA7XFxufVxcbi5hbnQtdGFibGUtdGhlYWQgPiB0ciA+IHRoIC5hbnRpY29uLWZpbHRlcixcXG4uYW50LXRhYmxlLXRoZWFkID4gdHIgPiB0aCAuYW50LXRhYmxlLWZpbHRlci1pY29uIHtcXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcXG4gIG1hcmdpbi1sZWZ0OiA4cHg7XFxuICBmb250LXNpemU6IDE0cHg7XFxuICBjdXJzb3I6IHBvaW50ZXI7XFxuICBjb2xvcjogcmdiYSgwLCAwLCAwLCAwLjQ1KTtcXG4gIC13ZWJraXQtdHJhbnNpdGlvbjogYWxsIC4zcztcXG4gIHRyYW5zaXRpb246IGFsbCAuM3M7XFxuICB3aWR0aDogMTRweDtcXG4gIGZvbnQtd2VpZ2h0OiBub3JtYWw7XFxuICB2ZXJ0aWNhbC1hbGlnbjogdGV4dC1ib3R0b207XFxufVxcbi5hbnQtdGFibGUtdGhlYWQgPiB0ciA+IHRoIC5hbnRpY29uLWZpbHRlcjpob3ZlcixcXG4uYW50LXRhYmxlLXRoZWFkID4gdHIgPiB0aCAuYW50LXRhYmxlLWZpbHRlci1pY29uOmhvdmVyIHtcXG4gIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuNjUpO1xcbn1cXG4uYW50LXRhYmxlLXRoZWFkID4gdHIgPiB0aCAuYW50LXRhYmxlLWNvbHVtbi1zb3J0ZXIgKyAuYW50aWNvbi1maWx0ZXIge1xcbiAgbWFyZ2luLWxlZnQ6IDRweDtcXG59XFxuLmFudC10YWJsZS10aGVhZCA+IHRyID4gdGggLmFudC10YWJsZS1maWx0ZXItc2VsZWN0ZWQuYW50aWNvbi1maWx0ZXIge1xcbiAgY29sb3I6ICMxODkwZmY7XFxufVxcbi5hbnQtdGFibGUtdGhlYWQgPiB0ciA+IHRoLmFudC10YWJsZS1jb2x1bW4taGFzLWZpbHRlcnMge1xcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcXG59XFxuLmFudC10YWJsZS10aGVhZCA+IHRyOmZpcnN0LWNoaWxkID4gdGg6Zmlyc3QtY2hpbGQge1xcbiAgYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogNHB4O1xcbn1cXG4uYW50LXRhYmxlLXRoZWFkID4gdHI6Zmlyc3QtY2hpbGQgPiB0aDpsYXN0LWNoaWxkIHtcXG4gIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiA0cHg7XFxufVxcbi5hbnQtdGFibGUtdGJvZHkgPiB0ciA+IHRkIHtcXG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZThlOGU4O1xcbiAgLXdlYmtpdC10cmFuc2l0aW9uOiBhbGwgLjNzO1xcbiAgdHJhbnNpdGlvbjogYWxsIC4zcztcXG59XFxuLmFudC10YWJsZS10aGVhZCA+IHRyLFxcbi5hbnQtdGFibGUtdGJvZHkgPiB0ciB7XFxuICAtd2Via2l0LXRyYW5zaXRpb246IGFsbCAuM3M7XFxuICB0cmFuc2l0aW9uOiBhbGwgLjNzO1xcbn1cXG4uYW50LXRhYmxlLXRoZWFkID4gdHIuYW50LXRhYmxlLXJvdy1ob3ZlciA+IHRkLFxcbi5hbnQtdGFibGUtdGJvZHkgPiB0ci5hbnQtdGFibGUtcm93LWhvdmVyID4gdGQsXFxuLmFudC10YWJsZS10aGVhZCA+IHRyOmhvdmVyID4gdGQsXFxuLmFudC10YWJsZS10Ym9keSA+IHRyOmhvdmVyID4gdGQge1xcbiAgYmFja2dyb3VuZDogI2U2ZjdmZjtcXG59XFxuLmFudC10YWJsZS10aGVhZCA+IHRyOmhvdmVyIHtcXG4gIGJhY2tncm91bmQ6IG5vbmU7XFxufVxcbi5hbnQtdGFibGUtZm9vdGVyIHtcXG4gIHBhZGRpbmc6IDE2cHggMTZweDtcXG4gIGJhY2tncm91bmQ6ICNmYWZhZmE7XFxuICBib3JkZXItcmFkaXVzOiAwIDAgNHB4IDRweDtcXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcXG4gIGJvcmRlci10b3A6IDFweCBzb2xpZCAjZThlOGU4O1xcbn1cXG4uYW50LXRhYmxlLWZvb3RlcjpiZWZvcmUge1xcbiAgY29udGVudDogJyc7XFxuICBoZWlnaHQ6IDFweDtcXG4gIGJhY2tncm91bmQ6ICNmYWZhZmE7XFxuICBwb3NpdGlvbjogYWJzb2x1dGU7XFxuICB0b3A6IC0xcHg7XFxuICB3aWR0aDogMTAwJTtcXG4gIGxlZnQ6IDA7XFxufVxcbi5hbnQtdGFibGUuYW50LXRhYmxlLWJvcmRlcmVkIC5hbnQtdGFibGUtZm9vdGVyIHtcXG4gIGJvcmRlcjogMXB4IHNvbGlkICNlOGU4ZTg7XFxufVxcbi5hbnQtdGFibGUtdGl0bGUge1xcbiAgcGFkZGluZzogMTZweCAwO1xcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xcbiAgdG9wOiAxcHg7XFxuICBib3JkZXItcmFkaXVzOiA0cHggNHB4IDAgMDtcXG59XFxuLmFudC10YWJsZS5hbnQtdGFibGUtYm9yZGVyZWQgLmFudC10YWJsZS10aXRsZSB7XFxuICBib3JkZXI6IDFweCBzb2xpZCAjZThlOGU4O1xcbiAgcGFkZGluZy1sZWZ0OiAxNnB4O1xcbiAgcGFkZGluZy1yaWdodDogMTZweDtcXG59XFxuLmFudC10YWJsZS10aXRsZSArIC5hbnQtdGFibGUtY29udGVudCB7XFxuICBwb3NpdGlvbjogcmVsYXRpdmU7XFxuICBib3JkZXItcmFkaXVzOiA0cHggNHB4IDAgMDtcXG4gIG92ZXJmbG93OiBoaWRkZW47XFxufVxcbi5hbnQtdGFibGUtYm9yZGVyZWQgLmFudC10YWJsZS10aXRsZSArIC5hbnQtdGFibGUtY29udGVudCxcXG4uYW50LXRhYmxlLWJvcmRlcmVkIC5hbnQtdGFibGUtdGl0bGUgKyAuYW50LXRhYmxlLWNvbnRlbnQgdGFibGUsXFxuLmFudC10YWJsZS1ib3JkZXJlZCAuYW50LXRhYmxlLXRpdGxlICsgLmFudC10YWJsZS1jb250ZW50IC5hbnQtdGFibGUtdGhlYWQgPiB0cjpmaXJzdC1jaGlsZCA+IHRoIHtcXG4gIGJvcmRlci1yYWRpdXM6IDA7XFxufVxcbi5hbnQtdGFibGUtd2l0aG91dC1jb2x1bW4taGVhZGVyIC5hbnQtdGFibGUtdGl0bGUgKyAuYW50LXRhYmxlLWNvbnRlbnQsXFxuLmFudC10YWJsZS13aXRob3V0LWNvbHVtbi1oZWFkZXIgdGFibGUge1xcbiAgYm9yZGVyLXJhZGl1czogMDtcXG59XFxuLmFudC10YWJsZS10Ym9keSA+IHRyLmFudC10YWJsZS1yb3ctc2VsZWN0ZWQgdGQge1xcbiAgYmFja2dyb3VuZDogI2ZhZmFmYTtcXG59XFxuLmFudC10YWJsZS10aGVhZCA+IHRyID4gdGguYW50LXRhYmxlLWNvbHVtbi1zb3J0IHtcXG4gIGJhY2tncm91bmQ6ICNmNWY1ZjU7XFxufVxcbi5hbnQtdGFibGUtdGhlYWQgPiB0ciA+IHRoLFxcbi5hbnQtdGFibGUtdGJvZHkgPiB0ciA+IHRkIHtcXG4gIHBhZGRpbmc6IDE2cHggMTZweDtcXG4gIHdvcmQtYnJlYWs6IGJyZWFrLWFsbDtcXG59XFxuLmFudC10YWJsZS10aGVhZCA+IHRyID4gdGguYW50LXRhYmxlLXNlbGVjdGlvbi1jb2x1bW4tY3VzdG9tIHtcXG4gIHBhZGRpbmctbGVmdDogMTZweDtcXG4gIHBhZGRpbmctcmlnaHQ6IDA7XFxufVxcbi5hbnQtdGFibGUtdGhlYWQgPiB0ciA+IHRoLmFudC10YWJsZS1zZWxlY3Rpb24tY29sdW1uLFxcbi5hbnQtdGFibGUtdGJvZHkgPiB0ciA+IHRkLmFudC10YWJsZS1zZWxlY3Rpb24tY29sdW1uIHtcXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcXG4gIG1pbi13aWR0aDogNjJweDtcXG4gIHdpZHRoOiA2MnB4O1xcbn1cXG4uYW50LXRhYmxlLXRoZWFkID4gdHIgPiB0aC5hbnQtdGFibGUtc2VsZWN0aW9uLWNvbHVtbiAuYW50LXJhZGlvLXdyYXBwZXIsXFxuLmFudC10YWJsZS10Ym9keSA+IHRyID4gdGQuYW50LXRhYmxlLXNlbGVjdGlvbi1jb2x1bW4gLmFudC1yYWRpby13cmFwcGVyIHtcXG4gIG1hcmdpbi1yaWdodDogMDtcXG59XFxuLmFudC10YWJsZS1leHBhbmQtaWNvbi10aCxcXG4uYW50LXRhYmxlLXJvdy1leHBhbmQtaWNvbi1jZWxsIHtcXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcXG4gIG1pbi13aWR0aDogNTBweDtcXG4gIHdpZHRoOiA1MHB4O1xcbn1cXG4uYW50LXRhYmxlLWhlYWRlciB7XFxuICBiYWNrZ3JvdW5kOiAjZmFmYWZhO1xcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcXG59XFxuLmFudC10YWJsZS1oZWFkZXIgdGFibGUge1xcbiAgYm9yZGVyLXJhZGl1czogNHB4IDRweCAwIDA7XFxufVxcbi5hbnQtdGFibGUtbG9hZGluZyB7XFxuICBwb3NpdGlvbjogcmVsYXRpdmU7XFxufVxcbi5hbnQtdGFibGUtbG9hZGluZyAuYW50LXRhYmxlLWJvZHkge1xcbiAgYmFja2dyb3VuZDogI2ZmZjtcXG4gIG9wYWNpdHk6IDAuNTtcXG59XFxuLmFudC10YWJsZS1sb2FkaW5nIC5hbnQtdGFibGUtc3Bpbi1ob2xkZXIge1xcbiAgaGVpZ2h0OiAyMHB4O1xcbiAgbGluZS1oZWlnaHQ6IDIwcHg7XFxuICBsZWZ0OiA1MCU7XFxuICB0b3A6IDUwJTtcXG4gIG1hcmdpbi1sZWZ0OiAtMzBweDtcXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcXG59XFxuLmFudC10YWJsZS1sb2FkaW5nIC5hbnQtdGFibGUtd2l0aC1wYWdpbmF0aW9uIHtcXG4gIG1hcmdpbi10b3A6IC0yMHB4O1xcbn1cXG4uYW50LXRhYmxlLWxvYWRpbmcgLmFudC10YWJsZS13aXRob3V0LXBhZ2luYXRpb24ge1xcbiAgbWFyZ2luLXRvcDogMTBweDtcXG59XFxuLmFudC10YWJsZS1jb2x1bW4tc29ydGVyIHtcXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcXG4gIG1hcmdpbi1sZWZ0OiA4cHg7XFxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XFxuICB3aWR0aDogMTRweDtcXG4gIGhlaWdodDogMTRweDtcXG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XFxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XFxuICBmb250LXdlaWdodDogbm9ybWFsO1xcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC40NSk7XFxufVxcbi5hbnQtdGFibGUtY29sdW1uLXNvcnRlci11cCxcXG4uYW50LXRhYmxlLWNvbHVtbi1zb3J0ZXItZG93biB7XFxuICBsaW5lLWhlaWdodDogNnB4O1xcbiAgZGlzcGxheTogYmxvY2s7XFxuICB3aWR0aDogMTRweDtcXG4gIGhlaWdodDogNnB4O1xcbiAgY3Vyc29yOiBwb2ludGVyO1xcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xcbn1cXG4uYW50LXRhYmxlLWNvbHVtbi1zb3J0ZXItdXA6aG92ZXIgLmFudGljb24sXFxuLmFudC10YWJsZS1jb2x1bW4tc29ydGVyLWRvd246aG92ZXIgLmFudGljb24ge1xcbiAgY29sb3I6ICM2OWMwZmY7XFxufVxcbi5hbnQtdGFibGUtY29sdW1uLXNvcnRlci11cC5vbiAuYW50aWNvbi1jYXJldC11cCxcXG4uYW50LXRhYmxlLWNvbHVtbi1zb3J0ZXItZG93bi5vbiAuYW50aWNvbi1jYXJldC11cCxcXG4uYW50LXRhYmxlLWNvbHVtbi1zb3J0ZXItdXAub24gLmFudGljb24tY2FyZXQtZG93bixcXG4uYW50LXRhYmxlLWNvbHVtbi1zb3J0ZXItZG93bi5vbiAuYW50aWNvbi1jYXJldC1kb3duIHtcXG4gIGNvbG9yOiAjMTg5MGZmO1xcbn1cXG4uYW50LXRhYmxlLWNvbHVtbi1zb3J0ZXItdXA6YWZ0ZXIsXFxuLmFudC10YWJsZS1jb2x1bW4tc29ydGVyLWRvd246YWZ0ZXIge1xcbiAgcG9zaXRpb246IGFic29sdXRlO1xcbiAgY29udGVudDogJyc7XFxuICBoZWlnaHQ6IDMwcHg7XFxuICB3aWR0aDogMTRweDtcXG4gIGxlZnQ6IDA7XFxufVxcbi5hbnQtdGFibGUtY29sdW1uLXNvcnRlci11cDphZnRlciB7XFxuICBib3R0b206IDA7XFxufVxcbi5hbnQtdGFibGUtY29sdW1uLXNvcnRlci1kb3duOmFmdGVyIHtcXG4gIHRvcDogMDtcXG59XFxuLmFudC10YWJsZS1jb2x1bW4tc29ydGVyIC5hbnRpY29uLWNhcmV0LXVwLFxcbi5hbnQtdGFibGUtY29sdW1uLXNvcnRlciAuYW50aWNvbi1jYXJldC1kb3duIHtcXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcXG4gIGZvbnQtc2l6ZTogMTJweDtcXG4gIGZvbnQtc2l6ZTogOHB4IFxcXFw5O1xcbiAgLXdlYmtpdC10cmFuc2Zvcm06IHNjYWxlKDAuNjY2NjY2NjcpIHJvdGF0ZSgwZGVnKTtcXG4gICAgICAtbXMtdHJhbnNmb3JtOiBzY2FsZSgwLjY2NjY2NjY3KSByb3RhdGUoMGRlZyk7XFxuICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC42NjY2NjY2Nykgcm90YXRlKDBkZWcpO1xcbiAgbGluZS1oZWlnaHQ6IDRweDtcXG4gIGhlaWdodDogNHB4O1xcbiAgLXdlYmtpdC10cmFuc2l0aW9uOiBhbGwgLjNzO1xcbiAgdHJhbnNpdGlvbjogYWxsIC4zcztcXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcXG59XFxuOnJvb3QgLmFudC10YWJsZS1jb2x1bW4tc29ydGVyIC5hbnRpY29uLWNhcmV0LXVwLFxcbjpyb290IC5hbnQtdGFibGUtY29sdW1uLXNvcnRlciAuYW50aWNvbi1jYXJldC1kb3duIHtcXG4gIGZvbnQtc2l6ZTogMTJweDtcXG59XFxuLmFudC10YWJsZS1jb2x1bW4tc29ydGVyLWRvd24ge1xcbiAgbWFyZ2luLXRvcDogMS41cHg7XFxufVxcbi5hbnQtdGFibGUtY29sdW1uLXNvcnRlciAuYW50aWNvbi1jYXJldC1kb3duIHtcXG4gIHRvcDogLTEuNXB4O1xcbn1cXG4uYW50LXRhYmxlLWJvcmRlcmVkIC5hbnQtdGFibGUtaGVhZGVyID4gdGFibGUsXFxuLmFudC10YWJsZS1ib3JkZXJlZCAuYW50LXRhYmxlLWJvZHkgPiB0YWJsZSxcXG4uYW50LXRhYmxlLWJvcmRlcmVkIC5hbnQtdGFibGUtZml4ZWQtbGVmdCB0YWJsZSxcXG4uYW50LXRhYmxlLWJvcmRlcmVkIC5hbnQtdGFibGUtZml4ZWQtcmlnaHQgdGFibGUge1xcbiAgYm9yZGVyOiAxcHggc29saWQgI2U4ZThlODtcXG4gIGJvcmRlci1yaWdodDogMDtcXG4gIGJvcmRlci1ib3R0b206IDA7XFxufVxcbi5hbnQtdGFibGUtYm9yZGVyZWQuYW50LXRhYmxlLWVtcHR5IC5hbnQtdGFibGUtcGxhY2Vob2xkZXIge1xcbiAgYm9yZGVyLWxlZnQ6IDFweCBzb2xpZCAjZThlOGU4O1xcbiAgYm9yZGVyLXJpZ2h0OiAxcHggc29saWQgI2U4ZThlODtcXG59XFxuLmFudC10YWJsZS1ib3JkZXJlZC5hbnQtdGFibGUtZml4ZWQtaGVhZGVyIC5hbnQtdGFibGUtaGVhZGVyID4gdGFibGUge1xcbiAgYm9yZGVyLWJvdHRvbTogMDtcXG59XFxuLmFudC10YWJsZS1ib3JkZXJlZC5hbnQtdGFibGUtZml4ZWQtaGVhZGVyIC5hbnQtdGFibGUtYm9keSA+IHRhYmxlIHtcXG4gIGJvcmRlci10b3A6IDA7XFxuICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiAwO1xcbiAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDA7XFxufVxcbi5hbnQtdGFibGUtYm9yZGVyZWQuYW50LXRhYmxlLWZpeGVkLWhlYWRlciAuYW50LXRhYmxlLWJvZHktaW5uZXIgPiB0YWJsZSB7XFxuICBib3JkZXItdG9wOiAwO1xcbn1cXG4uYW50LXRhYmxlLWJvcmRlcmVkLmFudC10YWJsZS1maXhlZC1oZWFkZXIgLmFudC10YWJsZS1wbGFjZWhvbGRlciB7XFxuICBib3JkZXI6IDA7XFxufVxcbi5hbnQtdGFibGUtYm9yZGVyZWQgLmFudC10YWJsZS10aGVhZCA+IHRyID4gdGgge1xcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlOGU4ZTg7XFxufVxcbi5hbnQtdGFibGUtYm9yZGVyZWQgLmFudC10YWJsZS10aGVhZCA+IHRyID4gdGgsXFxuLmFudC10YWJsZS1ib3JkZXJlZCAuYW50LXRhYmxlLXRib2R5ID4gdHIgPiB0ZCB7XFxuICBib3JkZXItcmlnaHQ6IDFweCBzb2xpZCAjZThlOGU4O1xcbn1cXG4uYW50LXRhYmxlLXBsYWNlaG9sZGVyIHtcXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcXG4gIHBhZGRpbmc6IDE2cHggMTZweDtcXG4gIGJhY2tncm91bmQ6ICNmZmY7XFxuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2U4ZThlODtcXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcXG4gIGZvbnQtc2l6ZTogMTRweDtcXG4gIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuNDUpO1xcbiAgei1pbmRleDogMTtcXG59XFxuLmFudC10YWJsZS1wbGFjZWhvbGRlciAuYW50aWNvbiB7XFxuICBtYXJnaW4tcmlnaHQ6IDRweDtcXG59XFxuLmFudC10YWJsZS1wYWdpbmF0aW9uLmFudC1wYWdpbmF0aW9uIHtcXG4gIG1hcmdpbjogMTZweCAwO1xcbiAgZmxvYXQ6IHJpZ2h0O1xcbn1cXG4uYW50LXRhYmxlLWZpbHRlci1kcm9wZG93biB7XFxuICBtaW4td2lkdGg6IDk2cHg7XFxuICBtYXJnaW4tbGVmdDogLThweDtcXG4gIGJhY2tncm91bmQ6ICNmZmY7XFxuICBib3JkZXItcmFkaXVzOiA0cHg7XFxuICAtd2Via2l0LWJveC1zaGFkb3c6IDAgMnB4IDhweCByZ2JhKDAsIDAsIDAsIDAuMTUpO1xcbiAgICAgICAgICBib3gtc2hhZG93OiAwIDJweCA4cHggcmdiYSgwLCAwLCAwLCAwLjE1KTtcXG59XFxuLmFudC10YWJsZS1maWx0ZXItZHJvcGRvd24gLmFudC1kcm9wZG93bi1tZW51IHtcXG4gIGJvcmRlcjogMDtcXG4gIC13ZWJraXQtYm94LXNoYWRvdzogbm9uZTtcXG4gICAgICAgICAgYm94LXNoYWRvdzogbm9uZTtcXG4gIGJvcmRlci1yYWRpdXM6IDRweCA0cHggMCAwO1xcbn1cXG4uYW50LXRhYmxlLWZpbHRlci1kcm9wZG93biAuYW50LWRyb3Bkb3duLW1lbnUtd2l0aG91dC1zdWJtZW51IHtcXG4gIG1heC1oZWlnaHQ6IDQwMHB4O1xcbiAgb3ZlcmZsb3cteDogaGlkZGVuO1xcbn1cXG4uYW50LXRhYmxlLWZpbHRlci1kcm9wZG93biAuYW50LWRyb3Bkb3duLW1lbnUtaXRlbSA+IGxhYmVsICsgc3BhbiB7XFxuICBwYWRkaW5nLXJpZ2h0OiAwO1xcbn1cXG4uYW50LXRhYmxlLWZpbHRlci1kcm9wZG93biAuYW50LWRyb3Bkb3duLW1lbnUtc3ViIHtcXG4gIGJvcmRlci1yYWRpdXM6IDRweDtcXG4gIC13ZWJraXQtYm94LXNoYWRvdzogMCAycHggOHB4IHJnYmEoMCwgMCwgMCwgMC4xNSk7XFxuICAgICAgICAgIGJveC1zaGFkb3c6IDAgMnB4IDhweCByZ2JhKDAsIDAsIDAsIDAuMTUpO1xcbn1cXG4uYW50LXRhYmxlLWZpbHRlci1kcm9wZG93biAuYW50LWRyb3Bkb3duLW1lbnUgLmFudC1kcm9wZG93bi1zdWJtZW51LWNvbnRhaW4tc2VsZWN0ZWQgLmFudC1kcm9wZG93bi1tZW51LXN1Ym1lbnUtdGl0bGU6YWZ0ZXIge1xcbiAgY29sb3I6ICMxODkwZmY7XFxuICBmb250LXdlaWdodDogYm9sZDtcXG4gIHRleHQtc2hhZG93OiAwIDAgMnB4ICNiYWU3ZmY7XFxufVxcbi5hbnQtdGFibGUtZmlsdGVyLWRyb3Bkb3duIC5hbnQtZHJvcGRvd24tbWVudS1pdGVtIHtcXG4gIG92ZXJmbG93OiBoaWRkZW47XFxufVxcbi5hbnQtdGFibGUtZmlsdGVyLWRyb3Bkb3duID4gLmFudC1kcm9wZG93bi1tZW51ID4gLmFudC1kcm9wZG93bi1tZW51LWl0ZW06bGFzdC1jaGlsZCxcXG4uYW50LXRhYmxlLWZpbHRlci1kcm9wZG93biA+IC5hbnQtZHJvcGRvd24tbWVudSA+IC5hbnQtZHJvcGRvd24tbWVudS1zdWJtZW51Omxhc3QtY2hpbGQgLmFudC1kcm9wZG93bi1tZW51LXN1Ym1lbnUtdGl0bGUge1xcbiAgYm9yZGVyLXJhZGl1czogMDtcXG59XFxuLmFudC10YWJsZS1maWx0ZXItZHJvcGRvd24tYnRucyB7XFxuICBvdmVyZmxvdzogaGlkZGVuO1xcbiAgcGFkZGluZzogN3B4IDhweDtcXG4gIGJvcmRlci10b3A6IDFweCBzb2xpZCAjZThlOGU4O1xcbn1cXG4uYW50LXRhYmxlLWZpbHRlci1kcm9wZG93bi1saW5rIHtcXG4gIGNvbG9yOiAjMTg5MGZmO1xcbn1cXG4uYW50LXRhYmxlLWZpbHRlci1kcm9wZG93bi1saW5rOmhvdmVyIHtcXG4gIGNvbG9yOiAjNDBhOWZmO1xcbn1cXG4uYW50LXRhYmxlLWZpbHRlci1kcm9wZG93bi1saW5rOmFjdGl2ZSB7XFxuICBjb2xvcjogIzA5NmRkOTtcXG59XFxuLmFudC10YWJsZS1maWx0ZXItZHJvcGRvd24tbGluay5jb25maXJtIHtcXG4gIGZsb2F0OiBsZWZ0O1xcbn1cXG4uYW50LXRhYmxlLWZpbHRlci1kcm9wZG93bi1saW5rLmNsZWFyIHtcXG4gIGZsb2F0OiByaWdodDtcXG59XFxuLmFudC10YWJsZS1zZWxlY3Rpb24tc2VsZWN0LWFsbC1jdXN0b20ge1xcbiAgbWFyZ2luLXJpZ2h0OiA0cHggIWltcG9ydGFudDtcXG59XFxuLmFudC10YWJsZS1zZWxlY3Rpb24gLmFudGljb24tZG93biB7XFxuICBjb2xvcjogcmdiYSgwLCAwLCAwLCAwLjQ1KTtcXG4gIC13ZWJraXQtdHJhbnNpdGlvbjogYWxsIC4zcztcXG4gIHRyYW5zaXRpb246IGFsbCAuM3M7XFxufVxcbi5hbnQtdGFibGUtc2VsZWN0aW9uLW1lbnUge1xcbiAgbWluLXdpZHRoOiA5NnB4O1xcbiAgbWFyZ2luLXRvcDogNXB4O1xcbiAgbWFyZ2luLWxlZnQ6IC0zMHB4O1xcbiAgYmFja2dyb3VuZDogI2ZmZjtcXG4gIGJvcmRlci1yYWRpdXM6IDRweDtcXG4gIC13ZWJraXQtYm94LXNoYWRvdzogMCAycHggOHB4IHJnYmEoMCwgMCwgMCwgMC4xNSk7XFxuICAgICAgICAgIGJveC1zaGFkb3c6IDAgMnB4IDhweCByZ2JhKDAsIDAsIDAsIDAuMTUpO1xcbn1cXG4uYW50LXRhYmxlLXNlbGVjdGlvbi1tZW51IC5hbnQtYWN0aW9uLWRvd24ge1xcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC40NSk7XFxufVxcbi5hbnQtdGFibGUtc2VsZWN0aW9uLWRvd24ge1xcbiAgY3Vyc29yOiBwb2ludGVyO1xcbiAgcGFkZGluZzogMDtcXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcXG4gIGxpbmUtaGVpZ2h0OiAxO1xcbn1cXG4uYW50LXRhYmxlLXNlbGVjdGlvbi1kb3duOmhvdmVyIC5hbnRpY29uLWRvd24ge1xcbiAgY29sb3I6ICM2NjY7XFxufVxcbi5hbnQtdGFibGUtcm93LWV4cGFuZC1pY29uIHtcXG4gIGN1cnNvcjogcG9pbnRlcjtcXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcXG4gIHdpZHRoOiAxN3B4O1xcbiAgaGVpZ2h0OiAxN3B4O1xcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xcbiAgbGluZS1oZWlnaHQ6IDE0cHg7XFxuICBib3JkZXI6IDFweCBzb2xpZCAjZThlOGU4O1xcbiAgLXdlYmtpdC11c2VyLXNlbGVjdDogbm9uZTtcXG4gICAgIC1tb3otdXNlci1zZWxlY3Q6IG5vbmU7XFxuICAgICAgLW1zLXVzZXItc2VsZWN0OiBub25lO1xcbiAgICAgICAgICB1c2VyLXNlbGVjdDogbm9uZTtcXG4gIGJhY2tncm91bmQ6ICNmZmY7XFxufVxcbi5hbnQtdGFibGUtcm93LWV4cGFuZGVkOmFmdGVyIHtcXG4gIGNvbnRlbnQ6ICctJztcXG59XFxuLmFudC10YWJsZS1yb3ctY29sbGFwc2VkOmFmdGVyIHtcXG4gIGNvbnRlbnQ6ICcrJztcXG59XFxuLmFudC10YWJsZS1yb3ctc3BhY2VkIHtcXG4gIHZpc2liaWxpdHk6IGhpZGRlbjtcXG59XFxuLmFudC10YWJsZS1yb3ctc3BhY2VkOmFmdGVyIHtcXG4gIGNvbnRlbnQ6ICcuJztcXG59XFxuLmFudC10YWJsZS1yb3dbY2xhc3MqPVxcXCJhbnQtdGFibGUtcm93LWxldmVsLTBcXFwiXSAuYW50LXRhYmxlLXNlbGVjdGlvbi1jb2x1bW4gPiBzcGFuIHtcXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcXG59XFxudHIuYW50LXRhYmxlLWV4cGFuZGVkLXJvdyxcXG50ci5hbnQtdGFibGUtZXhwYW5kZWQtcm93OmhvdmVyIHtcXG4gIGJhY2tncm91bmQ6ICNmYmZiZmI7XFxufVxcbi5hbnQtdGFibGUgLmFudC10YWJsZS1yb3ctaW5kZW50ICsgLmFudC10YWJsZS1yb3ctZXhwYW5kLWljb24ge1xcbiAgbWFyZ2luLXJpZ2h0OiA4cHg7XFxufVxcbi5hbnQtdGFibGUtc2Nyb2xsIHtcXG4gIG92ZXJmbG93OiBhdXRvO1xcbiAgb3ZlcmZsb3cteDogaGlkZGVuO1xcbn1cXG4uYW50LXRhYmxlLXNjcm9sbCB0YWJsZSB7XFxuICBtaW4td2lkdGg6IDEwMCU7XFxufVxcbi5hbnQtdGFibGUtYm9keS1pbm5lciB7XFxuICBoZWlnaHQ6IDEwMCU7XFxufVxcbi5hbnQtdGFibGUtZml4ZWQtaGVhZGVyID4gLmFudC10YWJsZS1jb250ZW50ID4gLmFudC10YWJsZS1zY3JvbGwgPiAuYW50LXRhYmxlLWJvZHkge1xcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xcbiAgYmFja2dyb3VuZDogI2ZmZjtcXG59XFxuLmFudC10YWJsZS1maXhlZC1oZWFkZXIgLmFudC10YWJsZS1ib2R5LWlubmVyIHtcXG4gIG92ZXJmbG93OiBzY3JvbGw7XFxufVxcbi5hbnQtdGFibGUtZml4ZWQtaGVhZGVyIC5hbnQtdGFibGUtc2Nyb2xsIC5hbnQtdGFibGUtaGVhZGVyIHtcXG4gIG92ZXJmbG93OiBzY3JvbGw7XFxuICBwYWRkaW5nLWJvdHRvbTogMjBweDtcXG4gIG1hcmdpbi1ib3R0b206IC0yMHB4O1xcbn1cXG4uYW50LXRhYmxlLWZpeGVkLWxlZnQsXFxuLmFudC10YWJsZS1maXhlZC1yaWdodCB7XFxuICBwb3NpdGlvbjogYWJzb2x1dGU7XFxuICB0b3A6IDA7XFxuICBvdmVyZmxvdzogaGlkZGVuO1xcbiAgLXdlYmtpdC10cmFuc2l0aW9uOiAtd2Via2l0LWJveC1zaGFkb3cgMC4zcyBlYXNlO1xcbiAgdHJhbnNpdGlvbjogLXdlYmtpdC1ib3gtc2hhZG93IDAuM3MgZWFzZTtcXG4gIHRyYW5zaXRpb246IGJveC1zaGFkb3cgMC4zcyBlYXNlO1xcbiAgdHJhbnNpdGlvbjogYm94LXNoYWRvdyAwLjNzIGVhc2UsIC13ZWJraXQtYm94LXNoYWRvdyAwLjNzIGVhc2U7XFxuICBib3JkZXItcmFkaXVzOiAwO1xcbn1cXG4uYW50LXRhYmxlLWZpeGVkLWxlZnQgdGFibGUsXFxuLmFudC10YWJsZS1maXhlZC1yaWdodCB0YWJsZSB7XFxuICB3aWR0aDogYXV0bztcXG4gIGJhY2tncm91bmQ6ICNmZmY7XFxufVxcbi5hbnQtdGFibGUtZml4ZWQtaGVhZGVyIC5hbnQtdGFibGUtZml4ZWQtbGVmdCAuYW50LXRhYmxlLWJvZHktb3V0ZXIgLmFudC10YWJsZS1maXhlZCxcXG4uYW50LXRhYmxlLWZpeGVkLWhlYWRlciAuYW50LXRhYmxlLWZpeGVkLXJpZ2h0IC5hbnQtdGFibGUtYm9keS1vdXRlciAuYW50LXRhYmxlLWZpeGVkIHtcXG4gIGJvcmRlci1yYWRpdXM6IDA7XFxufVxcbi5hbnQtdGFibGUtZml4ZWQtbGVmdCB7XFxuICBsZWZ0OiAwO1xcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiA2cHggMCA2cHggLTRweCByZ2JhKDAsIDAsIDAsIDAuMTUpO1xcbiAgICAgICAgICBib3gtc2hhZG93OiA2cHggMCA2cHggLTRweCByZ2JhKDAsIDAsIDAsIDAuMTUpO1xcbn1cXG4uYW50LXRhYmxlLWZpeGVkLWxlZnQgLmFudC10YWJsZS1oZWFkZXIge1xcbiAgb3ZlcmZsb3cteTogaGlkZGVuO1xcbn1cXG4uYW50LXRhYmxlLWZpeGVkLWxlZnQgLmFudC10YWJsZS1ib2R5LWlubmVyIHtcXG4gIG1hcmdpbi1yaWdodDogLTIwcHg7XFxuICBwYWRkaW5nLXJpZ2h0OiAyMHB4O1xcbn1cXG4uYW50LXRhYmxlLWZpeGVkLWhlYWRlciAuYW50LXRhYmxlLWZpeGVkLWxlZnQgLmFudC10YWJsZS1ib2R5LWlubmVyIHtcXG4gIHBhZGRpbmctcmlnaHQ6IDA7XFxufVxcbi5hbnQtdGFibGUtZml4ZWQtbGVmdCxcXG4uYW50LXRhYmxlLWZpeGVkLWxlZnQgdGFibGUge1xcbiAgYm9yZGVyLXJhZGl1czogNHB4IDAgMCAwO1xcbn1cXG4uYW50LXRhYmxlLWZpeGVkLWxlZnQgLmFudC10YWJsZS10aGVhZCA+IHRyID4gdGg6bGFzdC1jaGlsZCB7XFxuICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogMDtcXG59XFxuLmFudC10YWJsZS1maXhlZC1yaWdodCB7XFxuICByaWdodDogMDtcXG4gIC13ZWJraXQtYm94LXNoYWRvdzogLTZweCAwIDZweCAtNHB4IHJnYmEoMCwgMCwgMCwgMC4xNSk7XFxuICAgICAgICAgIGJveC1zaGFkb3c6IC02cHggMCA2cHggLTRweCByZ2JhKDAsIDAsIDAsIDAuMTUpO1xcbn1cXG4uYW50LXRhYmxlLWZpeGVkLXJpZ2h0LFxcbi5hbnQtdGFibGUtZml4ZWQtcmlnaHQgdGFibGUge1xcbiAgYm9yZGVyLXJhZGl1czogMCA0cHggMCAwO1xcbn1cXG4uYW50LXRhYmxlLWZpeGVkLXJpZ2h0IC5hbnQtdGFibGUtZXhwYW5kZWQtcm93IHtcXG4gIGNvbG9yOiB0cmFuc3BhcmVudDtcXG4gIHBvaW50ZXItZXZlbnRzOiBub25lO1xcbn1cXG4uYW50LXRhYmxlLWZpeGVkLXJpZ2h0IC5hbnQtdGFibGUtdGhlYWQgPiB0ciA+IHRoOmZpcnN0LWNoaWxkIHtcXG4gIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDA7XFxufVxcbi5hbnQtdGFibGUuYW50LXRhYmxlLXNjcm9sbC1wb3NpdGlvbi1sZWZ0IC5hbnQtdGFibGUtZml4ZWQtbGVmdCB7XFxuICAtd2Via2l0LWJveC1zaGFkb3c6IG5vbmU7XFxuICAgICAgICAgIGJveC1zaGFkb3c6IG5vbmU7XFxufVxcbi5hbnQtdGFibGUuYW50LXRhYmxlLXNjcm9sbC1wb3NpdGlvbi1yaWdodCAuYW50LXRhYmxlLWZpeGVkLXJpZ2h0IHtcXG4gIC13ZWJraXQtYm94LXNoYWRvdzogbm9uZTtcXG4gICAgICAgICAgYm94LXNoYWRvdzogbm9uZTtcXG59XFxuLmFudC10YWJsZS1taWRkbGUgPiAuYW50LXRhYmxlLXRpdGxlLFxcbi5hbnQtdGFibGUtbWlkZGxlID4gLmFudC10YWJsZS1mb290ZXIge1xcbiAgcGFkZGluZzogMTJweCA4cHg7XFxufVxcbi5hbnQtdGFibGUtbWlkZGxlID4gLmFudC10YWJsZS1jb250ZW50ID4gLmFudC10YWJsZS1oZWFkZXIgPiB0YWJsZSA+IC5hbnQtdGFibGUtdGhlYWQgPiB0ciA+IHRoLFxcbi5hbnQtdGFibGUtbWlkZGxlID4gLmFudC10YWJsZS1jb250ZW50ID4gLmFudC10YWJsZS1ib2R5ID4gdGFibGUgPiAuYW50LXRhYmxlLXRoZWFkID4gdHIgPiB0aCxcXG4uYW50LXRhYmxlLW1pZGRsZSA+IC5hbnQtdGFibGUtY29udGVudCA+IC5hbnQtdGFibGUtc2Nyb2xsID4gLmFudC10YWJsZS1oZWFkZXIgPiB0YWJsZSA+IC5hbnQtdGFibGUtdGhlYWQgPiB0ciA+IHRoLFxcbi5hbnQtdGFibGUtbWlkZGxlID4gLmFudC10YWJsZS1jb250ZW50ID4gLmFudC10YWJsZS1zY3JvbGwgPiAuYW50LXRhYmxlLWJvZHkgPiB0YWJsZSA+IC5hbnQtdGFibGUtdGhlYWQgPiB0ciA+IHRoLFxcbi5hbnQtdGFibGUtbWlkZGxlID4gLmFudC10YWJsZS1jb250ZW50ID4gLmFudC10YWJsZS1maXhlZC1sZWZ0ID4gLmFudC10YWJsZS1oZWFkZXIgPiB0YWJsZSA+IC5hbnQtdGFibGUtdGhlYWQgPiB0ciA+IHRoLFxcbi5hbnQtdGFibGUtbWlkZGxlID4gLmFudC10YWJsZS1jb250ZW50ID4gLmFudC10YWJsZS1maXhlZC1yaWdodCA+IC5hbnQtdGFibGUtaGVhZGVyID4gdGFibGUgPiAuYW50LXRhYmxlLXRoZWFkID4gdHIgPiB0aCxcXG4uYW50LXRhYmxlLW1pZGRsZSA+IC5hbnQtdGFibGUtY29udGVudCA+IC5hbnQtdGFibGUtZml4ZWQtbGVmdCA+IC5hbnQtdGFibGUtYm9keS1vdXRlciA+IC5hbnQtdGFibGUtYm9keS1pbm5lciA+IHRhYmxlID4gLmFudC10YWJsZS10aGVhZCA+IHRyID4gdGgsXFxuLmFudC10YWJsZS1taWRkbGUgPiAuYW50LXRhYmxlLWNvbnRlbnQgPiAuYW50LXRhYmxlLWZpeGVkLXJpZ2h0ID4gLmFudC10YWJsZS1ib2R5LW91dGVyID4gLmFudC10YWJsZS1ib2R5LWlubmVyID4gdGFibGUgPiAuYW50LXRhYmxlLXRoZWFkID4gdHIgPiB0aCxcXG4uYW50LXRhYmxlLW1pZGRsZSA+IC5hbnQtdGFibGUtY29udGVudCA+IC5hbnQtdGFibGUtaGVhZGVyID4gdGFibGUgPiAuYW50LXRhYmxlLXRib2R5ID4gdHIgPiB0ZCxcXG4uYW50LXRhYmxlLW1pZGRsZSA+IC5hbnQtdGFibGUtY29udGVudCA+IC5hbnQtdGFibGUtYm9keSA+IHRhYmxlID4gLmFudC10YWJsZS10Ym9keSA+IHRyID4gdGQsXFxuLmFudC10YWJsZS1taWRkbGUgPiAuYW50LXRhYmxlLWNvbnRlbnQgPiAuYW50LXRhYmxlLXNjcm9sbCA+IC5hbnQtdGFibGUtaGVhZGVyID4gdGFibGUgPiAuYW50LXRhYmxlLXRib2R5ID4gdHIgPiB0ZCxcXG4uYW50LXRhYmxlLW1pZGRsZSA+IC5hbnQtdGFibGUtY29udGVudCA+IC5hbnQtdGFibGUtc2Nyb2xsID4gLmFudC10YWJsZS1ib2R5ID4gdGFibGUgPiAuYW50LXRhYmxlLXRib2R5ID4gdHIgPiB0ZCxcXG4uYW50LXRhYmxlLW1pZGRsZSA+IC5hbnQtdGFibGUtY29udGVudCA+IC5hbnQtdGFibGUtZml4ZWQtbGVmdCA+IC5hbnQtdGFibGUtaGVhZGVyID4gdGFibGUgPiAuYW50LXRhYmxlLXRib2R5ID4gdHIgPiB0ZCxcXG4uYW50LXRhYmxlLW1pZGRsZSA+IC5hbnQtdGFibGUtY29udGVudCA+IC5hbnQtdGFibGUtZml4ZWQtcmlnaHQgPiAuYW50LXRhYmxlLWhlYWRlciA+IHRhYmxlID4gLmFudC10YWJsZS10Ym9keSA+IHRyID4gdGQsXFxuLmFudC10YWJsZS1taWRkbGUgPiAuYW50LXRhYmxlLWNvbnRlbnQgPiAuYW50LXRhYmxlLWZpeGVkLWxlZnQgPiAuYW50LXRhYmxlLWJvZHktb3V0ZXIgPiAuYW50LXRhYmxlLWJvZHktaW5uZXIgPiB0YWJsZSA+IC5hbnQtdGFibGUtdGJvZHkgPiB0ciA+IHRkLFxcbi5hbnQtdGFibGUtbWlkZGxlID4gLmFudC10YWJsZS1jb250ZW50ID4gLmFudC10YWJsZS1maXhlZC1yaWdodCA+IC5hbnQtdGFibGUtYm9keS1vdXRlciA+IC5hbnQtdGFibGUtYm9keS1pbm5lciA+IHRhYmxlID4gLmFudC10YWJsZS10Ym9keSA+IHRyID4gdGQge1xcbiAgcGFkZGluZzogMTJweCA4cHg7XFxufVxcbi5hbnQtdGFibGUtc21hbGwge1xcbiAgYm9yZGVyOiAxcHggc29saWQgI2U4ZThlODtcXG4gIGJvcmRlci1yYWRpdXM6IDRweDtcXG59XFxuLmFudC10YWJsZS1zbWFsbCA+IC5hbnQtdGFibGUtdGl0bGUsXFxuLmFudC10YWJsZS1zbWFsbCA+IC5hbnQtdGFibGUtZm9vdGVyIHtcXG4gIHBhZGRpbmc6IDhweCA4cHg7XFxufVxcbi5hbnQtdGFibGUtc21hbGwgPiAuYW50LXRhYmxlLXRpdGxlIHtcXG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZThlOGU4O1xcbiAgdG9wOiAwO1xcbn1cXG4uYW50LXRhYmxlLXNtYWxsID4gLmFudC10YWJsZS1jb250ZW50ID4gLmFudC10YWJsZS1oZWFkZXIgPiB0YWJsZSxcXG4uYW50LXRhYmxlLXNtYWxsID4gLmFudC10YWJsZS1jb250ZW50ID4gLmFudC10YWJsZS1ib2R5ID4gdGFibGUsXFxuLmFudC10YWJsZS1zbWFsbCA+IC5hbnQtdGFibGUtY29udGVudCA+IC5hbnQtdGFibGUtc2Nyb2xsID4gLmFudC10YWJsZS1oZWFkZXIgPiB0YWJsZSxcXG4uYW50LXRhYmxlLXNtYWxsID4gLmFudC10YWJsZS1jb250ZW50ID4gLmFudC10YWJsZS1zY3JvbGwgPiAuYW50LXRhYmxlLWJvZHkgPiB0YWJsZSxcXG4uYW50LXRhYmxlLXNtYWxsID4gLmFudC10YWJsZS1jb250ZW50ID4gLmFudC10YWJsZS1maXhlZC1sZWZ0ID4gLmFudC10YWJsZS1oZWFkZXIgPiB0YWJsZSxcXG4uYW50LXRhYmxlLXNtYWxsID4gLmFudC10YWJsZS1jb250ZW50ID4gLmFudC10YWJsZS1maXhlZC1yaWdodCA+IC5hbnQtdGFibGUtaGVhZGVyID4gdGFibGUsXFxuLmFudC10YWJsZS1zbWFsbCA+IC5hbnQtdGFibGUtY29udGVudCA+IC5hbnQtdGFibGUtZml4ZWQtbGVmdCA+IC5hbnQtdGFibGUtYm9keS1vdXRlciA+IC5hbnQtdGFibGUtYm9keS1pbm5lciA+IHRhYmxlLFxcbi5hbnQtdGFibGUtc21hbGwgPiAuYW50LXRhYmxlLWNvbnRlbnQgPiAuYW50LXRhYmxlLWZpeGVkLXJpZ2h0ID4gLmFudC10YWJsZS1ib2R5LW91dGVyID4gLmFudC10YWJsZS1ib2R5LWlubmVyID4gdGFibGUge1xcbiAgYm9yZGVyOiAwO1xcbiAgcGFkZGluZzogMCA4cHg7XFxufVxcbi5hbnQtdGFibGUtc21hbGwgPiAuYW50LXRhYmxlLWNvbnRlbnQgPiAuYW50LXRhYmxlLWhlYWRlciA+IHRhYmxlID4gLmFudC10YWJsZS10aGVhZCA+IHRyID4gdGgsXFxuLmFudC10YWJsZS1zbWFsbCA+IC5hbnQtdGFibGUtY29udGVudCA+IC5hbnQtdGFibGUtYm9keSA+IHRhYmxlID4gLmFudC10YWJsZS10aGVhZCA+IHRyID4gdGgsXFxuLmFudC10YWJsZS1zbWFsbCA+IC5hbnQtdGFibGUtY29udGVudCA+IC5hbnQtdGFibGUtc2Nyb2xsID4gLmFudC10YWJsZS1oZWFkZXIgPiB0YWJsZSA+IC5hbnQtdGFibGUtdGhlYWQgPiB0ciA+IHRoLFxcbi5hbnQtdGFibGUtc21hbGwgPiAuYW50LXRhYmxlLWNvbnRlbnQgPiAuYW50LXRhYmxlLXNjcm9sbCA+IC5hbnQtdGFibGUtYm9keSA+IHRhYmxlID4gLmFudC10YWJsZS10aGVhZCA+IHRyID4gdGgsXFxuLmFudC10YWJsZS1zbWFsbCA+IC5hbnQtdGFibGUtY29udGVudCA+IC5hbnQtdGFibGUtZml4ZWQtbGVmdCA+IC5hbnQtdGFibGUtaGVhZGVyID4gdGFibGUgPiAuYW50LXRhYmxlLXRoZWFkID4gdHIgPiB0aCxcXG4uYW50LXRhYmxlLXNtYWxsID4gLmFudC10YWJsZS1jb250ZW50ID4gLmFudC10YWJsZS1maXhlZC1yaWdodCA+IC5hbnQtdGFibGUtaGVhZGVyID4gdGFibGUgPiAuYW50LXRhYmxlLXRoZWFkID4gdHIgPiB0aCxcXG4uYW50LXRhYmxlLXNtYWxsID4gLmFudC10YWJsZS1jb250ZW50ID4gLmFudC10YWJsZS1maXhlZC1sZWZ0ID4gLmFudC10YWJsZS1ib2R5LW91dGVyID4gLmFudC10YWJsZS1ib2R5LWlubmVyID4gdGFibGUgPiAuYW50LXRhYmxlLXRoZWFkID4gdHIgPiB0aCxcXG4uYW50LXRhYmxlLXNtYWxsID4gLmFudC10YWJsZS1jb250ZW50ID4gLmFudC10YWJsZS1maXhlZC1yaWdodCA+IC5hbnQtdGFibGUtYm9keS1vdXRlciA+IC5hbnQtdGFibGUtYm9keS1pbm5lciA+IHRhYmxlID4gLmFudC10YWJsZS10aGVhZCA+IHRyID4gdGgsXFxuLmFudC10YWJsZS1zbWFsbCA+IC5hbnQtdGFibGUtY29udGVudCA+IC5hbnQtdGFibGUtaGVhZGVyID4gdGFibGUgPiAuYW50LXRhYmxlLXRib2R5ID4gdHIgPiB0ZCxcXG4uYW50LXRhYmxlLXNtYWxsID4gLmFudC10YWJsZS1jb250ZW50ID4gLmFudC10YWJsZS1ib2R5ID4gdGFibGUgPiAuYW50LXRhYmxlLXRib2R5ID4gdHIgPiB0ZCxcXG4uYW50LXRhYmxlLXNtYWxsID4gLmFudC10YWJsZS1jb250ZW50ID4gLmFudC10YWJsZS1zY3JvbGwgPiAuYW50LXRhYmxlLWhlYWRlciA+IHRhYmxlID4gLmFudC10YWJsZS10Ym9keSA+IHRyID4gdGQsXFxuLmFudC10YWJsZS1zbWFsbCA+IC5hbnQtdGFibGUtY29udGVudCA+IC5hbnQtdGFibGUtc2Nyb2xsID4gLmFudC10YWJsZS1ib2R5ID4gdGFibGUgPiAuYW50LXRhYmxlLXRib2R5ID4gdHIgPiB0ZCxcXG4uYW50LXRhYmxlLXNtYWxsID4gLmFudC10YWJsZS1jb250ZW50ID4gLmFudC10YWJsZS1maXhlZC1sZWZ0ID4gLmFudC10YWJsZS1oZWFkZXIgPiB0YWJsZSA+IC5hbnQtdGFibGUtdGJvZHkgPiB0ciA+IHRkLFxcbi5hbnQtdGFibGUtc21hbGwgPiAuYW50LXRhYmxlLWNvbnRlbnQgPiAuYW50LXRhYmxlLWZpeGVkLXJpZ2h0ID4gLmFudC10YWJsZS1oZWFkZXIgPiB0YWJsZSA+IC5hbnQtdGFibGUtdGJvZHkgPiB0ciA+IHRkLFxcbi5hbnQtdGFibGUtc21hbGwgPiAuYW50LXRhYmxlLWNvbnRlbnQgPiAuYW50LXRhYmxlLWZpeGVkLWxlZnQgPiAuYW50LXRhYmxlLWJvZHktb3V0ZXIgPiAuYW50LXRhYmxlLWJvZHktaW5uZXIgPiB0YWJsZSA+IC5hbnQtdGFibGUtdGJvZHkgPiB0ciA+IHRkLFxcbi5hbnQtdGFibGUtc21hbGwgPiAuYW50LXRhYmxlLWNvbnRlbnQgPiAuYW50LXRhYmxlLWZpeGVkLXJpZ2h0ID4gLmFudC10YWJsZS1ib2R5LW91dGVyID4gLmFudC10YWJsZS1ib2R5LWlubmVyID4gdGFibGUgPiAuYW50LXRhYmxlLXRib2R5ID4gdHIgPiB0ZCB7XFxuICBwYWRkaW5nOiA4cHggOHB4O1xcbn1cXG4uYW50LXRhYmxlLXNtYWxsID4gLmFudC10YWJsZS1jb250ZW50ID4gLmFudC10YWJsZS1oZWFkZXIgPiB0YWJsZSA+IC5hbnQtdGFibGUtdGhlYWQgPiB0ciA+IHRoLFxcbi5hbnQtdGFibGUtc21hbGwgPiAuYW50LXRhYmxlLWNvbnRlbnQgPiAuYW50LXRhYmxlLWJvZHkgPiB0YWJsZSA+IC5hbnQtdGFibGUtdGhlYWQgPiB0ciA+IHRoLFxcbi5hbnQtdGFibGUtc21hbGwgPiAuYW50LXRhYmxlLWNvbnRlbnQgPiAuYW50LXRhYmxlLXNjcm9sbCA+IC5hbnQtdGFibGUtaGVhZGVyID4gdGFibGUgPiAuYW50LXRhYmxlLXRoZWFkID4gdHIgPiB0aCxcXG4uYW50LXRhYmxlLXNtYWxsID4gLmFudC10YWJsZS1jb250ZW50ID4gLmFudC10YWJsZS1zY3JvbGwgPiAuYW50LXRhYmxlLWJvZHkgPiB0YWJsZSA+IC5hbnQtdGFibGUtdGhlYWQgPiB0ciA+IHRoLFxcbi5hbnQtdGFibGUtc21hbGwgPiAuYW50LXRhYmxlLWNvbnRlbnQgPiAuYW50LXRhYmxlLWZpeGVkLWxlZnQgPiAuYW50LXRhYmxlLWhlYWRlciA+IHRhYmxlID4gLmFudC10YWJsZS10aGVhZCA+IHRyID4gdGgsXFxuLmFudC10YWJsZS1zbWFsbCA+IC5hbnQtdGFibGUtY29udGVudCA+IC5hbnQtdGFibGUtZml4ZWQtcmlnaHQgPiAuYW50LXRhYmxlLWhlYWRlciA+IHRhYmxlID4gLmFudC10YWJsZS10aGVhZCA+IHRyID4gdGgsXFxuLmFudC10YWJsZS1zbWFsbCA+IC5hbnQtdGFibGUtY29udGVudCA+IC5hbnQtdGFibGUtZml4ZWQtbGVmdCA+IC5hbnQtdGFibGUtYm9keS1vdXRlciA+IC5hbnQtdGFibGUtYm9keS1pbm5lciA+IHRhYmxlID4gLmFudC10YWJsZS10aGVhZCA+IHRyID4gdGgsXFxuLmFudC10YWJsZS1zbWFsbCA+IC5hbnQtdGFibGUtY29udGVudCA+IC5hbnQtdGFibGUtZml4ZWQtcmlnaHQgPiAuYW50LXRhYmxlLWJvZHktb3V0ZXIgPiAuYW50LXRhYmxlLWJvZHktaW5uZXIgPiB0YWJsZSA+IC5hbnQtdGFibGUtdGhlYWQgPiB0ciA+IHRoIHtcXG4gIGJhY2tncm91bmQ6ICNmZmY7XFxuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2U4ZThlODtcXG59XFxuLmFudC10YWJsZS1zbWFsbCA+IC5hbnQtdGFibGUtY29udGVudCA+IC5hbnQtdGFibGUtc2Nyb2xsID4gLmFudC10YWJsZS1oZWFkZXIgPiB0YWJsZSxcXG4uYW50LXRhYmxlLXNtYWxsID4gLmFudC10YWJsZS1jb250ZW50ID4gLmFudC10YWJsZS1zY3JvbGwgPiAuYW50LXRhYmxlLWJvZHkgPiB0YWJsZSxcXG4uYW50LXRhYmxlLXNtYWxsID4gLmFudC10YWJsZS1jb250ZW50ID4gLmFudC10YWJsZS1maXhlZC1sZWZ0ID4gLmFudC10YWJsZS1oZWFkZXIgPiB0YWJsZSxcXG4uYW50LXRhYmxlLXNtYWxsID4gLmFudC10YWJsZS1jb250ZW50ID4gLmFudC10YWJsZS1maXhlZC1yaWdodCA+IC5hbnQtdGFibGUtaGVhZGVyID4gdGFibGUsXFxuLmFudC10YWJsZS1zbWFsbCA+IC5hbnQtdGFibGUtY29udGVudCA+IC5hbnQtdGFibGUtZml4ZWQtbGVmdCA+IC5hbnQtdGFibGUtYm9keS1vdXRlciA+IC5hbnQtdGFibGUtYm9keS1pbm5lciA+IHRhYmxlLFxcbi5hbnQtdGFibGUtc21hbGwgPiAuYW50LXRhYmxlLWNvbnRlbnQgPiAuYW50LXRhYmxlLWZpeGVkLXJpZ2h0ID4gLmFudC10YWJsZS1ib2R5LW91dGVyID4gLmFudC10YWJsZS1ib2R5LWlubmVyID4gdGFibGUge1xcbiAgcGFkZGluZzogMDtcXG59XFxuLmFudC10YWJsZS1zbWFsbCA+IC5hbnQtdGFibGUtY29udGVudCAuYW50LXRhYmxlLWhlYWRlciB7XFxuICBiYWNrZ3JvdW5kOiAjZmZmO1xcbn1cXG4uYW50LXRhYmxlLXNtYWxsID4gLmFudC10YWJsZS1jb250ZW50IC5hbnQtdGFibGUtcGxhY2Vob2xkZXIsXFxuLmFudC10YWJsZS1zbWFsbCA+IC5hbnQtdGFibGUtY29udGVudCAuYW50LXRhYmxlLXJvdzpsYXN0LWNoaWxkIHRkIHtcXG4gIGJvcmRlci1ib3R0b206IDA7XFxufVxcbi5hbnQtdGFibGUtc21hbGwuYW50LXRhYmxlLWJvcmRlcmVkIHtcXG4gIGJvcmRlci1yaWdodDogMDtcXG59XFxuLmFudC10YWJsZS1zbWFsbC5hbnQtdGFibGUtYm9yZGVyZWQgLmFudC10YWJsZS10aXRsZSB7XFxuICBib3JkZXI6IDA7XFxuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2U4ZThlODtcXG4gIGJvcmRlci1yaWdodDogMXB4IHNvbGlkICNlOGU4ZTg7XFxufVxcbi5hbnQtdGFibGUtc21hbGwuYW50LXRhYmxlLWJvcmRlcmVkIC5hbnQtdGFibGUtY29udGVudCB7XFxuICBib3JkZXItcmlnaHQ6IDFweCBzb2xpZCAjZThlOGU4O1xcbn1cXG4uYW50LXRhYmxlLXNtYWxsLmFudC10YWJsZS1ib3JkZXJlZCAuYW50LXRhYmxlLWZvb3RlciB7XFxuICBib3JkZXI6IDA7XFxuICBib3JkZXItdG9wOiAxcHggc29saWQgI2U4ZThlODtcXG4gIGJvcmRlci1yaWdodDogMXB4IHNvbGlkICNlOGU4ZTg7XFxufVxcbi5hbnQtdGFibGUtc21hbGwuYW50LXRhYmxlLWJvcmRlcmVkIC5hbnQtdGFibGUtZm9vdGVyOmJlZm9yZSB7XFxuICBkaXNwbGF5OiBub25lO1xcbn1cXG4uYW50LXRhYmxlLXNtYWxsLmFudC10YWJsZS1ib3JkZXJlZCAuYW50LXRhYmxlLXBsYWNlaG9sZGVyIHtcXG4gIGJvcmRlci1sZWZ0OiAwO1xcbiAgYm9yZGVyLWJvdHRvbTogMDtcXG59XFxuLmFudC10YWJsZS1zbWFsbC5hbnQtdGFibGUtYm9yZGVyZWQgLmFudC10YWJsZS10aGVhZCA+IHRyID4gdGg6bGFzdC1jaGlsZCxcXG4uYW50LXRhYmxlLXNtYWxsLmFudC10YWJsZS1ib3JkZXJlZCAuYW50LXRhYmxlLXRib2R5ID4gdHIgPiB0ZDpsYXN0LWNoaWxkIHtcXG4gIGJvcmRlci1yaWdodDogbm9uZTtcXG59XFxuXCIsIFwiXCJdKTtcblxuLy8gZXhwb3J0c1xuIiwiZXhwb3J0cyA9IG1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIi4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2xpYi9jc3MtYmFzZS5qc1wiKSh0cnVlKTtcbi8vIGltcG9ydHNcblxuXG4vLyBtb2R1bGVcbmV4cG9ydHMucHVzaChbbW9kdWxlLmlkLCBcIi5zZXR0aW5nX2NhcmQtbWFyZ2lue1xcclxcbiAgICBtYXJnaW4tYm90dG9tOiAyMHB4O1xcclxcbn1cXHJcXG4uc2V0dGluZ19hZGQtYWNjb3VudHtcXHJcXG4gICAgbWFyZ2luLXRvcDogMjBweDtcXHJcXG4gICAgd2lkdGg6IDEwMCU7XFxyXFxufVxcclxcbi5zZXR0aW5nX2Zvcm17XFxyXFxuICAgIHdpZHRoOiA0NTBweDtcXHJcXG4gICAgbWFyZ2luOiAwIGF1dG87XFxyXFxufVwiLCBcIlwiLCB7XCJ2ZXJzaW9uXCI6MyxcInNvdXJjZXNcIjpbXCJFOi9mcm9udGVuZC9qaGdzai1yZXBvcnQvcGMvc3JjL3BhZ2VzL3NldHRpbmcvc2V0dGluZy5jc3NcIl0sXCJuYW1lc1wiOltdLFwibWFwcGluZ3NcIjpcIkFBQUE7SUFDSSxvQkFBb0I7Q0FDdkI7QUFDRDtJQUNJLGlCQUFpQjtJQUNqQixZQUFZO0NBQ2Y7QUFDRDtJQUNJLGFBQWE7SUFDYixlQUFlO0NBQ2xCXCIsXCJmaWxlXCI6XCJzZXR0aW5nLmNzc1wiLFwic291cmNlc0NvbnRlbnRcIjpbXCIuY2FyZC1tYXJnaW57XFxyXFxuICAgIG1hcmdpbi1ib3R0b206IDIwcHg7XFxyXFxufVxcclxcbi5hZGQtYWNjb3VudHtcXHJcXG4gICAgbWFyZ2luLXRvcDogMjBweDtcXHJcXG4gICAgd2lkdGg6IDEwMCU7XFxyXFxufVxcclxcbi5mb3Jte1xcclxcbiAgICB3aWR0aDogNDUwcHg7XFxyXFxuICAgIG1hcmdpbjogMCBhdXRvO1xcclxcbn1cIl0sXCJzb3VyY2VSb290XCI6XCJcIn1dKTtcblxuLy8gZXhwb3J0c1xuZXhwb3J0cy5sb2NhbHMgPSB7XG5cdFwiY2FyZC1tYXJnaW5cIjogXCJzZXR0aW5nX2NhcmQtbWFyZ2luXCIsXG5cdFwiYWRkLWFjY291bnRcIjogXCJzZXR0aW5nX2FkZC1hY2NvdW50XCIsXG5cdFwiZm9ybVwiOiBcInNldHRpbmdfZm9ybVwiXG59OyIsIi8qKlxuICogTW9kdWxlIGRlcGVuZGVuY2llc1xuICovXG5cbnZhciBtYXRjaGVzID0gcmVxdWlyZSgnZG9tLW1hdGNoZXMnKTtcblxuLyoqXG4gKiBAcGFyYW0gZWxlbWVudCB7RWxlbWVudH1cbiAqIEBwYXJhbSBzZWxlY3RvciB7U3RyaW5nfVxuICogQHBhcmFtIGNvbnRleHQge0VsZW1lbnR9XG4gKiBAcmV0dXJuIHtFbGVtZW50fVxuICovXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChlbGVtZW50LCBzZWxlY3RvciwgY29udGV4dCkge1xuICBjb250ZXh0ID0gY29udGV4dCB8fCBkb2N1bWVudDtcbiAgLy8gZ3VhcmQgYWdhaW5zdCBvcnBoYW5zXG4gIGVsZW1lbnQgPSB7IHBhcmVudE5vZGU6IGVsZW1lbnQgfTtcblxuICB3aGlsZSAoKGVsZW1lbnQgPSBlbGVtZW50LnBhcmVudE5vZGUpICYmIGVsZW1lbnQgIT09IGNvbnRleHQpIHtcbiAgICBpZiAobWF0Y2hlcyhlbGVtZW50LCBzZWxlY3RvcikpIHtcbiAgICAgIHJldHVybiBlbGVtZW50O1xuICAgIH1cbiAgfVxufTtcbiIsIid1c2Ugc3RyaWN0JztcblxuLyoqXG4gKiBEZXRlcm1pbmUgaWYgYSBET00gZWxlbWVudCBtYXRjaGVzIGEgQ1NTIHNlbGVjdG9yXG4gKlxuICogQHBhcmFtIHtFbGVtZW50fSBlbGVtXG4gKiBAcGFyYW0ge1N0cmluZ30gc2VsZWN0b3JcbiAqIEByZXR1cm4ge0Jvb2xlYW59XG4gKiBAYXBpIHB1YmxpY1xuICovXG5cbmZ1bmN0aW9uIG1hdGNoZXMoZWxlbSwgc2VsZWN0b3IpIHtcbiAgLy8gVmVuZG9yLXNwZWNpZmljIGltcGxlbWVudGF0aW9ucyBvZiBgRWxlbWVudC5wcm90b3R5cGUubWF0Y2hlcygpYC5cbiAgdmFyIHByb3RvID0gd2luZG93LkVsZW1lbnQucHJvdG90eXBlO1xuICB2YXIgbmF0aXZlTWF0Y2hlcyA9IHByb3RvLm1hdGNoZXMgfHxcbiAgICAgIHByb3RvLm1vek1hdGNoZXNTZWxlY3RvciB8fFxuICAgICAgcHJvdG8ubXNNYXRjaGVzU2VsZWN0b3IgfHxcbiAgICAgIHByb3RvLm9NYXRjaGVzU2VsZWN0b3IgfHxcbiAgICAgIHByb3RvLndlYmtpdE1hdGNoZXNTZWxlY3RvcjtcblxuICBpZiAoIWVsZW0gfHwgZWxlbS5ub2RlVHlwZSAhPT0gMSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIHZhciBwYXJlbnRFbGVtID0gZWxlbS5wYXJlbnROb2RlO1xuXG4gIC8vIHVzZSBuYXRpdmUgJ21hdGNoZXMnXG4gIGlmIChuYXRpdmVNYXRjaGVzKSB7XG4gICAgcmV0dXJuIG5hdGl2ZU1hdGNoZXMuY2FsbChlbGVtLCBzZWxlY3Rvcik7XG4gIH1cblxuICAvLyBuYXRpdmUgc3VwcG9ydCBmb3IgYG1hdGNoZXNgIGlzIG1pc3NpbmcgYW5kIGEgZmFsbGJhY2sgaXMgcmVxdWlyZWRcbiAgdmFyIG5vZGVzID0gcGFyZW50RWxlbS5xdWVyeVNlbGVjdG9yQWxsKHNlbGVjdG9yKTtcbiAgdmFyIGxlbiA9IG5vZGVzLmxlbmd0aDtcblxuICBmb3IgKHZhciBpID0gMDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgaWYgKG5vZGVzW2ldID09PSBlbGVtKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gZmFsc2U7XG59XG5cbi8qKlxuICogRXhwb3NlIGBtYXRjaGVzYFxuICovXG5cbm1vZHVsZS5leHBvcnRzID0gbWF0Y2hlcztcbiIsInZhciBMaXN0Q2FjaGUgPSByZXF1aXJlKCcuL19MaXN0Q2FjaGUnKSxcbiAgICBzdGFja0NsZWFyID0gcmVxdWlyZSgnLi9fc3RhY2tDbGVhcicpLFxuICAgIHN0YWNrRGVsZXRlID0gcmVxdWlyZSgnLi9fc3RhY2tEZWxldGUnKSxcbiAgICBzdGFja0dldCA9IHJlcXVpcmUoJy4vX3N0YWNrR2V0JyksXG4gICAgc3RhY2tIYXMgPSByZXF1aXJlKCcuL19zdGFja0hhcycpLFxuICAgIHN0YWNrU2V0ID0gcmVxdWlyZSgnLi9fc3RhY2tTZXQnKTtcblxuLyoqXG4gKiBDcmVhdGVzIGEgc3RhY2sgY2FjaGUgb2JqZWN0IHRvIHN0b3JlIGtleS12YWx1ZSBwYWlycy5cbiAqXG4gKiBAcHJpdmF0ZVxuICogQGNvbnN0cnVjdG9yXG4gKiBAcGFyYW0ge0FycmF5fSBbZW50cmllc10gVGhlIGtleS12YWx1ZSBwYWlycyB0byBjYWNoZS5cbiAqL1xuZnVuY3Rpb24gU3RhY2soZW50cmllcykge1xuICB2YXIgZGF0YSA9IHRoaXMuX19kYXRhX18gPSBuZXcgTGlzdENhY2hlKGVudHJpZXMpO1xuICB0aGlzLnNpemUgPSBkYXRhLnNpemU7XG59XG5cbi8vIEFkZCBtZXRob2RzIHRvIGBTdGFja2AuXG5TdGFjay5wcm90b3R5cGUuY2xlYXIgPSBzdGFja0NsZWFyO1xuU3RhY2sucHJvdG90eXBlWydkZWxldGUnXSA9IHN0YWNrRGVsZXRlO1xuU3RhY2sucHJvdG90eXBlLmdldCA9IHN0YWNrR2V0O1xuU3RhY2sucHJvdG90eXBlLmhhcyA9IHN0YWNrSGFzO1xuU3RhY2sucHJvdG90eXBlLnNldCA9IHN0YWNrU2V0O1xuXG5tb2R1bGUuZXhwb3J0cyA9IFN0YWNrO1xuIiwidmFyIHJvb3QgPSByZXF1aXJlKCcuL19yb290Jyk7XG5cbi8qKiBCdWlsdC1pbiB2YWx1ZSByZWZlcmVuY2VzLiAqL1xudmFyIFVpbnQ4QXJyYXkgPSByb290LlVpbnQ4QXJyYXk7XG5cbm1vZHVsZS5leHBvcnRzID0gVWludDhBcnJheTtcbiIsIi8qKlxuICogQSBmYXN0ZXIgYWx0ZXJuYXRpdmUgdG8gYEZ1bmN0aW9uI2FwcGx5YCwgdGhpcyBmdW5jdGlvbiBpbnZva2VzIGBmdW5jYFxuICogd2l0aCB0aGUgYHRoaXNgIGJpbmRpbmcgb2YgYHRoaXNBcmdgIGFuZCB0aGUgYXJndW1lbnRzIG9mIGBhcmdzYC5cbiAqXG4gKiBAcHJpdmF0ZVxuICogQHBhcmFtIHtGdW5jdGlvbn0gZnVuYyBUaGUgZnVuY3Rpb24gdG8gaW52b2tlLlxuICogQHBhcmFtIHsqfSB0aGlzQXJnIFRoZSBgdGhpc2AgYmluZGluZyBvZiBgZnVuY2AuXG4gKiBAcGFyYW0ge0FycmF5fSBhcmdzIFRoZSBhcmd1bWVudHMgdG8gaW52b2tlIGBmdW5jYCB3aXRoLlxuICogQHJldHVybnMgeyp9IFJldHVybnMgdGhlIHJlc3VsdCBvZiBgZnVuY2AuXG4gKi9cbmZ1bmN0aW9uIGFwcGx5KGZ1bmMsIHRoaXNBcmcsIGFyZ3MpIHtcbiAgc3dpdGNoIChhcmdzLmxlbmd0aCkge1xuICAgIGNhc2UgMDogcmV0dXJuIGZ1bmMuY2FsbCh0aGlzQXJnKTtcbiAgICBjYXNlIDE6IHJldHVybiBmdW5jLmNhbGwodGhpc0FyZywgYXJnc1swXSk7XG4gICAgY2FzZSAyOiByZXR1cm4gZnVuYy5jYWxsKHRoaXNBcmcsIGFyZ3NbMF0sIGFyZ3NbMV0pO1xuICAgIGNhc2UgMzogcmV0dXJuIGZ1bmMuY2FsbCh0aGlzQXJnLCBhcmdzWzBdLCBhcmdzWzFdLCBhcmdzWzJdKTtcbiAgfVxuICByZXR1cm4gZnVuYy5hcHBseSh0aGlzQXJnLCBhcmdzKTtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBhcHBseTtcbiIsInZhciBiYXNlVGltZXMgPSByZXF1aXJlKCcuL19iYXNlVGltZXMnKSxcbiAgICBpc0FyZ3VtZW50cyA9IHJlcXVpcmUoJy4vaXNBcmd1bWVudHMnKSxcbiAgICBpc0FycmF5ID0gcmVxdWlyZSgnLi9pc0FycmF5JyksXG4gICAgaXNCdWZmZXIgPSByZXF1aXJlKCcuL2lzQnVmZmVyJyksXG4gICAgaXNJbmRleCA9IHJlcXVpcmUoJy4vX2lzSW5kZXgnKSxcbiAgICBpc1R5cGVkQXJyYXkgPSByZXF1aXJlKCcuL2lzVHlwZWRBcnJheScpO1xuXG4vKiogVXNlZCBmb3IgYnVpbHQtaW4gbWV0aG9kIHJlZmVyZW5jZXMuICovXG52YXIgb2JqZWN0UHJvdG8gPSBPYmplY3QucHJvdG90eXBlO1xuXG4vKiogVXNlZCB0byBjaGVjayBvYmplY3RzIGZvciBvd24gcHJvcGVydGllcy4gKi9cbnZhciBoYXNPd25Qcm9wZXJ0eSA9IG9iamVjdFByb3RvLmhhc093blByb3BlcnR5O1xuXG4vKipcbiAqIENyZWF0ZXMgYW4gYXJyYXkgb2YgdGhlIGVudW1lcmFibGUgcHJvcGVydHkgbmFtZXMgb2YgdGhlIGFycmF5LWxpa2UgYHZhbHVlYC5cbiAqXG4gKiBAcHJpdmF0ZVxuICogQHBhcmFtIHsqfSB2YWx1ZSBUaGUgdmFsdWUgdG8gcXVlcnkuXG4gKiBAcGFyYW0ge2Jvb2xlYW59IGluaGVyaXRlZCBTcGVjaWZ5IHJldHVybmluZyBpbmhlcml0ZWQgcHJvcGVydHkgbmFtZXMuXG4gKiBAcmV0dXJucyB7QXJyYXl9IFJldHVybnMgdGhlIGFycmF5IG9mIHByb3BlcnR5IG5hbWVzLlxuICovXG5mdW5jdGlvbiBhcnJheUxpa2VLZXlzKHZhbHVlLCBpbmhlcml0ZWQpIHtcbiAgdmFyIGlzQXJyID0gaXNBcnJheSh2YWx1ZSksXG4gICAgICBpc0FyZyA9ICFpc0FyciAmJiBpc0FyZ3VtZW50cyh2YWx1ZSksXG4gICAgICBpc0J1ZmYgPSAhaXNBcnIgJiYgIWlzQXJnICYmIGlzQnVmZmVyKHZhbHVlKSxcbiAgICAgIGlzVHlwZSA9ICFpc0FyciAmJiAhaXNBcmcgJiYgIWlzQnVmZiAmJiBpc1R5cGVkQXJyYXkodmFsdWUpLFxuICAgICAgc2tpcEluZGV4ZXMgPSBpc0FyciB8fCBpc0FyZyB8fCBpc0J1ZmYgfHwgaXNUeXBlLFxuICAgICAgcmVzdWx0ID0gc2tpcEluZGV4ZXMgPyBiYXNlVGltZXModmFsdWUubGVuZ3RoLCBTdHJpbmcpIDogW10sXG4gICAgICBsZW5ndGggPSByZXN1bHQubGVuZ3RoO1xuXG4gIGZvciAodmFyIGtleSBpbiB2YWx1ZSkge1xuICAgIGlmICgoaW5oZXJpdGVkIHx8IGhhc093blByb3BlcnR5LmNhbGwodmFsdWUsIGtleSkpICYmXG4gICAgICAgICEoc2tpcEluZGV4ZXMgJiYgKFxuICAgICAgICAgICAvLyBTYWZhcmkgOSBoYXMgZW51bWVyYWJsZSBgYXJndW1lbnRzLmxlbmd0aGAgaW4gc3RyaWN0IG1vZGUuXG4gICAgICAgICAgIGtleSA9PSAnbGVuZ3RoJyB8fFxuICAgICAgICAgICAvLyBOb2RlLmpzIDAuMTAgaGFzIGVudW1lcmFibGUgbm9uLWluZGV4IHByb3BlcnRpZXMgb24gYnVmZmVycy5cbiAgICAgICAgICAgKGlzQnVmZiAmJiAoa2V5ID09ICdvZmZzZXQnIHx8IGtleSA9PSAncGFyZW50JykpIHx8XG4gICAgICAgICAgIC8vIFBoYW50b21KUyAyIGhhcyBlbnVtZXJhYmxlIG5vbi1pbmRleCBwcm9wZXJ0aWVzIG9uIHR5cGVkIGFycmF5cy5cbiAgICAgICAgICAgKGlzVHlwZSAmJiAoa2V5ID09ICdidWZmZXInIHx8IGtleSA9PSAnYnl0ZUxlbmd0aCcgfHwga2V5ID09ICdieXRlT2Zmc2V0JykpIHx8XG4gICAgICAgICAgIC8vIFNraXAgaW5kZXggcHJvcGVydGllcy5cbiAgICAgICAgICAgaXNJbmRleChrZXksIGxlbmd0aClcbiAgICAgICAgKSkpIHtcbiAgICAgIHJlc3VsdC5wdXNoKGtleSk7XG4gICAgfVxuICB9XG4gIHJldHVybiByZXN1bHQ7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gYXJyYXlMaWtlS2V5cztcbiIsInZhciBiYXNlQXNzaWduVmFsdWUgPSByZXF1aXJlKCcuL19iYXNlQXNzaWduVmFsdWUnKSxcbiAgICBlcSA9IHJlcXVpcmUoJy4vZXEnKTtcblxuLyoqXG4gKiBUaGlzIGZ1bmN0aW9uIGlzIGxpa2UgYGFzc2lnblZhbHVlYCBleGNlcHQgdGhhdCBpdCBkb2Vzbid0IGFzc2lnblxuICogYHVuZGVmaW5lZGAgdmFsdWVzLlxuICpcbiAqIEBwcml2YXRlXG4gKiBAcGFyYW0ge09iamVjdH0gb2JqZWN0IFRoZSBvYmplY3QgdG8gbW9kaWZ5LlxuICogQHBhcmFtIHtzdHJpbmd9IGtleSBUaGUga2V5IG9mIHRoZSBwcm9wZXJ0eSB0byBhc3NpZ24uXG4gKiBAcGFyYW0geyp9IHZhbHVlIFRoZSB2YWx1ZSB0byBhc3NpZ24uXG4gKi9cbmZ1bmN0aW9uIGFzc2lnbk1lcmdlVmFsdWUob2JqZWN0LCBrZXksIHZhbHVlKSB7XG4gIGlmICgodmFsdWUgIT09IHVuZGVmaW5lZCAmJiAhZXEob2JqZWN0W2tleV0sIHZhbHVlKSkgfHxcbiAgICAgICh2YWx1ZSA9PT0gdW5kZWZpbmVkICYmICEoa2V5IGluIG9iamVjdCkpKSB7XG4gICAgYmFzZUFzc2lnblZhbHVlKG9iamVjdCwga2V5LCB2YWx1ZSk7XG4gIH1cbn1cblxubW9kdWxlLmV4cG9ydHMgPSBhc3NpZ25NZXJnZVZhbHVlO1xuIiwidmFyIGlzT2JqZWN0ID0gcmVxdWlyZSgnLi9pc09iamVjdCcpO1xuXG4vKiogQnVpbHQtaW4gdmFsdWUgcmVmZXJlbmNlcy4gKi9cbnZhciBvYmplY3RDcmVhdGUgPSBPYmplY3QuY3JlYXRlO1xuXG4vKipcbiAqIFRoZSBiYXNlIGltcGxlbWVudGF0aW9uIG9mIGBfLmNyZWF0ZWAgd2l0aG91dCBzdXBwb3J0IGZvciBhc3NpZ25pbmdcbiAqIHByb3BlcnRpZXMgdG8gdGhlIGNyZWF0ZWQgb2JqZWN0LlxuICpcbiAqIEBwcml2YXRlXG4gKiBAcGFyYW0ge09iamVjdH0gcHJvdG8gVGhlIG9iamVjdCB0byBpbmhlcml0IGZyb20uXG4gKiBAcmV0dXJucyB7T2JqZWN0fSBSZXR1cm5zIHRoZSBuZXcgb2JqZWN0LlxuICovXG52YXIgYmFzZUNyZWF0ZSA9IChmdW5jdGlvbigpIHtcbiAgZnVuY3Rpb24gb2JqZWN0KCkge31cbiAgcmV0dXJuIGZ1bmN0aW9uKHByb3RvKSB7XG4gICAgaWYgKCFpc09iamVjdChwcm90bykpIHtcbiAgICAgIHJldHVybiB7fTtcbiAgICB9XG4gICAgaWYgKG9iamVjdENyZWF0ZSkge1xuICAgICAgcmV0dXJuIG9iamVjdENyZWF0ZShwcm90byk7XG4gICAgfVxuICAgIG9iamVjdC5wcm90b3R5cGUgPSBwcm90bztcbiAgICB2YXIgcmVzdWx0ID0gbmV3IG9iamVjdDtcbiAgICBvYmplY3QucHJvdG90eXBlID0gdW5kZWZpbmVkO1xuICAgIHJldHVybiByZXN1bHQ7XG4gIH07XG59KCkpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IGJhc2VDcmVhdGU7XG4iLCJ2YXIgY3JlYXRlQmFzZUZvciA9IHJlcXVpcmUoJy4vX2NyZWF0ZUJhc2VGb3InKTtcblxuLyoqXG4gKiBUaGUgYmFzZSBpbXBsZW1lbnRhdGlvbiBvZiBgYmFzZUZvck93bmAgd2hpY2ggaXRlcmF0ZXMgb3ZlciBgb2JqZWN0YFxuICogcHJvcGVydGllcyByZXR1cm5lZCBieSBga2V5c0Z1bmNgIGFuZCBpbnZva2VzIGBpdGVyYXRlZWAgZm9yIGVhY2ggcHJvcGVydHkuXG4gKiBJdGVyYXRlZSBmdW5jdGlvbnMgbWF5IGV4aXQgaXRlcmF0aW9uIGVhcmx5IGJ5IGV4cGxpY2l0bHkgcmV0dXJuaW5nIGBmYWxzZWAuXG4gKlxuICogQHByaXZhdGVcbiAqIEBwYXJhbSB7T2JqZWN0fSBvYmplY3QgVGhlIG9iamVjdCB0byBpdGVyYXRlIG92ZXIuXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBpdGVyYXRlZSBUaGUgZnVuY3Rpb24gaW52b2tlZCBwZXIgaXRlcmF0aW9uLlxuICogQHBhcmFtIHtGdW5jdGlvbn0ga2V5c0Z1bmMgVGhlIGZ1bmN0aW9uIHRvIGdldCB0aGUga2V5cyBvZiBgb2JqZWN0YC5cbiAqIEByZXR1cm5zIHtPYmplY3R9IFJldHVybnMgYG9iamVjdGAuXG4gKi9cbnZhciBiYXNlRm9yID0gY3JlYXRlQmFzZUZvcigpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IGJhc2VGb3I7XG4iLCJ2YXIgYmFzZUdldFRhZyA9IHJlcXVpcmUoJy4vX2Jhc2VHZXRUYWcnKSxcbiAgICBpc0xlbmd0aCA9IHJlcXVpcmUoJy4vaXNMZW5ndGgnKSxcbiAgICBpc09iamVjdExpa2UgPSByZXF1aXJlKCcuL2lzT2JqZWN0TGlrZScpO1xuXG4vKiogYE9iamVjdCN0b1N0cmluZ2AgcmVzdWx0IHJlZmVyZW5jZXMuICovXG52YXIgYXJnc1RhZyA9ICdbb2JqZWN0IEFyZ3VtZW50c10nLFxuICAgIGFycmF5VGFnID0gJ1tvYmplY3QgQXJyYXldJyxcbiAgICBib29sVGFnID0gJ1tvYmplY3QgQm9vbGVhbl0nLFxuICAgIGRhdGVUYWcgPSAnW29iamVjdCBEYXRlXScsXG4gICAgZXJyb3JUYWcgPSAnW29iamVjdCBFcnJvcl0nLFxuICAgIGZ1bmNUYWcgPSAnW29iamVjdCBGdW5jdGlvbl0nLFxuICAgIG1hcFRhZyA9ICdbb2JqZWN0IE1hcF0nLFxuICAgIG51bWJlclRhZyA9ICdbb2JqZWN0IE51bWJlcl0nLFxuICAgIG9iamVjdFRhZyA9ICdbb2JqZWN0IE9iamVjdF0nLFxuICAgIHJlZ2V4cFRhZyA9ICdbb2JqZWN0IFJlZ0V4cF0nLFxuICAgIHNldFRhZyA9ICdbb2JqZWN0IFNldF0nLFxuICAgIHN0cmluZ1RhZyA9ICdbb2JqZWN0IFN0cmluZ10nLFxuICAgIHdlYWtNYXBUYWcgPSAnW29iamVjdCBXZWFrTWFwXSc7XG5cbnZhciBhcnJheUJ1ZmZlclRhZyA9ICdbb2JqZWN0IEFycmF5QnVmZmVyXScsXG4gICAgZGF0YVZpZXdUYWcgPSAnW29iamVjdCBEYXRhVmlld10nLFxuICAgIGZsb2F0MzJUYWcgPSAnW29iamVjdCBGbG9hdDMyQXJyYXldJyxcbiAgICBmbG9hdDY0VGFnID0gJ1tvYmplY3QgRmxvYXQ2NEFycmF5XScsXG4gICAgaW50OFRhZyA9ICdbb2JqZWN0IEludDhBcnJheV0nLFxuICAgIGludDE2VGFnID0gJ1tvYmplY3QgSW50MTZBcnJheV0nLFxuICAgIGludDMyVGFnID0gJ1tvYmplY3QgSW50MzJBcnJheV0nLFxuICAgIHVpbnQ4VGFnID0gJ1tvYmplY3QgVWludDhBcnJheV0nLFxuICAgIHVpbnQ4Q2xhbXBlZFRhZyA9ICdbb2JqZWN0IFVpbnQ4Q2xhbXBlZEFycmF5XScsXG4gICAgdWludDE2VGFnID0gJ1tvYmplY3QgVWludDE2QXJyYXldJyxcbiAgICB1aW50MzJUYWcgPSAnW29iamVjdCBVaW50MzJBcnJheV0nO1xuXG4vKiogVXNlZCB0byBpZGVudGlmeSBgdG9TdHJpbmdUYWdgIHZhbHVlcyBvZiB0eXBlZCBhcnJheXMuICovXG52YXIgdHlwZWRBcnJheVRhZ3MgPSB7fTtcbnR5cGVkQXJyYXlUYWdzW2Zsb2F0MzJUYWddID0gdHlwZWRBcnJheVRhZ3NbZmxvYXQ2NFRhZ10gPVxudHlwZWRBcnJheVRhZ3NbaW50OFRhZ10gPSB0eXBlZEFycmF5VGFnc1tpbnQxNlRhZ10gPVxudHlwZWRBcnJheVRhZ3NbaW50MzJUYWddID0gdHlwZWRBcnJheVRhZ3NbdWludDhUYWddID1cbnR5cGVkQXJyYXlUYWdzW3VpbnQ4Q2xhbXBlZFRhZ10gPSB0eXBlZEFycmF5VGFnc1t1aW50MTZUYWddID1cbnR5cGVkQXJyYXlUYWdzW3VpbnQzMlRhZ10gPSB0cnVlO1xudHlwZWRBcnJheVRhZ3NbYXJnc1RhZ10gPSB0eXBlZEFycmF5VGFnc1thcnJheVRhZ10gPVxudHlwZWRBcnJheVRhZ3NbYXJyYXlCdWZmZXJUYWddID0gdHlwZWRBcnJheVRhZ3NbYm9vbFRhZ10gPVxudHlwZWRBcnJheVRhZ3NbZGF0YVZpZXdUYWddID0gdHlwZWRBcnJheVRhZ3NbZGF0ZVRhZ10gPVxudHlwZWRBcnJheVRhZ3NbZXJyb3JUYWddID0gdHlwZWRBcnJheVRhZ3NbZnVuY1RhZ10gPVxudHlwZWRBcnJheVRhZ3NbbWFwVGFnXSA9IHR5cGVkQXJyYXlUYWdzW251bWJlclRhZ10gPVxudHlwZWRBcnJheVRhZ3Nbb2JqZWN0VGFnXSA9IHR5cGVkQXJyYXlUYWdzW3JlZ2V4cFRhZ10gPVxudHlwZWRBcnJheVRhZ3Nbc2V0VGFnXSA9IHR5cGVkQXJyYXlUYWdzW3N0cmluZ1RhZ10gPVxudHlwZWRBcnJheVRhZ3Nbd2Vha01hcFRhZ10gPSBmYWxzZTtcblxuLyoqXG4gKiBUaGUgYmFzZSBpbXBsZW1lbnRhdGlvbiBvZiBgXy5pc1R5cGVkQXJyYXlgIHdpdGhvdXQgTm9kZS5qcyBvcHRpbWl6YXRpb25zLlxuICpcbiAqIEBwcml2YXRlXG4gKiBAcGFyYW0geyp9IHZhbHVlIFRoZSB2YWx1ZSB0byBjaGVjay5cbiAqIEByZXR1cm5zIHtib29sZWFufSBSZXR1cm5zIGB0cnVlYCBpZiBgdmFsdWVgIGlzIGEgdHlwZWQgYXJyYXksIGVsc2UgYGZhbHNlYC5cbiAqL1xuZnVuY3Rpb24gYmFzZUlzVHlwZWRBcnJheSh2YWx1ZSkge1xuICByZXR1cm4gaXNPYmplY3RMaWtlKHZhbHVlKSAmJlxuICAgIGlzTGVuZ3RoKHZhbHVlLmxlbmd0aCkgJiYgISF0eXBlZEFycmF5VGFnc1tiYXNlR2V0VGFnKHZhbHVlKV07XG59XG5cbm1vZHVsZS5leHBvcnRzID0gYmFzZUlzVHlwZWRBcnJheTtcbiIsInZhciBpc09iamVjdCA9IHJlcXVpcmUoJy4vaXNPYmplY3QnKSxcbiAgICBpc1Byb3RvdHlwZSA9IHJlcXVpcmUoJy4vX2lzUHJvdG90eXBlJyksXG4gICAgbmF0aXZlS2V5c0luID0gcmVxdWlyZSgnLi9fbmF0aXZlS2V5c0luJyk7XG5cbi8qKiBVc2VkIGZvciBidWlsdC1pbiBtZXRob2QgcmVmZXJlbmNlcy4gKi9cbnZhciBvYmplY3RQcm90byA9IE9iamVjdC5wcm90b3R5cGU7XG5cbi8qKiBVc2VkIHRvIGNoZWNrIG9iamVjdHMgZm9yIG93biBwcm9wZXJ0aWVzLiAqL1xudmFyIGhhc093blByb3BlcnR5ID0gb2JqZWN0UHJvdG8uaGFzT3duUHJvcGVydHk7XG5cbi8qKlxuICogVGhlIGJhc2UgaW1wbGVtZW50YXRpb24gb2YgYF8ua2V5c0luYCB3aGljaCBkb2Vzbid0IHRyZWF0IHNwYXJzZSBhcnJheXMgYXMgZGVuc2UuXG4gKlxuICogQHByaXZhdGVcbiAqIEBwYXJhbSB7T2JqZWN0fSBvYmplY3QgVGhlIG9iamVjdCB0byBxdWVyeS5cbiAqIEByZXR1cm5zIHtBcnJheX0gUmV0dXJucyB0aGUgYXJyYXkgb2YgcHJvcGVydHkgbmFtZXMuXG4gKi9cbmZ1bmN0aW9uIGJhc2VLZXlzSW4ob2JqZWN0KSB7XG4gIGlmICghaXNPYmplY3Qob2JqZWN0KSkge1xuICAgIHJldHVybiBuYXRpdmVLZXlzSW4ob2JqZWN0KTtcbiAgfVxuICB2YXIgaXNQcm90byA9IGlzUHJvdG90eXBlKG9iamVjdCksXG4gICAgICByZXN1bHQgPSBbXTtcblxuICBmb3IgKHZhciBrZXkgaW4gb2JqZWN0KSB7XG4gICAgaWYgKCEoa2V5ID09ICdjb25zdHJ1Y3RvcicgJiYgKGlzUHJvdG8gfHwgIWhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBrZXkpKSkpIHtcbiAgICAgIHJlc3VsdC5wdXNoKGtleSk7XG4gICAgfVxuICB9XG4gIHJldHVybiByZXN1bHQ7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gYmFzZUtleXNJbjtcbiIsInZhciBTdGFjayA9IHJlcXVpcmUoJy4vX1N0YWNrJyksXG4gICAgYXNzaWduTWVyZ2VWYWx1ZSA9IHJlcXVpcmUoJy4vX2Fzc2lnbk1lcmdlVmFsdWUnKSxcbiAgICBiYXNlRm9yID0gcmVxdWlyZSgnLi9fYmFzZUZvcicpLFxuICAgIGJhc2VNZXJnZURlZXAgPSByZXF1aXJlKCcuL19iYXNlTWVyZ2VEZWVwJyksXG4gICAgaXNPYmplY3QgPSByZXF1aXJlKCcuL2lzT2JqZWN0JyksXG4gICAga2V5c0luID0gcmVxdWlyZSgnLi9rZXlzSW4nKSxcbiAgICBzYWZlR2V0ID0gcmVxdWlyZSgnLi9fc2FmZUdldCcpO1xuXG4vKipcbiAqIFRoZSBiYXNlIGltcGxlbWVudGF0aW9uIG9mIGBfLm1lcmdlYCB3aXRob3V0IHN1cHBvcnQgZm9yIG11bHRpcGxlIHNvdXJjZXMuXG4gKlxuICogQHByaXZhdGVcbiAqIEBwYXJhbSB7T2JqZWN0fSBvYmplY3QgVGhlIGRlc3RpbmF0aW9uIG9iamVjdC5cbiAqIEBwYXJhbSB7T2JqZWN0fSBzb3VyY2UgVGhlIHNvdXJjZSBvYmplY3QuXG4gKiBAcGFyYW0ge251bWJlcn0gc3JjSW5kZXggVGhlIGluZGV4IG9mIGBzb3VyY2VgLlxuICogQHBhcmFtIHtGdW5jdGlvbn0gW2N1c3RvbWl6ZXJdIFRoZSBmdW5jdGlvbiB0byBjdXN0b21pemUgbWVyZ2VkIHZhbHVlcy5cbiAqIEBwYXJhbSB7T2JqZWN0fSBbc3RhY2tdIFRyYWNrcyB0cmF2ZXJzZWQgc291cmNlIHZhbHVlcyBhbmQgdGhlaXIgbWVyZ2VkXG4gKiAgY291bnRlcnBhcnRzLlxuICovXG5mdW5jdGlvbiBiYXNlTWVyZ2Uob2JqZWN0LCBzb3VyY2UsIHNyY0luZGV4LCBjdXN0b21pemVyLCBzdGFjaykge1xuICBpZiAob2JqZWN0ID09PSBzb3VyY2UpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgYmFzZUZvcihzb3VyY2UsIGZ1bmN0aW9uKHNyY1ZhbHVlLCBrZXkpIHtcbiAgICBpZiAoaXNPYmplY3Qoc3JjVmFsdWUpKSB7XG4gICAgICBzdGFjayB8fCAoc3RhY2sgPSBuZXcgU3RhY2spO1xuICAgICAgYmFzZU1lcmdlRGVlcChvYmplY3QsIHNvdXJjZSwga2V5LCBzcmNJbmRleCwgYmFzZU1lcmdlLCBjdXN0b21pemVyLCBzdGFjayk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgdmFyIG5ld1ZhbHVlID0gY3VzdG9taXplclxuICAgICAgICA/IGN1c3RvbWl6ZXIoc2FmZUdldChvYmplY3QsIGtleSksIHNyY1ZhbHVlLCAoa2V5ICsgJycpLCBvYmplY3QsIHNvdXJjZSwgc3RhY2spXG4gICAgICAgIDogdW5kZWZpbmVkO1xuXG4gICAgICBpZiAobmV3VmFsdWUgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICBuZXdWYWx1ZSA9IHNyY1ZhbHVlO1xuICAgICAgfVxuICAgICAgYXNzaWduTWVyZ2VWYWx1ZShvYmplY3QsIGtleSwgbmV3VmFsdWUpO1xuICAgIH1cbiAgfSwga2V5c0luKTtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBiYXNlTWVyZ2U7XG4iLCJ2YXIgYXNzaWduTWVyZ2VWYWx1ZSA9IHJlcXVpcmUoJy4vX2Fzc2lnbk1lcmdlVmFsdWUnKSxcbiAgICBjbG9uZUJ1ZmZlciA9IHJlcXVpcmUoJy4vX2Nsb25lQnVmZmVyJyksXG4gICAgY2xvbmVUeXBlZEFycmF5ID0gcmVxdWlyZSgnLi9fY2xvbmVUeXBlZEFycmF5JyksXG4gICAgY29weUFycmF5ID0gcmVxdWlyZSgnLi9fY29weUFycmF5JyksXG4gICAgaW5pdENsb25lT2JqZWN0ID0gcmVxdWlyZSgnLi9faW5pdENsb25lT2JqZWN0JyksXG4gICAgaXNBcmd1bWVudHMgPSByZXF1aXJlKCcuL2lzQXJndW1lbnRzJyksXG4gICAgaXNBcnJheSA9IHJlcXVpcmUoJy4vaXNBcnJheScpLFxuICAgIGlzQXJyYXlMaWtlT2JqZWN0ID0gcmVxdWlyZSgnLi9pc0FycmF5TGlrZU9iamVjdCcpLFxuICAgIGlzQnVmZmVyID0gcmVxdWlyZSgnLi9pc0J1ZmZlcicpLFxuICAgIGlzRnVuY3Rpb24gPSByZXF1aXJlKCcuL2lzRnVuY3Rpb24nKSxcbiAgICBpc09iamVjdCA9IHJlcXVpcmUoJy4vaXNPYmplY3QnKSxcbiAgICBpc1BsYWluT2JqZWN0ID0gcmVxdWlyZSgnLi9pc1BsYWluT2JqZWN0JyksXG4gICAgaXNUeXBlZEFycmF5ID0gcmVxdWlyZSgnLi9pc1R5cGVkQXJyYXknKSxcbiAgICBzYWZlR2V0ID0gcmVxdWlyZSgnLi9fc2FmZUdldCcpLFxuICAgIHRvUGxhaW5PYmplY3QgPSByZXF1aXJlKCcuL3RvUGxhaW5PYmplY3QnKTtcblxuLyoqXG4gKiBBIHNwZWNpYWxpemVkIHZlcnNpb24gb2YgYGJhc2VNZXJnZWAgZm9yIGFycmF5cyBhbmQgb2JqZWN0cyB3aGljaCBwZXJmb3Jtc1xuICogZGVlcCBtZXJnZXMgYW5kIHRyYWNrcyB0cmF2ZXJzZWQgb2JqZWN0cyBlbmFibGluZyBvYmplY3RzIHdpdGggY2lyY3VsYXJcbiAqIHJlZmVyZW5jZXMgdG8gYmUgbWVyZ2VkLlxuICpcbiAqIEBwcml2YXRlXG4gKiBAcGFyYW0ge09iamVjdH0gb2JqZWN0IFRoZSBkZXN0aW5hdGlvbiBvYmplY3QuXG4gKiBAcGFyYW0ge09iamVjdH0gc291cmNlIFRoZSBzb3VyY2Ugb2JqZWN0LlxuICogQHBhcmFtIHtzdHJpbmd9IGtleSBUaGUga2V5IG9mIHRoZSB2YWx1ZSB0byBtZXJnZS5cbiAqIEBwYXJhbSB7bnVtYmVyfSBzcmNJbmRleCBUaGUgaW5kZXggb2YgYHNvdXJjZWAuXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBtZXJnZUZ1bmMgVGhlIGZ1bmN0aW9uIHRvIG1lcmdlIHZhbHVlcy5cbiAqIEBwYXJhbSB7RnVuY3Rpb259IFtjdXN0b21pemVyXSBUaGUgZnVuY3Rpb24gdG8gY3VzdG9taXplIGFzc2lnbmVkIHZhbHVlcy5cbiAqIEBwYXJhbSB7T2JqZWN0fSBbc3RhY2tdIFRyYWNrcyB0cmF2ZXJzZWQgc291cmNlIHZhbHVlcyBhbmQgdGhlaXIgbWVyZ2VkXG4gKiAgY291bnRlcnBhcnRzLlxuICovXG5mdW5jdGlvbiBiYXNlTWVyZ2VEZWVwKG9iamVjdCwgc291cmNlLCBrZXksIHNyY0luZGV4LCBtZXJnZUZ1bmMsIGN1c3RvbWl6ZXIsIHN0YWNrKSB7XG4gIHZhciBvYmpWYWx1ZSA9IHNhZmVHZXQob2JqZWN0LCBrZXkpLFxuICAgICAgc3JjVmFsdWUgPSBzYWZlR2V0KHNvdXJjZSwga2V5KSxcbiAgICAgIHN0YWNrZWQgPSBzdGFjay5nZXQoc3JjVmFsdWUpO1xuXG4gIGlmIChzdGFja2VkKSB7XG4gICAgYXNzaWduTWVyZ2VWYWx1ZShvYmplY3QsIGtleSwgc3RhY2tlZCk7XG4gICAgcmV0dXJuO1xuICB9XG4gIHZhciBuZXdWYWx1ZSA9IGN1c3RvbWl6ZXJcbiAgICA/IGN1c3RvbWl6ZXIob2JqVmFsdWUsIHNyY1ZhbHVlLCAoa2V5ICsgJycpLCBvYmplY3QsIHNvdXJjZSwgc3RhY2spXG4gICAgOiB1bmRlZmluZWQ7XG5cbiAgdmFyIGlzQ29tbW9uID0gbmV3VmFsdWUgPT09IHVuZGVmaW5lZDtcblxuICBpZiAoaXNDb21tb24pIHtcbiAgICB2YXIgaXNBcnIgPSBpc0FycmF5KHNyY1ZhbHVlKSxcbiAgICAgICAgaXNCdWZmID0gIWlzQXJyICYmIGlzQnVmZmVyKHNyY1ZhbHVlKSxcbiAgICAgICAgaXNUeXBlZCA9ICFpc0FyciAmJiAhaXNCdWZmICYmIGlzVHlwZWRBcnJheShzcmNWYWx1ZSk7XG5cbiAgICBuZXdWYWx1ZSA9IHNyY1ZhbHVlO1xuICAgIGlmIChpc0FyciB8fCBpc0J1ZmYgfHwgaXNUeXBlZCkge1xuICAgICAgaWYgKGlzQXJyYXkob2JqVmFsdWUpKSB7XG4gICAgICAgIG5ld1ZhbHVlID0gb2JqVmFsdWU7XG4gICAgICB9XG4gICAgICBlbHNlIGlmIChpc0FycmF5TGlrZU9iamVjdChvYmpWYWx1ZSkpIHtcbiAgICAgICAgbmV3VmFsdWUgPSBjb3B5QXJyYXkob2JqVmFsdWUpO1xuICAgICAgfVxuICAgICAgZWxzZSBpZiAoaXNCdWZmKSB7XG4gICAgICAgIGlzQ29tbW9uID0gZmFsc2U7XG4gICAgICAgIG5ld1ZhbHVlID0gY2xvbmVCdWZmZXIoc3JjVmFsdWUsIHRydWUpO1xuICAgICAgfVxuICAgICAgZWxzZSBpZiAoaXNUeXBlZCkge1xuICAgICAgICBpc0NvbW1vbiA9IGZhbHNlO1xuICAgICAgICBuZXdWYWx1ZSA9IGNsb25lVHlwZWRBcnJheShzcmNWYWx1ZSwgdHJ1ZSk7XG4gICAgICB9XG4gICAgICBlbHNlIHtcbiAgICAgICAgbmV3VmFsdWUgPSBbXTtcbiAgICAgIH1cbiAgICB9XG4gICAgZWxzZSBpZiAoaXNQbGFpbk9iamVjdChzcmNWYWx1ZSkgfHwgaXNBcmd1bWVudHMoc3JjVmFsdWUpKSB7XG4gICAgICBuZXdWYWx1ZSA9IG9ialZhbHVlO1xuICAgICAgaWYgKGlzQXJndW1lbnRzKG9ialZhbHVlKSkge1xuICAgICAgICBuZXdWYWx1ZSA9IHRvUGxhaW5PYmplY3Qob2JqVmFsdWUpO1xuICAgICAgfVxuICAgICAgZWxzZSBpZiAoIWlzT2JqZWN0KG9ialZhbHVlKSB8fCAoc3JjSW5kZXggJiYgaXNGdW5jdGlvbihvYmpWYWx1ZSkpKSB7XG4gICAgICAgIG5ld1ZhbHVlID0gaW5pdENsb25lT2JqZWN0KHNyY1ZhbHVlKTtcbiAgICAgIH1cbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICBpc0NvbW1vbiA9IGZhbHNlO1xuICAgIH1cbiAgfVxuICBpZiAoaXNDb21tb24pIHtcbiAgICAvLyBSZWN1cnNpdmVseSBtZXJnZSBvYmplY3RzIGFuZCBhcnJheXMgKHN1c2NlcHRpYmxlIHRvIGNhbGwgc3RhY2sgbGltaXRzKS5cbiAgICBzdGFjay5zZXQoc3JjVmFsdWUsIG5ld1ZhbHVlKTtcbiAgICBtZXJnZUZ1bmMobmV3VmFsdWUsIHNyY1ZhbHVlLCBzcmNJbmRleCwgY3VzdG9taXplciwgc3RhY2spO1xuICAgIHN0YWNrWydkZWxldGUnXShzcmNWYWx1ZSk7XG4gIH1cbiAgYXNzaWduTWVyZ2VWYWx1ZShvYmplY3QsIGtleSwgbmV3VmFsdWUpO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IGJhc2VNZXJnZURlZXA7XG4iLCJ2YXIgaWRlbnRpdHkgPSByZXF1aXJlKCcuL2lkZW50aXR5JyksXG4gICAgb3ZlclJlc3QgPSByZXF1aXJlKCcuL19vdmVyUmVzdCcpLFxuICAgIHNldFRvU3RyaW5nID0gcmVxdWlyZSgnLi9fc2V0VG9TdHJpbmcnKTtcblxuLyoqXG4gKiBUaGUgYmFzZSBpbXBsZW1lbnRhdGlvbiBvZiBgXy5yZXN0YCB3aGljaCBkb2Vzbid0IHZhbGlkYXRlIG9yIGNvZXJjZSBhcmd1bWVudHMuXG4gKlxuICogQHByaXZhdGVcbiAqIEBwYXJhbSB7RnVuY3Rpb259IGZ1bmMgVGhlIGZ1bmN0aW9uIHRvIGFwcGx5IGEgcmVzdCBwYXJhbWV0ZXIgdG8uXG4gKiBAcGFyYW0ge251bWJlcn0gW3N0YXJ0PWZ1bmMubGVuZ3RoLTFdIFRoZSBzdGFydCBwb3NpdGlvbiBvZiB0aGUgcmVzdCBwYXJhbWV0ZXIuXG4gKiBAcmV0dXJucyB7RnVuY3Rpb259IFJldHVybnMgdGhlIG5ldyBmdW5jdGlvbi5cbiAqL1xuZnVuY3Rpb24gYmFzZVJlc3QoZnVuYywgc3RhcnQpIHtcbiAgcmV0dXJuIHNldFRvU3RyaW5nKG92ZXJSZXN0KGZ1bmMsIHN0YXJ0LCBpZGVudGl0eSksIGZ1bmMgKyAnJyk7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gYmFzZVJlc3Q7XG4iLCJ2YXIgY29uc3RhbnQgPSByZXF1aXJlKCcuL2NvbnN0YW50JyksXG4gICAgZGVmaW5lUHJvcGVydHkgPSByZXF1aXJlKCcuL19kZWZpbmVQcm9wZXJ0eScpLFxuICAgIGlkZW50aXR5ID0gcmVxdWlyZSgnLi9pZGVudGl0eScpO1xuXG4vKipcbiAqIFRoZSBiYXNlIGltcGxlbWVudGF0aW9uIG9mIGBzZXRUb1N0cmluZ2Agd2l0aG91dCBzdXBwb3J0IGZvciBob3QgbG9vcCBzaG9ydGluZy5cbiAqXG4gKiBAcHJpdmF0ZVxuICogQHBhcmFtIHtGdW5jdGlvbn0gZnVuYyBUaGUgZnVuY3Rpb24gdG8gbW9kaWZ5LlxuICogQHBhcmFtIHtGdW5jdGlvbn0gc3RyaW5nIFRoZSBgdG9TdHJpbmdgIHJlc3VsdC5cbiAqIEByZXR1cm5zIHtGdW5jdGlvbn0gUmV0dXJucyBgZnVuY2AuXG4gKi9cbnZhciBiYXNlU2V0VG9TdHJpbmcgPSAhZGVmaW5lUHJvcGVydHkgPyBpZGVudGl0eSA6IGZ1bmN0aW9uKGZ1bmMsIHN0cmluZykge1xuICByZXR1cm4gZGVmaW5lUHJvcGVydHkoZnVuYywgJ3RvU3RyaW5nJywge1xuICAgICdjb25maWd1cmFibGUnOiB0cnVlLFxuICAgICdlbnVtZXJhYmxlJzogZmFsc2UsXG4gICAgJ3ZhbHVlJzogY29uc3RhbnQoc3RyaW5nKSxcbiAgICAnd3JpdGFibGUnOiB0cnVlXG4gIH0pO1xufTtcblxubW9kdWxlLmV4cG9ydHMgPSBiYXNlU2V0VG9TdHJpbmc7XG4iLCIvKipcbiAqIFRoZSBiYXNlIGltcGxlbWVudGF0aW9uIG9mIGBfLnRpbWVzYCB3aXRob3V0IHN1cHBvcnQgZm9yIGl0ZXJhdGVlIHNob3J0aGFuZHNcbiAqIG9yIG1heCBhcnJheSBsZW5ndGggY2hlY2tzLlxuICpcbiAqIEBwcml2YXRlXG4gKiBAcGFyYW0ge251bWJlcn0gbiBUaGUgbnVtYmVyIG9mIHRpbWVzIHRvIGludm9rZSBgaXRlcmF0ZWVgLlxuICogQHBhcmFtIHtGdW5jdGlvbn0gaXRlcmF0ZWUgVGhlIGZ1bmN0aW9uIGludm9rZWQgcGVyIGl0ZXJhdGlvbi5cbiAqIEByZXR1cm5zIHtBcnJheX0gUmV0dXJucyB0aGUgYXJyYXkgb2YgcmVzdWx0cy5cbiAqL1xuZnVuY3Rpb24gYmFzZVRpbWVzKG4sIGl0ZXJhdGVlKSB7XG4gIHZhciBpbmRleCA9IC0xLFxuICAgICAgcmVzdWx0ID0gQXJyYXkobik7XG5cbiAgd2hpbGUgKCsraW5kZXggPCBuKSB7XG4gICAgcmVzdWx0W2luZGV4XSA9IGl0ZXJhdGVlKGluZGV4KTtcbiAgfVxuICByZXR1cm4gcmVzdWx0O1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IGJhc2VUaW1lcztcbiIsIi8qKlxuICogVGhlIGJhc2UgaW1wbGVtZW50YXRpb24gb2YgYF8udW5hcnlgIHdpdGhvdXQgc3VwcG9ydCBmb3Igc3RvcmluZyBtZXRhZGF0YS5cbiAqXG4gKiBAcHJpdmF0ZVxuICogQHBhcmFtIHtGdW5jdGlvbn0gZnVuYyBUaGUgZnVuY3Rpb24gdG8gY2FwIGFyZ3VtZW50cyBmb3IuXG4gKiBAcmV0dXJucyB7RnVuY3Rpb259IFJldHVybnMgdGhlIG5ldyBjYXBwZWQgZnVuY3Rpb24uXG4gKi9cbmZ1bmN0aW9uIGJhc2VVbmFyeShmdW5jKSB7XG4gIHJldHVybiBmdW5jdGlvbih2YWx1ZSkge1xuICAgIHJldHVybiBmdW5jKHZhbHVlKTtcbiAgfTtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBiYXNlVW5hcnk7XG4iLCJ2YXIgVWludDhBcnJheSA9IHJlcXVpcmUoJy4vX1VpbnQ4QXJyYXknKTtcblxuLyoqXG4gKiBDcmVhdGVzIGEgY2xvbmUgb2YgYGFycmF5QnVmZmVyYC5cbiAqXG4gKiBAcHJpdmF0ZVxuICogQHBhcmFtIHtBcnJheUJ1ZmZlcn0gYXJyYXlCdWZmZXIgVGhlIGFycmF5IGJ1ZmZlciB0byBjbG9uZS5cbiAqIEByZXR1cm5zIHtBcnJheUJ1ZmZlcn0gUmV0dXJucyB0aGUgY2xvbmVkIGFycmF5IGJ1ZmZlci5cbiAqL1xuZnVuY3Rpb24gY2xvbmVBcnJheUJ1ZmZlcihhcnJheUJ1ZmZlcikge1xuICB2YXIgcmVzdWx0ID0gbmV3IGFycmF5QnVmZmVyLmNvbnN0cnVjdG9yKGFycmF5QnVmZmVyLmJ5dGVMZW5ndGgpO1xuICBuZXcgVWludDhBcnJheShyZXN1bHQpLnNldChuZXcgVWludDhBcnJheShhcnJheUJ1ZmZlcikpO1xuICByZXR1cm4gcmVzdWx0O1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IGNsb25lQXJyYXlCdWZmZXI7XG4iLCJ2YXIgcm9vdCA9IHJlcXVpcmUoJy4vX3Jvb3QnKTtcblxuLyoqIERldGVjdCBmcmVlIHZhcmlhYmxlIGBleHBvcnRzYC4gKi9cbnZhciBmcmVlRXhwb3J0cyA9IHR5cGVvZiBleHBvcnRzID09ICdvYmplY3QnICYmIGV4cG9ydHMgJiYgIWV4cG9ydHMubm9kZVR5cGUgJiYgZXhwb3J0cztcblxuLyoqIERldGVjdCBmcmVlIHZhcmlhYmxlIGBtb2R1bGVgLiAqL1xudmFyIGZyZWVNb2R1bGUgPSBmcmVlRXhwb3J0cyAmJiB0eXBlb2YgbW9kdWxlID09ICdvYmplY3QnICYmIG1vZHVsZSAmJiAhbW9kdWxlLm5vZGVUeXBlICYmIG1vZHVsZTtcblxuLyoqIERldGVjdCB0aGUgcG9wdWxhciBDb21tb25KUyBleHRlbnNpb24gYG1vZHVsZS5leHBvcnRzYC4gKi9cbnZhciBtb2R1bGVFeHBvcnRzID0gZnJlZU1vZHVsZSAmJiBmcmVlTW9kdWxlLmV4cG9ydHMgPT09IGZyZWVFeHBvcnRzO1xuXG4vKiogQnVpbHQtaW4gdmFsdWUgcmVmZXJlbmNlcy4gKi9cbnZhciBCdWZmZXIgPSBtb2R1bGVFeHBvcnRzID8gcm9vdC5CdWZmZXIgOiB1bmRlZmluZWQsXG4gICAgYWxsb2NVbnNhZmUgPSBCdWZmZXIgPyBCdWZmZXIuYWxsb2NVbnNhZmUgOiB1bmRlZmluZWQ7XG5cbi8qKlxuICogQ3JlYXRlcyBhIGNsb25lIG9mICBgYnVmZmVyYC5cbiAqXG4gKiBAcHJpdmF0ZVxuICogQHBhcmFtIHtCdWZmZXJ9IGJ1ZmZlciBUaGUgYnVmZmVyIHRvIGNsb25lLlxuICogQHBhcmFtIHtib29sZWFufSBbaXNEZWVwXSBTcGVjaWZ5IGEgZGVlcCBjbG9uZS5cbiAqIEByZXR1cm5zIHtCdWZmZXJ9IFJldHVybnMgdGhlIGNsb25lZCBidWZmZXIuXG4gKi9cbmZ1bmN0aW9uIGNsb25lQnVmZmVyKGJ1ZmZlciwgaXNEZWVwKSB7XG4gIGlmIChpc0RlZXApIHtcbiAgICByZXR1cm4gYnVmZmVyLnNsaWNlKCk7XG4gIH1cbiAgdmFyIGxlbmd0aCA9IGJ1ZmZlci5sZW5ndGgsXG4gICAgICByZXN1bHQgPSBhbGxvY1Vuc2FmZSA/IGFsbG9jVW5zYWZlKGxlbmd0aCkgOiBuZXcgYnVmZmVyLmNvbnN0cnVjdG9yKGxlbmd0aCk7XG5cbiAgYnVmZmVyLmNvcHkocmVzdWx0KTtcbiAgcmV0dXJuIHJlc3VsdDtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBjbG9uZUJ1ZmZlcjtcbiIsInZhciBjbG9uZUFycmF5QnVmZmVyID0gcmVxdWlyZSgnLi9fY2xvbmVBcnJheUJ1ZmZlcicpO1xuXG4vKipcbiAqIENyZWF0ZXMgYSBjbG9uZSBvZiBgdHlwZWRBcnJheWAuXG4gKlxuICogQHByaXZhdGVcbiAqIEBwYXJhbSB7T2JqZWN0fSB0eXBlZEFycmF5IFRoZSB0eXBlZCBhcnJheSB0byBjbG9uZS5cbiAqIEBwYXJhbSB7Ym9vbGVhbn0gW2lzRGVlcF0gU3BlY2lmeSBhIGRlZXAgY2xvbmUuXG4gKiBAcmV0dXJucyB7T2JqZWN0fSBSZXR1cm5zIHRoZSBjbG9uZWQgdHlwZWQgYXJyYXkuXG4gKi9cbmZ1bmN0aW9uIGNsb25lVHlwZWRBcnJheSh0eXBlZEFycmF5LCBpc0RlZXApIHtcbiAgdmFyIGJ1ZmZlciA9IGlzRGVlcCA/IGNsb25lQXJyYXlCdWZmZXIodHlwZWRBcnJheS5idWZmZXIpIDogdHlwZWRBcnJheS5idWZmZXI7XG4gIHJldHVybiBuZXcgdHlwZWRBcnJheS5jb25zdHJ1Y3RvcihidWZmZXIsIHR5cGVkQXJyYXkuYnl0ZU9mZnNldCwgdHlwZWRBcnJheS5sZW5ndGgpO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IGNsb25lVHlwZWRBcnJheTtcbiIsIi8qKlxuICogQ29waWVzIHRoZSB2YWx1ZXMgb2YgYHNvdXJjZWAgdG8gYGFycmF5YC5cbiAqXG4gKiBAcHJpdmF0ZVxuICogQHBhcmFtIHtBcnJheX0gc291cmNlIFRoZSBhcnJheSB0byBjb3B5IHZhbHVlcyBmcm9tLlxuICogQHBhcmFtIHtBcnJheX0gW2FycmF5PVtdXSBUaGUgYXJyYXkgdG8gY29weSB2YWx1ZXMgdG8uXG4gKiBAcmV0dXJucyB7QXJyYXl9IFJldHVybnMgYGFycmF5YC5cbiAqL1xuZnVuY3Rpb24gY29weUFycmF5KHNvdXJjZSwgYXJyYXkpIHtcbiAgdmFyIGluZGV4ID0gLTEsXG4gICAgICBsZW5ndGggPSBzb3VyY2UubGVuZ3RoO1xuXG4gIGFycmF5IHx8IChhcnJheSA9IEFycmF5KGxlbmd0aCkpO1xuICB3aGlsZSAoKytpbmRleCA8IGxlbmd0aCkge1xuICAgIGFycmF5W2luZGV4XSA9IHNvdXJjZVtpbmRleF07XG4gIH1cbiAgcmV0dXJuIGFycmF5O1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IGNvcHlBcnJheTtcbiIsInZhciBhc3NpZ25WYWx1ZSA9IHJlcXVpcmUoJy4vX2Fzc2lnblZhbHVlJyksXG4gICAgYmFzZUFzc2lnblZhbHVlID0gcmVxdWlyZSgnLi9fYmFzZUFzc2lnblZhbHVlJyk7XG5cbi8qKlxuICogQ29waWVzIHByb3BlcnRpZXMgb2YgYHNvdXJjZWAgdG8gYG9iamVjdGAuXG4gKlxuICogQHByaXZhdGVcbiAqIEBwYXJhbSB7T2JqZWN0fSBzb3VyY2UgVGhlIG9iamVjdCB0byBjb3B5IHByb3BlcnRpZXMgZnJvbS5cbiAqIEBwYXJhbSB7QXJyYXl9IHByb3BzIFRoZSBwcm9wZXJ0eSBpZGVudGlmaWVycyB0byBjb3B5LlxuICogQHBhcmFtIHtPYmplY3R9IFtvYmplY3Q9e31dIFRoZSBvYmplY3QgdG8gY29weSBwcm9wZXJ0aWVzIHRvLlxuICogQHBhcmFtIHtGdW5jdGlvbn0gW2N1c3RvbWl6ZXJdIFRoZSBmdW5jdGlvbiB0byBjdXN0b21pemUgY29waWVkIHZhbHVlcy5cbiAqIEByZXR1cm5zIHtPYmplY3R9IFJldHVybnMgYG9iamVjdGAuXG4gKi9cbmZ1bmN0aW9uIGNvcHlPYmplY3Qoc291cmNlLCBwcm9wcywgb2JqZWN0LCBjdXN0b21pemVyKSB7XG4gIHZhciBpc05ldyA9ICFvYmplY3Q7XG4gIG9iamVjdCB8fCAob2JqZWN0ID0ge30pO1xuXG4gIHZhciBpbmRleCA9IC0xLFxuICAgICAgbGVuZ3RoID0gcHJvcHMubGVuZ3RoO1xuXG4gIHdoaWxlICgrK2luZGV4IDwgbGVuZ3RoKSB7XG4gICAgdmFyIGtleSA9IHByb3BzW2luZGV4XTtcblxuICAgIHZhciBuZXdWYWx1ZSA9IGN1c3RvbWl6ZXJcbiAgICAgID8gY3VzdG9taXplcihvYmplY3Rba2V5XSwgc291cmNlW2tleV0sIGtleSwgb2JqZWN0LCBzb3VyY2UpXG4gICAgICA6IHVuZGVmaW5lZDtcblxuICAgIGlmIChuZXdWYWx1ZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICBuZXdWYWx1ZSA9IHNvdXJjZVtrZXldO1xuICAgIH1cbiAgICBpZiAoaXNOZXcpIHtcbiAgICAgIGJhc2VBc3NpZ25WYWx1ZShvYmplY3QsIGtleSwgbmV3VmFsdWUpO1xuICAgIH0gZWxzZSB7XG4gICAgICBhc3NpZ25WYWx1ZShvYmplY3QsIGtleSwgbmV3VmFsdWUpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gb2JqZWN0O1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IGNvcHlPYmplY3Q7XG4iLCJ2YXIgYmFzZVJlc3QgPSByZXF1aXJlKCcuL19iYXNlUmVzdCcpLFxuICAgIGlzSXRlcmF0ZWVDYWxsID0gcmVxdWlyZSgnLi9faXNJdGVyYXRlZUNhbGwnKTtcblxuLyoqXG4gKiBDcmVhdGVzIGEgZnVuY3Rpb24gbGlrZSBgXy5hc3NpZ25gLlxuICpcbiAqIEBwcml2YXRlXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBhc3NpZ25lciBUaGUgZnVuY3Rpb24gdG8gYXNzaWduIHZhbHVlcy5cbiAqIEByZXR1cm5zIHtGdW5jdGlvbn0gUmV0dXJucyB0aGUgbmV3IGFzc2lnbmVyIGZ1bmN0aW9uLlxuICovXG5mdW5jdGlvbiBjcmVhdGVBc3NpZ25lcihhc3NpZ25lcikge1xuICByZXR1cm4gYmFzZVJlc3QoZnVuY3Rpb24ob2JqZWN0LCBzb3VyY2VzKSB7XG4gICAgdmFyIGluZGV4ID0gLTEsXG4gICAgICAgIGxlbmd0aCA9IHNvdXJjZXMubGVuZ3RoLFxuICAgICAgICBjdXN0b21pemVyID0gbGVuZ3RoID4gMSA/IHNvdXJjZXNbbGVuZ3RoIC0gMV0gOiB1bmRlZmluZWQsXG4gICAgICAgIGd1YXJkID0gbGVuZ3RoID4gMiA/IHNvdXJjZXNbMl0gOiB1bmRlZmluZWQ7XG5cbiAgICBjdXN0b21pemVyID0gKGFzc2lnbmVyLmxlbmd0aCA+IDMgJiYgdHlwZW9mIGN1c3RvbWl6ZXIgPT0gJ2Z1bmN0aW9uJylcbiAgICAgID8gKGxlbmd0aC0tLCBjdXN0b21pemVyKVxuICAgICAgOiB1bmRlZmluZWQ7XG5cbiAgICBpZiAoZ3VhcmQgJiYgaXNJdGVyYXRlZUNhbGwoc291cmNlc1swXSwgc291cmNlc1sxXSwgZ3VhcmQpKSB7XG4gICAgICBjdXN0b21pemVyID0gbGVuZ3RoIDwgMyA/IHVuZGVmaW5lZCA6IGN1c3RvbWl6ZXI7XG4gICAgICBsZW5ndGggPSAxO1xuICAgIH1cbiAgICBvYmplY3QgPSBPYmplY3Qob2JqZWN0KTtcbiAgICB3aGlsZSAoKytpbmRleCA8IGxlbmd0aCkge1xuICAgICAgdmFyIHNvdXJjZSA9IHNvdXJjZXNbaW5kZXhdO1xuICAgICAgaWYgKHNvdXJjZSkge1xuICAgICAgICBhc3NpZ25lcihvYmplY3QsIHNvdXJjZSwgaW5kZXgsIGN1c3RvbWl6ZXIpO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gb2JqZWN0O1xuICB9KTtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBjcmVhdGVBc3NpZ25lcjtcbiIsIi8qKlxuICogQ3JlYXRlcyBhIGJhc2UgZnVuY3Rpb24gZm9yIG1ldGhvZHMgbGlrZSBgXy5mb3JJbmAgYW5kIGBfLmZvck93bmAuXG4gKlxuICogQHByaXZhdGVcbiAqIEBwYXJhbSB7Ym9vbGVhbn0gW2Zyb21SaWdodF0gU3BlY2lmeSBpdGVyYXRpbmcgZnJvbSByaWdodCB0byBsZWZ0LlxuICogQHJldHVybnMge0Z1bmN0aW9ufSBSZXR1cm5zIHRoZSBuZXcgYmFzZSBmdW5jdGlvbi5cbiAqL1xuZnVuY3Rpb24gY3JlYXRlQmFzZUZvcihmcm9tUmlnaHQpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uKG9iamVjdCwgaXRlcmF0ZWUsIGtleXNGdW5jKSB7XG4gICAgdmFyIGluZGV4ID0gLTEsXG4gICAgICAgIGl0ZXJhYmxlID0gT2JqZWN0KG9iamVjdCksXG4gICAgICAgIHByb3BzID0ga2V5c0Z1bmMob2JqZWN0KSxcbiAgICAgICAgbGVuZ3RoID0gcHJvcHMubGVuZ3RoO1xuXG4gICAgd2hpbGUgKGxlbmd0aC0tKSB7XG4gICAgICB2YXIga2V5ID0gcHJvcHNbZnJvbVJpZ2h0ID8gbGVuZ3RoIDogKytpbmRleF07XG4gICAgICBpZiAoaXRlcmF0ZWUoaXRlcmFibGVba2V5XSwga2V5LCBpdGVyYWJsZSkgPT09IGZhbHNlKSB7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gb2JqZWN0O1xuICB9O1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IGNyZWF0ZUJhc2VGb3I7XG4iLCJ2YXIgb3ZlckFyZyA9IHJlcXVpcmUoJy4vX292ZXJBcmcnKTtcblxuLyoqIEJ1aWx0LWluIHZhbHVlIHJlZmVyZW5jZXMuICovXG52YXIgZ2V0UHJvdG90eXBlID0gb3ZlckFyZyhPYmplY3QuZ2V0UHJvdG90eXBlT2YsIE9iamVjdCk7XG5cbm1vZHVsZS5leHBvcnRzID0gZ2V0UHJvdG90eXBlO1xuIiwidmFyIGJhc2VDcmVhdGUgPSByZXF1aXJlKCcuL19iYXNlQ3JlYXRlJyksXG4gICAgZ2V0UHJvdG90eXBlID0gcmVxdWlyZSgnLi9fZ2V0UHJvdG90eXBlJyksXG4gICAgaXNQcm90b3R5cGUgPSByZXF1aXJlKCcuL19pc1Byb3RvdHlwZScpO1xuXG4vKipcbiAqIEluaXRpYWxpemVzIGFuIG9iamVjdCBjbG9uZS5cbiAqXG4gKiBAcHJpdmF0ZVxuICogQHBhcmFtIHtPYmplY3R9IG9iamVjdCBUaGUgb2JqZWN0IHRvIGNsb25lLlxuICogQHJldHVybnMge09iamVjdH0gUmV0dXJucyB0aGUgaW5pdGlhbGl6ZWQgY2xvbmUuXG4gKi9cbmZ1bmN0aW9uIGluaXRDbG9uZU9iamVjdChvYmplY3QpIHtcbiAgcmV0dXJuICh0eXBlb2Ygb2JqZWN0LmNvbnN0cnVjdG9yID09ICdmdW5jdGlvbicgJiYgIWlzUHJvdG90eXBlKG9iamVjdCkpXG4gICAgPyBiYXNlQ3JlYXRlKGdldFByb3RvdHlwZShvYmplY3QpKVxuICAgIDoge307XG59XG5cbm1vZHVsZS5leHBvcnRzID0gaW5pdENsb25lT2JqZWN0O1xuIiwidmFyIGVxID0gcmVxdWlyZSgnLi9lcScpLFxuICAgIGlzQXJyYXlMaWtlID0gcmVxdWlyZSgnLi9pc0FycmF5TGlrZScpLFxuICAgIGlzSW5kZXggPSByZXF1aXJlKCcuL19pc0luZGV4JyksXG4gICAgaXNPYmplY3QgPSByZXF1aXJlKCcuL2lzT2JqZWN0Jyk7XG5cbi8qKlxuICogQ2hlY2tzIGlmIHRoZSBnaXZlbiBhcmd1bWVudHMgYXJlIGZyb20gYW4gaXRlcmF0ZWUgY2FsbC5cbiAqXG4gKiBAcHJpdmF0ZVxuICogQHBhcmFtIHsqfSB2YWx1ZSBUaGUgcG90ZW50aWFsIGl0ZXJhdGVlIHZhbHVlIGFyZ3VtZW50LlxuICogQHBhcmFtIHsqfSBpbmRleCBUaGUgcG90ZW50aWFsIGl0ZXJhdGVlIGluZGV4IG9yIGtleSBhcmd1bWVudC5cbiAqIEBwYXJhbSB7Kn0gb2JqZWN0IFRoZSBwb3RlbnRpYWwgaXRlcmF0ZWUgb2JqZWN0IGFyZ3VtZW50LlxuICogQHJldHVybnMge2Jvb2xlYW59IFJldHVybnMgYHRydWVgIGlmIHRoZSBhcmd1bWVudHMgYXJlIGZyb20gYW4gaXRlcmF0ZWUgY2FsbCxcbiAqICBlbHNlIGBmYWxzZWAuXG4gKi9cbmZ1bmN0aW9uIGlzSXRlcmF0ZWVDYWxsKHZhbHVlLCBpbmRleCwgb2JqZWN0KSB7XG4gIGlmICghaXNPYmplY3Qob2JqZWN0KSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICB2YXIgdHlwZSA9IHR5cGVvZiBpbmRleDtcbiAgaWYgKHR5cGUgPT0gJ251bWJlcidcbiAgICAgICAgPyAoaXNBcnJheUxpa2Uob2JqZWN0KSAmJiBpc0luZGV4KGluZGV4LCBvYmplY3QubGVuZ3RoKSlcbiAgICAgICAgOiAodHlwZSA9PSAnc3RyaW5nJyAmJiBpbmRleCBpbiBvYmplY3QpXG4gICAgICApIHtcbiAgICByZXR1cm4gZXEob2JqZWN0W2luZGV4XSwgdmFsdWUpO1xuICB9XG4gIHJldHVybiBmYWxzZTtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBpc0l0ZXJhdGVlQ2FsbDtcbiIsIi8qKiBVc2VkIGZvciBidWlsdC1pbiBtZXRob2QgcmVmZXJlbmNlcy4gKi9cbnZhciBvYmplY3RQcm90byA9IE9iamVjdC5wcm90b3R5cGU7XG5cbi8qKlxuICogQ2hlY2tzIGlmIGB2YWx1ZWAgaXMgbGlrZWx5IGEgcHJvdG90eXBlIG9iamVjdC5cbiAqXG4gKiBAcHJpdmF0ZVxuICogQHBhcmFtIHsqfSB2YWx1ZSBUaGUgdmFsdWUgdG8gY2hlY2suXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gUmV0dXJucyBgdHJ1ZWAgaWYgYHZhbHVlYCBpcyBhIHByb3RvdHlwZSwgZWxzZSBgZmFsc2VgLlxuICovXG5mdW5jdGlvbiBpc1Byb3RvdHlwZSh2YWx1ZSkge1xuICB2YXIgQ3RvciA9IHZhbHVlICYmIHZhbHVlLmNvbnN0cnVjdG9yLFxuICAgICAgcHJvdG8gPSAodHlwZW9mIEN0b3IgPT0gJ2Z1bmN0aW9uJyAmJiBDdG9yLnByb3RvdHlwZSkgfHwgb2JqZWN0UHJvdG87XG5cbiAgcmV0dXJuIHZhbHVlID09PSBwcm90bztcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBpc1Byb3RvdHlwZTtcbiIsIi8qKlxuICogVGhpcyBmdW5jdGlvbiBpcyBsaWtlXG4gKiBbYE9iamVjdC5rZXlzYF0oaHR0cDovL2VjbWEtaW50ZXJuYXRpb25hbC5vcmcvZWNtYS0yNjIvNy4wLyNzZWMtb2JqZWN0LmtleXMpXG4gKiBleGNlcHQgdGhhdCBpdCBpbmNsdWRlcyBpbmhlcml0ZWQgZW51bWVyYWJsZSBwcm9wZXJ0aWVzLlxuICpcbiAqIEBwcml2YXRlXG4gKiBAcGFyYW0ge09iamVjdH0gb2JqZWN0IFRoZSBvYmplY3QgdG8gcXVlcnkuXG4gKiBAcmV0dXJucyB7QXJyYXl9IFJldHVybnMgdGhlIGFycmF5IG9mIHByb3BlcnR5IG5hbWVzLlxuICovXG5mdW5jdGlvbiBuYXRpdmVLZXlzSW4ob2JqZWN0KSB7XG4gIHZhciByZXN1bHQgPSBbXTtcbiAgaWYgKG9iamVjdCAhPSBudWxsKSB7XG4gICAgZm9yICh2YXIga2V5IGluIE9iamVjdChvYmplY3QpKSB7XG4gICAgICByZXN1bHQucHVzaChrZXkpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gcmVzdWx0O1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IG5hdGl2ZUtleXNJbjtcbiIsInZhciBmcmVlR2xvYmFsID0gcmVxdWlyZSgnLi9fZnJlZUdsb2JhbCcpO1xuXG4vKiogRGV0ZWN0IGZyZWUgdmFyaWFibGUgYGV4cG9ydHNgLiAqL1xudmFyIGZyZWVFeHBvcnRzID0gdHlwZW9mIGV4cG9ydHMgPT0gJ29iamVjdCcgJiYgZXhwb3J0cyAmJiAhZXhwb3J0cy5ub2RlVHlwZSAmJiBleHBvcnRzO1xuXG4vKiogRGV0ZWN0IGZyZWUgdmFyaWFibGUgYG1vZHVsZWAuICovXG52YXIgZnJlZU1vZHVsZSA9IGZyZWVFeHBvcnRzICYmIHR5cGVvZiBtb2R1bGUgPT0gJ29iamVjdCcgJiYgbW9kdWxlICYmICFtb2R1bGUubm9kZVR5cGUgJiYgbW9kdWxlO1xuXG4vKiogRGV0ZWN0IHRoZSBwb3B1bGFyIENvbW1vbkpTIGV4dGVuc2lvbiBgbW9kdWxlLmV4cG9ydHNgLiAqL1xudmFyIG1vZHVsZUV4cG9ydHMgPSBmcmVlTW9kdWxlICYmIGZyZWVNb2R1bGUuZXhwb3J0cyA9PT0gZnJlZUV4cG9ydHM7XG5cbi8qKiBEZXRlY3QgZnJlZSB2YXJpYWJsZSBgcHJvY2Vzc2AgZnJvbSBOb2RlLmpzLiAqL1xudmFyIGZyZWVQcm9jZXNzID0gbW9kdWxlRXhwb3J0cyAmJiBmcmVlR2xvYmFsLnByb2Nlc3M7XG5cbi8qKiBVc2VkIHRvIGFjY2VzcyBmYXN0ZXIgTm9kZS5qcyBoZWxwZXJzLiAqL1xudmFyIG5vZGVVdGlsID0gKGZ1bmN0aW9uKCkge1xuICB0cnkge1xuICAgIHJldHVybiBmcmVlUHJvY2VzcyAmJiBmcmVlUHJvY2Vzcy5iaW5kaW5nICYmIGZyZWVQcm9jZXNzLmJpbmRpbmcoJ3V0aWwnKTtcbiAgfSBjYXRjaCAoZSkge31cbn0oKSk7XG5cbm1vZHVsZS5leHBvcnRzID0gbm9kZVV0aWw7XG4iLCIvKipcbiAqIENyZWF0ZXMgYSB1bmFyeSBmdW5jdGlvbiB0aGF0IGludm9rZXMgYGZ1bmNgIHdpdGggaXRzIGFyZ3VtZW50IHRyYW5zZm9ybWVkLlxuICpcbiAqIEBwcml2YXRlXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBmdW5jIFRoZSBmdW5jdGlvbiB0byB3cmFwLlxuICogQHBhcmFtIHtGdW5jdGlvbn0gdHJhbnNmb3JtIFRoZSBhcmd1bWVudCB0cmFuc2Zvcm0uXG4gKiBAcmV0dXJucyB7RnVuY3Rpb259IFJldHVybnMgdGhlIG5ldyBmdW5jdGlvbi5cbiAqL1xuZnVuY3Rpb24gb3ZlckFyZyhmdW5jLCB0cmFuc2Zvcm0pIHtcbiAgcmV0dXJuIGZ1bmN0aW9uKGFyZykge1xuICAgIHJldHVybiBmdW5jKHRyYW5zZm9ybShhcmcpKTtcbiAgfTtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBvdmVyQXJnO1xuIiwidmFyIGFwcGx5ID0gcmVxdWlyZSgnLi9fYXBwbHknKTtcblxuLyogQnVpbHQtaW4gbWV0aG9kIHJlZmVyZW5jZXMgZm9yIHRob3NlIHdpdGggdGhlIHNhbWUgbmFtZSBhcyBvdGhlciBgbG9kYXNoYCBtZXRob2RzLiAqL1xudmFyIG5hdGl2ZU1heCA9IE1hdGgubWF4O1xuXG4vKipcbiAqIEEgc3BlY2lhbGl6ZWQgdmVyc2lvbiBvZiBgYmFzZVJlc3RgIHdoaWNoIHRyYW5zZm9ybXMgdGhlIHJlc3QgYXJyYXkuXG4gKlxuICogQHByaXZhdGVcbiAqIEBwYXJhbSB7RnVuY3Rpb259IGZ1bmMgVGhlIGZ1bmN0aW9uIHRvIGFwcGx5IGEgcmVzdCBwYXJhbWV0ZXIgdG8uXG4gKiBAcGFyYW0ge251bWJlcn0gW3N0YXJ0PWZ1bmMubGVuZ3RoLTFdIFRoZSBzdGFydCBwb3NpdGlvbiBvZiB0aGUgcmVzdCBwYXJhbWV0ZXIuXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSB0cmFuc2Zvcm0gVGhlIHJlc3QgYXJyYXkgdHJhbnNmb3JtLlxuICogQHJldHVybnMge0Z1bmN0aW9ufSBSZXR1cm5zIHRoZSBuZXcgZnVuY3Rpb24uXG4gKi9cbmZ1bmN0aW9uIG92ZXJSZXN0KGZ1bmMsIHN0YXJ0LCB0cmFuc2Zvcm0pIHtcbiAgc3RhcnQgPSBuYXRpdmVNYXgoc3RhcnQgPT09IHVuZGVmaW5lZCA/IChmdW5jLmxlbmd0aCAtIDEpIDogc3RhcnQsIDApO1xuICByZXR1cm4gZnVuY3Rpb24oKSB7XG4gICAgdmFyIGFyZ3MgPSBhcmd1bWVudHMsXG4gICAgICAgIGluZGV4ID0gLTEsXG4gICAgICAgIGxlbmd0aCA9IG5hdGl2ZU1heChhcmdzLmxlbmd0aCAtIHN0YXJ0LCAwKSxcbiAgICAgICAgYXJyYXkgPSBBcnJheShsZW5ndGgpO1xuXG4gICAgd2hpbGUgKCsraW5kZXggPCBsZW5ndGgpIHtcbiAgICAgIGFycmF5W2luZGV4XSA9IGFyZ3Nbc3RhcnQgKyBpbmRleF07XG4gICAgfVxuICAgIGluZGV4ID0gLTE7XG4gICAgdmFyIG90aGVyQXJncyA9IEFycmF5KHN0YXJ0ICsgMSk7XG4gICAgd2hpbGUgKCsraW5kZXggPCBzdGFydCkge1xuICAgICAgb3RoZXJBcmdzW2luZGV4XSA9IGFyZ3NbaW5kZXhdO1xuICAgIH1cbiAgICBvdGhlckFyZ3Nbc3RhcnRdID0gdHJhbnNmb3JtKGFycmF5KTtcbiAgICByZXR1cm4gYXBwbHkoZnVuYywgdGhpcywgb3RoZXJBcmdzKTtcbiAgfTtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBvdmVyUmVzdDtcbiIsIi8qKlxuICogR2V0cyB0aGUgdmFsdWUgYXQgYGtleWAsIHVubGVzcyBga2V5YCBpcyBcIl9fcHJvdG9fX1wiLlxuICpcbiAqIEBwcml2YXRlXG4gKiBAcGFyYW0ge09iamVjdH0gb2JqZWN0IFRoZSBvYmplY3QgdG8gcXVlcnkuXG4gKiBAcGFyYW0ge3N0cmluZ30ga2V5IFRoZSBrZXkgb2YgdGhlIHByb3BlcnR5IHRvIGdldC5cbiAqIEByZXR1cm5zIHsqfSBSZXR1cm5zIHRoZSBwcm9wZXJ0eSB2YWx1ZS5cbiAqL1xuZnVuY3Rpb24gc2FmZUdldChvYmplY3QsIGtleSkge1xuICByZXR1cm4ga2V5ID09ICdfX3Byb3RvX18nXG4gICAgPyB1bmRlZmluZWRcbiAgICA6IG9iamVjdFtrZXldO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHNhZmVHZXQ7XG4iLCJ2YXIgYmFzZVNldFRvU3RyaW5nID0gcmVxdWlyZSgnLi9fYmFzZVNldFRvU3RyaW5nJyksXG4gICAgc2hvcnRPdXQgPSByZXF1aXJlKCcuL19zaG9ydE91dCcpO1xuXG4vKipcbiAqIFNldHMgdGhlIGB0b1N0cmluZ2AgbWV0aG9kIG9mIGBmdW5jYCB0byByZXR1cm4gYHN0cmluZ2AuXG4gKlxuICogQHByaXZhdGVcbiAqIEBwYXJhbSB7RnVuY3Rpb259IGZ1bmMgVGhlIGZ1bmN0aW9uIHRvIG1vZGlmeS5cbiAqIEBwYXJhbSB7RnVuY3Rpb259IHN0cmluZyBUaGUgYHRvU3RyaW5nYCByZXN1bHQuXG4gKiBAcmV0dXJucyB7RnVuY3Rpb259IFJldHVybnMgYGZ1bmNgLlxuICovXG52YXIgc2V0VG9TdHJpbmcgPSBzaG9ydE91dChiYXNlU2V0VG9TdHJpbmcpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IHNldFRvU3RyaW5nO1xuIiwiLyoqIFVzZWQgdG8gZGV0ZWN0IGhvdCBmdW5jdGlvbnMgYnkgbnVtYmVyIG9mIGNhbGxzIHdpdGhpbiBhIHNwYW4gb2YgbWlsbGlzZWNvbmRzLiAqL1xudmFyIEhPVF9DT1VOVCA9IDgwMCxcbiAgICBIT1RfU1BBTiA9IDE2O1xuXG4vKiBCdWlsdC1pbiBtZXRob2QgcmVmZXJlbmNlcyBmb3IgdGhvc2Ugd2l0aCB0aGUgc2FtZSBuYW1lIGFzIG90aGVyIGBsb2Rhc2hgIG1ldGhvZHMuICovXG52YXIgbmF0aXZlTm93ID0gRGF0ZS5ub3c7XG5cbi8qKlxuICogQ3JlYXRlcyBhIGZ1bmN0aW9uIHRoYXQnbGwgc2hvcnQgb3V0IGFuZCBpbnZva2UgYGlkZW50aXR5YCBpbnN0ZWFkXG4gKiBvZiBgZnVuY2Agd2hlbiBpdCdzIGNhbGxlZCBgSE9UX0NPVU5UYCBvciBtb3JlIHRpbWVzIGluIGBIT1RfU1BBTmBcbiAqIG1pbGxpc2Vjb25kcy5cbiAqXG4gKiBAcHJpdmF0ZVxuICogQHBhcmFtIHtGdW5jdGlvbn0gZnVuYyBUaGUgZnVuY3Rpb24gdG8gcmVzdHJpY3QuXG4gKiBAcmV0dXJucyB7RnVuY3Rpb259IFJldHVybnMgdGhlIG5ldyBzaG9ydGFibGUgZnVuY3Rpb24uXG4gKi9cbmZ1bmN0aW9uIHNob3J0T3V0KGZ1bmMpIHtcbiAgdmFyIGNvdW50ID0gMCxcbiAgICAgIGxhc3RDYWxsZWQgPSAwO1xuXG4gIHJldHVybiBmdW5jdGlvbigpIHtcbiAgICB2YXIgc3RhbXAgPSBuYXRpdmVOb3coKSxcbiAgICAgICAgcmVtYWluaW5nID0gSE9UX1NQQU4gLSAoc3RhbXAgLSBsYXN0Q2FsbGVkKTtcblxuICAgIGxhc3RDYWxsZWQgPSBzdGFtcDtcbiAgICBpZiAocmVtYWluaW5nID4gMCkge1xuICAgICAgaWYgKCsrY291bnQgPj0gSE9UX0NPVU5UKSB7XG4gICAgICAgIHJldHVybiBhcmd1bWVudHNbMF07XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvdW50ID0gMDtcbiAgICB9XG4gICAgcmV0dXJuIGZ1bmMuYXBwbHkodW5kZWZpbmVkLCBhcmd1bWVudHMpO1xuICB9O1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHNob3J0T3V0O1xuIiwidmFyIExpc3RDYWNoZSA9IHJlcXVpcmUoJy4vX0xpc3RDYWNoZScpO1xuXG4vKipcbiAqIFJlbW92ZXMgYWxsIGtleS12YWx1ZSBlbnRyaWVzIGZyb20gdGhlIHN0YWNrLlxuICpcbiAqIEBwcml2YXRlXG4gKiBAbmFtZSBjbGVhclxuICogQG1lbWJlck9mIFN0YWNrXG4gKi9cbmZ1bmN0aW9uIHN0YWNrQ2xlYXIoKSB7XG4gIHRoaXMuX19kYXRhX18gPSBuZXcgTGlzdENhY2hlO1xuICB0aGlzLnNpemUgPSAwO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHN0YWNrQ2xlYXI7XG4iLCIvKipcbiAqIFJlbW92ZXMgYGtleWAgYW5kIGl0cyB2YWx1ZSBmcm9tIHRoZSBzdGFjay5cbiAqXG4gKiBAcHJpdmF0ZVxuICogQG5hbWUgZGVsZXRlXG4gKiBAbWVtYmVyT2YgU3RhY2tcbiAqIEBwYXJhbSB7c3RyaW5nfSBrZXkgVGhlIGtleSBvZiB0aGUgdmFsdWUgdG8gcmVtb3ZlLlxuICogQHJldHVybnMge2Jvb2xlYW59IFJldHVybnMgYHRydWVgIGlmIHRoZSBlbnRyeSB3YXMgcmVtb3ZlZCwgZWxzZSBgZmFsc2VgLlxuICovXG5mdW5jdGlvbiBzdGFja0RlbGV0ZShrZXkpIHtcbiAgdmFyIGRhdGEgPSB0aGlzLl9fZGF0YV9fLFxuICAgICAgcmVzdWx0ID0gZGF0YVsnZGVsZXRlJ10oa2V5KTtcblxuICB0aGlzLnNpemUgPSBkYXRhLnNpemU7XG4gIHJldHVybiByZXN1bHQ7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gc3RhY2tEZWxldGU7XG4iLCIvKipcbiAqIEdldHMgdGhlIHN0YWNrIHZhbHVlIGZvciBga2V5YC5cbiAqXG4gKiBAcHJpdmF0ZVxuICogQG5hbWUgZ2V0XG4gKiBAbWVtYmVyT2YgU3RhY2tcbiAqIEBwYXJhbSB7c3RyaW5nfSBrZXkgVGhlIGtleSBvZiB0aGUgdmFsdWUgdG8gZ2V0LlxuICogQHJldHVybnMgeyp9IFJldHVybnMgdGhlIGVudHJ5IHZhbHVlLlxuICovXG5mdW5jdGlvbiBzdGFja0dldChrZXkpIHtcbiAgcmV0dXJuIHRoaXMuX19kYXRhX18uZ2V0KGtleSk7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gc3RhY2tHZXQ7XG4iLCIvKipcbiAqIENoZWNrcyBpZiBhIHN0YWNrIHZhbHVlIGZvciBga2V5YCBleGlzdHMuXG4gKlxuICogQHByaXZhdGVcbiAqIEBuYW1lIGhhc1xuICogQG1lbWJlck9mIFN0YWNrXG4gKiBAcGFyYW0ge3N0cmluZ30ga2V5IFRoZSBrZXkgb2YgdGhlIGVudHJ5IHRvIGNoZWNrLlxuICogQHJldHVybnMge2Jvb2xlYW59IFJldHVybnMgYHRydWVgIGlmIGFuIGVudHJ5IGZvciBga2V5YCBleGlzdHMsIGVsc2UgYGZhbHNlYC5cbiAqL1xuZnVuY3Rpb24gc3RhY2tIYXMoa2V5KSB7XG4gIHJldHVybiB0aGlzLl9fZGF0YV9fLmhhcyhrZXkpO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHN0YWNrSGFzO1xuIiwidmFyIExpc3RDYWNoZSA9IHJlcXVpcmUoJy4vX0xpc3RDYWNoZScpLFxuICAgIE1hcCA9IHJlcXVpcmUoJy4vX01hcCcpLFxuICAgIE1hcENhY2hlID0gcmVxdWlyZSgnLi9fTWFwQ2FjaGUnKTtcblxuLyoqIFVzZWQgYXMgdGhlIHNpemUgdG8gZW5hYmxlIGxhcmdlIGFycmF5IG9wdGltaXphdGlvbnMuICovXG52YXIgTEFSR0VfQVJSQVlfU0laRSA9IDIwMDtcblxuLyoqXG4gKiBTZXRzIHRoZSBzdGFjayBga2V5YCB0byBgdmFsdWVgLlxuICpcbiAqIEBwcml2YXRlXG4gKiBAbmFtZSBzZXRcbiAqIEBtZW1iZXJPZiBTdGFja1xuICogQHBhcmFtIHtzdHJpbmd9IGtleSBUaGUga2V5IG9mIHRoZSB2YWx1ZSB0byBzZXQuXG4gKiBAcGFyYW0geyp9IHZhbHVlIFRoZSB2YWx1ZSB0byBzZXQuXG4gKiBAcmV0dXJucyB7T2JqZWN0fSBSZXR1cm5zIHRoZSBzdGFjayBjYWNoZSBpbnN0YW5jZS5cbiAqL1xuZnVuY3Rpb24gc3RhY2tTZXQoa2V5LCB2YWx1ZSkge1xuICB2YXIgZGF0YSA9IHRoaXMuX19kYXRhX187XG4gIGlmIChkYXRhIGluc3RhbmNlb2YgTGlzdENhY2hlKSB7XG4gICAgdmFyIHBhaXJzID0gZGF0YS5fX2RhdGFfXztcbiAgICBpZiAoIU1hcCB8fCAocGFpcnMubGVuZ3RoIDwgTEFSR0VfQVJSQVlfU0laRSAtIDEpKSB7XG4gICAgICBwYWlycy5wdXNoKFtrZXksIHZhbHVlXSk7XG4gICAgICB0aGlzLnNpemUgPSArK2RhdGEuc2l6ZTtcbiAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICBkYXRhID0gdGhpcy5fX2RhdGFfXyA9IG5ldyBNYXBDYWNoZShwYWlycyk7XG4gIH1cbiAgZGF0YS5zZXQoa2V5LCB2YWx1ZSk7XG4gIHRoaXMuc2l6ZSA9IGRhdGEuc2l6ZTtcbiAgcmV0dXJuIHRoaXM7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gc3RhY2tTZXQ7XG4iLCIvKipcbiAqIENyZWF0ZXMgYSBmdW5jdGlvbiB0aGF0IHJldHVybnMgYHZhbHVlYC5cbiAqXG4gKiBAc3RhdGljXG4gKiBAbWVtYmVyT2YgX1xuICogQHNpbmNlIDIuNC4wXG4gKiBAY2F0ZWdvcnkgVXRpbFxuICogQHBhcmFtIHsqfSB2YWx1ZSBUaGUgdmFsdWUgdG8gcmV0dXJuIGZyb20gdGhlIG5ldyBmdW5jdGlvbi5cbiAqIEByZXR1cm5zIHtGdW5jdGlvbn0gUmV0dXJucyB0aGUgbmV3IGNvbnN0YW50IGZ1bmN0aW9uLlxuICogQGV4YW1wbGVcbiAqXG4gKiB2YXIgb2JqZWN0cyA9IF8udGltZXMoMiwgXy5jb25zdGFudCh7ICdhJzogMSB9KSk7XG4gKlxuICogY29uc29sZS5sb2cob2JqZWN0cyk7XG4gKiAvLyA9PiBbeyAnYSc6IDEgfSwgeyAnYSc6IDEgfV1cbiAqXG4gKiBjb25zb2xlLmxvZyhvYmplY3RzWzBdID09PSBvYmplY3RzWzFdKTtcbiAqIC8vID0+IHRydWVcbiAqL1xuZnVuY3Rpb24gY29uc3RhbnQodmFsdWUpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uKCkge1xuICAgIHJldHVybiB2YWx1ZTtcbiAgfTtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBjb25zdGFudDtcbiIsIi8qKlxuICogVGhpcyBtZXRob2QgcmV0dXJucyB0aGUgZmlyc3QgYXJndW1lbnQgaXQgcmVjZWl2ZXMuXG4gKlxuICogQHN0YXRpY1xuICogQHNpbmNlIDAuMS4wXG4gKiBAbWVtYmVyT2YgX1xuICogQGNhdGVnb3J5IFV0aWxcbiAqIEBwYXJhbSB7Kn0gdmFsdWUgQW55IHZhbHVlLlxuICogQHJldHVybnMgeyp9IFJldHVybnMgYHZhbHVlYC5cbiAqIEBleGFtcGxlXG4gKlxuICogdmFyIG9iamVjdCA9IHsgJ2EnOiAxIH07XG4gKlxuICogY29uc29sZS5sb2coXy5pZGVudGl0eShvYmplY3QpID09PSBvYmplY3QpO1xuICogLy8gPT4gdHJ1ZVxuICovXG5mdW5jdGlvbiBpZGVudGl0eSh2YWx1ZSkge1xuICByZXR1cm4gdmFsdWU7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gaWRlbnRpdHk7XG4iLCJ2YXIgaXNGdW5jdGlvbiA9IHJlcXVpcmUoJy4vaXNGdW5jdGlvbicpLFxuICAgIGlzTGVuZ3RoID0gcmVxdWlyZSgnLi9pc0xlbmd0aCcpO1xuXG4vKipcbiAqIENoZWNrcyBpZiBgdmFsdWVgIGlzIGFycmF5LWxpa2UuIEEgdmFsdWUgaXMgY29uc2lkZXJlZCBhcnJheS1saWtlIGlmIGl0J3NcbiAqIG5vdCBhIGZ1bmN0aW9uIGFuZCBoYXMgYSBgdmFsdWUubGVuZ3RoYCB0aGF0J3MgYW4gaW50ZWdlciBncmVhdGVyIHRoYW4gb3JcbiAqIGVxdWFsIHRvIGAwYCBhbmQgbGVzcyB0aGFuIG9yIGVxdWFsIHRvIGBOdW1iZXIuTUFYX1NBRkVfSU5URUdFUmAuXG4gKlxuICogQHN0YXRpY1xuICogQG1lbWJlck9mIF9cbiAqIEBzaW5jZSA0LjAuMFxuICogQGNhdGVnb3J5IExhbmdcbiAqIEBwYXJhbSB7Kn0gdmFsdWUgVGhlIHZhbHVlIHRvIGNoZWNrLlxuICogQHJldHVybnMge2Jvb2xlYW59IFJldHVybnMgYHRydWVgIGlmIGB2YWx1ZWAgaXMgYXJyYXktbGlrZSwgZWxzZSBgZmFsc2VgLlxuICogQGV4YW1wbGVcbiAqXG4gKiBfLmlzQXJyYXlMaWtlKFsxLCAyLCAzXSk7XG4gKiAvLyA9PiB0cnVlXG4gKlxuICogXy5pc0FycmF5TGlrZShkb2N1bWVudC5ib2R5LmNoaWxkcmVuKTtcbiAqIC8vID0+IHRydWVcbiAqXG4gKiBfLmlzQXJyYXlMaWtlKCdhYmMnKTtcbiAqIC8vID0+IHRydWVcbiAqXG4gKiBfLmlzQXJyYXlMaWtlKF8ubm9vcCk7XG4gKiAvLyA9PiBmYWxzZVxuICovXG5mdW5jdGlvbiBpc0FycmF5TGlrZSh2YWx1ZSkge1xuICByZXR1cm4gdmFsdWUgIT0gbnVsbCAmJiBpc0xlbmd0aCh2YWx1ZS5sZW5ndGgpICYmICFpc0Z1bmN0aW9uKHZhbHVlKTtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBpc0FycmF5TGlrZTtcbiIsInZhciBpc0FycmF5TGlrZSA9IHJlcXVpcmUoJy4vaXNBcnJheUxpa2UnKSxcbiAgICBpc09iamVjdExpa2UgPSByZXF1aXJlKCcuL2lzT2JqZWN0TGlrZScpO1xuXG4vKipcbiAqIFRoaXMgbWV0aG9kIGlzIGxpa2UgYF8uaXNBcnJheUxpa2VgIGV4Y2VwdCB0aGF0IGl0IGFsc28gY2hlY2tzIGlmIGB2YWx1ZWBcbiAqIGlzIGFuIG9iamVjdC5cbiAqXG4gKiBAc3RhdGljXG4gKiBAbWVtYmVyT2YgX1xuICogQHNpbmNlIDQuMC4wXG4gKiBAY2F0ZWdvcnkgTGFuZ1xuICogQHBhcmFtIHsqfSB2YWx1ZSBUaGUgdmFsdWUgdG8gY2hlY2suXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gUmV0dXJucyBgdHJ1ZWAgaWYgYHZhbHVlYCBpcyBhbiBhcnJheS1saWtlIG9iamVjdCxcbiAqICBlbHNlIGBmYWxzZWAuXG4gKiBAZXhhbXBsZVxuICpcbiAqIF8uaXNBcnJheUxpa2VPYmplY3QoWzEsIDIsIDNdKTtcbiAqIC8vID0+IHRydWVcbiAqXG4gKiBfLmlzQXJyYXlMaWtlT2JqZWN0KGRvY3VtZW50LmJvZHkuY2hpbGRyZW4pO1xuICogLy8gPT4gdHJ1ZVxuICpcbiAqIF8uaXNBcnJheUxpa2VPYmplY3QoJ2FiYycpO1xuICogLy8gPT4gZmFsc2VcbiAqXG4gKiBfLmlzQXJyYXlMaWtlT2JqZWN0KF8ubm9vcCk7XG4gKiAvLyA9PiBmYWxzZVxuICovXG5mdW5jdGlvbiBpc0FycmF5TGlrZU9iamVjdCh2YWx1ZSkge1xuICByZXR1cm4gaXNPYmplY3RMaWtlKHZhbHVlKSAmJiBpc0FycmF5TGlrZSh2YWx1ZSk7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gaXNBcnJheUxpa2VPYmplY3Q7XG4iLCJ2YXIgcm9vdCA9IHJlcXVpcmUoJy4vX3Jvb3QnKSxcbiAgICBzdHViRmFsc2UgPSByZXF1aXJlKCcuL3N0dWJGYWxzZScpO1xuXG4vKiogRGV0ZWN0IGZyZWUgdmFyaWFibGUgYGV4cG9ydHNgLiAqL1xudmFyIGZyZWVFeHBvcnRzID0gdHlwZW9mIGV4cG9ydHMgPT0gJ29iamVjdCcgJiYgZXhwb3J0cyAmJiAhZXhwb3J0cy5ub2RlVHlwZSAmJiBleHBvcnRzO1xuXG4vKiogRGV0ZWN0IGZyZWUgdmFyaWFibGUgYG1vZHVsZWAuICovXG52YXIgZnJlZU1vZHVsZSA9IGZyZWVFeHBvcnRzICYmIHR5cGVvZiBtb2R1bGUgPT0gJ29iamVjdCcgJiYgbW9kdWxlICYmICFtb2R1bGUubm9kZVR5cGUgJiYgbW9kdWxlO1xuXG4vKiogRGV0ZWN0IHRoZSBwb3B1bGFyIENvbW1vbkpTIGV4dGVuc2lvbiBgbW9kdWxlLmV4cG9ydHNgLiAqL1xudmFyIG1vZHVsZUV4cG9ydHMgPSBmcmVlTW9kdWxlICYmIGZyZWVNb2R1bGUuZXhwb3J0cyA9PT0gZnJlZUV4cG9ydHM7XG5cbi8qKiBCdWlsdC1pbiB2YWx1ZSByZWZlcmVuY2VzLiAqL1xudmFyIEJ1ZmZlciA9IG1vZHVsZUV4cG9ydHMgPyByb290LkJ1ZmZlciA6IHVuZGVmaW5lZDtcblxuLyogQnVpbHQtaW4gbWV0aG9kIHJlZmVyZW5jZXMgZm9yIHRob3NlIHdpdGggdGhlIHNhbWUgbmFtZSBhcyBvdGhlciBgbG9kYXNoYCBtZXRob2RzLiAqL1xudmFyIG5hdGl2ZUlzQnVmZmVyID0gQnVmZmVyID8gQnVmZmVyLmlzQnVmZmVyIDogdW5kZWZpbmVkO1xuXG4vKipcbiAqIENoZWNrcyBpZiBgdmFsdWVgIGlzIGEgYnVmZmVyLlxuICpcbiAqIEBzdGF0aWNcbiAqIEBtZW1iZXJPZiBfXG4gKiBAc2luY2UgNC4zLjBcbiAqIEBjYXRlZ29yeSBMYW5nXG4gKiBAcGFyYW0geyp9IHZhbHVlIFRoZSB2YWx1ZSB0byBjaGVjay5cbiAqIEByZXR1cm5zIHtib29sZWFufSBSZXR1cm5zIGB0cnVlYCBpZiBgdmFsdWVgIGlzIGEgYnVmZmVyLCBlbHNlIGBmYWxzZWAuXG4gKiBAZXhhbXBsZVxuICpcbiAqIF8uaXNCdWZmZXIobmV3IEJ1ZmZlcigyKSk7XG4gKiAvLyA9PiB0cnVlXG4gKlxuICogXy5pc0J1ZmZlcihuZXcgVWludDhBcnJheSgyKSk7XG4gKiAvLyA9PiBmYWxzZVxuICovXG52YXIgaXNCdWZmZXIgPSBuYXRpdmVJc0J1ZmZlciB8fCBzdHViRmFsc2U7XG5cbm1vZHVsZS5leHBvcnRzID0gaXNCdWZmZXI7XG4iLCJ2YXIgYmFzZUdldFRhZyA9IHJlcXVpcmUoJy4vX2Jhc2VHZXRUYWcnKSxcbiAgICBnZXRQcm90b3R5cGUgPSByZXF1aXJlKCcuL19nZXRQcm90b3R5cGUnKSxcbiAgICBpc09iamVjdExpa2UgPSByZXF1aXJlKCcuL2lzT2JqZWN0TGlrZScpO1xuXG4vKiogYE9iamVjdCN0b1N0cmluZ2AgcmVzdWx0IHJlZmVyZW5jZXMuICovXG52YXIgb2JqZWN0VGFnID0gJ1tvYmplY3QgT2JqZWN0XSc7XG5cbi8qKiBVc2VkIGZvciBidWlsdC1pbiBtZXRob2QgcmVmZXJlbmNlcy4gKi9cbnZhciBmdW5jUHJvdG8gPSBGdW5jdGlvbi5wcm90b3R5cGUsXG4gICAgb2JqZWN0UHJvdG8gPSBPYmplY3QucHJvdG90eXBlO1xuXG4vKiogVXNlZCB0byByZXNvbHZlIHRoZSBkZWNvbXBpbGVkIHNvdXJjZSBvZiBmdW5jdGlvbnMuICovXG52YXIgZnVuY1RvU3RyaW5nID0gZnVuY1Byb3RvLnRvU3RyaW5nO1xuXG4vKiogVXNlZCB0byBjaGVjayBvYmplY3RzIGZvciBvd24gcHJvcGVydGllcy4gKi9cbnZhciBoYXNPd25Qcm9wZXJ0eSA9IG9iamVjdFByb3RvLmhhc093blByb3BlcnR5O1xuXG4vKiogVXNlZCB0byBpbmZlciB0aGUgYE9iamVjdGAgY29uc3RydWN0b3IuICovXG52YXIgb2JqZWN0Q3RvclN0cmluZyA9IGZ1bmNUb1N0cmluZy5jYWxsKE9iamVjdCk7XG5cbi8qKlxuICogQ2hlY2tzIGlmIGB2YWx1ZWAgaXMgYSBwbGFpbiBvYmplY3QsIHRoYXQgaXMsIGFuIG9iamVjdCBjcmVhdGVkIGJ5IHRoZVxuICogYE9iamVjdGAgY29uc3RydWN0b3Igb3Igb25lIHdpdGggYSBgW1tQcm90b3R5cGVdXWAgb2YgYG51bGxgLlxuICpcbiAqIEBzdGF0aWNcbiAqIEBtZW1iZXJPZiBfXG4gKiBAc2luY2UgMC44LjBcbiAqIEBjYXRlZ29yeSBMYW5nXG4gKiBAcGFyYW0geyp9IHZhbHVlIFRoZSB2YWx1ZSB0byBjaGVjay5cbiAqIEByZXR1cm5zIHtib29sZWFufSBSZXR1cm5zIGB0cnVlYCBpZiBgdmFsdWVgIGlzIGEgcGxhaW4gb2JqZWN0LCBlbHNlIGBmYWxzZWAuXG4gKiBAZXhhbXBsZVxuICpcbiAqIGZ1bmN0aW9uIEZvbygpIHtcbiAqICAgdGhpcy5hID0gMTtcbiAqIH1cbiAqXG4gKiBfLmlzUGxhaW5PYmplY3QobmV3IEZvbyk7XG4gKiAvLyA9PiBmYWxzZVxuICpcbiAqIF8uaXNQbGFpbk9iamVjdChbMSwgMiwgM10pO1xuICogLy8gPT4gZmFsc2VcbiAqXG4gKiBfLmlzUGxhaW5PYmplY3QoeyAneCc6IDAsICd5JzogMCB9KTtcbiAqIC8vID0+IHRydWVcbiAqXG4gKiBfLmlzUGxhaW5PYmplY3QoT2JqZWN0LmNyZWF0ZShudWxsKSk7XG4gKiAvLyA9PiB0cnVlXG4gKi9cbmZ1bmN0aW9uIGlzUGxhaW5PYmplY3QodmFsdWUpIHtcbiAgaWYgKCFpc09iamVjdExpa2UodmFsdWUpIHx8IGJhc2VHZXRUYWcodmFsdWUpICE9IG9iamVjdFRhZykge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICB2YXIgcHJvdG8gPSBnZXRQcm90b3R5cGUodmFsdWUpO1xuICBpZiAocHJvdG8gPT09IG51bGwpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICB2YXIgQ3RvciA9IGhhc093blByb3BlcnR5LmNhbGwocHJvdG8sICdjb25zdHJ1Y3RvcicpICYmIHByb3RvLmNvbnN0cnVjdG9yO1xuICByZXR1cm4gdHlwZW9mIEN0b3IgPT0gJ2Z1bmN0aW9uJyAmJiBDdG9yIGluc3RhbmNlb2YgQ3RvciAmJlxuICAgIGZ1bmNUb1N0cmluZy5jYWxsKEN0b3IpID09IG9iamVjdEN0b3JTdHJpbmc7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gaXNQbGFpbk9iamVjdDtcbiIsInZhciBiYXNlSXNUeXBlZEFycmF5ID0gcmVxdWlyZSgnLi9fYmFzZUlzVHlwZWRBcnJheScpLFxuICAgIGJhc2VVbmFyeSA9IHJlcXVpcmUoJy4vX2Jhc2VVbmFyeScpLFxuICAgIG5vZGVVdGlsID0gcmVxdWlyZSgnLi9fbm9kZVV0aWwnKTtcblxuLyogTm9kZS5qcyBoZWxwZXIgcmVmZXJlbmNlcy4gKi9cbnZhciBub2RlSXNUeXBlZEFycmF5ID0gbm9kZVV0aWwgJiYgbm9kZVV0aWwuaXNUeXBlZEFycmF5O1xuXG4vKipcbiAqIENoZWNrcyBpZiBgdmFsdWVgIGlzIGNsYXNzaWZpZWQgYXMgYSB0eXBlZCBhcnJheS5cbiAqXG4gKiBAc3RhdGljXG4gKiBAbWVtYmVyT2YgX1xuICogQHNpbmNlIDMuMC4wXG4gKiBAY2F0ZWdvcnkgTGFuZ1xuICogQHBhcmFtIHsqfSB2YWx1ZSBUaGUgdmFsdWUgdG8gY2hlY2suXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gUmV0dXJucyBgdHJ1ZWAgaWYgYHZhbHVlYCBpcyBhIHR5cGVkIGFycmF5LCBlbHNlIGBmYWxzZWAuXG4gKiBAZXhhbXBsZVxuICpcbiAqIF8uaXNUeXBlZEFycmF5KG5ldyBVaW50OEFycmF5KTtcbiAqIC8vID0+IHRydWVcbiAqXG4gKiBfLmlzVHlwZWRBcnJheShbXSk7XG4gKiAvLyA9PiBmYWxzZVxuICovXG52YXIgaXNUeXBlZEFycmF5ID0gbm9kZUlzVHlwZWRBcnJheSA/IGJhc2VVbmFyeShub2RlSXNUeXBlZEFycmF5KSA6IGJhc2VJc1R5cGVkQXJyYXk7XG5cbm1vZHVsZS5leHBvcnRzID0gaXNUeXBlZEFycmF5O1xuIiwidmFyIGFycmF5TGlrZUtleXMgPSByZXF1aXJlKCcuL19hcnJheUxpa2VLZXlzJyksXG4gICAgYmFzZUtleXNJbiA9IHJlcXVpcmUoJy4vX2Jhc2VLZXlzSW4nKSxcbiAgICBpc0FycmF5TGlrZSA9IHJlcXVpcmUoJy4vaXNBcnJheUxpa2UnKTtcblxuLyoqXG4gKiBDcmVhdGVzIGFuIGFycmF5IG9mIHRoZSBvd24gYW5kIGluaGVyaXRlZCBlbnVtZXJhYmxlIHByb3BlcnR5IG5hbWVzIG9mIGBvYmplY3RgLlxuICpcbiAqICoqTm90ZToqKiBOb24tb2JqZWN0IHZhbHVlcyBhcmUgY29lcmNlZCB0byBvYmplY3RzLlxuICpcbiAqIEBzdGF0aWNcbiAqIEBtZW1iZXJPZiBfXG4gKiBAc2luY2UgMy4wLjBcbiAqIEBjYXRlZ29yeSBPYmplY3RcbiAqIEBwYXJhbSB7T2JqZWN0fSBvYmplY3QgVGhlIG9iamVjdCB0byBxdWVyeS5cbiAqIEByZXR1cm5zIHtBcnJheX0gUmV0dXJucyB0aGUgYXJyYXkgb2YgcHJvcGVydHkgbmFtZXMuXG4gKiBAZXhhbXBsZVxuICpcbiAqIGZ1bmN0aW9uIEZvbygpIHtcbiAqICAgdGhpcy5hID0gMTtcbiAqICAgdGhpcy5iID0gMjtcbiAqIH1cbiAqXG4gKiBGb28ucHJvdG90eXBlLmMgPSAzO1xuICpcbiAqIF8ua2V5c0luKG5ldyBGb28pO1xuICogLy8gPT4gWydhJywgJ2InLCAnYyddIChpdGVyYXRpb24gb3JkZXIgaXMgbm90IGd1YXJhbnRlZWQpXG4gKi9cbmZ1bmN0aW9uIGtleXNJbihvYmplY3QpIHtcbiAgcmV0dXJuIGlzQXJyYXlMaWtlKG9iamVjdCkgPyBhcnJheUxpa2VLZXlzKG9iamVjdCwgdHJ1ZSkgOiBiYXNlS2V5c0luKG9iamVjdCk7XG59XG5cbm1vZHVsZS5leHBvcnRzID0ga2V5c0luO1xuIiwidmFyIGJhc2VNZXJnZSA9IHJlcXVpcmUoJy4vX2Jhc2VNZXJnZScpLFxuICAgIGNyZWF0ZUFzc2lnbmVyID0gcmVxdWlyZSgnLi9fY3JlYXRlQXNzaWduZXInKTtcblxuLyoqXG4gKiBUaGlzIG1ldGhvZCBpcyBsaWtlIGBfLmFzc2lnbmAgZXhjZXB0IHRoYXQgaXQgcmVjdXJzaXZlbHkgbWVyZ2VzIG93biBhbmRcbiAqIGluaGVyaXRlZCBlbnVtZXJhYmxlIHN0cmluZyBrZXllZCBwcm9wZXJ0aWVzIG9mIHNvdXJjZSBvYmplY3RzIGludG8gdGhlXG4gKiBkZXN0aW5hdGlvbiBvYmplY3QuIFNvdXJjZSBwcm9wZXJ0aWVzIHRoYXQgcmVzb2x2ZSB0byBgdW5kZWZpbmVkYCBhcmVcbiAqIHNraXBwZWQgaWYgYSBkZXN0aW5hdGlvbiB2YWx1ZSBleGlzdHMuIEFycmF5IGFuZCBwbGFpbiBvYmplY3QgcHJvcGVydGllc1xuICogYXJlIG1lcmdlZCByZWN1cnNpdmVseS4gT3RoZXIgb2JqZWN0cyBhbmQgdmFsdWUgdHlwZXMgYXJlIG92ZXJyaWRkZW4gYnlcbiAqIGFzc2lnbm1lbnQuIFNvdXJjZSBvYmplY3RzIGFyZSBhcHBsaWVkIGZyb20gbGVmdCB0byByaWdodC4gU3Vic2VxdWVudFxuICogc291cmNlcyBvdmVyd3JpdGUgcHJvcGVydHkgYXNzaWdubWVudHMgb2YgcHJldmlvdXMgc291cmNlcy5cbiAqXG4gKiAqKk5vdGU6KiogVGhpcyBtZXRob2QgbXV0YXRlcyBgb2JqZWN0YC5cbiAqXG4gKiBAc3RhdGljXG4gKiBAbWVtYmVyT2YgX1xuICogQHNpbmNlIDAuNS4wXG4gKiBAY2F0ZWdvcnkgT2JqZWN0XG4gKiBAcGFyYW0ge09iamVjdH0gb2JqZWN0IFRoZSBkZXN0aW5hdGlvbiBvYmplY3QuXG4gKiBAcGFyYW0gey4uLk9iamVjdH0gW3NvdXJjZXNdIFRoZSBzb3VyY2Ugb2JqZWN0cy5cbiAqIEByZXR1cm5zIHtPYmplY3R9IFJldHVybnMgYG9iamVjdGAuXG4gKiBAZXhhbXBsZVxuICpcbiAqIHZhciBvYmplY3QgPSB7XG4gKiAgICdhJzogW3sgJ2InOiAyIH0sIHsgJ2QnOiA0IH1dXG4gKiB9O1xuICpcbiAqIHZhciBvdGhlciA9IHtcbiAqICAgJ2EnOiBbeyAnYyc6IDMgfSwgeyAnZSc6IDUgfV1cbiAqIH07XG4gKlxuICogXy5tZXJnZShvYmplY3QsIG90aGVyKTtcbiAqIC8vID0+IHsgJ2EnOiBbeyAnYic6IDIsICdjJzogMyB9LCB7ICdkJzogNCwgJ2UnOiA1IH1dIH1cbiAqL1xudmFyIG1lcmdlID0gY3JlYXRlQXNzaWduZXIoZnVuY3Rpb24ob2JqZWN0LCBzb3VyY2UsIHNyY0luZGV4KSB7XG4gIGJhc2VNZXJnZShvYmplY3QsIHNvdXJjZSwgc3JjSW5kZXgpO1xufSk7XG5cbm1vZHVsZS5leHBvcnRzID0gbWVyZ2U7XG4iLCIvKipcbiAqIFRoaXMgbWV0aG9kIHJldHVybnMgYGZhbHNlYC5cbiAqXG4gKiBAc3RhdGljXG4gKiBAbWVtYmVyT2YgX1xuICogQHNpbmNlIDQuMTMuMFxuICogQGNhdGVnb3J5IFV0aWxcbiAqIEByZXR1cm5zIHtib29sZWFufSBSZXR1cm5zIGBmYWxzZWAuXG4gKiBAZXhhbXBsZVxuICpcbiAqIF8udGltZXMoMiwgXy5zdHViRmFsc2UpO1xuICogLy8gPT4gW2ZhbHNlLCBmYWxzZV1cbiAqL1xuZnVuY3Rpb24gc3R1YkZhbHNlKCkge1xuICByZXR1cm4gZmFsc2U7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gc3R1YkZhbHNlO1xuIiwidmFyIGNvcHlPYmplY3QgPSByZXF1aXJlKCcuL19jb3B5T2JqZWN0JyksXG4gICAga2V5c0luID0gcmVxdWlyZSgnLi9rZXlzSW4nKTtcblxuLyoqXG4gKiBDb252ZXJ0cyBgdmFsdWVgIHRvIGEgcGxhaW4gb2JqZWN0IGZsYXR0ZW5pbmcgaW5oZXJpdGVkIGVudW1lcmFibGUgc3RyaW5nXG4gKiBrZXllZCBwcm9wZXJ0aWVzIG9mIGB2YWx1ZWAgdG8gb3duIHByb3BlcnRpZXMgb2YgdGhlIHBsYWluIG9iamVjdC5cbiAqXG4gKiBAc3RhdGljXG4gKiBAbWVtYmVyT2YgX1xuICogQHNpbmNlIDMuMC4wXG4gKiBAY2F0ZWdvcnkgTGFuZ1xuICogQHBhcmFtIHsqfSB2YWx1ZSBUaGUgdmFsdWUgdG8gY29udmVydC5cbiAqIEByZXR1cm5zIHtPYmplY3R9IFJldHVybnMgdGhlIGNvbnZlcnRlZCBwbGFpbiBvYmplY3QuXG4gKiBAZXhhbXBsZVxuICpcbiAqIGZ1bmN0aW9uIEZvbygpIHtcbiAqICAgdGhpcy5iID0gMjtcbiAqIH1cbiAqXG4gKiBGb28ucHJvdG90eXBlLmMgPSAzO1xuICpcbiAqIF8uYXNzaWduKHsgJ2EnOiAxIH0sIG5ldyBGb28pO1xuICogLy8gPT4geyAnYSc6IDEsICdiJzogMiB9XG4gKlxuICogXy5hc3NpZ24oeyAnYSc6IDEgfSwgXy50b1BsYWluT2JqZWN0KG5ldyBGb28pKTtcbiAqIC8vID0+IHsgJ2EnOiAxLCAnYic6IDIsICdjJzogMyB9XG4gKi9cbmZ1bmN0aW9uIHRvUGxhaW5PYmplY3QodmFsdWUpIHtcbiAgcmV0dXJuIGNvcHlPYmplY3QodmFsdWUsIGtleXNJbih2YWx1ZSkpO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHRvUGxhaW5PYmplY3Q7XG4iLCJpbXBvcnQgX2V4dGVuZHMgZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL2V4dGVuZHMnO1xuaW1wb3J0IF9jbGFzc0NhbGxDaGVjayBmcm9tICdiYWJlbC1ydW50aW1lL2hlbHBlcnMvY2xhc3NDYWxsQ2hlY2snO1xuaW1wb3J0IF9wb3NzaWJsZUNvbnN0cnVjdG9yUmV0dXJuIGZyb20gJ2JhYmVsLXJ1bnRpbWUvaGVscGVycy9wb3NzaWJsZUNvbnN0cnVjdG9yUmV0dXJuJztcbmltcG9ydCBfaW5oZXJpdHMgZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL2luaGVyaXRzJztcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCAqIGFzIFJlYWN0RE9NIGZyb20gJ3JlYWN0LWRvbSc7XG5pbXBvcnQgS2V5Q29kZSBmcm9tICdyYy11dGlsL2VzL0tleUNvZGUnO1xuaW1wb3J0IEFuaW1hdGUgZnJvbSAncmMtYW5pbWF0ZSc7XG5pbXBvcnQgTGF6eVJlbmRlckJveCBmcm9tICcuL0xhenlSZW5kZXJCb3gnO1xuaW1wb3J0IGdldFNjcm9sbEJhclNpemUgZnJvbSAncmMtdXRpbC9lcy9nZXRTY3JvbGxCYXJTaXplJztcbnZhciB1dWlkID0gMDtcbnZhciBvcGVuQ291bnQgPSAwO1xuLyogZXNsaW50IHJlYWN0L25vLWlzLW1vdW50ZWQ6MCAqL1xuZnVuY3Rpb24gZ2V0U2Nyb2xsKHcsIHRvcCkge1xuICAgIHZhciByZXQgPSB3WydwYWdlJyArICh0b3AgPyAnWScgOiAnWCcpICsgJ09mZnNldCddO1xuICAgIHZhciBtZXRob2QgPSAnc2Nyb2xsJyArICh0b3AgPyAnVG9wJyA6ICdMZWZ0Jyk7XG4gICAgaWYgKHR5cGVvZiByZXQgIT09ICdudW1iZXInKSB7XG4gICAgICAgIHZhciBkID0gdy5kb2N1bWVudDtcbiAgICAgICAgcmV0ID0gZC5kb2N1bWVudEVsZW1lbnRbbWV0aG9kXTtcbiAgICAgICAgaWYgKHR5cGVvZiByZXQgIT09ICdudW1iZXInKSB7XG4gICAgICAgICAgICByZXQgPSBkLmJvZHlbbWV0aG9kXTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gcmV0O1xufVxuZnVuY3Rpb24gc2V0VHJhbnNmb3JtT3JpZ2luKG5vZGUsIHZhbHVlKSB7XG4gICAgdmFyIHN0eWxlID0gbm9kZS5zdHlsZTtcbiAgICBbJ1dlYmtpdCcsICdNb3onLCAnTXMnLCAnbXMnXS5mb3JFYWNoKGZ1bmN0aW9uIChwcmVmaXgpIHtcbiAgICAgICAgc3R5bGVbcHJlZml4ICsgJ1RyYW5zZm9ybU9yaWdpbiddID0gdmFsdWU7XG4gICAgfSk7XG4gICAgc3R5bGVbJ3RyYW5zZm9ybU9yaWdpbiddID0gdmFsdWU7XG59XG5mdW5jdGlvbiBvZmZzZXQoZWwpIHtcbiAgICB2YXIgcmVjdCA9IGVsLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgIHZhciBwb3MgPSB7XG4gICAgICAgIGxlZnQ6IHJlY3QubGVmdCxcbiAgICAgICAgdG9wOiByZWN0LnRvcFxuICAgIH07XG4gICAgdmFyIGRvYyA9IGVsLm93bmVyRG9jdW1lbnQ7XG4gICAgdmFyIHcgPSBkb2MuZGVmYXVsdFZpZXcgfHwgZG9jLnBhcmVudFdpbmRvdztcbiAgICBwb3MubGVmdCArPSBnZXRTY3JvbGwodyk7XG4gICAgcG9zLnRvcCArPSBnZXRTY3JvbGwodywgdHJ1ZSk7XG4gICAgcmV0dXJuIHBvcztcbn1cblxudmFyIERpYWxvZyA9IGZ1bmN0aW9uIChfUmVhY3QkQ29tcG9uZW50KSB7XG4gICAgX2luaGVyaXRzKERpYWxvZywgX1JlYWN0JENvbXBvbmVudCk7XG5cbiAgICBmdW5jdGlvbiBEaWFsb2coKSB7XG4gICAgICAgIF9jbGFzc0NhbGxDaGVjayh0aGlzLCBEaWFsb2cpO1xuXG4gICAgICAgIHZhciBfdGhpcyA9IF9wb3NzaWJsZUNvbnN0cnVjdG9yUmV0dXJuKHRoaXMsIF9SZWFjdCRDb21wb25lbnQuYXBwbHkodGhpcywgYXJndW1lbnRzKSk7XG5cbiAgICAgICAgX3RoaXMub25BbmltYXRlTGVhdmUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB2YXIgYWZ0ZXJDbG9zZSA9IF90aGlzLnByb3BzLmFmdGVyQ2xvc2U7XG4gICAgICAgICAgICAvLyBuZWVkIGRlbW8/XG4gICAgICAgICAgICAvLyBodHRwczovL2dpdGh1Yi5jb20vcmVhY3QtY29tcG9uZW50L2RpYWxvZy9wdWxsLzI4XG5cbiAgICAgICAgICAgIGlmIChfdGhpcy53cmFwKSB7XG4gICAgICAgICAgICAgICAgX3RoaXMud3JhcC5zdHlsZS5kaXNwbGF5ID0gJ25vbmUnO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgX3RoaXMuaW5UcmFuc2l0aW9uID0gZmFsc2U7XG4gICAgICAgICAgICBfdGhpcy5yZW1vdmVTY3JvbGxpbmdFZmZlY3QoKTtcbiAgICAgICAgICAgIGlmIChhZnRlckNsb3NlKSB7XG4gICAgICAgICAgICAgICAgYWZ0ZXJDbG9zZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICBfdGhpcy5vbk1hc2tDbGljayA9IGZ1bmN0aW9uIChlKSB7XG4gICAgICAgICAgICAvLyBhbmRyb2lkIHRyaWdnZXIgY2xpY2sgb24gb3BlbiAoZmFzdGNsaWNrPz8pXG4gICAgICAgICAgICBpZiAoRGF0ZS5ub3coKSAtIF90aGlzLm9wZW5UaW1lIDwgMzAwKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGUudGFyZ2V0ID09PSBlLmN1cnJlbnRUYXJnZXQpIHtcbiAgICAgICAgICAgICAgICBfdGhpcy5jbG9zZShlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgICAgX3RoaXMub25LZXlEb3duID0gZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgICAgIHZhciBwcm9wcyA9IF90aGlzLnByb3BzO1xuICAgICAgICAgICAgaWYgKHByb3BzLmtleWJvYXJkICYmIGUua2V5Q29kZSA9PT0gS2V5Q29kZS5FU0MpIHtcbiAgICAgICAgICAgICAgICBfdGhpcy5jbG9zZShlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIGtlZXAgZm9jdXMgaW5zaWRlIGRpYWxvZ1xuICAgICAgICAgICAgaWYgKHByb3BzLnZpc2libGUpIHtcbiAgICAgICAgICAgICAgICBpZiAoZS5rZXlDb2RlID09PSBLZXlDb2RlLlRBQikge1xuICAgICAgICAgICAgICAgICAgICB2YXIgYWN0aXZlRWxlbWVudCA9IGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQ7XG4gICAgICAgICAgICAgICAgICAgIHZhciBkaWFsb2dSb290ID0gX3RoaXMud3JhcDtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGUuc2hpZnRLZXkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChhY3RpdmVFbGVtZW50ID09PSBkaWFsb2dSb290KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuc2VudGluZWwuZm9jdXMoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChhY3RpdmVFbGVtZW50ID09PSBfdGhpcy5zZW50aW5lbCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZGlhbG9nUm9vdC5mb2N1cygpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICBfdGhpcy5nZXREaWFsb2dFbGVtZW50ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdmFyIHByb3BzID0gX3RoaXMucHJvcHM7XG4gICAgICAgICAgICB2YXIgY2xvc2FibGUgPSBwcm9wcy5jbG9zYWJsZTtcbiAgICAgICAgICAgIHZhciBwcmVmaXhDbHMgPSBwcm9wcy5wcmVmaXhDbHM7XG4gICAgICAgICAgICB2YXIgZGVzdCA9IHt9O1xuICAgICAgICAgICAgaWYgKHByb3BzLndpZHRoICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICBkZXN0LndpZHRoID0gcHJvcHMud2lkdGg7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAocHJvcHMuaGVpZ2h0ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICBkZXN0LmhlaWdodCA9IHByb3BzLmhlaWdodDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHZhciBmb290ZXIgPSB2b2lkIDA7XG4gICAgICAgICAgICBpZiAocHJvcHMuZm9vdGVyKSB7XG4gICAgICAgICAgICAgICAgZm9vdGVyID0gUmVhY3QuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7IGNsYXNzTmFtZTogcHJlZml4Q2xzICsgJy1mb290ZXInLCByZWY6IF90aGlzLnNhdmVSZWYoJ2Zvb3RlcicpIH0sIHByb3BzLmZvb3Rlcik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB2YXIgaGVhZGVyID0gdm9pZCAwO1xuICAgICAgICAgICAgaWYgKHByb3BzLnRpdGxlKSB7XG4gICAgICAgICAgICAgICAgaGVhZGVyID0gUmVhY3QuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7IGNsYXNzTmFtZTogcHJlZml4Q2xzICsgJy1oZWFkZXInLCByZWY6IF90aGlzLnNhdmVSZWYoJ2hlYWRlcicpIH0sIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgeyBjbGFzc05hbWU6IHByZWZpeENscyArICctdGl0bGUnLCBpZDogX3RoaXMudGl0bGVJZCB9LCBwcm9wcy50aXRsZSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdmFyIGNsb3NlciA9IHZvaWQgMDtcbiAgICAgICAgICAgIGlmIChjbG9zYWJsZSkge1xuICAgICAgICAgICAgICAgIGNsb3NlciA9IFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJidXR0b25cIiwgeyBvbkNsaWNrOiBfdGhpcy5jbG9zZSwgXCJhcmlhLWxhYmVsXCI6IFwiQ2xvc2VcIiwgY2xhc3NOYW1lOiBwcmVmaXhDbHMgKyAnLWNsb3NlJyB9LCBSZWFjdC5jcmVhdGVFbGVtZW50KFwic3BhblwiLCB7IGNsYXNzTmFtZTogcHJlZml4Q2xzICsgJy1jbG9zZS14JyB9KSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB2YXIgc3R5bGUgPSBfZXh0ZW5kcyh7fSwgcHJvcHMuc3R5bGUsIGRlc3QpO1xuICAgICAgICAgICAgdmFyIHRyYW5zaXRpb25OYW1lID0gX3RoaXMuZ2V0VHJhbnNpdGlvbk5hbWUoKTtcbiAgICAgICAgICAgIHZhciBkaWFsb2dFbGVtZW50ID0gUmVhY3QuY3JlYXRlRWxlbWVudChMYXp5UmVuZGVyQm94LCB7IGtleTogXCJkaWFsb2ctZWxlbWVudFwiLCByb2xlOiBcImRvY3VtZW50XCIsIHJlZjogX3RoaXMuc2F2ZVJlZignZGlhbG9nJyksIHN0eWxlOiBzdHlsZSwgY2xhc3NOYW1lOiBwcmVmaXhDbHMgKyAnICcgKyAocHJvcHMuY2xhc3NOYW1lIHx8ICcnKSwgdmlzaWJsZTogcHJvcHMudmlzaWJsZSB9LCBSZWFjdC5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIHsgY2xhc3NOYW1lOiBwcmVmaXhDbHMgKyAnLWNvbnRlbnQnIH0sIGNsb3NlciwgaGVhZGVyLCBSZWFjdC5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIF9leHRlbmRzKHsgY2xhc3NOYW1lOiBwcmVmaXhDbHMgKyAnLWJvZHknLCBzdHlsZTogcHJvcHMuYm9keVN0eWxlLCByZWY6IF90aGlzLnNhdmVSZWYoJ2JvZHknKSB9LCBwcm9wcy5ib2R5UHJvcHMpLCBwcm9wcy5jaGlsZHJlbiksIGZvb3RlciksIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgeyB0YWJJbmRleDogMCwgcmVmOiBfdGhpcy5zYXZlUmVmKCdzZW50aW5lbCcpLCBzdHlsZTogeyB3aWR0aDogMCwgaGVpZ2h0OiAwLCBvdmVyZmxvdzogJ2hpZGRlbicgfSB9LCBcInNlbnRpbmVsXCIpKTtcbiAgICAgICAgICAgIHJldHVybiBSZWFjdC5jcmVhdGVFbGVtZW50KEFuaW1hdGUsIHsga2V5OiBcImRpYWxvZ1wiLCBzaG93UHJvcDogXCJ2aXNpYmxlXCIsIG9uTGVhdmU6IF90aGlzLm9uQW5pbWF0ZUxlYXZlLCB0cmFuc2l0aW9uTmFtZTogdHJhbnNpdGlvbk5hbWUsIGNvbXBvbmVudDogXCJcIiwgdHJhbnNpdGlvbkFwcGVhcjogdHJ1ZSB9LCBwcm9wcy52aXNpYmxlIHx8ICFwcm9wcy5kZXN0cm95T25DbG9zZSA/IGRpYWxvZ0VsZW1lbnQgOiBudWxsKTtcbiAgICAgICAgfTtcbiAgICAgICAgX3RoaXMuZ2V0WkluZGV4U3R5bGUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB2YXIgc3R5bGUgPSB7fTtcbiAgICAgICAgICAgIHZhciBwcm9wcyA9IF90aGlzLnByb3BzO1xuICAgICAgICAgICAgaWYgKHByb3BzLnpJbmRleCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgc3R5bGUuekluZGV4ID0gcHJvcHMuekluZGV4O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHN0eWxlO1xuICAgICAgICB9O1xuICAgICAgICBfdGhpcy5nZXRXcmFwU3R5bGUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICByZXR1cm4gX2V4dGVuZHMoe30sIF90aGlzLmdldFpJbmRleFN0eWxlKCksIF90aGlzLnByb3BzLndyYXBTdHlsZSk7XG4gICAgICAgIH07XG4gICAgICAgIF90aGlzLmdldE1hc2tTdHlsZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHJldHVybiBfZXh0ZW5kcyh7fSwgX3RoaXMuZ2V0WkluZGV4U3R5bGUoKSwgX3RoaXMucHJvcHMubWFza1N0eWxlKTtcbiAgICAgICAgfTtcbiAgICAgICAgX3RoaXMuZ2V0TWFza0VsZW1lbnQgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB2YXIgcHJvcHMgPSBfdGhpcy5wcm9wcztcbiAgICAgICAgICAgIHZhciBtYXNrRWxlbWVudCA9IHZvaWQgMDtcbiAgICAgICAgICAgIGlmIChwcm9wcy5tYXNrKSB7XG4gICAgICAgICAgICAgICAgdmFyIG1hc2tUcmFuc2l0aW9uID0gX3RoaXMuZ2V0TWFza1RyYW5zaXRpb25OYW1lKCk7XG4gICAgICAgICAgICAgICAgbWFza0VsZW1lbnQgPSBSZWFjdC5jcmVhdGVFbGVtZW50KExhenlSZW5kZXJCb3gsIF9leHRlbmRzKHsgc3R5bGU6IF90aGlzLmdldE1hc2tTdHlsZSgpLCBrZXk6IFwibWFza1wiLCBjbGFzc05hbWU6IHByb3BzLnByZWZpeENscyArICctbWFzaycsIGhpZGRlbkNsYXNzTmFtZTogcHJvcHMucHJlZml4Q2xzICsgJy1tYXNrLWhpZGRlbicsIHZpc2libGU6IHByb3BzLnZpc2libGUgfSwgcHJvcHMubWFza1Byb3BzKSk7XG4gICAgICAgICAgICAgICAgaWYgKG1hc2tUcmFuc2l0aW9uKSB7XG4gICAgICAgICAgICAgICAgICAgIG1hc2tFbGVtZW50ID0gUmVhY3QuY3JlYXRlRWxlbWVudChBbmltYXRlLCB7IGtleTogXCJtYXNrXCIsIHNob3dQcm9wOiBcInZpc2libGVcIiwgdHJhbnNpdGlvbkFwcGVhcjogdHJ1ZSwgY29tcG9uZW50OiBcIlwiLCB0cmFuc2l0aW9uTmFtZTogbWFza1RyYW5zaXRpb24gfSwgbWFza0VsZW1lbnQpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBtYXNrRWxlbWVudDtcbiAgICAgICAgfTtcbiAgICAgICAgX3RoaXMuZ2V0TWFza1RyYW5zaXRpb25OYW1lID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdmFyIHByb3BzID0gX3RoaXMucHJvcHM7XG4gICAgICAgICAgICB2YXIgdHJhbnNpdGlvbk5hbWUgPSBwcm9wcy5tYXNrVHJhbnNpdGlvbk5hbWU7XG4gICAgICAgICAgICB2YXIgYW5pbWF0aW9uID0gcHJvcHMubWFza0FuaW1hdGlvbjtcbiAgICAgICAgICAgIGlmICghdHJhbnNpdGlvbk5hbWUgJiYgYW5pbWF0aW9uKSB7XG4gICAgICAgICAgICAgICAgdHJhbnNpdGlvbk5hbWUgPSBwcm9wcy5wcmVmaXhDbHMgKyAnLScgKyBhbmltYXRpb247XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gdHJhbnNpdGlvbk5hbWU7XG4gICAgICAgIH07XG4gICAgICAgIF90aGlzLmdldFRyYW5zaXRpb25OYW1lID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdmFyIHByb3BzID0gX3RoaXMucHJvcHM7XG4gICAgICAgICAgICB2YXIgdHJhbnNpdGlvbk5hbWUgPSBwcm9wcy50cmFuc2l0aW9uTmFtZTtcbiAgICAgICAgICAgIHZhciBhbmltYXRpb24gPSBwcm9wcy5hbmltYXRpb247XG4gICAgICAgICAgICBpZiAoIXRyYW5zaXRpb25OYW1lICYmIGFuaW1hdGlvbikge1xuICAgICAgICAgICAgICAgIHRyYW5zaXRpb25OYW1lID0gcHJvcHMucHJlZml4Q2xzICsgJy0nICsgYW5pbWF0aW9uO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHRyYW5zaXRpb25OYW1lO1xuICAgICAgICB9O1xuICAgICAgICBfdGhpcy5zZXRTY3JvbGxiYXIgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBpZiAoX3RoaXMuYm9keUlzT3ZlcmZsb3dpbmcgJiYgX3RoaXMuc2Nyb2xsYmFyV2lkdGggIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgIGRvY3VtZW50LmJvZHkuc3R5bGUucGFkZGluZ1JpZ2h0ID0gX3RoaXMuc2Nyb2xsYmFyV2lkdGggKyAncHgnO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICBfdGhpcy5hZGRTY3JvbGxpbmdFZmZlY3QgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBvcGVuQ291bnQrKztcbiAgICAgICAgICAgIGlmIChvcGVuQ291bnQgIT09IDEpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBfdGhpcy5jaGVja1Njcm9sbGJhcigpO1xuICAgICAgICAgICAgX3RoaXMuc2V0U2Nyb2xsYmFyKCk7XG4gICAgICAgICAgICBkb2N1bWVudC5ib2R5LnN0eWxlLm92ZXJmbG93ID0gJ2hpZGRlbic7XG4gICAgICAgICAgICAvLyB0aGlzLmFkanVzdERpYWxvZygpO1xuICAgICAgICB9O1xuICAgICAgICBfdGhpcy5yZW1vdmVTY3JvbGxpbmdFZmZlY3QgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBvcGVuQ291bnQtLTtcbiAgICAgICAgICAgIGlmIChvcGVuQ291bnQgIT09IDApIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBkb2N1bWVudC5ib2R5LnN0eWxlLm92ZXJmbG93ID0gJyc7XG4gICAgICAgICAgICBfdGhpcy5yZXNldFNjcm9sbGJhcigpO1xuICAgICAgICAgICAgLy8gdGhpcy5yZXNldEFkanVzdG1lbnRzKCk7XG4gICAgICAgIH07XG4gICAgICAgIF90aGlzLmNsb3NlID0gZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgICAgIHZhciBvbkNsb3NlID0gX3RoaXMucHJvcHMub25DbG9zZTtcblxuICAgICAgICAgICAgaWYgKG9uQ2xvc2UpIHtcbiAgICAgICAgICAgICAgICBvbkNsb3NlKGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICBfdGhpcy5jaGVja1Njcm9sbGJhciA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHZhciBmdWxsV2luZG93V2lkdGggPSB3aW5kb3cuaW5uZXJXaWR0aDtcbiAgICAgICAgICAgIGlmICghZnVsbFdpbmRvd1dpZHRoKSB7XG4gICAgICAgICAgICAgICAgLy8gd29ya2Fyb3VuZCBmb3IgbWlzc2luZyB3aW5kb3cuaW5uZXJXaWR0aCBpbiBJRThcbiAgICAgICAgICAgICAgICB2YXIgZG9jdW1lbnRFbGVtZW50UmVjdCA9IGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICAgICAgICAgICAgICBmdWxsV2luZG93V2lkdGggPSBkb2N1bWVudEVsZW1lbnRSZWN0LnJpZ2h0IC0gTWF0aC5hYnMoZG9jdW1lbnRFbGVtZW50UmVjdC5sZWZ0KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIF90aGlzLmJvZHlJc092ZXJmbG93aW5nID0gZG9jdW1lbnQuYm9keS5jbGllbnRXaWR0aCA8IGZ1bGxXaW5kb3dXaWR0aDtcbiAgICAgICAgICAgIGlmIChfdGhpcy5ib2R5SXNPdmVyZmxvd2luZykge1xuICAgICAgICAgICAgICAgIF90aGlzLnNjcm9sbGJhcldpZHRoID0gZ2V0U2Nyb2xsQmFyU2l6ZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICBfdGhpcy5yZXNldFNjcm9sbGJhciA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGRvY3VtZW50LmJvZHkuc3R5bGUucGFkZGluZ1JpZ2h0ID0gJyc7XG4gICAgICAgIH07XG4gICAgICAgIF90aGlzLmFkanVzdERpYWxvZyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGlmIChfdGhpcy53cmFwICYmIF90aGlzLnNjcm9sbGJhcldpZHRoICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICB2YXIgbW9kYWxJc092ZXJmbG93aW5nID0gX3RoaXMud3JhcC5zY3JvbGxIZWlnaHQgPiBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuY2xpZW50SGVpZ2h0O1xuICAgICAgICAgICAgICAgIF90aGlzLndyYXAuc3R5bGUucGFkZGluZ0xlZnQgPSAoIV90aGlzLmJvZHlJc092ZXJmbG93aW5nICYmIG1vZGFsSXNPdmVyZmxvd2luZyA/IF90aGlzLnNjcm9sbGJhcldpZHRoIDogJycpICsgJ3B4JztcbiAgICAgICAgICAgICAgICBfdGhpcy53cmFwLnN0eWxlLnBhZGRpbmdSaWdodCA9IChfdGhpcy5ib2R5SXNPdmVyZmxvd2luZyAmJiAhbW9kYWxJc092ZXJmbG93aW5nID8gX3RoaXMuc2Nyb2xsYmFyV2lkdGggOiAnJykgKyAncHgnO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICBfdGhpcy5yZXNldEFkanVzdG1lbnRzID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgaWYgKF90aGlzLndyYXApIHtcbiAgICAgICAgICAgICAgICBfdGhpcy53cmFwLnN0eWxlLnBhZGRpbmdMZWZ0ID0gX3RoaXMud3JhcC5zdHlsZS5wYWRkaW5nTGVmdCA9ICcnO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICBfdGhpcy5zYXZlUmVmID0gZnVuY3Rpb24gKG5hbWUpIHtcbiAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbiAobm9kZSkge1xuICAgICAgICAgICAgICAgIF90aGlzW25hbWVdID0gbm9kZTtcbiAgICAgICAgICAgIH07XG4gICAgICAgIH07XG4gICAgICAgIHJldHVybiBfdGhpcztcbiAgICB9XG5cbiAgICBEaWFsb2cucHJvdG90eXBlLmNvbXBvbmVudFdpbGxNb3VudCA9IGZ1bmN0aW9uIGNvbXBvbmVudFdpbGxNb3VudCgpIHtcbiAgICAgICAgdGhpcy5pblRyYW5zaXRpb24gPSBmYWxzZTtcbiAgICAgICAgdGhpcy50aXRsZUlkID0gJ3JjRGlhbG9nVGl0bGUnICsgdXVpZCsrO1xuICAgIH07XG5cbiAgICBEaWFsb2cucHJvdG90eXBlLmNvbXBvbmVudERpZE1vdW50ID0gZnVuY3Rpb24gY29tcG9uZW50RGlkTW91bnQoKSB7XG4gICAgICAgIHRoaXMuY29tcG9uZW50RGlkVXBkYXRlKHt9KTtcbiAgICB9O1xuXG4gICAgRGlhbG9nLnByb3RvdHlwZS5jb21wb25lbnREaWRVcGRhdGUgPSBmdW5jdGlvbiBjb21wb25lbnREaWRVcGRhdGUocHJldlByb3BzKSB7XG4gICAgICAgIHZhciBwcm9wcyA9IHRoaXMucHJvcHM7XG4gICAgICAgIHZhciBtb3VzZVBvc2l0aW9uID0gdGhpcy5wcm9wcy5tb3VzZVBvc2l0aW9uO1xuICAgICAgICBpZiAocHJvcHMudmlzaWJsZSkge1xuICAgICAgICAgICAgLy8gZmlyc3Qgc2hvd1xuICAgICAgICAgICAgaWYgKCFwcmV2UHJvcHMudmlzaWJsZSkge1xuICAgICAgICAgICAgICAgIHRoaXMub3BlblRpbWUgPSBEYXRlLm5vdygpO1xuICAgICAgICAgICAgICAgIHRoaXMubGFzdE91dFNpZGVGb2N1c05vZGUgPSBkb2N1bWVudC5hY3RpdmVFbGVtZW50O1xuICAgICAgICAgICAgICAgIHRoaXMuYWRkU2Nyb2xsaW5nRWZmZWN0KCk7XG4gICAgICAgICAgICAgICAgdGhpcy53cmFwLmZvY3VzKCk7XG4gICAgICAgICAgICAgICAgdmFyIGRpYWxvZ05vZGUgPSBSZWFjdERPTS5maW5kRE9NTm9kZSh0aGlzLmRpYWxvZyk7XG4gICAgICAgICAgICAgICAgaWYgKG1vdXNlUG9zaXRpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIGVsT2Zmc2V0ID0gb2Zmc2V0KGRpYWxvZ05vZGUpO1xuICAgICAgICAgICAgICAgICAgICBzZXRUcmFuc2Zvcm1PcmlnaW4oZGlhbG9nTm9kZSwgbW91c2VQb3NpdGlvbi54IC0gZWxPZmZzZXQubGVmdCArICdweCAnICsgKG1vdXNlUG9zaXRpb24ueSAtIGVsT2Zmc2V0LnRvcCkgKyAncHgnKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBzZXRUcmFuc2Zvcm1PcmlnaW4oZGlhbG9nTm9kZSwgJycpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIGlmIChwcmV2UHJvcHMudmlzaWJsZSkge1xuICAgICAgICAgICAgdGhpcy5pblRyYW5zaXRpb24gPSB0cnVlO1xuICAgICAgICAgICAgaWYgKHByb3BzLm1hc2sgJiYgdGhpcy5sYXN0T3V0U2lkZUZvY3VzTm9kZSkge1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMubGFzdE91dFNpZGVGb2N1c05vZGUuZm9jdXMoKTtcbiAgICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMubGFzdE91dFNpZGVGb2N1c05vZGUgPSBudWxsO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB0aGlzLmxhc3RPdXRTaWRlRm9jdXNOb2RlID0gbnVsbDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBEaWFsb2cucHJvdG90eXBlLmNvbXBvbmVudFdpbGxVbm1vdW50ID0gZnVuY3Rpb24gY29tcG9uZW50V2lsbFVubW91bnQoKSB7XG4gICAgICAgIGlmICh0aGlzLnByb3BzLnZpc2libGUgfHwgdGhpcy5pblRyYW5zaXRpb24pIHtcbiAgICAgICAgICAgIHRoaXMucmVtb3ZlU2Nyb2xsaW5nRWZmZWN0KCk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgRGlhbG9nLnByb3RvdHlwZS5yZW5kZXIgPSBmdW5jdGlvbiByZW5kZXIoKSB7XG4gICAgICAgIHZhciBwcm9wcyA9IHRoaXMucHJvcHM7XG4gICAgICAgIHZhciBwcmVmaXhDbHMgPSBwcm9wcy5wcmVmaXhDbHMsXG4gICAgICAgICAgICBtYXNrQ2xvc2FibGUgPSBwcm9wcy5tYXNrQ2xvc2FibGU7XG5cbiAgICAgICAgdmFyIHN0eWxlID0gdGhpcy5nZXRXcmFwU3R5bGUoKTtcbiAgICAgICAgLy8gY2xlYXIgaGlkZSBkaXNwbGF5XG4gICAgICAgIC8vIGFuZCBvbmx5IHNldCBkaXNwbGF5IGFmdGVyIGFzeW5jIGFuaW0sIG5vdCBoZXJlIGZvciBoaWRlXG4gICAgICAgIGlmIChwcm9wcy52aXNpYmxlKSB7XG4gICAgICAgICAgICBzdHlsZS5kaXNwbGF5ID0gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gUmVhY3QuY3JlYXRlRWxlbWVudChcImRpdlwiLCBudWxsLCB0aGlzLmdldE1hc2tFbGVtZW50KCksIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgX2V4dGVuZHMoeyB0YWJJbmRleDogLTEsIG9uS2V5RG93bjogdGhpcy5vbktleURvd24sIGNsYXNzTmFtZTogcHJlZml4Q2xzICsgJy13cmFwICcgKyAocHJvcHMud3JhcENsYXNzTmFtZSB8fCAnJyksIHJlZjogdGhpcy5zYXZlUmVmKCd3cmFwJyksIG9uQ2xpY2s6IG1hc2tDbG9zYWJsZSA/IHRoaXMub25NYXNrQ2xpY2sgOiB1bmRlZmluZWQsIHJvbGU6IFwiZGlhbG9nXCIsIFwiYXJpYS1sYWJlbGxlZGJ5XCI6IHByb3BzLnRpdGxlID8gdGhpcy50aXRsZUlkIDogbnVsbCwgc3R5bGU6IHN0eWxlIH0sIHByb3BzLndyYXBQcm9wcyksIHRoaXMuZ2V0RGlhbG9nRWxlbWVudCgpKSk7XG4gICAgfTtcblxuICAgIHJldHVybiBEaWFsb2c7XG59KFJlYWN0LkNvbXBvbmVudCk7XG5cbmV4cG9ydCBkZWZhdWx0IERpYWxvZztcblxuRGlhbG9nLmRlZmF1bHRQcm9wcyA9IHtcbiAgICBjbGFzc05hbWU6ICcnLFxuICAgIG1hc2s6IHRydWUsXG4gICAgdmlzaWJsZTogZmFsc2UsXG4gICAga2V5Ym9hcmQ6IHRydWUsXG4gICAgY2xvc2FibGU6IHRydWUsXG4gICAgbWFza0Nsb3NhYmxlOiB0cnVlLFxuICAgIGRlc3Ryb3lPbkNsb3NlOiBmYWxzZSxcbiAgICBwcmVmaXhDbHM6ICdyYy1kaWFsb2cnXG59OyIsImltcG9ydCBfZXh0ZW5kcyBmcm9tICdiYWJlbC1ydW50aW1lL2hlbHBlcnMvZXh0ZW5kcyc7XG5pbXBvcnQgX2NsYXNzQ2FsbENoZWNrIGZyb20gJ2JhYmVsLXJ1bnRpbWUvaGVscGVycy9jbGFzc0NhbGxDaGVjayc7XG5pbXBvcnQgX3Bvc3NpYmxlQ29uc3RydWN0b3JSZXR1cm4gZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL3Bvc3NpYmxlQ29uc3RydWN0b3JSZXR1cm4nO1xuaW1wb3J0IF9pbmhlcml0cyBmcm9tICdiYWJlbC1ydW50aW1lL2hlbHBlcnMvaW5oZXJpdHMnO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0ICogYXMgUmVhY3RET00gZnJvbSAncmVhY3QtZG9tJztcbmltcG9ydCBEaWFsb2cgZnJvbSAnLi9EaWFsb2cnO1xuaW1wb3J0IENvbnRhaW5lclJlbmRlciBmcm9tICdyYy11dGlsL2VzL0NvbnRhaW5lclJlbmRlcic7XG5pbXBvcnQgUG9ydGFsIGZyb20gJ3JjLXV0aWwvZXMvUG9ydGFsJztcbnZhciBJU19SRUFDVF8xNiA9ICdjcmVhdGVQb3J0YWwnIGluIFJlYWN0RE9NO1xuXG52YXIgRGlhbG9nV3JhcCA9IGZ1bmN0aW9uIChfUmVhY3QkQ29tcG9uZW50KSB7XG4gICAgX2luaGVyaXRzKERpYWxvZ1dyYXAsIF9SZWFjdCRDb21wb25lbnQpO1xuXG4gICAgZnVuY3Rpb24gRGlhbG9nV3JhcCgpIHtcbiAgICAgICAgX2NsYXNzQ2FsbENoZWNrKHRoaXMsIERpYWxvZ1dyYXApO1xuXG4gICAgICAgIHZhciBfdGhpcyA9IF9wb3NzaWJsZUNvbnN0cnVjdG9yUmV0dXJuKHRoaXMsIF9SZWFjdCRDb21wb25lbnQuYXBwbHkodGhpcywgYXJndW1lbnRzKSk7XG5cbiAgICAgICAgX3RoaXMuc2F2ZURpYWxvZyA9IGZ1bmN0aW9uIChub2RlKSB7XG4gICAgICAgICAgICBfdGhpcy5fY29tcG9uZW50ID0gbm9kZTtcbiAgICAgICAgfTtcbiAgICAgICAgX3RoaXMuZ2V0Q29tcG9uZW50ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdmFyIGV4dHJhID0gYXJndW1lbnRzLmxlbmd0aCA+IDAgJiYgYXJndW1lbnRzWzBdICE9PSB1bmRlZmluZWQgPyBhcmd1bWVudHNbMF0gOiB7fTtcblxuICAgICAgICAgICAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoRGlhbG9nLCBfZXh0ZW5kcyh7IHJlZjogX3RoaXMuc2F2ZURpYWxvZyB9LCBfdGhpcy5wcm9wcywgZXh0cmEsIHsga2V5OiBcImRpYWxvZ1wiIH0pKTtcbiAgICAgICAgfTtcbiAgICAgICAgX3RoaXMuZ2V0Q29udGFpbmVyID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgaWYgKF90aGlzLnByb3BzLmdldENvbnRhaW5lcikge1xuICAgICAgICAgICAgICAgIHJldHVybiBfdGhpcy5wcm9wcy5nZXRDb250YWluZXIoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHZhciBjb250YWluZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICAgICAgICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoY29udGFpbmVyKTtcbiAgICAgICAgICAgIHJldHVybiBjb250YWluZXI7XG4gICAgICAgIH07XG4gICAgICAgIHJldHVybiBfdGhpcztcbiAgICB9XG5cbiAgICBEaWFsb2dXcmFwLnByb3RvdHlwZS5zaG91bGRDb21wb25lbnRVcGRhdGUgPSBmdW5jdGlvbiBzaG91bGRDb21wb25lbnRVcGRhdGUoX3JlZikge1xuICAgICAgICB2YXIgdmlzaWJsZSA9IF9yZWYudmlzaWJsZTtcblxuICAgICAgICByZXR1cm4gISEodGhpcy5wcm9wcy52aXNpYmxlIHx8IHZpc2libGUpO1xuICAgIH07XG5cbiAgICBEaWFsb2dXcmFwLnByb3RvdHlwZS5jb21wb25lbnRXaWxsVW5tb3VudCA9IGZ1bmN0aW9uIGNvbXBvbmVudFdpbGxVbm1vdW50KCkge1xuICAgICAgICBpZiAoSVNfUkVBQ1RfMTYpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5wcm9wcy52aXNpYmxlKSB7XG4gICAgICAgICAgICB0aGlzLnJlbmRlckNvbXBvbmVudCh7XG4gICAgICAgICAgICAgICAgYWZ0ZXJDbG9zZTogdGhpcy5yZW1vdmVDb250YWluZXIsXG4gICAgICAgICAgICAgICAgb25DbG9zZTogZnVuY3Rpb24gb25DbG9zZSgpIHt9LFxuXG4gICAgICAgICAgICAgICAgdmlzaWJsZTogZmFsc2VcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5yZW1vdmVDb250YWluZXIoKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBEaWFsb2dXcmFwLnByb3RvdHlwZS5yZW5kZXIgPSBmdW5jdGlvbiByZW5kZXIoKSB7XG4gICAgICAgIHZhciBfdGhpczIgPSB0aGlzO1xuXG4gICAgICAgIHZhciB2aXNpYmxlID0gdGhpcy5wcm9wcy52aXNpYmxlO1xuXG4gICAgICAgIHZhciBwb3J0YWwgPSBudWxsO1xuICAgICAgICBpZiAoIUlTX1JFQUNUXzE2KSB7XG4gICAgICAgICAgICByZXR1cm4gUmVhY3QuY3JlYXRlRWxlbWVudChDb250YWluZXJSZW5kZXIsIHsgcGFyZW50OiB0aGlzLCB2aXNpYmxlOiB2aXNpYmxlLCBhdXRvRGVzdHJveTogZmFsc2UsIGdldENvbXBvbmVudDogdGhpcy5nZXRDb21wb25lbnQsIGdldENvbnRhaW5lcjogdGhpcy5nZXRDb250YWluZXIgfSwgZnVuY3Rpb24gKF9yZWYyKSB7XG4gICAgICAgICAgICAgICAgdmFyIHJlbmRlckNvbXBvbmVudCA9IF9yZWYyLnJlbmRlckNvbXBvbmVudCxcbiAgICAgICAgICAgICAgICAgICAgcmVtb3ZlQ29udGFpbmVyID0gX3JlZjIucmVtb3ZlQ29udGFpbmVyO1xuXG4gICAgICAgICAgICAgICAgX3RoaXMyLnJlbmRlckNvbXBvbmVudCA9IHJlbmRlckNvbXBvbmVudDtcbiAgICAgICAgICAgICAgICBfdGhpczIucmVtb3ZlQ29udGFpbmVyID0gcmVtb3ZlQ29udGFpbmVyO1xuICAgICAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHZpc2libGUgfHwgdGhpcy5fY29tcG9uZW50KSB7XG4gICAgICAgICAgICBwb3J0YWwgPSBSZWFjdC5jcmVhdGVFbGVtZW50KFBvcnRhbCwgeyBnZXRDb250YWluZXI6IHRoaXMuZ2V0Q29udGFpbmVyIH0sIHRoaXMuZ2V0Q29tcG9uZW50KCkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBwb3J0YWw7XG4gICAgfTtcblxuICAgIHJldHVybiBEaWFsb2dXcmFwO1xufShSZWFjdC5Db21wb25lbnQpO1xuXG5EaWFsb2dXcmFwLmRlZmF1bHRQcm9wcyA9IHtcbiAgICB2aXNpYmxlOiBmYWxzZVxufTtcbmV4cG9ydCBkZWZhdWx0IERpYWxvZ1dyYXA7IiwiaW1wb3J0IF9leHRlbmRzIGZyb20gXCJiYWJlbC1ydW50aW1lL2hlbHBlcnMvZXh0ZW5kc1wiO1xuaW1wb3J0IF9jbGFzc0NhbGxDaGVjayBmcm9tIFwiYmFiZWwtcnVudGltZS9oZWxwZXJzL2NsYXNzQ2FsbENoZWNrXCI7XG5pbXBvcnQgX3Bvc3NpYmxlQ29uc3RydWN0b3JSZXR1cm4gZnJvbSBcImJhYmVsLXJ1bnRpbWUvaGVscGVycy9wb3NzaWJsZUNvbnN0cnVjdG9yUmV0dXJuXCI7XG5pbXBvcnQgX2luaGVyaXRzIGZyb20gXCJiYWJlbC1ydW50aW1lL2hlbHBlcnMvaW5oZXJpdHNcIjtcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcblxudmFyIExhenlSZW5kZXJCb3ggPSBmdW5jdGlvbiAoX1JlYWN0JENvbXBvbmVudCkge1xuICAgIF9pbmhlcml0cyhMYXp5UmVuZGVyQm94LCBfUmVhY3QkQ29tcG9uZW50KTtcblxuICAgIGZ1bmN0aW9uIExhenlSZW5kZXJCb3goKSB7XG4gICAgICAgIF9jbGFzc0NhbGxDaGVjayh0aGlzLCBMYXp5UmVuZGVyQm94KTtcblxuICAgICAgICByZXR1cm4gX3Bvc3NpYmxlQ29uc3RydWN0b3JSZXR1cm4odGhpcywgX1JlYWN0JENvbXBvbmVudC5hcHBseSh0aGlzLCBhcmd1bWVudHMpKTtcbiAgICB9XG5cbiAgICBMYXp5UmVuZGVyQm94LnByb3RvdHlwZS5zaG91bGRDb21wb25lbnRVcGRhdGUgPSBmdW5jdGlvbiBzaG91bGRDb21wb25lbnRVcGRhdGUobmV4dFByb3BzKSB7XG4gICAgICAgIHJldHVybiAhIW5leHRQcm9wcy5oaWRkZW5DbGFzc05hbWUgfHwgISFuZXh0UHJvcHMudmlzaWJsZTtcbiAgICB9O1xuXG4gICAgTGF6eVJlbmRlckJveC5wcm90b3R5cGUucmVuZGVyID0gZnVuY3Rpb24gcmVuZGVyKCkge1xuICAgICAgICB2YXIgY2xhc3NOYW1lID0gdGhpcy5wcm9wcy5jbGFzc05hbWU7XG4gICAgICAgIGlmICghIXRoaXMucHJvcHMuaGlkZGVuQ2xhc3NOYW1lICYmICF0aGlzLnByb3BzLnZpc2libGUpIHtcbiAgICAgICAgICAgIGNsYXNzTmFtZSArPSBcIiBcIiArIHRoaXMucHJvcHMuaGlkZGVuQ2xhc3NOYW1lO1xuICAgICAgICB9XG4gICAgICAgIHZhciBwcm9wcyA9IF9leHRlbmRzKHt9LCB0aGlzLnByb3BzKTtcbiAgICAgICAgZGVsZXRlIHByb3BzLmhpZGRlbkNsYXNzTmFtZTtcbiAgICAgICAgZGVsZXRlIHByb3BzLnZpc2libGU7XG4gICAgICAgIHByb3BzLmNsYXNzTmFtZSA9IGNsYXNzTmFtZTtcbiAgICAgICAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgX2V4dGVuZHMoe30sIHByb3BzKSk7XG4gICAgfTtcblxuICAgIHJldHVybiBMYXp5UmVuZGVyQm94O1xufShSZWFjdC5Db21wb25lbnQpO1xuXG5leHBvcnQgZGVmYXVsdCBMYXp5UmVuZGVyQm94OyIsImltcG9ydCBfZGVmaW5lUHJvcGVydHkgZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL2RlZmluZVByb3BlcnR5JztcbmltcG9ydCBfY2xhc3NDYWxsQ2hlY2sgZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL2NsYXNzQ2FsbENoZWNrJztcbmltcG9ydCBfY3JlYXRlQ2xhc3MgZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL2NyZWF0ZUNsYXNzJztcbmltcG9ydCBfcG9zc2libGVDb25zdHJ1Y3RvclJldHVybiBmcm9tICdiYWJlbC1ydW50aW1lL2hlbHBlcnMvcG9zc2libGVDb25zdHJ1Y3RvclJldHVybic7XG5pbXBvcnQgX2luaGVyaXRzIGZyb20gJ2JhYmVsLXJ1bnRpbWUvaGVscGVycy9pbmhlcml0cyc7XG5pbXBvcnQgUmVhY3QsIHsgQ29tcG9uZW50IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IGNsYXNzTmFtZXMgZnJvbSAnY2xhc3NuYW1lcyc7XG5pbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnO1xuXG52YXIgTm90aWNlID0gZnVuY3Rpb24gKF9Db21wb25lbnQpIHtcbiAgX2luaGVyaXRzKE5vdGljZSwgX0NvbXBvbmVudCk7XG5cbiAgZnVuY3Rpb24gTm90aWNlKCkge1xuICAgIHZhciBfcmVmO1xuXG4gICAgdmFyIF90ZW1wLCBfdGhpcywgX3JldDtcblxuICAgIF9jbGFzc0NhbGxDaGVjayh0aGlzLCBOb3RpY2UpO1xuXG4gICAgZm9yICh2YXIgX2xlbiA9IGFyZ3VtZW50cy5sZW5ndGgsIGFyZ3MgPSBBcnJheShfbGVuKSwgX2tleSA9IDA7IF9rZXkgPCBfbGVuOyBfa2V5KyspIHtcbiAgICAgIGFyZ3NbX2tleV0gPSBhcmd1bWVudHNbX2tleV07XG4gICAgfVxuXG4gICAgcmV0dXJuIF9yZXQgPSAoX3RlbXAgPSAoX3RoaXMgPSBfcG9zc2libGVDb25zdHJ1Y3RvclJldHVybih0aGlzLCAoX3JlZiA9IE5vdGljZS5fX3Byb3RvX18gfHwgT2JqZWN0LmdldFByb3RvdHlwZU9mKE5vdGljZSkpLmNhbGwuYXBwbHkoX3JlZiwgW3RoaXNdLmNvbmNhdChhcmdzKSkpLCBfdGhpcyksIF90aGlzLmNsb3NlID0gZnVuY3Rpb24gKCkge1xuICAgICAgX3RoaXMuY2xlYXJDbG9zZVRpbWVyKCk7XG4gICAgICBfdGhpcy5wcm9wcy5vbkNsb3NlKCk7XG4gICAgfSwgX3RoaXMuc3RhcnRDbG9zZVRpbWVyID0gZnVuY3Rpb24gKCkge1xuICAgICAgaWYgKF90aGlzLnByb3BzLmR1cmF0aW9uKSB7XG4gICAgICAgIF90aGlzLmNsb3NlVGltZXIgPSBzZXRUaW1lb3V0KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICBfdGhpcy5jbG9zZSgpO1xuICAgICAgICB9LCBfdGhpcy5wcm9wcy5kdXJhdGlvbiAqIDEwMDApO1xuICAgICAgfVxuICAgIH0sIF90aGlzLmNsZWFyQ2xvc2VUaW1lciA9IGZ1bmN0aW9uICgpIHtcbiAgICAgIGlmIChfdGhpcy5jbG9zZVRpbWVyKSB7XG4gICAgICAgIGNsZWFyVGltZW91dChfdGhpcy5jbG9zZVRpbWVyKTtcbiAgICAgICAgX3RoaXMuY2xvc2VUaW1lciA9IG51bGw7XG4gICAgICB9XG4gICAgfSwgX3RlbXApLCBfcG9zc2libGVDb25zdHJ1Y3RvclJldHVybihfdGhpcywgX3JldCk7XG4gIH1cblxuICBfY3JlYXRlQ2xhc3MoTm90aWNlLCBbe1xuICAgIGtleTogJ2NvbXBvbmVudERpZE1vdW50JyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gY29tcG9uZW50RGlkTW91bnQoKSB7XG4gICAgICB0aGlzLnN0YXJ0Q2xvc2VUaW1lcigpO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ2NvbXBvbmVudFdpbGxVbm1vdW50JyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gY29tcG9uZW50V2lsbFVubW91bnQoKSB7XG4gICAgICB0aGlzLmNsZWFyQ2xvc2VUaW1lcigpO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ3JlbmRlcicsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHJlbmRlcigpIHtcbiAgICAgIHZhciBfY2xhc3NOYW1lO1xuXG4gICAgICB2YXIgcHJvcHMgPSB0aGlzLnByb3BzO1xuICAgICAgdmFyIGNvbXBvbmVudENsYXNzID0gcHJvcHMucHJlZml4Q2xzICsgJy1ub3RpY2UnO1xuICAgICAgdmFyIGNsYXNzTmFtZSA9IChfY2xhc3NOYW1lID0ge30sIF9kZWZpbmVQcm9wZXJ0eShfY2xhc3NOYW1lLCAnJyArIGNvbXBvbmVudENsYXNzLCAxKSwgX2RlZmluZVByb3BlcnR5KF9jbGFzc05hbWUsIGNvbXBvbmVudENsYXNzICsgJy1jbG9zYWJsZScsIHByb3BzLmNsb3NhYmxlKSwgX2RlZmluZVByb3BlcnR5KF9jbGFzc05hbWUsIHByb3BzLmNsYXNzTmFtZSwgISFwcm9wcy5jbGFzc05hbWUpLCBfY2xhc3NOYW1lKTtcbiAgICAgIHJldHVybiBSZWFjdC5jcmVhdGVFbGVtZW50KFxuICAgICAgICAnZGl2JyxcbiAgICAgICAgeyBjbGFzc05hbWU6IGNsYXNzTmFtZXMoY2xhc3NOYW1lKSwgc3R5bGU6IHByb3BzLnN0eWxlLCBvbk1vdXNlRW50ZXI6IHRoaXMuY2xlYXJDbG9zZVRpbWVyLFxuICAgICAgICAgIG9uTW91c2VMZWF2ZTogdGhpcy5zdGFydENsb3NlVGltZXJcbiAgICAgICAgfSxcbiAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcbiAgICAgICAgICAnZGl2JyxcbiAgICAgICAgICB7IGNsYXNzTmFtZTogY29tcG9uZW50Q2xhc3MgKyAnLWNvbnRlbnQnIH0sXG4gICAgICAgICAgcHJvcHMuY2hpbGRyZW5cbiAgICAgICAgKSxcbiAgICAgICAgcHJvcHMuY2xvc2FibGUgPyBSZWFjdC5jcmVhdGVFbGVtZW50KFxuICAgICAgICAgICdhJyxcbiAgICAgICAgICB7IHRhYkluZGV4OiAnMCcsIG9uQ2xpY2s6IHRoaXMuY2xvc2UsIGNsYXNzTmFtZTogY29tcG9uZW50Q2xhc3MgKyAnLWNsb3NlJyB9LFxuICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nLCB7IGNsYXNzTmFtZTogY29tcG9uZW50Q2xhc3MgKyAnLWNsb3NlLXgnIH0pXG4gICAgICAgICkgOiBudWxsXG4gICAgICApO1xuICAgIH1cbiAgfV0pO1xuXG4gIHJldHVybiBOb3RpY2U7XG59KENvbXBvbmVudCk7XG5cbk5vdGljZS5wcm9wVHlwZXMgPSB7XG4gIGR1cmF0aW9uOiBQcm9wVHlwZXMubnVtYmVyLFxuICBvbkNsb3NlOiBQcm9wVHlwZXMuZnVuYyxcbiAgY2hpbGRyZW46IFByb3BUeXBlcy5hbnlcbn07XG5Ob3RpY2UuZGVmYXVsdFByb3BzID0ge1xuICBvbkVuZDogZnVuY3Rpb24gb25FbmQoKSB7fSxcbiAgb25DbG9zZTogZnVuY3Rpb24gb25DbG9zZSgpIHt9LFxuXG4gIGR1cmF0aW9uOiAxLjUsXG4gIHN0eWxlOiB7XG4gICAgcmlnaHQ6ICc1MCUnXG4gIH1cbn07XG5leHBvcnQgZGVmYXVsdCBOb3RpY2U7IiwiaW1wb3J0IF9vYmplY3RXaXRob3V0UHJvcGVydGllcyBmcm9tICdiYWJlbC1ydW50aW1lL2hlbHBlcnMvb2JqZWN0V2l0aG91dFByb3BlcnRpZXMnO1xuaW1wb3J0IF9kZWZpbmVQcm9wZXJ0eSBmcm9tICdiYWJlbC1ydW50aW1lL2hlbHBlcnMvZGVmaW5lUHJvcGVydHknO1xuaW1wb3J0IF9leHRlbmRzIGZyb20gJ2JhYmVsLXJ1bnRpbWUvaGVscGVycy9leHRlbmRzJztcbmltcG9ydCBfY2xhc3NDYWxsQ2hlY2sgZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL2NsYXNzQ2FsbENoZWNrJztcbmltcG9ydCBfY3JlYXRlQ2xhc3MgZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL2NyZWF0ZUNsYXNzJztcbmltcG9ydCBfcG9zc2libGVDb25zdHJ1Y3RvclJldHVybiBmcm9tICdiYWJlbC1ydW50aW1lL2hlbHBlcnMvcG9zc2libGVDb25zdHJ1Y3RvclJldHVybic7XG5pbXBvcnQgX2luaGVyaXRzIGZyb20gJ2JhYmVsLXJ1bnRpbWUvaGVscGVycy9pbmhlcml0cyc7XG5pbXBvcnQgUmVhY3QsIHsgQ29tcG9uZW50IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcbmltcG9ydCBSZWFjdERPTSBmcm9tICdyZWFjdC1kb20nO1xuaW1wb3J0IEFuaW1hdGUgZnJvbSAncmMtYW5pbWF0ZSc7XG5pbXBvcnQgY3JlYXRlQ2hhaW5lZEZ1bmN0aW9uIGZyb20gJ3JjLXV0aWwvZXMvY3JlYXRlQ2hhaW5lZEZ1bmN0aW9uJztcbmltcG9ydCBjbGFzc25hbWVzIGZyb20gJ2NsYXNzbmFtZXMnO1xuaW1wb3J0IE5vdGljZSBmcm9tICcuL05vdGljZSc7XG5cbnZhciBzZWVkID0gMDtcbnZhciBub3cgPSBEYXRlLm5vdygpO1xuXG5mdW5jdGlvbiBnZXRVdWlkKCkge1xuICByZXR1cm4gJ3JjTm90aWZpY2F0aW9uXycgKyBub3cgKyAnXycgKyBzZWVkKys7XG59XG5cbnZhciBOb3RpZmljYXRpb24gPSBmdW5jdGlvbiAoX0NvbXBvbmVudCkge1xuICBfaW5oZXJpdHMoTm90aWZpY2F0aW9uLCBfQ29tcG9uZW50KTtcblxuICBmdW5jdGlvbiBOb3RpZmljYXRpb24oKSB7XG4gICAgdmFyIF9yZWY7XG5cbiAgICB2YXIgX3RlbXAsIF90aGlzLCBfcmV0O1xuXG4gICAgX2NsYXNzQ2FsbENoZWNrKHRoaXMsIE5vdGlmaWNhdGlvbik7XG5cbiAgICBmb3IgKHZhciBfbGVuID0gYXJndW1lbnRzLmxlbmd0aCwgYXJncyA9IEFycmF5KF9sZW4pLCBfa2V5ID0gMDsgX2tleSA8IF9sZW47IF9rZXkrKykge1xuICAgICAgYXJnc1tfa2V5XSA9IGFyZ3VtZW50c1tfa2V5XTtcbiAgICB9XG5cbiAgICByZXR1cm4gX3JldCA9IChfdGVtcCA9IChfdGhpcyA9IF9wb3NzaWJsZUNvbnN0cnVjdG9yUmV0dXJuKHRoaXMsIChfcmVmID0gTm90aWZpY2F0aW9uLl9fcHJvdG9fXyB8fCBPYmplY3QuZ2V0UHJvdG90eXBlT2YoTm90aWZpY2F0aW9uKSkuY2FsbC5hcHBseShfcmVmLCBbdGhpc10uY29uY2F0KGFyZ3MpKSksIF90aGlzKSwgX3RoaXMuc3RhdGUgPSB7XG4gICAgICBub3RpY2VzOiBbXVxuICAgIH0sIF90aGlzLmFkZCA9IGZ1bmN0aW9uIChub3RpY2UpIHtcbiAgICAgIHZhciBrZXkgPSBub3RpY2Uua2V5ID0gbm90aWNlLmtleSB8fCBnZXRVdWlkKCk7XG4gICAgICBfdGhpcy5zZXRTdGF0ZShmdW5jdGlvbiAocHJldmlvdXNTdGF0ZSkge1xuICAgICAgICB2YXIgbm90aWNlcyA9IHByZXZpb3VzU3RhdGUubm90aWNlcztcbiAgICAgICAgaWYgKCFub3RpY2VzLmZpbHRlcihmdW5jdGlvbiAodikge1xuICAgICAgICAgIHJldHVybiB2LmtleSA9PT0ga2V5O1xuICAgICAgICB9KS5sZW5ndGgpIHtcbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgbm90aWNlczogbm90aWNlcy5jb25jYXQobm90aWNlKVxuICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0sIF90aGlzLnJlbW92ZSA9IGZ1bmN0aW9uIChrZXkpIHtcbiAgICAgIF90aGlzLnNldFN0YXRlKGZ1bmN0aW9uIChwcmV2aW91c1N0YXRlKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgbm90aWNlczogcHJldmlvdXNTdGF0ZS5ub3RpY2VzLmZpbHRlcihmdW5jdGlvbiAobm90aWNlKSB7XG4gICAgICAgICAgICByZXR1cm4gbm90aWNlLmtleSAhPT0ga2V5O1xuICAgICAgICAgIH0pXG4gICAgICAgIH07XG4gICAgICB9KTtcbiAgICB9LCBfdGVtcCksIF9wb3NzaWJsZUNvbnN0cnVjdG9yUmV0dXJuKF90aGlzLCBfcmV0KTtcbiAgfVxuXG4gIF9jcmVhdGVDbGFzcyhOb3RpZmljYXRpb24sIFt7XG4gICAga2V5OiAnZ2V0VHJhbnNpdGlvbk5hbWUnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBnZXRUcmFuc2l0aW9uTmFtZSgpIHtcbiAgICAgIHZhciBwcm9wcyA9IHRoaXMucHJvcHM7XG4gICAgICB2YXIgdHJhbnNpdGlvbk5hbWUgPSBwcm9wcy50cmFuc2l0aW9uTmFtZTtcbiAgICAgIGlmICghdHJhbnNpdGlvbk5hbWUgJiYgcHJvcHMuYW5pbWF0aW9uKSB7XG4gICAgICAgIHRyYW5zaXRpb25OYW1lID0gcHJvcHMucHJlZml4Q2xzICsgJy0nICsgcHJvcHMuYW5pbWF0aW9uO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHRyYW5zaXRpb25OYW1lO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ3JlbmRlcicsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHJlbmRlcigpIHtcbiAgICAgIHZhciBfdGhpczIgPSB0aGlzLFxuICAgICAgICAgIF9jbGFzc05hbWU7XG5cbiAgICAgIHZhciBwcm9wcyA9IHRoaXMucHJvcHM7XG4gICAgICB2YXIgbm90aWNlTm9kZXMgPSB0aGlzLnN0YXRlLm5vdGljZXMubWFwKGZ1bmN0aW9uIChub3RpY2UpIHtcbiAgICAgICAgdmFyIG9uQ2xvc2UgPSBjcmVhdGVDaGFpbmVkRnVuY3Rpb24oX3RoaXMyLnJlbW92ZS5iaW5kKF90aGlzMiwgbm90aWNlLmtleSksIG5vdGljZS5vbkNsb3NlKTtcbiAgICAgICAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXG4gICAgICAgICAgTm90aWNlLFxuICAgICAgICAgIF9leHRlbmRzKHtcbiAgICAgICAgICAgIHByZWZpeENsczogcHJvcHMucHJlZml4Q2xzXG4gICAgICAgICAgfSwgbm90aWNlLCB7XG4gICAgICAgICAgICBvbkNsb3NlOiBvbkNsb3NlXG4gICAgICAgICAgfSksXG4gICAgICAgICAgbm90aWNlLmNvbnRlbnRcbiAgICAgICAgKTtcbiAgICAgIH0pO1xuICAgICAgdmFyIGNsYXNzTmFtZSA9IChfY2xhc3NOYW1lID0ge30sIF9kZWZpbmVQcm9wZXJ0eShfY2xhc3NOYW1lLCBwcm9wcy5wcmVmaXhDbHMsIDEpLCBfZGVmaW5lUHJvcGVydHkoX2NsYXNzTmFtZSwgcHJvcHMuY2xhc3NOYW1lLCAhIXByb3BzLmNsYXNzTmFtZSksIF9jbGFzc05hbWUpO1xuICAgICAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXG4gICAgICAgICdkaXYnLFxuICAgICAgICB7IGNsYXNzTmFtZTogY2xhc3NuYW1lcyhjbGFzc05hbWUpLCBzdHlsZTogcHJvcHMuc3R5bGUgfSxcbiAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcbiAgICAgICAgICBBbmltYXRlLFxuICAgICAgICAgIHsgdHJhbnNpdGlvbk5hbWU6IHRoaXMuZ2V0VHJhbnNpdGlvbk5hbWUoKSB9LFxuICAgICAgICAgIG5vdGljZU5vZGVzXG4gICAgICAgIClcbiAgICAgICk7XG4gICAgfVxuICB9XSk7XG5cbiAgcmV0dXJuIE5vdGlmaWNhdGlvbjtcbn0oQ29tcG9uZW50KTtcblxuTm90aWZpY2F0aW9uLnByb3BUeXBlcyA9IHtcbiAgcHJlZml4Q2xzOiBQcm9wVHlwZXMuc3RyaW5nLFxuICB0cmFuc2l0aW9uTmFtZTogUHJvcFR5cGVzLnN0cmluZyxcbiAgYW5pbWF0aW9uOiBQcm9wVHlwZXMub25lT2ZUeXBlKFtQcm9wVHlwZXMuc3RyaW5nLCBQcm9wVHlwZXMub2JqZWN0XSksXG4gIHN0eWxlOiBQcm9wVHlwZXMub2JqZWN0XG59O1xuTm90aWZpY2F0aW9uLmRlZmF1bHRQcm9wcyA9IHtcbiAgcHJlZml4Q2xzOiAncmMtbm90aWZpY2F0aW9uJyxcbiAgYW5pbWF0aW9uOiAnZmFkZScsXG4gIHN0eWxlOiB7XG4gICAgdG9wOiA2NSxcbiAgICBsZWZ0OiAnNTAlJ1xuICB9XG59O1xuXG5cbk5vdGlmaWNhdGlvbi5uZXdJbnN0YW5jZSA9IGZ1bmN0aW9uIG5ld05vdGlmaWNhdGlvbkluc3RhbmNlKHByb3BlcnRpZXMsIGNhbGxiYWNrKSB7XG4gIHZhciBfcmVmMiA9IHByb3BlcnRpZXMgfHwge30sXG4gICAgICBnZXRDb250YWluZXIgPSBfcmVmMi5nZXRDb250YWluZXIsXG4gICAgICBwcm9wcyA9IF9vYmplY3RXaXRob3V0UHJvcGVydGllcyhfcmVmMiwgWydnZXRDb250YWluZXInXSk7XG5cbiAgdmFyIGRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICBpZiAoZ2V0Q29udGFpbmVyKSB7XG4gICAgdmFyIHJvb3QgPSBnZXRDb250YWluZXIoKTtcbiAgICByb290LmFwcGVuZENoaWxkKGRpdik7XG4gIH0gZWxzZSB7XG4gICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChkaXYpO1xuICB9XG4gIHZhciBjYWxsZWQgPSBmYWxzZTtcbiAgZnVuY3Rpb24gcmVmKG5vdGlmaWNhdGlvbikge1xuICAgIGlmIChjYWxsZWQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY2FsbGVkID0gdHJ1ZTtcbiAgICBjYWxsYmFjayh7XG4gICAgICBub3RpY2U6IGZ1bmN0aW9uIG5vdGljZShub3RpY2VQcm9wcykge1xuICAgICAgICBub3RpZmljYXRpb24uYWRkKG5vdGljZVByb3BzKTtcbiAgICAgIH0sXG4gICAgICByZW1vdmVOb3RpY2U6IGZ1bmN0aW9uIHJlbW92ZU5vdGljZShrZXkpIHtcbiAgICAgICAgbm90aWZpY2F0aW9uLnJlbW92ZShrZXkpO1xuICAgICAgfSxcblxuICAgICAgY29tcG9uZW50OiBub3RpZmljYXRpb24sXG4gICAgICBkZXN0cm95OiBmdW5jdGlvbiBkZXN0cm95KCkge1xuICAgICAgICBSZWFjdERPTS51bm1vdW50Q29tcG9uZW50QXROb2RlKGRpdik7XG4gICAgICAgIGRpdi5wYXJlbnROb2RlLnJlbW92ZUNoaWxkKGRpdik7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbiAgUmVhY3RET00ucmVuZGVyKFJlYWN0LmNyZWF0ZUVsZW1lbnQoTm90aWZpY2F0aW9uLCBfZXh0ZW5kcyh7fSwgcHJvcHMsIHsgcmVmOiByZWYgfSkpLCBkaXYpO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgTm90aWZpY2F0aW9uOyIsImltcG9ydCBOb3RpZmljYXRpb24gZnJvbSAnLi9Ob3RpZmljYXRpb24nO1xuZXhwb3J0IGRlZmF1bHQgTm90aWZpY2F0aW9uOyIsImltcG9ydCBfZXh0ZW5kcyBmcm9tICdiYWJlbC1ydW50aW1lL2hlbHBlcnMvZXh0ZW5kcyc7XG5pbXBvcnQgX2NsYXNzQ2FsbENoZWNrIGZyb20gJ2JhYmVsLXJ1bnRpbWUvaGVscGVycy9jbGFzc0NhbGxDaGVjayc7XG5pbXBvcnQgX3Bvc3NpYmxlQ29uc3RydWN0b3JSZXR1cm4gZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL3Bvc3NpYmxlQ29uc3RydWN0b3JSZXR1cm4nO1xuaW1wb3J0IF9pbmhlcml0cyBmcm9tICdiYWJlbC1ydW50aW1lL2hlbHBlcnMvaW5oZXJpdHMnO1xuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcyc7XG5pbXBvcnQgeyBjb25uZWN0IH0gZnJvbSAnbWluaS1zdG9yZSc7XG5pbXBvcnQgQ29sR3JvdXAgZnJvbSAnLi9Db2xHcm91cCc7XG5pbXBvcnQgVGFibGVIZWFkZXIgZnJvbSAnLi9UYWJsZUhlYWRlcic7XG5pbXBvcnQgVGFibGVSb3cgZnJvbSAnLi9UYWJsZVJvdyc7XG5pbXBvcnQgRXhwYW5kYWJsZVJvdyBmcm9tICcuL0V4cGFuZGFibGVSb3cnO1xuXG52YXIgQmFzZVRhYmxlID0gZnVuY3Rpb24gKF9SZWFjdCRDb21wb25lbnQpIHtcbiAgX2luaGVyaXRzKEJhc2VUYWJsZSwgX1JlYWN0JENvbXBvbmVudCk7XG5cbiAgZnVuY3Rpb24gQmFzZVRhYmxlKCkge1xuICAgIHZhciBfdGVtcCwgX3RoaXMsIF9yZXQ7XG5cbiAgICBfY2xhc3NDYWxsQ2hlY2sodGhpcywgQmFzZVRhYmxlKTtcblxuICAgIGZvciAodmFyIF9sZW4gPSBhcmd1bWVudHMubGVuZ3RoLCBhcmdzID0gQXJyYXkoX2xlbiksIF9rZXkgPSAwOyBfa2V5IDwgX2xlbjsgX2tleSsrKSB7XG4gICAgICBhcmdzW19rZXldID0gYXJndW1lbnRzW19rZXldO1xuICAgIH1cblxuICAgIHJldHVybiBfcmV0ID0gKF90ZW1wID0gKF90aGlzID0gX3Bvc3NpYmxlQ29uc3RydWN0b3JSZXR1cm4odGhpcywgX1JlYWN0JENvbXBvbmVudC5jYWxsLmFwcGx5KF9SZWFjdCRDb21wb25lbnQsIFt0aGlzXS5jb25jYXQoYXJncykpKSwgX3RoaXMpLCBfdGhpcy5oYW5kbGVSb3dIb3ZlciA9IGZ1bmN0aW9uIChpc0hvdmVyLCBrZXkpIHtcbiAgICAgIF90aGlzLnByb3BzLnN0b3JlLnNldFN0YXRlKHtcbiAgICAgICAgY3VycmVudEhvdmVyS2V5OiBpc0hvdmVyID8ga2V5IDogbnVsbFxuICAgICAgfSk7XG4gICAgfSwgX3RoaXMucmVuZGVyUm93cyA9IGZ1bmN0aW9uIChyZW5kZXJEYXRhLCBpbmRlbnQpIHtcbiAgICAgIHZhciBhbmNlc3RvcktleXMgPSBhcmd1bWVudHMubGVuZ3RoID4gMiAmJiBhcmd1bWVudHNbMl0gIT09IHVuZGVmaW5lZCA/IGFyZ3VtZW50c1syXSA6IFtdO1xuICAgICAgdmFyIHRhYmxlID0gX3RoaXMuY29udGV4dC50YWJsZTtcbiAgICAgIHZhciBjb2x1bW5NYW5hZ2VyID0gdGFibGUuY29sdW1uTWFuYWdlcixcbiAgICAgICAgICBjb21wb25lbnRzID0gdGFibGUuY29tcG9uZW50cztcbiAgICAgIHZhciBfdGFibGUkcHJvcHMgPSB0YWJsZS5wcm9wcyxcbiAgICAgICAgICBwcmVmaXhDbHMgPSBfdGFibGUkcHJvcHMucHJlZml4Q2xzLFxuICAgICAgICAgIGNoaWxkcmVuQ29sdW1uTmFtZSA9IF90YWJsZSRwcm9wcy5jaGlsZHJlbkNvbHVtbk5hbWUsXG4gICAgICAgICAgcm93Q2xhc3NOYW1lID0gX3RhYmxlJHByb3BzLnJvd0NsYXNzTmFtZSxcbiAgICAgICAgICByb3dSZWYgPSBfdGFibGUkcHJvcHMucm93UmVmLFxuICAgICAgICAgIG9uUm93Q2xpY2sgPSBfdGFibGUkcHJvcHMub25Sb3dDbGljayxcbiAgICAgICAgICBvblJvd0RvdWJsZUNsaWNrID0gX3RhYmxlJHByb3BzLm9uUm93RG91YmxlQ2xpY2ssXG4gICAgICAgICAgb25Sb3dDb250ZXh0TWVudSA9IF90YWJsZSRwcm9wcy5vblJvd0NvbnRleHRNZW51LFxuICAgICAgICAgIG9uUm93TW91c2VFbnRlciA9IF90YWJsZSRwcm9wcy5vblJvd01vdXNlRW50ZXIsXG4gICAgICAgICAgb25Sb3dNb3VzZUxlYXZlID0gX3RhYmxlJHByb3BzLm9uUm93TW91c2VMZWF2ZSxcbiAgICAgICAgICBvblJvdyA9IF90YWJsZSRwcm9wcy5vblJvdztcbiAgICAgIHZhciBfdGhpcyRwcm9wcyA9IF90aGlzLnByb3BzLFxuICAgICAgICAgIGdldFJvd0tleSA9IF90aGlzJHByb3BzLmdldFJvd0tleSxcbiAgICAgICAgICBmaXhlZCA9IF90aGlzJHByb3BzLmZpeGVkLFxuICAgICAgICAgIGV4cGFuZGVyID0gX3RoaXMkcHJvcHMuZXhwYW5kZXIsXG4gICAgICAgICAgaXNBbnlDb2x1bW5zRml4ZWQgPSBfdGhpcyRwcm9wcy5pc0FueUNvbHVtbnNGaXhlZDtcblxuXG4gICAgICB2YXIgcm93cyA9IFtdO1xuXG4gICAgICB2YXIgX2xvb3AgPSBmdW5jdGlvbiBfbG9vcChpKSB7XG4gICAgICAgIHZhciByZWNvcmQgPSByZW5kZXJEYXRhW2ldO1xuICAgICAgICB2YXIga2V5ID0gZ2V0Um93S2V5KHJlY29yZCwgaSk7XG4gICAgICAgIHZhciBjbGFzc05hbWUgPSB0eXBlb2Ygcm93Q2xhc3NOYW1lID09PSAnc3RyaW5nJyA/IHJvd0NsYXNzTmFtZSA6IHJvd0NsYXNzTmFtZShyZWNvcmQsIGksIGluZGVudCk7XG5cbiAgICAgICAgdmFyIG9uSG92ZXJQcm9wcyA9IHt9O1xuICAgICAgICBpZiAoY29sdW1uTWFuYWdlci5pc0FueUNvbHVtbnNGaXhlZCgpKSB7XG4gICAgICAgICAgb25Ib3ZlclByb3BzLm9uSG92ZXIgPSBfdGhpcy5oYW5kbGVSb3dIb3ZlcjtcbiAgICAgICAgfVxuXG4gICAgICAgIHZhciBsZWFmQ29sdW1ucyA9IHZvaWQgMDtcbiAgICAgICAgaWYgKGZpeGVkID09PSAnbGVmdCcpIHtcbiAgICAgICAgICBsZWFmQ29sdW1ucyA9IGNvbHVtbk1hbmFnZXIubGVmdExlYWZDb2x1bW5zKCk7XG4gICAgICAgIH0gZWxzZSBpZiAoZml4ZWQgPT09ICdyaWdodCcpIHtcbiAgICAgICAgICBsZWFmQ29sdW1ucyA9IGNvbHVtbk1hbmFnZXIucmlnaHRMZWFmQ29sdW1ucygpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGxlYWZDb2x1bW5zID0gY29sdW1uTWFuYWdlci5sZWFmQ29sdW1ucygpO1xuICAgICAgICB9XG5cbiAgICAgICAgdmFyIHJvd1ByZWZpeENscyA9IHByZWZpeENscyArICctcm93JztcblxuICAgICAgICB2YXIgcm93ID0gUmVhY3QuY3JlYXRlRWxlbWVudChcbiAgICAgICAgICBFeHBhbmRhYmxlUm93LFxuICAgICAgICAgIF9leHRlbmRzKHt9LCBleHBhbmRlci5wcm9wcywge1xuICAgICAgICAgICAgZml4ZWQ6IGZpeGVkLFxuICAgICAgICAgICAgaW5kZXg6IGksXG4gICAgICAgICAgICBwcmVmaXhDbHM6IHJvd1ByZWZpeENscyxcbiAgICAgICAgICAgIHJlY29yZDogcmVjb3JkLFxuICAgICAgICAgICAga2V5OiBrZXksXG4gICAgICAgICAgICByb3dLZXk6IGtleSxcbiAgICAgICAgICAgIG9uUm93Q2xpY2s6IG9uUm93Q2xpY2ssXG4gICAgICAgICAgICBuZWVkSW5kZW50U3BhY2VkOiBleHBhbmRlci5uZWVkSW5kZW50U3BhY2VkLFxuICAgICAgICAgICAgb25FeHBhbmRlZENoYW5nZTogZXhwYW5kZXIuaGFuZGxlRXhwYW5kQ2hhbmdlXG4gICAgICAgICAgfSksXG4gICAgICAgICAgZnVuY3Rpb24gKGV4cGFuZGFibGVSb3cpIHtcbiAgICAgICAgICAgIHJldHVybiAoLy8gZXNsaW50LWRpc2FibGUtbGluZVxuICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFRhYmxlUm93LCBfZXh0ZW5kcyh7XG4gICAgICAgICAgICAgICAgZml4ZWQ6IGZpeGVkLFxuICAgICAgICAgICAgICAgIGluZGVudDogaW5kZW50LFxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZTogY2xhc3NOYW1lLFxuICAgICAgICAgICAgICAgIHJlY29yZDogcmVjb3JkLFxuICAgICAgICAgICAgICAgIGluZGV4OiBpLFxuICAgICAgICAgICAgICAgIHByZWZpeENsczogcm93UHJlZml4Q2xzLFxuICAgICAgICAgICAgICAgIGNoaWxkcmVuQ29sdW1uTmFtZTogY2hpbGRyZW5Db2x1bW5OYW1lLFxuICAgICAgICAgICAgICAgIGNvbHVtbnM6IGxlYWZDb2x1bW5zLFxuICAgICAgICAgICAgICAgIG9uUm93OiBvblJvdyxcbiAgICAgICAgICAgICAgICBvblJvd0RvdWJsZUNsaWNrOiBvblJvd0RvdWJsZUNsaWNrLFxuICAgICAgICAgICAgICAgIG9uUm93Q29udGV4dE1lbnU6IG9uUm93Q29udGV4dE1lbnUsXG4gICAgICAgICAgICAgICAgb25Sb3dNb3VzZUVudGVyOiBvblJvd01vdXNlRW50ZXIsXG4gICAgICAgICAgICAgICAgb25Sb3dNb3VzZUxlYXZlOiBvblJvd01vdXNlTGVhdmVcbiAgICAgICAgICAgICAgfSwgb25Ib3ZlclByb3BzLCB7XG4gICAgICAgICAgICAgICAgcm93S2V5OiBrZXksXG4gICAgICAgICAgICAgICAgYW5jZXN0b3JLZXlzOiBhbmNlc3RvcktleXMsXG4gICAgICAgICAgICAgICAgcmVmOiByb3dSZWYocmVjb3JkLCBpLCBpbmRlbnQpLFxuICAgICAgICAgICAgICAgIGNvbXBvbmVudHM6IGNvbXBvbmVudHMsXG4gICAgICAgICAgICAgICAgaXNBbnlDb2x1bW5zRml4ZWQ6IGlzQW55Q29sdW1uc0ZpeGVkXG4gICAgICAgICAgICAgIH0sIGV4cGFuZGFibGVSb3cpKVxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9XG4gICAgICAgICk7XG5cbiAgICAgICAgcm93cy5wdXNoKHJvdyk7XG5cbiAgICAgICAgZXhwYW5kZXIucmVuZGVyUm93cyhfdGhpcy5yZW5kZXJSb3dzLCByb3dzLCByZWNvcmQsIGksIGluZGVudCwgZml4ZWQsIGtleSwgYW5jZXN0b3JLZXlzKTtcbiAgICAgIH07XG5cbiAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgcmVuZGVyRGF0YS5sZW5ndGg7IGkrKykge1xuICAgICAgICBfbG9vcChpKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiByb3dzO1xuICAgIH0sIF90ZW1wKSwgX3Bvc3NpYmxlQ29uc3RydWN0b3JSZXR1cm4oX3RoaXMsIF9yZXQpO1xuICB9XG5cbiAgQmFzZVRhYmxlLnByb3RvdHlwZS5yZW5kZXIgPSBmdW5jdGlvbiByZW5kZXIoKSB7XG4gICAgdmFyIHRhYmxlID0gdGhpcy5jb250ZXh0LnRhYmxlO1xuICAgIHZhciBjb21wb25lbnRzID0gdGFibGUuY29tcG9uZW50cztcbiAgICB2YXIgX3RhYmxlJHByb3BzMiA9IHRhYmxlLnByb3BzLFxuICAgICAgICBwcmVmaXhDbHMgPSBfdGFibGUkcHJvcHMyLnByZWZpeENscyxcbiAgICAgICAgc2Nyb2xsID0gX3RhYmxlJHByb3BzMi5zY3JvbGwsXG4gICAgICAgIGRhdGEgPSBfdGFibGUkcHJvcHMyLmRhdGEsXG4gICAgICAgIGdldEJvZHlXcmFwcGVyID0gX3RhYmxlJHByb3BzMi5nZXRCb2R5V3JhcHBlcjtcbiAgICB2YXIgX3Byb3BzID0gdGhpcy5wcm9wcyxcbiAgICAgICAgZXhwYW5kZXIgPSBfcHJvcHMuZXhwYW5kZXIsXG4gICAgICAgIHRhYmxlQ2xhc3NOYW1lID0gX3Byb3BzLnRhYmxlQ2xhc3NOYW1lLFxuICAgICAgICBoYXNIZWFkID0gX3Byb3BzLmhhc0hlYWQsXG4gICAgICAgIGhhc0JvZHkgPSBfcHJvcHMuaGFzQm9keSxcbiAgICAgICAgZml4ZWQgPSBfcHJvcHMuZml4ZWQsXG4gICAgICAgIGNvbHVtbnMgPSBfcHJvcHMuY29sdW1ucztcblxuICAgIHZhciB0YWJsZVN0eWxlID0ge307XG5cbiAgICBpZiAoIWZpeGVkICYmIHNjcm9sbC54KSB7XG4gICAgICAvLyBub3Qgc2V0IHdpZHRoLCB0aGVuIHVzZSBjb250ZW50IGZpeGVkIHdpZHRoXG4gICAgICBpZiAoc2Nyb2xsLnggPT09IHRydWUpIHtcbiAgICAgICAgdGFibGVTdHlsZS50YWJsZUxheW91dCA9ICdmaXhlZCc7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0YWJsZVN0eWxlLndpZHRoID0gc2Nyb2xsLng7XG4gICAgICB9XG4gICAgfVxuXG4gICAgdmFyIFRhYmxlID0gaGFzQm9keSA/IGNvbXBvbmVudHMudGFibGUgOiAndGFibGUnO1xuICAgIHZhciBCb2R5V3JhcHBlciA9IGNvbXBvbmVudHMuYm9keS53cmFwcGVyO1xuXG4gICAgdmFyIGJvZHkgPSB2b2lkIDA7XG4gICAgaWYgKGhhc0JvZHkpIHtcbiAgICAgIGJvZHkgPSBSZWFjdC5jcmVhdGVFbGVtZW50KFxuICAgICAgICBCb2R5V3JhcHBlcixcbiAgICAgICAgeyBjbGFzc05hbWU6IHByZWZpeENscyArICctdGJvZHknIH0sXG4gICAgICAgIHRoaXMucmVuZGVyUm93cyhkYXRhLCAwKVxuICAgICAgKTtcbiAgICAgIGlmIChnZXRCb2R5V3JhcHBlcikge1xuICAgICAgICBib2R5ID0gZ2V0Qm9keVdyYXBwZXIoYm9keSk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXG4gICAgICBUYWJsZSxcbiAgICAgIHsgY2xhc3NOYW1lOiB0YWJsZUNsYXNzTmFtZSwgc3R5bGU6IHRhYmxlU3R5bGUsIGtleTogJ3RhYmxlJyB9LFxuICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChDb2xHcm91cCwgeyBjb2x1bW5zOiBjb2x1bW5zLCBmaXhlZDogZml4ZWQgfSksXG4gICAgICBoYXNIZWFkICYmIFJlYWN0LmNyZWF0ZUVsZW1lbnQoVGFibGVIZWFkZXIsIHsgZXhwYW5kZXI6IGV4cGFuZGVyLCBjb2x1bW5zOiBjb2x1bW5zLCBmaXhlZDogZml4ZWQgfSksXG4gICAgICBib2R5XG4gICAgKTtcbiAgfTtcblxuICByZXR1cm4gQmFzZVRhYmxlO1xufShSZWFjdC5Db21wb25lbnQpO1xuXG5CYXNlVGFibGUucHJvcFR5cGVzID0ge1xuICBmaXhlZDogUHJvcFR5cGVzLm9uZU9mVHlwZShbUHJvcFR5cGVzLnN0cmluZywgUHJvcFR5cGVzLmJvb2xdKSxcbiAgY29sdW1uczogUHJvcFR5cGVzLmFycmF5LmlzUmVxdWlyZWQsXG4gIHRhYmxlQ2xhc3NOYW1lOiBQcm9wVHlwZXMuc3RyaW5nLmlzUmVxdWlyZWQsXG4gIGhhc0hlYWQ6IFByb3BUeXBlcy5ib29sLmlzUmVxdWlyZWQsXG4gIGhhc0JvZHk6IFByb3BUeXBlcy5ib29sLmlzUmVxdWlyZWQsXG4gIHN0b3JlOiBQcm9wVHlwZXMub2JqZWN0LmlzUmVxdWlyZWQsXG4gIGV4cGFuZGVyOiBQcm9wVHlwZXMub2JqZWN0LmlzUmVxdWlyZWQsXG4gIGdldFJvd0tleTogUHJvcFR5cGVzLmZ1bmMsXG4gIGlzQW55Q29sdW1uc0ZpeGVkOiBQcm9wVHlwZXMuYm9vbFxufTtcbkJhc2VUYWJsZS5jb250ZXh0VHlwZXMgPSB7XG4gIHRhYmxlOiBQcm9wVHlwZXMuYW55XG59O1xuXG5cbmV4cG9ydCBkZWZhdWx0IGNvbm5lY3QoKShCYXNlVGFibGUpOyIsImltcG9ydCBfZXh0ZW5kcyBmcm9tICdiYWJlbC1ydW50aW1lL2hlbHBlcnMvZXh0ZW5kcyc7XG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcbmltcG9ydCB7IG1lYXN1cmVTY3JvbGxiYXIgfSBmcm9tICcuL3V0aWxzJztcbmltcG9ydCBCYXNlVGFibGUgZnJvbSAnLi9CYXNlVGFibGUnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBCb2R5VGFibGUocHJvcHMsIF9yZWYpIHtcbiAgdmFyIHRhYmxlID0gX3JlZi50YWJsZTtcbiAgdmFyIF90YWJsZSRwcm9wcyA9IHRhYmxlLnByb3BzLFxuICAgICAgcHJlZml4Q2xzID0gX3RhYmxlJHByb3BzLnByZWZpeENscyxcbiAgICAgIHNjcm9sbCA9IF90YWJsZSRwcm9wcy5zY3JvbGw7XG4gIHZhciBjb2x1bW5zID0gcHJvcHMuY29sdW1ucyxcbiAgICAgIGZpeGVkID0gcHJvcHMuZml4ZWQsXG4gICAgICB0YWJsZUNsYXNzTmFtZSA9IHByb3BzLnRhYmxlQ2xhc3NOYW1lLFxuICAgICAgZ2V0Um93S2V5ID0gcHJvcHMuZ2V0Um93S2V5LFxuICAgICAgaGFuZGxlQm9keVNjcm9sbCA9IHByb3BzLmhhbmRsZUJvZHlTY3JvbGwsXG4gICAgICBoYW5kbGVXaGVlbCA9IHByb3BzLmhhbmRsZVdoZWVsLFxuICAgICAgZXhwYW5kZXIgPSBwcm9wcy5leHBhbmRlcixcbiAgICAgIGlzQW55Q29sdW1uc0ZpeGVkID0gcHJvcHMuaXNBbnlDb2x1bW5zRml4ZWQ7XG4gIHZhciBzYXZlUmVmID0gdGFibGUuc2F2ZVJlZjtcbiAgdmFyIHVzZUZpeGVkSGVhZGVyID0gdGFibGUucHJvcHMudXNlRml4ZWRIZWFkZXI7XG5cbiAgdmFyIGJvZHlTdHlsZSA9IF9leHRlbmRzKHt9LCB0YWJsZS5wcm9wcy5ib2R5U3R5bGUpO1xuICB2YXIgaW5uZXJCb2R5U3R5bGUgPSB7fTtcblxuICBpZiAoc2Nyb2xsLnggfHwgZml4ZWQpIHtcbiAgICBib2R5U3R5bGUub3ZlcmZsb3dYID0gYm9keVN0eWxlLm92ZXJmbG93WCB8fCAnYXV0byc7XG4gICAgLy8gRml4IHdlaXJlZCB3ZWJraXQgcmVuZGVyIGJ1Z1xuICAgIC8vIGh0dHBzOi8vZ2l0aHViLmNvbS9hbnQtZGVzaWduL2FudC1kZXNpZ24vaXNzdWVzLzc3ODNcbiAgICBib2R5U3R5bGUuV2Via2l0VHJhbnNmb3JtID0gJ3RyYW5zbGF0ZTNkICgwLCAwLCAwKSc7XG4gIH1cblxuICBpZiAoc2Nyb2xsLnkpIHtcbiAgICAvLyBtYXhIZWlnaHQgd2lsbCBtYWtlIGZpeGVkLVRhYmxlIHNjcm9sbGluZyBub3Qgd29ya2luZ1xuICAgIC8vIHNvIHdlIG9ubHkgc2V0IG1heEhlaWdodCB0byBib2R5LVRhYmxlIGhlcmVcbiAgICBpZiAoZml4ZWQpIHtcbiAgICAgIGlubmVyQm9keVN0eWxlLm1heEhlaWdodCA9IGJvZHlTdHlsZS5tYXhIZWlnaHQgfHwgc2Nyb2xsLnk7XG4gICAgICBpbm5lckJvZHlTdHlsZS5vdmVyZmxvd1kgPSBib2R5U3R5bGUub3ZlcmZsb3dZIHx8ICdzY3JvbGwnO1xuICAgIH0gZWxzZSB7XG4gICAgICBib2R5U3R5bGUubWF4SGVpZ2h0ID0gYm9keVN0eWxlLm1heEhlaWdodCB8fCBzY3JvbGwueTtcbiAgICB9XG4gICAgYm9keVN0eWxlLm92ZXJmbG93WSA9IGJvZHlTdHlsZS5vdmVyZmxvd1kgfHwgJ3Njcm9sbCc7XG4gICAgdXNlRml4ZWRIZWFkZXIgPSB0cnVlO1xuXG4gICAgLy8gQWRkIG5lZ2F0aXZlIG1hcmdpbiBib3R0b20gZm9yIHNjcm9sbCBiYXIgb3ZlcmZsb3cgYnVnXG4gICAgdmFyIHNjcm9sbGJhcldpZHRoID0gbWVhc3VyZVNjcm9sbGJhcigpO1xuICAgIGlmIChzY3JvbGxiYXJXaWR0aCA+IDAgJiYgZml4ZWQpIHtcbiAgICAgIGJvZHlTdHlsZS5tYXJnaW5Cb3R0b20gPSAnLScgKyBzY3JvbGxiYXJXaWR0aCArICdweCc7XG4gICAgICBib2R5U3R5bGUucGFkZGluZ0JvdHRvbSA9ICcwcHgnO1xuICAgIH1cbiAgfVxuXG4gIHZhciBiYXNlVGFibGUgPSBSZWFjdC5jcmVhdGVFbGVtZW50KEJhc2VUYWJsZSwge1xuICAgIHRhYmxlQ2xhc3NOYW1lOiB0YWJsZUNsYXNzTmFtZSxcbiAgICBoYXNIZWFkOiAhdXNlRml4ZWRIZWFkZXIsXG4gICAgaGFzQm9keTogdHJ1ZSxcbiAgICBmaXhlZDogZml4ZWQsXG4gICAgY29sdW1uczogY29sdW1ucyxcbiAgICBleHBhbmRlcjogZXhwYW5kZXIsXG4gICAgZ2V0Um93S2V5OiBnZXRSb3dLZXksXG4gICAgaXNBbnlDb2x1bW5zRml4ZWQ6IGlzQW55Q29sdW1uc0ZpeGVkXG4gIH0pO1xuXG4gIGlmIChmaXhlZCAmJiBjb2x1bW5zLmxlbmd0aCkge1xuICAgIHZhciByZWZOYW1lID0gdm9pZCAwO1xuICAgIGlmIChjb2x1bW5zWzBdLmZpeGVkID09PSAnbGVmdCcgfHwgY29sdW1uc1swXS5maXhlZCA9PT0gdHJ1ZSkge1xuICAgICAgcmVmTmFtZSA9ICdmaXhlZENvbHVtbnNCb2R5TGVmdCc7XG4gICAgfSBlbHNlIGlmIChjb2x1bW5zWzBdLmZpeGVkID09PSAncmlnaHQnKSB7XG4gICAgICByZWZOYW1lID0gJ2ZpeGVkQ29sdW1uc0JvZHlSaWdodCc7XG4gICAgfVxuICAgIGRlbGV0ZSBib2R5U3R5bGUub3ZlcmZsb3dYO1xuICAgIGRlbGV0ZSBib2R5U3R5bGUub3ZlcmZsb3dZO1xuICAgIHJldHVybiBSZWFjdC5jcmVhdGVFbGVtZW50KFxuICAgICAgJ2RpdicsXG4gICAgICB7IGtleTogJ2JvZHlUYWJsZScsIGNsYXNzTmFtZTogcHJlZml4Q2xzICsgJy1ib2R5LW91dGVyJywgc3R5bGU6IF9leHRlbmRzKHt9LCBib2R5U3R5bGUpIH0sXG4gICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFxuICAgICAgICAnZGl2JyxcbiAgICAgICAge1xuICAgICAgICAgIGNsYXNzTmFtZTogcHJlZml4Q2xzICsgJy1ib2R5LWlubmVyJyxcbiAgICAgICAgICBzdHlsZTogaW5uZXJCb2R5U3R5bGUsXG4gICAgICAgICAgcmVmOiBzYXZlUmVmKHJlZk5hbWUpLFxuICAgICAgICAgIG9uV2hlZWw6IGhhbmRsZVdoZWVsLFxuICAgICAgICAgIG9uU2Nyb2xsOiBoYW5kbGVCb2R5U2Nyb2xsXG4gICAgICAgIH0sXG4gICAgICAgIGJhc2VUYWJsZVxuICAgICAgKVxuICAgICk7XG4gIH1cblxuICByZXR1cm4gUmVhY3QuY3JlYXRlRWxlbWVudChcbiAgICAnZGl2JyxcbiAgICB7XG4gICAgICBrZXk6ICdib2R5VGFibGUnLFxuICAgICAgY2xhc3NOYW1lOiBwcmVmaXhDbHMgKyAnLWJvZHknLFxuICAgICAgc3R5bGU6IGJvZHlTdHlsZSxcbiAgICAgIHJlZjogc2F2ZVJlZignYm9keVRhYmxlJyksXG4gICAgICBvbldoZWVsOiBoYW5kbGVXaGVlbCxcbiAgICAgIG9uU2Nyb2xsOiBoYW5kbGVCb2R5U2Nyb2xsXG4gICAgfSxcbiAgICBiYXNlVGFibGVcbiAgKTtcbn1cblxuQm9keVRhYmxlLnByb3BUeXBlcyA9IHtcbiAgZml4ZWQ6IFByb3BUeXBlcy5vbmVPZlR5cGUoW1Byb3BUeXBlcy5zdHJpbmcsIFByb3BUeXBlcy5ib29sXSksXG4gIGNvbHVtbnM6IFByb3BUeXBlcy5hcnJheS5pc1JlcXVpcmVkLFxuICB0YWJsZUNsYXNzTmFtZTogUHJvcFR5cGVzLnN0cmluZy5pc1JlcXVpcmVkLFxuICBoYW5kbGVXaGVlbDogUHJvcFR5cGVzLmZ1bmMuaXNSZXF1aXJlZCxcbiAgaGFuZGxlQm9keVNjcm9sbDogUHJvcFR5cGVzLmZ1bmMuaXNSZXF1aXJlZCxcbiAgZ2V0Um93S2V5OiBQcm9wVHlwZXMuZnVuYy5pc1JlcXVpcmVkLFxuICBleHBhbmRlcjogUHJvcFR5cGVzLm9iamVjdC5pc1JlcXVpcmVkLFxuICBpc0FueUNvbHVtbnNGaXhlZDogUHJvcFR5cGVzLmJvb2xcbn07XG5cbkJvZHlUYWJsZS5jb250ZXh0VHlwZXMgPSB7XG4gIHRhYmxlOiBQcm9wVHlwZXMuYW55XG59OyIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDb2xHcm91cChwcm9wcywgX3JlZikge1xuICB2YXIgdGFibGUgPSBfcmVmLnRhYmxlO1xuICB2YXIgX3RhYmxlJHByb3BzID0gdGFibGUucHJvcHMsXG4gICAgICBwcmVmaXhDbHMgPSBfdGFibGUkcHJvcHMucHJlZml4Q2xzLFxuICAgICAgZXhwYW5kSWNvbkFzQ2VsbCA9IF90YWJsZSRwcm9wcy5leHBhbmRJY29uQXNDZWxsO1xuICB2YXIgZml4ZWQgPSBwcm9wcy5maXhlZDtcblxuXG4gIHZhciBjb2xzID0gW107XG5cbiAgaWYgKGV4cGFuZEljb25Bc0NlbGwgJiYgZml4ZWQgIT09ICdyaWdodCcpIHtcbiAgICBjb2xzLnB1c2goUmVhY3QuY3JlYXRlRWxlbWVudCgnY29sJywgeyBjbGFzc05hbWU6IHByZWZpeENscyArICctZXhwYW5kLWljb24tY29sJywga2V5OiAncmMtdGFibGUtZXhwYW5kLWljb24tY29sJyB9KSk7XG4gIH1cblxuICB2YXIgbGVhZkNvbHVtbnMgPSB2b2lkIDA7XG5cbiAgaWYgKGZpeGVkID09PSAnbGVmdCcpIHtcbiAgICBsZWFmQ29sdW1ucyA9IHRhYmxlLmNvbHVtbk1hbmFnZXIubGVmdExlYWZDb2x1bW5zKCk7XG4gIH0gZWxzZSBpZiAoZml4ZWQgPT09ICdyaWdodCcpIHtcbiAgICBsZWFmQ29sdW1ucyA9IHRhYmxlLmNvbHVtbk1hbmFnZXIucmlnaHRMZWFmQ29sdW1ucygpO1xuICB9IGVsc2Uge1xuICAgIGxlYWZDb2x1bW5zID0gdGFibGUuY29sdW1uTWFuYWdlci5sZWFmQ29sdW1ucygpO1xuICB9XG4gIGNvbHMgPSBjb2xzLmNvbmNhdChsZWFmQ29sdW1ucy5tYXAoZnVuY3Rpb24gKGMpIHtcbiAgICByZXR1cm4gUmVhY3QuY3JlYXRlRWxlbWVudCgnY29sJywgeyBrZXk6IGMua2V5IHx8IGMuZGF0YUluZGV4LCBzdHlsZTogeyB3aWR0aDogYy53aWR0aCwgbWluV2lkdGg6IGMud2lkdGggfSB9KTtcbiAgfSkpO1xuXG4gIHJldHVybiBSZWFjdC5jcmVhdGVFbGVtZW50KFxuICAgICdjb2xncm91cCcsXG4gICAgbnVsbCxcbiAgICBjb2xzXG4gICk7XG59XG5cbkNvbEdyb3VwLnByb3BUeXBlcyA9IHtcbiAgZml4ZWQ6IFByb3BUeXBlcy5zdHJpbmdcbn07XG5cbkNvbEdyb3VwLmNvbnRleHRUeXBlcyA9IHtcbiAgdGFibGU6IFByb3BUeXBlcy5hbnlcbn07IiwiaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcblxuZnVuY3Rpb24gQ29sdW1uKCkge31cblxuQ29sdW1uLnByb3BUeXBlcyA9IHtcbiAgY2xhc3NOYW1lOiBQcm9wVHlwZXMuc3RyaW5nLFxuICBjb2xTcGFuOiBQcm9wVHlwZXMubnVtYmVyLFxuICB0aXRsZTogUHJvcFR5cGVzLm5vZGUsXG4gIGRhdGFJbmRleDogUHJvcFR5cGVzLnN0cmluZyxcbiAgd2lkdGg6IFByb3BUeXBlcy5vbmVPZlR5cGUoW1Byb3BUeXBlcy5udW1iZXIsIFByb3BUeXBlcy5zdHJpbmddKSxcbiAgZml4ZWQ6IFByb3BUeXBlcy5vbmVPZihbdHJ1ZSwgJ2xlZnQnLCAncmlnaHQnXSksXG4gIHJlbmRlcjogUHJvcFR5cGVzLmZ1bmMsXG4gIG9uQ2VsbENsaWNrOiBQcm9wVHlwZXMuZnVuYyxcbiAgb25DZWxsOiBQcm9wVHlwZXMuZnVuYyxcbiAgb25IZWFkZXJDZWxsOiBQcm9wVHlwZXMuZnVuY1xufTtcblxuZXhwb3J0IGRlZmF1bHQgQ29sdW1uOyIsImltcG9ydCBfY2xhc3NDYWxsQ2hlY2sgZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL2NsYXNzQ2FsbENoZWNrJztcbmltcG9ydCBfcG9zc2libGVDb25zdHJ1Y3RvclJldHVybiBmcm9tICdiYWJlbC1ydW50aW1lL2hlbHBlcnMvcG9zc2libGVDb25zdHJ1Y3RvclJldHVybic7XG5pbXBvcnQgX2luaGVyaXRzIGZyb20gJ2JhYmVsLXJ1bnRpbWUvaGVscGVycy9pbmhlcml0cyc7XG5pbXBvcnQgeyBDb21wb25lbnQgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnO1xuXG52YXIgQ29sdW1uR3JvdXAgPSBmdW5jdGlvbiAoX0NvbXBvbmVudCkge1xuICBfaW5oZXJpdHMoQ29sdW1uR3JvdXAsIF9Db21wb25lbnQpO1xuXG4gIGZ1bmN0aW9uIENvbHVtbkdyb3VwKCkge1xuICAgIF9jbGFzc0NhbGxDaGVjayh0aGlzLCBDb2x1bW5Hcm91cCk7XG5cbiAgICByZXR1cm4gX3Bvc3NpYmxlQ29uc3RydWN0b3JSZXR1cm4odGhpcywgX0NvbXBvbmVudC5hcHBseSh0aGlzLCBhcmd1bWVudHMpKTtcbiAgfVxuXG4gIHJldHVybiBDb2x1bW5Hcm91cDtcbn0oQ29tcG9uZW50KTtcblxuQ29sdW1uR3JvdXAucHJvcFR5cGVzID0ge1xuICB0aXRsZTogUHJvcFR5cGVzLm5vZGVcbn07XG5Db2x1bW5Hcm91cC5pc1RhYmxlQ29sdW1uR3JvdXAgPSB0cnVlO1xuZXhwb3J0IGRlZmF1bHQgQ29sdW1uR3JvdXA7IiwiaW1wb3J0IF9leHRlbmRzIGZyb20gJ2JhYmVsLXJ1bnRpbWUvaGVscGVycy9leHRlbmRzJztcbmltcG9ydCBfY2xhc3NDYWxsQ2hlY2sgZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL2NsYXNzQ2FsbENoZWNrJztcbmltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5cbnZhciBDb2x1bW5NYW5hZ2VyID0gZnVuY3Rpb24gKCkge1xuICBmdW5jdGlvbiBDb2x1bW5NYW5hZ2VyKGNvbHVtbnMsIGVsZW1lbnRzKSB7XG4gICAgX2NsYXNzQ2FsbENoZWNrKHRoaXMsIENvbHVtbk1hbmFnZXIpO1xuXG4gICAgdGhpcy5fY2FjaGVkID0ge307XG5cbiAgICB0aGlzLmNvbHVtbnMgPSBjb2x1bW5zIHx8IHRoaXMubm9ybWFsaXplKGVsZW1lbnRzKTtcbiAgfVxuXG4gIENvbHVtbk1hbmFnZXIucHJvdG90eXBlLmlzQW55Q29sdW1uc0ZpeGVkID0gZnVuY3Rpb24gaXNBbnlDb2x1bW5zRml4ZWQoKSB7XG4gICAgdmFyIF90aGlzID0gdGhpcztcblxuICAgIHJldHVybiB0aGlzLl9jYWNoZSgnaXNBbnlDb2x1bW5zRml4ZWQnLCBmdW5jdGlvbiAoKSB7XG4gICAgICByZXR1cm4gX3RoaXMuY29sdW1ucy5zb21lKGZ1bmN0aW9uIChjb2x1bW4pIHtcbiAgICAgICAgcmV0dXJuICEhY29sdW1uLmZpeGVkO1xuICAgICAgfSk7XG4gICAgfSk7XG4gIH07XG5cbiAgQ29sdW1uTWFuYWdlci5wcm90b3R5cGUuaXNBbnlDb2x1bW5zTGVmdEZpeGVkID0gZnVuY3Rpb24gaXNBbnlDb2x1bW5zTGVmdEZpeGVkKCkge1xuICAgIHZhciBfdGhpczIgPSB0aGlzO1xuXG4gICAgcmV0dXJuIHRoaXMuX2NhY2hlKCdpc0FueUNvbHVtbnNMZWZ0Rml4ZWQnLCBmdW5jdGlvbiAoKSB7XG4gICAgICByZXR1cm4gX3RoaXMyLmNvbHVtbnMuc29tZShmdW5jdGlvbiAoY29sdW1uKSB7XG4gICAgICAgIHJldHVybiBjb2x1bW4uZml4ZWQgPT09ICdsZWZ0JyB8fCBjb2x1bW4uZml4ZWQgPT09IHRydWU7XG4gICAgICB9KTtcbiAgICB9KTtcbiAgfTtcblxuICBDb2x1bW5NYW5hZ2VyLnByb3RvdHlwZS5pc0FueUNvbHVtbnNSaWdodEZpeGVkID0gZnVuY3Rpb24gaXNBbnlDb2x1bW5zUmlnaHRGaXhlZCgpIHtcbiAgICB2YXIgX3RoaXMzID0gdGhpcztcblxuICAgIHJldHVybiB0aGlzLl9jYWNoZSgnaXNBbnlDb2x1bW5zUmlnaHRGaXhlZCcsIGZ1bmN0aW9uICgpIHtcbiAgICAgIHJldHVybiBfdGhpczMuY29sdW1ucy5zb21lKGZ1bmN0aW9uIChjb2x1bW4pIHtcbiAgICAgICAgcmV0dXJuIGNvbHVtbi5maXhlZCA9PT0gJ3JpZ2h0JztcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9O1xuXG4gIENvbHVtbk1hbmFnZXIucHJvdG90eXBlLmxlZnRDb2x1bW5zID0gZnVuY3Rpb24gbGVmdENvbHVtbnMoKSB7XG4gICAgdmFyIF90aGlzNCA9IHRoaXM7XG5cbiAgICByZXR1cm4gdGhpcy5fY2FjaGUoJ2xlZnRDb2x1bW5zJywgZnVuY3Rpb24gKCkge1xuICAgICAgcmV0dXJuIF90aGlzNC5ncm91cGVkQ29sdW1ucygpLmZpbHRlcihmdW5jdGlvbiAoY29sdW1uKSB7XG4gICAgICAgIHJldHVybiBjb2x1bW4uZml4ZWQgPT09ICdsZWZ0JyB8fCBjb2x1bW4uZml4ZWQgPT09IHRydWU7XG4gICAgICB9KTtcbiAgICB9KTtcbiAgfTtcblxuICBDb2x1bW5NYW5hZ2VyLnByb3RvdHlwZS5yaWdodENvbHVtbnMgPSBmdW5jdGlvbiByaWdodENvbHVtbnMoKSB7XG4gICAgdmFyIF90aGlzNSA9IHRoaXM7XG5cbiAgICByZXR1cm4gdGhpcy5fY2FjaGUoJ3JpZ2h0Q29sdW1ucycsIGZ1bmN0aW9uICgpIHtcbiAgICAgIHJldHVybiBfdGhpczUuZ3JvdXBlZENvbHVtbnMoKS5maWx0ZXIoZnVuY3Rpb24gKGNvbHVtbikge1xuICAgICAgICByZXR1cm4gY29sdW1uLmZpeGVkID09PSAncmlnaHQnO1xuICAgICAgfSk7XG4gICAgfSk7XG4gIH07XG5cbiAgQ29sdW1uTWFuYWdlci5wcm90b3R5cGUubGVhZkNvbHVtbnMgPSBmdW5jdGlvbiBsZWFmQ29sdW1ucygpIHtcbiAgICB2YXIgX3RoaXM2ID0gdGhpcztcblxuICAgIHJldHVybiB0aGlzLl9jYWNoZSgnbGVhZkNvbHVtbnMnLCBmdW5jdGlvbiAoKSB7XG4gICAgICByZXR1cm4gX3RoaXM2Ll9sZWFmQ29sdW1ucyhfdGhpczYuY29sdW1ucyk7XG4gICAgfSk7XG4gIH07XG5cbiAgQ29sdW1uTWFuYWdlci5wcm90b3R5cGUubGVmdExlYWZDb2x1bW5zID0gZnVuY3Rpb24gbGVmdExlYWZDb2x1bW5zKCkge1xuICAgIHZhciBfdGhpczcgPSB0aGlzO1xuXG4gICAgcmV0dXJuIHRoaXMuX2NhY2hlKCdsZWZ0TGVhZkNvbHVtbnMnLCBmdW5jdGlvbiAoKSB7XG4gICAgICByZXR1cm4gX3RoaXM3Ll9sZWFmQ29sdW1ucyhfdGhpczcubGVmdENvbHVtbnMoKSk7XG4gICAgfSk7XG4gIH07XG5cbiAgQ29sdW1uTWFuYWdlci5wcm90b3R5cGUucmlnaHRMZWFmQ29sdW1ucyA9IGZ1bmN0aW9uIHJpZ2h0TGVhZkNvbHVtbnMoKSB7XG4gICAgdmFyIF90aGlzOCA9IHRoaXM7XG5cbiAgICByZXR1cm4gdGhpcy5fY2FjaGUoJ3JpZ2h0TGVhZkNvbHVtbnMnLCBmdW5jdGlvbiAoKSB7XG4gICAgICByZXR1cm4gX3RoaXM4Ll9sZWFmQ29sdW1ucyhfdGhpczgucmlnaHRDb2x1bW5zKCkpO1xuICAgIH0pO1xuICB9O1xuXG4gIC8vIGFkZCBhcHByb3ByaWF0ZSByb3dzcGFuIGFuZCBjb2xzcGFuIHRvIGNvbHVtblxuXG5cbiAgQ29sdW1uTWFuYWdlci5wcm90b3R5cGUuZ3JvdXBlZENvbHVtbnMgPSBmdW5jdGlvbiBncm91cGVkQ29sdW1ucygpIHtcbiAgICB2YXIgX3RoaXM5ID0gdGhpcztcblxuICAgIHJldHVybiB0aGlzLl9jYWNoZSgnZ3JvdXBlZENvbHVtbnMnLCBmdW5jdGlvbiAoKSB7XG4gICAgICB2YXIgX2dyb3VwQ29sdW1ucyA9IGZ1bmN0aW9uIF9ncm91cENvbHVtbnMoY29sdW1ucykge1xuICAgICAgICB2YXIgY3VycmVudFJvdyA9IGFyZ3VtZW50cy5sZW5ndGggPiAxICYmIGFyZ3VtZW50c1sxXSAhPT0gdW5kZWZpbmVkID8gYXJndW1lbnRzWzFdIDogMDtcbiAgICAgICAgdmFyIHBhcmVudENvbHVtbiA9IGFyZ3VtZW50cy5sZW5ndGggPiAyICYmIGFyZ3VtZW50c1syXSAhPT0gdW5kZWZpbmVkID8gYXJndW1lbnRzWzJdIDoge307XG4gICAgICAgIHZhciByb3dzID0gYXJndW1lbnRzLmxlbmd0aCA+IDMgJiYgYXJndW1lbnRzWzNdICE9PSB1bmRlZmluZWQgPyBhcmd1bWVudHNbM10gOiBbXTtcblxuICAgICAgICAvLyB0cmFjayBob3cgbWFueSByb3dzIHdlIGdvdFxuICAgICAgICByb3dzW2N1cnJlbnRSb3ddID0gcm93c1tjdXJyZW50Um93XSB8fCBbXTtcbiAgICAgICAgdmFyIGdyb3VwZWQgPSBbXTtcbiAgICAgICAgdmFyIHNldFJvd1NwYW4gPSBmdW5jdGlvbiBzZXRSb3dTcGFuKGNvbHVtbikge1xuICAgICAgICAgIHZhciByb3dTcGFuID0gcm93cy5sZW5ndGggLSBjdXJyZW50Um93O1xuICAgICAgICAgIGlmIChjb2x1bW4gJiYgIWNvbHVtbi5jaGlsZHJlbiAmJiAvLyBwYXJlbnQgY29sdW1ucyBhcmUgc3VwcG9zZWQgdG8gYmUgb25lIHJvd1xuICAgICAgICAgIHJvd1NwYW4gPiAxICYmICghY29sdW1uLnJvd1NwYW4gfHwgY29sdW1uLnJvd1NwYW4gPCByb3dTcGFuKSkge1xuICAgICAgICAgICAgY29sdW1uLnJvd1NwYW4gPSByb3dTcGFuO1xuICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgICAgY29sdW1ucy5mb3JFYWNoKGZ1bmN0aW9uIChjb2x1bW4sIGluZGV4KSB7XG4gICAgICAgICAgdmFyIG5ld0NvbHVtbiA9IF9leHRlbmRzKHt9LCBjb2x1bW4pO1xuICAgICAgICAgIHJvd3NbY3VycmVudFJvd10ucHVzaChuZXdDb2x1bW4pO1xuICAgICAgICAgIHBhcmVudENvbHVtbi5jb2xTcGFuID0gcGFyZW50Q29sdW1uLmNvbFNwYW4gfHwgMDtcbiAgICAgICAgICBpZiAobmV3Q29sdW1uLmNoaWxkcmVuICYmIG5ld0NvbHVtbi5jaGlsZHJlbi5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICBuZXdDb2x1bW4uY2hpbGRyZW4gPSBfZ3JvdXBDb2x1bW5zKG5ld0NvbHVtbi5jaGlsZHJlbiwgY3VycmVudFJvdyArIDEsIG5ld0NvbHVtbiwgcm93cyk7XG4gICAgICAgICAgICBwYXJlbnRDb2x1bW4uY29sU3BhbiArPSBuZXdDb2x1bW4uY29sU3BhbjtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcGFyZW50Q29sdW1uLmNvbFNwYW4rKztcbiAgICAgICAgICB9XG4gICAgICAgICAgLy8gdXBkYXRlIHJvd3NwYW4gdG8gYWxsIHNhbWUgcm93IGNvbHVtbnNcbiAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHJvd3NbY3VycmVudFJvd10ubGVuZ3RoIC0gMTsgKytpKSB7XG4gICAgICAgICAgICBzZXRSb3dTcGFuKHJvd3NbY3VycmVudFJvd11baV0pO1xuICAgICAgICAgIH1cbiAgICAgICAgICAvLyBsYXN0IGNvbHVtbiwgdXBkYXRlIHJvd3NwYW4gaW1tZWRpYXRlbHlcbiAgICAgICAgICBpZiAoaW5kZXggKyAxID09PSBjb2x1bW5zLmxlbmd0aCkge1xuICAgICAgICAgICAgc2V0Um93U3BhbihuZXdDb2x1bW4pO1xuICAgICAgICAgIH1cbiAgICAgICAgICBncm91cGVkLnB1c2gobmV3Q29sdW1uKTtcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiBncm91cGVkO1xuICAgICAgfTtcbiAgICAgIHJldHVybiBfZ3JvdXBDb2x1bW5zKF90aGlzOS5jb2x1bW5zKTtcbiAgICB9KTtcbiAgfTtcblxuICBDb2x1bW5NYW5hZ2VyLnByb3RvdHlwZS5ub3JtYWxpemUgPSBmdW5jdGlvbiBub3JtYWxpemUoZWxlbWVudHMpIHtcbiAgICB2YXIgX3RoaXMxMCA9IHRoaXM7XG5cbiAgICB2YXIgY29sdW1ucyA9IFtdO1xuICAgIFJlYWN0LkNoaWxkcmVuLmZvckVhY2goZWxlbWVudHMsIGZ1bmN0aW9uIChlbGVtZW50KSB7XG4gICAgICBpZiAoIVJlYWN0LmlzVmFsaWRFbGVtZW50KGVsZW1lbnQpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIHZhciBjb2x1bW4gPSBfZXh0ZW5kcyh7fSwgZWxlbWVudC5wcm9wcyk7XG4gICAgICBpZiAoZWxlbWVudC5rZXkpIHtcbiAgICAgICAgY29sdW1uLmtleSA9IGVsZW1lbnQua2V5O1xuICAgICAgfVxuICAgICAgaWYgKGVsZW1lbnQudHlwZS5pc1RhYmxlQ29sdW1uR3JvdXApIHtcbiAgICAgICAgY29sdW1uLmNoaWxkcmVuID0gX3RoaXMxMC5ub3JtYWxpemUoY29sdW1uLmNoaWxkcmVuKTtcbiAgICAgIH1cbiAgICAgIGNvbHVtbnMucHVzaChjb2x1bW4pO1xuICAgIH0pO1xuICAgIHJldHVybiBjb2x1bW5zO1xuICB9O1xuXG4gIENvbHVtbk1hbmFnZXIucHJvdG90eXBlLnJlc2V0ID0gZnVuY3Rpb24gcmVzZXQoY29sdW1ucywgZWxlbWVudHMpIHtcbiAgICB0aGlzLmNvbHVtbnMgPSBjb2x1bW5zIHx8IHRoaXMubm9ybWFsaXplKGVsZW1lbnRzKTtcbiAgICB0aGlzLl9jYWNoZWQgPSB7fTtcbiAgfTtcblxuICBDb2x1bW5NYW5hZ2VyLnByb3RvdHlwZS5fY2FjaGUgPSBmdW5jdGlvbiBfY2FjaGUobmFtZSwgZm4pIHtcbiAgICBpZiAobmFtZSBpbiB0aGlzLl9jYWNoZWQpIHtcbiAgICAgIHJldHVybiB0aGlzLl9jYWNoZWRbbmFtZV07XG4gICAgfVxuICAgIHRoaXMuX2NhY2hlZFtuYW1lXSA9IGZuKCk7XG4gICAgcmV0dXJuIHRoaXMuX2NhY2hlZFtuYW1lXTtcbiAgfTtcblxuICBDb2x1bW5NYW5hZ2VyLnByb3RvdHlwZS5fbGVhZkNvbHVtbnMgPSBmdW5jdGlvbiBfbGVhZkNvbHVtbnMoY29sdW1ucykge1xuICAgIHZhciBfdGhpczExID0gdGhpcztcblxuICAgIHZhciBsZWFmQ29sdW1ucyA9IFtdO1xuICAgIGNvbHVtbnMuZm9yRWFjaChmdW5jdGlvbiAoY29sdW1uKSB7XG4gICAgICBpZiAoIWNvbHVtbi5jaGlsZHJlbikge1xuICAgICAgICBsZWFmQ29sdW1ucy5wdXNoKGNvbHVtbik7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBsZWFmQ29sdW1ucy5wdXNoLmFwcGx5KGxlYWZDb2x1bW5zLCBfdGhpczExLl9sZWFmQ29sdW1ucyhjb2x1bW4uY2hpbGRyZW4pKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICByZXR1cm4gbGVhZkNvbHVtbnM7XG4gIH07XG5cbiAgcmV0dXJuIENvbHVtbk1hbmFnZXI7XG59KCk7XG5cbmV4cG9ydCBkZWZhdWx0IENvbHVtbk1hbmFnZXI7IiwiaW1wb3J0IF9jbGFzc0NhbGxDaGVjayBmcm9tICdiYWJlbC1ydW50aW1lL2hlbHBlcnMvY2xhc3NDYWxsQ2hlY2snO1xuaW1wb3J0IF9wb3NzaWJsZUNvbnN0cnVjdG9yUmV0dXJuIGZyb20gJ2JhYmVsLXJ1bnRpbWUvaGVscGVycy9wb3NzaWJsZUNvbnN0cnVjdG9yUmV0dXJuJztcbmltcG9ydCBfaW5oZXJpdHMgZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL2luaGVyaXRzJztcbmltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnO1xuaW1wb3J0IHNoYWxsb3dlcXVhbCBmcm9tICdzaGFsbG93ZXF1YWwnO1xuXG52YXIgRXhwYW5kSWNvbiA9IGZ1bmN0aW9uIChfUmVhY3QkQ29tcG9uZW50KSB7XG4gIF9pbmhlcml0cyhFeHBhbmRJY29uLCBfUmVhY3QkQ29tcG9uZW50KTtcblxuICBmdW5jdGlvbiBFeHBhbmRJY29uKCkge1xuICAgIF9jbGFzc0NhbGxDaGVjayh0aGlzLCBFeHBhbmRJY29uKTtcblxuICAgIHJldHVybiBfcG9zc2libGVDb25zdHJ1Y3RvclJldHVybih0aGlzLCBfUmVhY3QkQ29tcG9uZW50LmFwcGx5KHRoaXMsIGFyZ3VtZW50cykpO1xuICB9XG5cbiAgRXhwYW5kSWNvbi5wcm90b3R5cGUuc2hvdWxkQ29tcG9uZW50VXBkYXRlID0gZnVuY3Rpb24gc2hvdWxkQ29tcG9uZW50VXBkYXRlKG5leHRQcm9wcykge1xuICAgIHJldHVybiAhc2hhbGxvd2VxdWFsKG5leHRQcm9wcywgdGhpcy5wcm9wcyk7XG4gIH07XG5cbiAgRXhwYW5kSWNvbi5wcm90b3R5cGUucmVuZGVyID0gZnVuY3Rpb24gcmVuZGVyKCkge1xuICAgIHZhciBfcHJvcHMgPSB0aGlzLnByb3BzLFxuICAgICAgICBleHBhbmRhYmxlID0gX3Byb3BzLmV4cGFuZGFibGUsXG4gICAgICAgIHByZWZpeENscyA9IF9wcm9wcy5wcmVmaXhDbHMsXG4gICAgICAgIG9uRXhwYW5kID0gX3Byb3BzLm9uRXhwYW5kLFxuICAgICAgICBuZWVkSW5kZW50U3BhY2VkID0gX3Byb3BzLm5lZWRJbmRlbnRTcGFjZWQsXG4gICAgICAgIGV4cGFuZGVkID0gX3Byb3BzLmV4cGFuZGVkLFxuICAgICAgICByZWNvcmQgPSBfcHJvcHMucmVjb3JkO1xuXG4gICAgaWYgKGV4cGFuZGFibGUpIHtcbiAgICAgIHZhciBleHBhbmRDbGFzc05hbWUgPSBleHBhbmRlZCA/ICdleHBhbmRlZCcgOiAnY29sbGFwc2VkJztcbiAgICAgIHJldHVybiBSZWFjdC5jcmVhdGVFbGVtZW50KCdzcGFuJywge1xuICAgICAgICBjbGFzc05hbWU6IHByZWZpeENscyArICctZXhwYW5kLWljb24gJyArIHByZWZpeENscyArICctJyArIGV4cGFuZENsYXNzTmFtZSxcbiAgICAgICAgb25DbGljazogZnVuY3Rpb24gb25DbGljayhlKSB7XG4gICAgICAgICAgcmV0dXJuIG9uRXhwYW5kKHJlY29yZCwgZSk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0gZWxzZSBpZiAobmVlZEluZGVudFNwYWNlZCkge1xuICAgICAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nLCB7IGNsYXNzTmFtZTogcHJlZml4Q2xzICsgJy1leHBhbmQtaWNvbiAnICsgcHJlZml4Q2xzICsgJy1zcGFjZWQnIH0pO1xuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbiAgfTtcblxuICByZXR1cm4gRXhwYW5kSWNvbjtcbn0oUmVhY3QuQ29tcG9uZW50KTtcblxuRXhwYW5kSWNvbi5wcm9wVHlwZXMgPSB7XG4gIHJlY29yZDogUHJvcFR5cGVzLm9iamVjdCxcbiAgcHJlZml4Q2xzOiBQcm9wVHlwZXMuc3RyaW5nLFxuICBleHBhbmRhYmxlOiBQcm9wVHlwZXMuYW55LFxuICBleHBhbmRlZDogUHJvcFR5cGVzLmJvb2wsXG4gIG5lZWRJbmRlbnRTcGFjZWQ6IFByb3BUeXBlcy5ib29sLFxuICBvbkV4cGFuZDogUHJvcFR5cGVzLmZ1bmNcbn07XG5leHBvcnQgZGVmYXVsdCBFeHBhbmRJY29uOyIsImltcG9ydCBfY2xhc3NDYWxsQ2hlY2sgZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL2NsYXNzQ2FsbENoZWNrJztcbmltcG9ydCBfcG9zc2libGVDb25zdHJ1Y3RvclJldHVybiBmcm9tICdiYWJlbC1ydW50aW1lL2hlbHBlcnMvcG9zc2libGVDb25zdHJ1Y3RvclJldHVybic7XG5pbXBvcnQgX2luaGVyaXRzIGZyb20gJ2JhYmVsLXJ1bnRpbWUvaGVscGVycy9pbmhlcml0cyc7XG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcbmltcG9ydCB7IGNvbm5lY3QgfSBmcm9tICdtaW5pLXN0b3JlJztcbmltcG9ydCBFeHBhbmRJY29uIGZyb20gJy4vRXhwYW5kSWNvbic7XG5cbnZhciBFeHBhbmRhYmxlUm93ID0gZnVuY3Rpb24gKF9SZWFjdCRDb21wb25lbnQpIHtcbiAgX2luaGVyaXRzKEV4cGFuZGFibGVSb3csIF9SZWFjdCRDb21wb25lbnQpO1xuXG4gIGZ1bmN0aW9uIEV4cGFuZGFibGVSb3coKSB7XG4gICAgdmFyIF90ZW1wLCBfdGhpcywgX3JldDtcblxuICAgIF9jbGFzc0NhbGxDaGVjayh0aGlzLCBFeHBhbmRhYmxlUm93KTtcblxuICAgIGZvciAodmFyIF9sZW4gPSBhcmd1bWVudHMubGVuZ3RoLCBhcmdzID0gQXJyYXkoX2xlbiksIF9rZXkgPSAwOyBfa2V5IDwgX2xlbjsgX2tleSsrKSB7XG4gICAgICBhcmdzW19rZXldID0gYXJndW1lbnRzW19rZXldO1xuICAgIH1cblxuICAgIHJldHVybiBfcmV0ID0gKF90ZW1wID0gKF90aGlzID0gX3Bvc3NpYmxlQ29uc3RydWN0b3JSZXR1cm4odGhpcywgX1JlYWN0JENvbXBvbmVudC5jYWxsLmFwcGx5KF9SZWFjdCRDb21wb25lbnQsIFt0aGlzXS5jb25jYXQoYXJncykpKSwgX3RoaXMpLCBfdGhpcy5oYXNFeHBhbmRJY29uID0gZnVuY3Rpb24gKGNvbHVtbkluZGV4KSB7XG4gICAgICB2YXIgZXhwYW5kUm93QnlDbGljayA9IF90aGlzLnByb3BzLmV4cGFuZFJvd0J5Q2xpY2s7XG5cbiAgICAgIHJldHVybiAhX3RoaXMuZXhwYW5kSWNvbkFzQ2VsbCAmJiAhZXhwYW5kUm93QnlDbGljayAmJiBjb2x1bW5JbmRleCA9PT0gX3RoaXMuZXhwYW5kSWNvbkNvbHVtbkluZGV4O1xuICAgIH0sIF90aGlzLmhhbmRsZUV4cGFuZENoYW5nZSA9IGZ1bmN0aW9uIChyZWNvcmQsIGV2ZW50KSB7XG4gICAgICB2YXIgX3RoaXMkcHJvcHMgPSBfdGhpcy5wcm9wcyxcbiAgICAgICAgICBvbkV4cGFuZGVkQ2hhbmdlID0gX3RoaXMkcHJvcHMub25FeHBhbmRlZENoYW5nZSxcbiAgICAgICAgICBleHBhbmRlZCA9IF90aGlzJHByb3BzLmV4cGFuZGVkLFxuICAgICAgICAgIHJvd0tleSA9IF90aGlzJHByb3BzLnJvd0tleTtcblxuICAgICAgaWYgKF90aGlzLmV4cGFuZGFibGUpIHtcbiAgICAgICAgb25FeHBhbmRlZENoYW5nZSghZXhwYW5kZWQsIHJlY29yZCwgZXZlbnQsIHJvd0tleSk7XG4gICAgICB9XG4gICAgfSwgX3RoaXMuaGFuZGxlUm93Q2xpY2sgPSBmdW5jdGlvbiAocmVjb3JkLCBpbmRleCwgZXZlbnQpIHtcbiAgICAgIHZhciBfdGhpcyRwcm9wczIgPSBfdGhpcy5wcm9wcyxcbiAgICAgICAgICBleHBhbmRSb3dCeUNsaWNrID0gX3RoaXMkcHJvcHMyLmV4cGFuZFJvd0J5Q2xpY2ssXG4gICAgICAgICAgb25Sb3dDbGljayA9IF90aGlzJHByb3BzMi5vblJvd0NsaWNrO1xuXG4gICAgICBpZiAoZXhwYW5kUm93QnlDbGljaykge1xuICAgICAgICBfdGhpcy5oYW5kbGVFeHBhbmRDaGFuZ2UocmVjb3JkLCBldmVudCk7XG4gICAgICB9XG4gICAgICBpZiAob25Sb3dDbGljaykge1xuICAgICAgICBvblJvd0NsaWNrKHJlY29yZCwgaW5kZXgsIGV2ZW50KTtcbiAgICAgIH1cbiAgICB9LCBfdGhpcy5yZW5kZXJFeHBhbmRJY29uID0gZnVuY3Rpb24gKCkge1xuICAgICAgdmFyIF90aGlzJHByb3BzMyA9IF90aGlzLnByb3BzLFxuICAgICAgICAgIHByZWZpeENscyA9IF90aGlzJHByb3BzMy5wcmVmaXhDbHMsXG4gICAgICAgICAgZXhwYW5kZWQgPSBfdGhpcyRwcm9wczMuZXhwYW5kZWQsXG4gICAgICAgICAgcmVjb3JkID0gX3RoaXMkcHJvcHMzLnJlY29yZCxcbiAgICAgICAgICBuZWVkSW5kZW50U3BhY2VkID0gX3RoaXMkcHJvcHMzLm5lZWRJbmRlbnRTcGFjZWQ7XG5cblxuICAgICAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoRXhwYW5kSWNvbiwge1xuICAgICAgICBleHBhbmRhYmxlOiBfdGhpcy5leHBhbmRhYmxlLFxuICAgICAgICBwcmVmaXhDbHM6IHByZWZpeENscyxcbiAgICAgICAgb25FeHBhbmQ6IF90aGlzLmhhbmRsZUV4cGFuZENoYW5nZSxcbiAgICAgICAgbmVlZEluZGVudFNwYWNlZDogbmVlZEluZGVudFNwYWNlZCxcbiAgICAgICAgZXhwYW5kZWQ6IGV4cGFuZGVkLFxuICAgICAgICByZWNvcmQ6IHJlY29yZFxuICAgICAgfSk7XG4gICAgfSwgX3RoaXMucmVuZGVyRXhwYW5kSWNvbkNlbGwgPSBmdW5jdGlvbiAoY2VsbHMpIHtcbiAgICAgIGlmICghX3RoaXMuZXhwYW5kSWNvbkFzQ2VsbCkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICB2YXIgcHJlZml4Q2xzID0gX3RoaXMucHJvcHMucHJlZml4Q2xzO1xuXG5cbiAgICAgIGNlbGxzLnB1c2goUmVhY3QuY3JlYXRlRWxlbWVudChcbiAgICAgICAgJ3RkJyxcbiAgICAgICAgeyBjbGFzc05hbWU6IHByZWZpeENscyArICctZXhwYW5kLWljb24tY2VsbCcsIGtleTogJ3JjLXRhYmxlLWV4cGFuZC1pY29uLWNlbGwnIH0sXG4gICAgICAgIF90aGlzLnJlbmRlckV4cGFuZEljb24oKVxuICAgICAgKSk7XG4gICAgfSwgX3RlbXApLCBfcG9zc2libGVDb25zdHJ1Y3RvclJldHVybihfdGhpcywgX3JldCk7XG4gIH1cblxuICBFeHBhbmRhYmxlUm93LnByb3RvdHlwZS5jb21wb25lbnRXaWxsVW5tb3VudCA9IGZ1bmN0aW9uIGNvbXBvbmVudFdpbGxVbm1vdW50KCkge1xuICAgIHRoaXMuaGFuZGxlRGVzdHJveSgpO1xuICB9O1xuXG4gIEV4cGFuZGFibGVSb3cucHJvdG90eXBlLmhhbmRsZURlc3Ryb3kgPSBmdW5jdGlvbiBoYW5kbGVEZXN0cm95KCkge1xuICAgIHZhciBfcHJvcHMgPSB0aGlzLnByb3BzLFxuICAgICAgICBvbkV4cGFuZGVkQ2hhbmdlID0gX3Byb3BzLm9uRXhwYW5kZWRDaGFuZ2UsXG4gICAgICAgIHJvd0tleSA9IF9wcm9wcy5yb3dLZXksXG4gICAgICAgIHJlY29yZCA9IF9wcm9wcy5yZWNvcmQ7XG5cbiAgICBpZiAodGhpcy5leHBhbmRhYmxlKSB7XG4gICAgICBvbkV4cGFuZGVkQ2hhbmdlKGZhbHNlLCByZWNvcmQsIG51bGwsIHJvd0tleSwgdHJ1ZSk7XG4gICAgfVxuICB9O1xuXG4gIEV4cGFuZGFibGVSb3cucHJvdG90eXBlLnJlbmRlciA9IGZ1bmN0aW9uIHJlbmRlcigpIHtcbiAgICB2YXIgX3Byb3BzMiA9IHRoaXMucHJvcHMsXG4gICAgICAgIGNoaWxkcmVuQ29sdW1uTmFtZSA9IF9wcm9wczIuY2hpbGRyZW5Db2x1bW5OYW1lLFxuICAgICAgICBleHBhbmRlZFJvd1JlbmRlciA9IF9wcm9wczIuZXhwYW5kZWRSb3dSZW5kZXIsXG4gICAgICAgIGluZGVudFNpemUgPSBfcHJvcHMyLmluZGVudFNpemUsXG4gICAgICAgIHJlY29yZCA9IF9wcm9wczIucmVjb3JkLFxuICAgICAgICBmaXhlZCA9IF9wcm9wczIuZml4ZWQ7XG5cblxuICAgIHRoaXMuZXhwYW5kSWNvbkFzQ2VsbCA9IGZpeGVkICE9PSAncmlnaHQnID8gdGhpcy5wcm9wcy5leHBhbmRJY29uQXNDZWxsIDogZmFsc2U7XG4gICAgdGhpcy5leHBhbmRJY29uQ29sdW1uSW5kZXggPSBmaXhlZCAhPT0gJ3JpZ2h0JyA/IHRoaXMucHJvcHMuZXhwYW5kSWNvbkNvbHVtbkluZGV4IDogLTE7XG4gICAgdmFyIGNoaWxkcmVuRGF0YSA9IHJlY29yZFtjaGlsZHJlbkNvbHVtbk5hbWVdO1xuICAgIHRoaXMuZXhwYW5kYWJsZSA9ICEhKGNoaWxkcmVuRGF0YSB8fCBleHBhbmRlZFJvd1JlbmRlcik7XG5cbiAgICB2YXIgZXhwYW5kYWJsZVJvd1Byb3BzID0ge1xuICAgICAgaW5kZW50U2l6ZTogaW5kZW50U2l6ZSxcbiAgICAgIG9uUm93Q2xpY2s6IHRoaXMuaGFuZGxlUm93Q2xpY2ssXG4gICAgICBoYXNFeHBhbmRJY29uOiB0aGlzLmhhc0V4cGFuZEljb24sXG4gICAgICByZW5kZXJFeHBhbmRJY29uOiB0aGlzLnJlbmRlckV4cGFuZEljb24sXG4gICAgICByZW5kZXJFeHBhbmRJY29uQ2VsbDogdGhpcy5yZW5kZXJFeHBhbmRJY29uQ2VsbFxuICAgIH07XG5cbiAgICByZXR1cm4gdGhpcy5wcm9wcy5jaGlsZHJlbihleHBhbmRhYmxlUm93UHJvcHMpO1xuICB9O1xuXG4gIHJldHVybiBFeHBhbmRhYmxlUm93O1xufShSZWFjdC5Db21wb25lbnQpO1xuXG5FeHBhbmRhYmxlUm93LnByb3BUeXBlcyA9IHtcbiAgcHJlZml4Q2xzOiBQcm9wVHlwZXMuc3RyaW5nLmlzUmVxdWlyZWQsXG4gIHJvd0tleTogUHJvcFR5cGVzLm9uZU9mVHlwZShbUHJvcFR5cGVzLnN0cmluZywgUHJvcFR5cGVzLm51bWJlcl0pLmlzUmVxdWlyZWQsXG4gIGZpeGVkOiBQcm9wVHlwZXMub25lT2ZUeXBlKFtQcm9wVHlwZXMuc3RyaW5nLCBQcm9wVHlwZXMuYm9vbF0pLFxuICByZWNvcmQ6IFByb3BUeXBlcy5vYmplY3QuaXNSZXF1aXJlZCxcbiAgaW5kZW50U2l6ZTogUHJvcFR5cGVzLm51bWJlcixcbiAgbmVlZEluZGVudFNwYWNlZDogUHJvcFR5cGVzLmJvb2wuaXNSZXF1aXJlZCxcbiAgZXhwYW5kUm93QnlDbGljazogUHJvcFR5cGVzLmJvb2wsXG4gIGV4cGFuZGVkOiBQcm9wVHlwZXMuYm9vbC5pc1JlcXVpcmVkLFxuICBleHBhbmRJY29uQXNDZWxsOiBQcm9wVHlwZXMuYm9vbCxcbiAgZXhwYW5kSWNvbkNvbHVtbkluZGV4OiBQcm9wVHlwZXMubnVtYmVyLFxuICBjaGlsZHJlbkNvbHVtbk5hbWU6IFByb3BUeXBlcy5zdHJpbmcsXG4gIGV4cGFuZGVkUm93UmVuZGVyOiBQcm9wVHlwZXMuZnVuYyxcbiAgb25FeHBhbmRlZENoYW5nZTogUHJvcFR5cGVzLmZ1bmMuaXNSZXF1aXJlZCxcbiAgb25Sb3dDbGljazogUHJvcFR5cGVzLmZ1bmMsXG4gIGNoaWxkcmVuOiBQcm9wVHlwZXMuZnVuYy5pc1JlcXVpcmVkXG59O1xuXG5cbmV4cG9ydCBkZWZhdWx0IGNvbm5lY3QoZnVuY3Rpb24gKF9yZWYsIF9yZWYyKSB7XG4gIHZhciBleHBhbmRlZFJvd0tleXMgPSBfcmVmLmV4cGFuZGVkUm93S2V5cztcbiAgdmFyIHJvd0tleSA9IF9yZWYyLnJvd0tleTtcbiAgcmV0dXJuIHtcbiAgICBleHBhbmRlZDogISF+ZXhwYW5kZWRSb3dLZXlzLmluZGV4T2Yocm93S2V5KVxuICB9O1xufSkoRXhwYW5kYWJsZVJvdyk7IiwiaW1wb3J0IF9leHRlbmRzIGZyb20gJ2JhYmVsLXJ1bnRpbWUvaGVscGVycy9leHRlbmRzJztcbmltcG9ydCBfY2xhc3NDYWxsQ2hlY2sgZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL2NsYXNzQ2FsbENoZWNrJztcbmltcG9ydCBfcG9zc2libGVDb25zdHJ1Y3RvclJldHVybiBmcm9tICdiYWJlbC1ydW50aW1lL2hlbHBlcnMvcG9zc2libGVDb25zdHJ1Y3RvclJldHVybic7XG5pbXBvcnQgX2luaGVyaXRzIGZyb20gJ2JhYmVsLXJ1bnRpbWUvaGVscGVycy9pbmhlcml0cyc7XG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcbmltcG9ydCB7IGNvbm5lY3QgfSBmcm9tICdtaW5pLXN0b3JlJztcbmltcG9ydCB7IHBvbHlmaWxsIH0gZnJvbSAncmVhY3QtbGlmZWN5Y2xlcy1jb21wYXQnO1xuaW1wb3J0IFRhYmxlUm93IGZyb20gJy4vVGFibGVSb3cnO1xuaW1wb3J0IHsgcmVtb3ZlIH0gZnJvbSAnLi91dGlscyc7XG5cbnZhciBFeHBhbmRhYmxlVGFibGUgPSBmdW5jdGlvbiAoX1JlYWN0JENvbXBvbmVudCkge1xuICBfaW5oZXJpdHMoRXhwYW5kYWJsZVRhYmxlLCBfUmVhY3QkQ29tcG9uZW50KTtcblxuICBmdW5jdGlvbiBFeHBhbmRhYmxlVGFibGUocHJvcHMpIHtcbiAgICBfY2xhc3NDYWxsQ2hlY2sodGhpcywgRXhwYW5kYWJsZVRhYmxlKTtcblxuICAgIHZhciBfdGhpcyA9IF9wb3NzaWJsZUNvbnN0cnVjdG9yUmV0dXJuKHRoaXMsIF9SZWFjdCRDb21wb25lbnQuY2FsbCh0aGlzLCBwcm9wcykpO1xuXG4gICAgX2luaXRpYWxpc2VQcm9wcy5jYWxsKF90aGlzKTtcblxuICAgIHZhciBkYXRhID0gcHJvcHMuZGF0YSxcbiAgICAgICAgY2hpbGRyZW5Db2x1bW5OYW1lID0gcHJvcHMuY2hpbGRyZW5Db2x1bW5OYW1lLFxuICAgICAgICBkZWZhdWx0RXhwYW5kQWxsUm93cyA9IHByb3BzLmRlZmF1bHRFeHBhbmRBbGxSb3dzLFxuICAgICAgICBleHBhbmRlZFJvd0tleXMgPSBwcm9wcy5leHBhbmRlZFJvd0tleXMsXG4gICAgICAgIGRlZmF1bHRFeHBhbmRlZFJvd0tleXMgPSBwcm9wcy5kZWZhdWx0RXhwYW5kZWRSb3dLZXlzLFxuICAgICAgICBnZXRSb3dLZXkgPSBwcm9wcy5nZXRSb3dLZXk7XG5cblxuICAgIHZhciBmaW5uYWxFeHBhbmRlZFJvd0tleXMgPSBbXTtcbiAgICB2YXIgcm93cyA9IFtdLmNvbmNhdChkYXRhKTtcblxuICAgIGlmIChkZWZhdWx0RXhwYW5kQWxsUm93cykge1xuICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCByb3dzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIHZhciByb3cgPSByb3dzW2ldO1xuICAgICAgICBmaW5uYWxFeHBhbmRlZFJvd0tleXMucHVzaChnZXRSb3dLZXkocm93LCBpKSk7XG4gICAgICAgIHJvd3MgPSByb3dzLmNvbmNhdChyb3dbY2hpbGRyZW5Db2x1bW5OYW1lXSB8fCBbXSk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIGZpbm5hbEV4cGFuZGVkUm93S2V5cyA9IGV4cGFuZGVkUm93S2V5cyB8fCBkZWZhdWx0RXhwYW5kZWRSb3dLZXlzO1xuICAgIH1cblxuICAgIF90aGlzLmNvbHVtbk1hbmFnZXIgPSBwcm9wcy5jb2x1bW5NYW5hZ2VyO1xuICAgIF90aGlzLnN0b3JlID0gcHJvcHMuc3RvcmU7XG5cbiAgICBfdGhpcy5zdG9yZS5zZXRTdGF0ZSh7XG4gICAgICBleHBhbmRlZFJvd3NIZWlnaHQ6IHt9LFxuICAgICAgZXhwYW5kZWRSb3dLZXlzOiBmaW5uYWxFeHBhbmRlZFJvd0tleXNcbiAgICB9KTtcbiAgICByZXR1cm4gX3RoaXM7XG4gIH1cblxuICBFeHBhbmRhYmxlVGFibGUucHJvdG90eXBlLmNvbXBvbmVudERpZFVwZGF0ZSA9IGZ1bmN0aW9uIGNvbXBvbmVudERpZFVwZGF0ZSgpIHtcbiAgICBpZiAoJ2V4cGFuZGVkUm93S2V5cycgaW4gdGhpcy5wcm9wcykge1xuICAgICAgdGhpcy5zdG9yZS5zZXRTdGF0ZSh7XG4gICAgICAgIGV4cGFuZGVkUm93S2V5czogdGhpcy5wcm9wcy5leHBhbmRlZFJvd0tleXNcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcblxuICBFeHBhbmRhYmxlVGFibGUucHJvdG90eXBlLnJlbmRlckV4cGFuZGVkUm93ID0gZnVuY3Rpb24gcmVuZGVyRXhwYW5kZWRSb3cocmVjb3JkLCBpbmRleCwgX3JlbmRlciwgY2xhc3NOYW1lLCBhbmNlc3RvcktleXMsIGluZGVudCwgZml4ZWQpIHtcbiAgICB2YXIgX3Byb3BzID0gdGhpcy5wcm9wcyxcbiAgICAgICAgcHJlZml4Q2xzID0gX3Byb3BzLnByZWZpeENscyxcbiAgICAgICAgZXhwYW5kSWNvbkFzQ2VsbCA9IF9wcm9wcy5leHBhbmRJY29uQXNDZWxsLFxuICAgICAgICBpbmRlbnRTaXplID0gX3Byb3BzLmluZGVudFNpemU7XG5cbiAgICB2YXIgY29sQ291bnQgPSB2b2lkIDA7XG4gICAgaWYgKGZpeGVkID09PSAnbGVmdCcpIHtcbiAgICAgIGNvbENvdW50ID0gdGhpcy5jb2x1bW5NYW5hZ2VyLmxlZnRMZWFmQ29sdW1ucygpLmxlbmd0aDtcbiAgICB9IGVsc2UgaWYgKGZpeGVkID09PSAncmlnaHQnKSB7XG4gICAgICBjb2xDb3VudCA9IHRoaXMuY29sdW1uTWFuYWdlci5yaWdodExlYWZDb2x1bW5zKCkubGVuZ3RoO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb2xDb3VudCA9IHRoaXMuY29sdW1uTWFuYWdlci5sZWFmQ29sdW1ucygpLmxlbmd0aDtcbiAgICB9XG4gICAgdmFyIGNvbHVtbnMgPSBbe1xuICAgICAga2V5OiAnZXh0cmEtcm93JyxcbiAgICAgIHJlbmRlcjogZnVuY3Rpb24gcmVuZGVyKCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIHByb3BzOiB7XG4gICAgICAgICAgICBjb2xTcGFuOiBjb2xDb3VudFxuICAgICAgICAgIH0sXG4gICAgICAgICAgY2hpbGRyZW46IGZpeGVkICE9PSAncmlnaHQnID8gX3JlbmRlcihyZWNvcmQsIGluZGV4LCBpbmRlbnQpIDogJyZuYnNwOydcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICB9XTtcbiAgICBpZiAoZXhwYW5kSWNvbkFzQ2VsbCAmJiBmaXhlZCAhPT0gJ3JpZ2h0Jykge1xuICAgICAgY29sdW1ucy51bnNoaWZ0KHtcbiAgICAgICAga2V5OiAnZXhwYW5kLWljb24tcGxhY2Vob2xkZXInLFxuICAgICAgICByZW5kZXI6IGZ1bmN0aW9uIHJlbmRlcigpIHtcbiAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICAgIHZhciBwYXJlbnRLZXkgPSBhbmNlc3RvcktleXNbYW5jZXN0b3JLZXlzLmxlbmd0aCAtIDFdO1xuICAgIHZhciByb3dLZXkgPSBwYXJlbnRLZXkgKyAnLWV4dHJhLXJvdyc7XG4gICAgdmFyIGNvbXBvbmVudHMgPSB7XG4gICAgICBib2R5OiB7XG4gICAgICAgIHJvdzogJ3RyJyxcbiAgICAgICAgY2VsbDogJ3RkJ1xuICAgICAgfVxuICAgIH07XG5cbiAgICByZXR1cm4gUmVhY3QuY3JlYXRlRWxlbWVudChUYWJsZVJvdywge1xuICAgICAga2V5OiByb3dLZXksXG4gICAgICBjb2x1bW5zOiBjb2x1bW5zLFxuICAgICAgY2xhc3NOYW1lOiBjbGFzc05hbWUsXG4gICAgICByb3dLZXk6IHJvd0tleSxcbiAgICAgIGFuY2VzdG9yS2V5czogYW5jZXN0b3JLZXlzLFxuICAgICAgcHJlZml4Q2xzOiBwcmVmaXhDbHMgKyAnLWV4cGFuZGVkLXJvdycsXG4gICAgICBpbmRlbnRTaXplOiBpbmRlbnRTaXplLFxuICAgICAgaW5kZW50OiBpbmRlbnQsXG4gICAgICBmaXhlZDogZml4ZWQsXG4gICAgICBjb21wb25lbnRzOiBjb21wb25lbnRzLFxuICAgICAgZXhwYW5kZWRSb3c6IHRydWVcbiAgICB9KTtcbiAgfTtcblxuICBFeHBhbmRhYmxlVGFibGUucHJvdG90eXBlLnJlbmRlciA9IGZ1bmN0aW9uIHJlbmRlcigpIHtcbiAgICB2YXIgX3Byb3BzMiA9IHRoaXMucHJvcHMsXG4gICAgICAgIGRhdGEgPSBfcHJvcHMyLmRhdGEsXG4gICAgICAgIGNoaWxkcmVuQ29sdW1uTmFtZSA9IF9wcm9wczIuY2hpbGRyZW5Db2x1bW5OYW1lLFxuICAgICAgICBjaGlsZHJlbiA9IF9wcm9wczIuY2hpbGRyZW47XG5cbiAgICB2YXIgbmVlZEluZGVudFNwYWNlZCA9IGRhdGEuc29tZShmdW5jdGlvbiAocmVjb3JkKSB7XG4gICAgICByZXR1cm4gcmVjb3JkW2NoaWxkcmVuQ29sdW1uTmFtZV07XG4gICAgfSk7XG5cbiAgICByZXR1cm4gY2hpbGRyZW4oe1xuICAgICAgcHJvcHM6IHRoaXMucHJvcHMsXG4gICAgICBuZWVkSW5kZW50U3BhY2VkOiBuZWVkSW5kZW50U3BhY2VkLFxuICAgICAgcmVuZGVyUm93czogdGhpcy5yZW5kZXJSb3dzLFxuICAgICAgaGFuZGxlRXhwYW5kQ2hhbmdlOiB0aGlzLmhhbmRsZUV4cGFuZENoYW5nZSxcbiAgICAgIHJlbmRlckV4cGFuZEluZGVudENlbGw6IHRoaXMucmVuZGVyRXhwYW5kSW5kZW50Q2VsbFxuICAgIH0pO1xuICB9O1xuXG4gIHJldHVybiBFeHBhbmRhYmxlVGFibGU7XG59KFJlYWN0LkNvbXBvbmVudCk7XG5cbkV4cGFuZGFibGVUYWJsZS5wcm9wVHlwZXMgPSB7XG4gIGV4cGFuZEljb25Bc0NlbGw6IFByb3BUeXBlcy5ib29sLFxuICBleHBhbmRlZFJvd0tleXM6IFByb3BUeXBlcy5hcnJheSxcbiAgZXhwYW5kZWRSb3dDbGFzc05hbWU6IFByb3BUeXBlcy5mdW5jLFxuICBkZWZhdWx0RXhwYW5kQWxsUm93czogUHJvcFR5cGVzLmJvb2wsXG4gIGRlZmF1bHRFeHBhbmRlZFJvd0tleXM6IFByb3BUeXBlcy5hcnJheSxcbiAgZXhwYW5kSWNvbkNvbHVtbkluZGV4OiBQcm9wVHlwZXMubnVtYmVyLFxuICBleHBhbmRlZFJvd1JlbmRlcjogUHJvcFR5cGVzLmZ1bmMsXG4gIGNoaWxkcmVuQ29sdW1uTmFtZTogUHJvcFR5cGVzLnN0cmluZyxcbiAgaW5kZW50U2l6ZTogUHJvcFR5cGVzLm51bWJlcixcbiAgb25FeHBhbmQ6IFByb3BUeXBlcy5mdW5jLFxuICBvbkV4cGFuZGVkUm93c0NoYW5nZTogUHJvcFR5cGVzLmZ1bmMsXG4gIGNvbHVtbk1hbmFnZXI6IFByb3BUeXBlcy5vYmplY3QuaXNSZXF1aXJlZCxcbiAgc3RvcmU6IFByb3BUeXBlcy5vYmplY3QuaXNSZXF1aXJlZCxcbiAgcHJlZml4Q2xzOiBQcm9wVHlwZXMuc3RyaW5nLmlzUmVxdWlyZWQsXG4gIGRhdGE6IFByb3BUeXBlcy5hcnJheSxcbiAgY2hpbGRyZW46IFByb3BUeXBlcy5mdW5jLmlzUmVxdWlyZWQsXG4gIGdldFJvd0tleTogUHJvcFR5cGVzLmZ1bmMuaXNSZXF1aXJlZFxufTtcbkV4cGFuZGFibGVUYWJsZS5kZWZhdWx0UHJvcHMgPSB7XG4gIGV4cGFuZEljb25Bc0NlbGw6IGZhbHNlLFxuICBleHBhbmRlZFJvd0NsYXNzTmFtZTogZnVuY3Rpb24gZXhwYW5kZWRSb3dDbGFzc05hbWUoKSB7XG4gICAgcmV0dXJuICcnO1xuICB9LFxuICBleHBhbmRJY29uQ29sdW1uSW5kZXg6IDAsXG4gIGRlZmF1bHRFeHBhbmRBbGxSb3dzOiBmYWxzZSxcbiAgZGVmYXVsdEV4cGFuZGVkUm93S2V5czogW10sXG4gIGNoaWxkcmVuQ29sdW1uTmFtZTogJ2NoaWxkcmVuJyxcbiAgaW5kZW50U2l6ZTogMTUsXG4gIG9uRXhwYW5kOiBmdW5jdGlvbiBvbkV4cGFuZCgpIHt9LFxuICBvbkV4cGFuZGVkUm93c0NoYW5nZTogZnVuY3Rpb24gb25FeHBhbmRlZFJvd3NDaGFuZ2UoKSB7fVxufTtcblxudmFyIF9pbml0aWFsaXNlUHJvcHMgPSBmdW5jdGlvbiBfaW5pdGlhbGlzZVByb3BzKCkge1xuICB2YXIgX3RoaXMyID0gdGhpcztcblxuICB0aGlzLmhhbmRsZUV4cGFuZENoYW5nZSA9IGZ1bmN0aW9uIChleHBhbmRlZCwgcmVjb3JkLCBldmVudCwgcm93S2V5KSB7XG4gICAgdmFyIGRlc3Ryb3kgPSBhcmd1bWVudHMubGVuZ3RoID4gNCAmJiBhcmd1bWVudHNbNF0gIT09IHVuZGVmaW5lZCA/IGFyZ3VtZW50c1s0XSA6IGZhbHNlO1xuXG4gICAgaWYgKGV2ZW50KSB7XG4gICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgfVxuXG4gICAgdmFyIF9wcm9wczMgPSBfdGhpczIucHJvcHMsXG4gICAgICAgIG9uRXhwYW5kZWRSb3dzQ2hhbmdlID0gX3Byb3BzMy5vbkV4cGFuZGVkUm93c0NoYW5nZSxcbiAgICAgICAgb25FeHBhbmQgPSBfcHJvcHMzLm9uRXhwYW5kO1xuXG4gICAgdmFyIF9zdG9yZSRnZXRTdGF0ZSA9IF90aGlzMi5zdG9yZS5nZXRTdGF0ZSgpLFxuICAgICAgICBleHBhbmRlZFJvd0tleXMgPSBfc3RvcmUkZ2V0U3RhdGUuZXhwYW5kZWRSb3dLZXlzO1xuXG4gICAgaWYgKGV4cGFuZGVkKSB7XG4gICAgICAvLyByb3cgd2FzIGV4cGFuZWRcbiAgICAgIGV4cGFuZGVkUm93S2V5cyA9IFtdLmNvbmNhdChleHBhbmRlZFJvd0tleXMsIFtyb3dLZXldKTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gcm93IHdhcyBjb2xsYXBzZVxuICAgICAgdmFyIGV4cGFuZGVkUm93SW5kZXggPSBleHBhbmRlZFJvd0tleXMuaW5kZXhPZihyb3dLZXkpO1xuICAgICAgaWYgKGV4cGFuZGVkUm93SW5kZXggIT09IC0xKSB7XG4gICAgICAgIGV4cGFuZGVkUm93S2V5cyA9IHJlbW92ZShleHBhbmRlZFJvd0tleXMsIHJvd0tleSk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKCFfdGhpczIucHJvcHMuZXhwYW5kZWRSb3dLZXlzKSB7XG4gICAgICBfdGhpczIuc3RvcmUuc2V0U3RhdGUoeyBleHBhbmRlZFJvd0tleXM6IGV4cGFuZGVkUm93S2V5cyB9KTtcbiAgICB9XG5cbiAgICBvbkV4cGFuZGVkUm93c0NoYW5nZShleHBhbmRlZFJvd0tleXMpO1xuICAgIGlmICghZGVzdHJveSkge1xuICAgICAgb25FeHBhbmQoZXhwYW5kZWQsIHJlY29yZCk7XG4gICAgfVxuICB9O1xuXG4gIHRoaXMucmVuZGVyRXhwYW5kSW5kZW50Q2VsbCA9IGZ1bmN0aW9uIChyb3dzLCBmaXhlZCkge1xuICAgIHZhciBfcHJvcHM0ID0gX3RoaXMyLnByb3BzLFxuICAgICAgICBwcmVmaXhDbHMgPSBfcHJvcHM0LnByZWZpeENscyxcbiAgICAgICAgZXhwYW5kSWNvbkFzQ2VsbCA9IF9wcm9wczQuZXhwYW5kSWNvbkFzQ2VsbDtcblxuICAgIGlmICghZXhwYW5kSWNvbkFzQ2VsbCB8fCBmaXhlZCA9PT0gJ3JpZ2h0JyB8fCAhcm93cy5sZW5ndGgpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICB2YXIgaWNvbkNvbHVtbiA9IHtcbiAgICAgIGtleTogJ3JjLXRhYmxlLWV4cGFuZC1pY29uLWNlbGwnLFxuICAgICAgY2xhc3NOYW1lOiBwcmVmaXhDbHMgKyAnLWV4cGFuZC1pY29uLXRoJyxcbiAgICAgIHRpdGxlOiAnJyxcbiAgICAgIHJvd1NwYW46IHJvd3MubGVuZ3RoXG4gICAgfTtcblxuICAgIHJvd3NbMF0udW5zaGlmdChfZXh0ZW5kcyh7fSwgaWNvbkNvbHVtbiwgeyBjb2x1bW46IGljb25Db2x1bW4gfSkpO1xuICB9O1xuXG4gIHRoaXMucmVuZGVyUm93cyA9IGZ1bmN0aW9uIChyZW5kZXJSb3dzLCByb3dzLCByZWNvcmQsIGluZGV4LCBpbmRlbnQsIGZpeGVkLCBwYXJlbnRLZXksIGFuY2VzdG9yS2V5cykge1xuICAgIHZhciBfcHJvcHM1ID0gX3RoaXMyLnByb3BzLFxuICAgICAgICBleHBhbmRlZFJvd0NsYXNzTmFtZSA9IF9wcm9wczUuZXhwYW5kZWRSb3dDbGFzc05hbWUsXG4gICAgICAgIGV4cGFuZGVkUm93UmVuZGVyID0gX3Byb3BzNS5leHBhbmRlZFJvd1JlbmRlcixcbiAgICAgICAgY2hpbGRyZW5Db2x1bW5OYW1lID0gX3Byb3BzNS5jaGlsZHJlbkNvbHVtbk5hbWU7XG5cbiAgICB2YXIgY2hpbGRyZW5EYXRhID0gcmVjb3JkW2NoaWxkcmVuQ29sdW1uTmFtZV07XG4gICAgdmFyIG5leHRBbmNlc3RvcktleXMgPSBbXS5jb25jYXQoYW5jZXN0b3JLZXlzLCBbcGFyZW50S2V5XSk7XG4gICAgdmFyIG5leHRJbmRlbnQgPSBpbmRlbnQgKyAxO1xuXG4gICAgaWYgKGV4cGFuZGVkUm93UmVuZGVyKSB7XG4gICAgICByb3dzLnB1c2goX3RoaXMyLnJlbmRlckV4cGFuZGVkUm93KHJlY29yZCwgaW5kZXgsIGV4cGFuZGVkUm93UmVuZGVyLCBleHBhbmRlZFJvd0NsYXNzTmFtZShyZWNvcmQsIGluZGV4LCBpbmRlbnQpLCBuZXh0QW5jZXN0b3JLZXlzLCBuZXh0SW5kZW50LCBmaXhlZCkpO1xuICAgIH1cblxuICAgIGlmIChjaGlsZHJlbkRhdGEpIHtcbiAgICAgIHJvd3MucHVzaC5hcHBseShyb3dzLCByZW5kZXJSb3dzKGNoaWxkcmVuRGF0YSwgbmV4dEluZGVudCwgbmV4dEFuY2VzdG9yS2V5cykpO1xuICAgIH1cbiAgfTtcbn07XG5cbnBvbHlmaWxsKEV4cGFuZGFibGVUYWJsZSk7XG5cbmV4cG9ydCBkZWZhdWx0IGNvbm5lY3QoKShFeHBhbmRhYmxlVGFibGUpOyIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnO1xuaW1wb3J0IHsgbWVhc3VyZVNjcm9sbGJhciB9IGZyb20gJy4vdXRpbHMnO1xuaW1wb3J0IEJhc2VUYWJsZSBmcm9tICcuL0Jhc2VUYWJsZSc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEhlYWRUYWJsZShwcm9wcywgX3JlZikge1xuICB2YXIgdGFibGUgPSBfcmVmLnRhYmxlO1xuICB2YXIgX3RhYmxlJHByb3BzID0gdGFibGUucHJvcHMsXG4gICAgICBwcmVmaXhDbHMgPSBfdGFibGUkcHJvcHMucHJlZml4Q2xzLFxuICAgICAgc2Nyb2xsID0gX3RhYmxlJHByb3BzLnNjcm9sbCxcbiAgICAgIHNob3dIZWFkZXIgPSBfdGFibGUkcHJvcHMuc2hvd0hlYWRlcjtcbiAgdmFyIGNvbHVtbnMgPSBwcm9wcy5jb2x1bW5zLFxuICAgICAgZml4ZWQgPSBwcm9wcy5maXhlZCxcbiAgICAgIHRhYmxlQ2xhc3NOYW1lID0gcHJvcHMudGFibGVDbGFzc05hbWUsXG4gICAgICBoYW5kbGVCb2R5U2Nyb2xsTGVmdCA9IHByb3BzLmhhbmRsZUJvZHlTY3JvbGxMZWZ0LFxuICAgICAgZXhwYW5kZXIgPSBwcm9wcy5leHBhbmRlcjtcbiAgdmFyIHNhdmVSZWYgPSB0YWJsZS5zYXZlUmVmO1xuICB2YXIgdXNlRml4ZWRIZWFkZXIgPSB0YWJsZS5wcm9wcy51c2VGaXhlZEhlYWRlcjtcblxuICB2YXIgaGVhZFN0eWxlID0ge307XG5cbiAgaWYgKHNjcm9sbC55KSB7XG4gICAgdXNlRml4ZWRIZWFkZXIgPSB0cnVlO1xuICAgIC8vIEFkZCBuZWdhdGl2ZSBtYXJnaW4gYm90dG9tIGZvciBzY3JvbGwgYmFyIG92ZXJmbG93IGJ1Z1xuICAgIHZhciBzY3JvbGxiYXJXaWR0aCA9IG1lYXN1cmVTY3JvbGxiYXIoJ2hvcml6b250YWwnKTtcbiAgICBpZiAoc2Nyb2xsYmFyV2lkdGggPiAwICYmICFmaXhlZCkge1xuICAgICAgaGVhZFN0eWxlLm1hcmdpbkJvdHRvbSA9ICctJyArIHNjcm9sbGJhcldpZHRoICsgJ3B4JztcbiAgICAgIGhlYWRTdHlsZS5wYWRkaW5nQm90dG9tID0gJzBweCc7XG4gICAgfVxuICB9XG5cbiAgaWYgKCF1c2VGaXhlZEhlYWRlciB8fCAhc2hvd0hlYWRlcikge1xuICAgIHJldHVybiBudWxsO1xuICB9XG5cbiAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXG4gICAgJ2RpdicsXG4gICAge1xuICAgICAga2V5OiAnaGVhZFRhYmxlJyxcbiAgICAgIHJlZjogZml4ZWQgPyBudWxsIDogc2F2ZVJlZignaGVhZFRhYmxlJyksXG4gICAgICBjbGFzc05hbWU6IHByZWZpeENscyArICctaGVhZGVyJyxcbiAgICAgIHN0eWxlOiBoZWFkU3R5bGUsXG4gICAgICBvblNjcm9sbDogaGFuZGxlQm9keVNjcm9sbExlZnRcbiAgICB9LFxuICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQmFzZVRhYmxlLCB7XG4gICAgICB0YWJsZUNsYXNzTmFtZTogdGFibGVDbGFzc05hbWUsXG4gICAgICBoYXNIZWFkOiB0cnVlLFxuICAgICAgaGFzQm9keTogZmFsc2UsXG4gICAgICBmaXhlZDogZml4ZWQsXG4gICAgICBjb2x1bW5zOiBjb2x1bW5zLFxuICAgICAgZXhwYW5kZXI6IGV4cGFuZGVyXG4gICAgfSlcbiAgKTtcbn1cblxuSGVhZFRhYmxlLnByb3BUeXBlcyA9IHtcbiAgZml4ZWQ6IFByb3BUeXBlcy5vbmVPZlR5cGUoW1Byb3BUeXBlcy5zdHJpbmcsIFByb3BUeXBlcy5ib29sXSksXG4gIGNvbHVtbnM6IFByb3BUeXBlcy5hcnJheS5pc1JlcXVpcmVkLFxuICB0YWJsZUNsYXNzTmFtZTogUHJvcFR5cGVzLnN0cmluZy5pc1JlcXVpcmVkLFxuICBoYW5kbGVCb2R5U2Nyb2xsTGVmdDogUHJvcFR5cGVzLmZ1bmMuaXNSZXF1aXJlZCxcbiAgZXhwYW5kZXI6IFByb3BUeXBlcy5vYmplY3QuaXNSZXF1aXJlZFxufTtcblxuSGVhZFRhYmxlLmNvbnRleHRUeXBlcyA9IHtcbiAgdGFibGU6IFByb3BUeXBlcy5hbnlcbn07IiwiaW1wb3J0IF9leHRlbmRzIGZyb20gJ2JhYmVsLXJ1bnRpbWUvaGVscGVycy9leHRlbmRzJztcbmltcG9ydCBfY2xhc3NDYWxsQ2hlY2sgZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL2NsYXNzQ2FsbENoZWNrJztcbmltcG9ydCBfcG9zc2libGVDb25zdHJ1Y3RvclJldHVybiBmcm9tICdiYWJlbC1ydW50aW1lL2hlbHBlcnMvcG9zc2libGVDb25zdHJ1Y3RvclJldHVybic7XG5pbXBvcnQgX2luaGVyaXRzIGZyb20gJ2JhYmVsLXJ1bnRpbWUvaGVscGVycy9pbmhlcml0cyc7XG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcbmltcG9ydCBzaGFsbG93ZXF1YWwgZnJvbSAnc2hhbGxvd2VxdWFsJztcbmltcG9ydCBhZGRFdmVudExpc3RlbmVyIGZyb20gJ3JjLXV0aWwvZXMvRG9tL2FkZEV2ZW50TGlzdGVuZXInO1xuaW1wb3J0IHsgUHJvdmlkZXIsIGNyZWF0ZSB9IGZyb20gJ21pbmktc3RvcmUnO1xuaW1wb3J0IG1lcmdlIGZyb20gJ2xvZGFzaC9tZXJnZSc7XG5pbXBvcnQgY2xhc3NlcyBmcm9tICdjb21wb25lbnQtY2xhc3Nlcyc7XG5pbXBvcnQgeyBwb2x5ZmlsbCB9IGZyb20gJ3JlYWN0LWxpZmVjeWNsZXMtY29tcGF0JztcbmltcG9ydCB7IGRlYm91bmNlLCB3YXJuaW5nT25jZSB9IGZyb20gJy4vdXRpbHMnO1xuaW1wb3J0IENvbHVtbk1hbmFnZXIgZnJvbSAnLi9Db2x1bW5NYW5hZ2VyJztcbmltcG9ydCBIZWFkVGFibGUgZnJvbSAnLi9IZWFkVGFibGUnO1xuaW1wb3J0IEJvZHlUYWJsZSBmcm9tICcuL0JvZHlUYWJsZSc7XG5pbXBvcnQgRXhwYW5kYWJsZVRhYmxlIGZyb20gJy4vRXhwYW5kYWJsZVRhYmxlJztcblxudmFyIFRhYmxlID0gZnVuY3Rpb24gKF9SZWFjdCRDb21wb25lbnQpIHtcbiAgX2luaGVyaXRzKFRhYmxlLCBfUmVhY3QkQ29tcG9uZW50KTtcblxuICBUYWJsZS5nZXREZXJpdmVkU3RhdGVGcm9tUHJvcHMgPSBmdW5jdGlvbiBnZXREZXJpdmVkU3RhdGVGcm9tUHJvcHMobmV4dFByb3BzLCBwcmV2U3RhdGUpIHtcbiAgICBpZiAobmV4dFByb3BzLmNvbHVtbnMgJiYgbmV4dFByb3BzLmNvbHVtbnMgIT09IHByZXZTdGF0ZS5jb2x1bW5zKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBjb2x1bW5zOiBuZXh0UHJvcHMuY29sdW1ucyxcbiAgICAgICAgY2hpbGRyZW46IG51bGxcbiAgICAgIH07XG4gICAgfSBlbHNlIGlmIChuZXh0UHJvcHMuY2hpbGRyZW4gIT09IHByZXZTdGF0ZS5jaGlsZHJlbikge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgY29sdW1uczogbnVsbCxcbiAgICAgICAgY2hpbGRyZW46IG5leHRQcm9wcy5jaGlsZHJlblxuICAgICAgfTtcbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG4gIH07XG5cbiAgZnVuY3Rpb24gVGFibGUocHJvcHMpIHtcbiAgICBfY2xhc3NDYWxsQ2hlY2sodGhpcywgVGFibGUpO1xuXG4gICAgdmFyIF90aGlzID0gX3Bvc3NpYmxlQ29uc3RydWN0b3JSZXR1cm4odGhpcywgX1JlYWN0JENvbXBvbmVudC5jYWxsKHRoaXMsIHByb3BzKSk7XG5cbiAgICBfdGhpcy5zdGF0ZSA9IHt9O1xuXG4gICAgX3RoaXMuZ2V0Um93S2V5ID0gZnVuY3Rpb24gKHJlY29yZCwgaW5kZXgpIHtcbiAgICAgIHZhciByb3dLZXkgPSBfdGhpcy5wcm9wcy5yb3dLZXk7XG4gICAgICB2YXIga2V5ID0gdHlwZW9mIHJvd0tleSA9PT0gJ2Z1bmN0aW9uJyA/IHJvd0tleShyZWNvcmQsIGluZGV4KSA6IHJlY29yZFtyb3dLZXldO1xuICAgICAgd2FybmluZ09uY2Uoa2V5ICE9PSB1bmRlZmluZWQsICdFYWNoIHJlY29yZCBpbiB0YWJsZSBzaG91bGQgaGF2ZSBhIHVuaXF1ZSBga2V5YCBwcm9wLCcgKyAnb3Igc2V0IGByb3dLZXlgIHRvIGFuIHVuaXF1ZSBwcmltYXJ5IGtleS4nKTtcbiAgICAgIHJldHVybiBrZXkgPT09IHVuZGVmaW5lZCA/IGluZGV4IDoga2V5O1xuICAgIH07XG5cbiAgICBfdGhpcy5oYW5kbGVXaW5kb3dSZXNpemUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICBfdGhpcy5zeW5jRml4ZWRUYWJsZVJvd0hlaWdodCgpO1xuICAgICAgX3RoaXMuc2V0U2Nyb2xsUG9zaXRpb25DbGFzc05hbWUoKTtcbiAgICB9O1xuXG4gICAgX3RoaXMuc3luY0ZpeGVkVGFibGVSb3dIZWlnaHQgPSBmdW5jdGlvbiAoKSB7XG4gICAgICB2YXIgdGFibGVSZWN0ID0gX3RoaXMudGFibGVOb2RlLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgICAgLy8gSWYgdGFibGVOb2RlJ3MgaGVpZ2h0IGxlc3MgdGhhbiAwLCBzdXBwb3NlIGl0IGlzIGhpZGRlbiBhbmQgZG9uJ3QgcmVjYWxjdWxhdGUgcm93SGVpZ2h0LlxuICAgICAgLy8gc2VlOiBodHRwczovL2dpdGh1Yi5jb20vYW50LWRlc2lnbi9hbnQtZGVzaWduL2lzc3Vlcy80ODM2XG4gICAgICBpZiAodGFibGVSZWN0LmhlaWdodCAhPT0gdW5kZWZpbmVkICYmIHRhYmxlUmVjdC5oZWlnaHQgPD0gMCkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICB2YXIgcHJlZml4Q2xzID0gX3RoaXMucHJvcHMucHJlZml4Q2xzO1xuXG4gICAgICB2YXIgaGVhZFJvd3MgPSBfdGhpcy5oZWFkVGFibGUgPyBfdGhpcy5oZWFkVGFibGUucXVlcnlTZWxlY3RvckFsbCgndGhlYWQnKSA6IF90aGlzLmJvZHlUYWJsZS5xdWVyeVNlbGVjdG9yQWxsKCd0aGVhZCcpO1xuICAgICAgdmFyIGJvZHlSb3dzID0gX3RoaXMuYm9keVRhYmxlLnF1ZXJ5U2VsZWN0b3JBbGwoJy4nICsgcHJlZml4Q2xzICsgJy1yb3cnKSB8fCBbXTtcbiAgICAgIHZhciBmaXhlZENvbHVtbnNIZWFkUm93c0hlaWdodCA9IFtdLm1hcC5jYWxsKGhlYWRSb3dzLCBmdW5jdGlvbiAocm93KSB7XG4gICAgICAgIHJldHVybiByb3cuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkuaGVpZ2h0IHx8ICdhdXRvJztcbiAgICAgIH0pO1xuICAgICAgdmFyIGZpeGVkQ29sdW1uc0JvZHlSb3dzSGVpZ2h0ID0gW10ubWFwLmNhbGwoYm9keVJvd3MsIGZ1bmN0aW9uIChyb3cpIHtcbiAgICAgICAgcmV0dXJuIHJvdy5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5oZWlnaHQgfHwgJ2F1dG8nO1xuICAgICAgfSk7XG4gICAgICB2YXIgc3RhdGUgPSBfdGhpcy5zdG9yZS5nZXRTdGF0ZSgpO1xuICAgICAgaWYgKHNoYWxsb3dlcXVhbChzdGF0ZS5maXhlZENvbHVtbnNIZWFkUm93c0hlaWdodCwgZml4ZWRDb2x1bW5zSGVhZFJvd3NIZWlnaHQpICYmIHNoYWxsb3dlcXVhbChzdGF0ZS5maXhlZENvbHVtbnNCb2R5Um93c0hlaWdodCwgZml4ZWRDb2x1bW5zQm9keVJvd3NIZWlnaHQpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgX3RoaXMuc3RvcmUuc2V0U3RhdGUoe1xuICAgICAgICBmaXhlZENvbHVtbnNIZWFkUm93c0hlaWdodDogZml4ZWRDb2x1bW5zSGVhZFJvd3NIZWlnaHQsXG4gICAgICAgIGZpeGVkQ29sdW1uc0JvZHlSb3dzSGVpZ2h0OiBmaXhlZENvbHVtbnNCb2R5Um93c0hlaWdodFxuICAgICAgfSk7XG4gICAgfTtcblxuICAgIF90aGlzLmhhbmRsZUJvZHlTY3JvbGxMZWZ0ID0gZnVuY3Rpb24gKGUpIHtcbiAgICAgIC8vIEZpeCBodHRwczovL2dpdGh1Yi5jb20vYW50LWRlc2lnbi9hbnQtZGVzaWduL2lzc3Vlcy83NjM1XG4gICAgICBpZiAoZS5jdXJyZW50VGFyZ2V0ICE9PSBlLnRhcmdldCkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICB2YXIgdGFyZ2V0ID0gZS50YXJnZXQ7XG4gICAgICB2YXIgX3RoaXMkcHJvcHMkc2Nyb2xsID0gX3RoaXMucHJvcHMuc2Nyb2xsLFxuICAgICAgICAgIHNjcm9sbCA9IF90aGlzJHByb3BzJHNjcm9sbCA9PT0gdW5kZWZpbmVkID8ge30gOiBfdGhpcyRwcm9wcyRzY3JvbGw7XG4gICAgICB2YXIgaGVhZFRhYmxlID0gX3RoaXMuaGVhZFRhYmxlLFxuICAgICAgICAgIGJvZHlUYWJsZSA9IF90aGlzLmJvZHlUYWJsZTtcblxuICAgICAgaWYgKHRhcmdldC5zY3JvbGxMZWZ0ICE9PSBfdGhpcy5sYXN0U2Nyb2xsTGVmdCAmJiBzY3JvbGwueCkge1xuICAgICAgICBpZiAodGFyZ2V0ID09PSBib2R5VGFibGUgJiYgaGVhZFRhYmxlKSB7XG4gICAgICAgICAgaGVhZFRhYmxlLnNjcm9sbExlZnQgPSB0YXJnZXQuc2Nyb2xsTGVmdDtcbiAgICAgICAgfSBlbHNlIGlmICh0YXJnZXQgPT09IGhlYWRUYWJsZSAmJiBib2R5VGFibGUpIHtcbiAgICAgICAgICBib2R5VGFibGUuc2Nyb2xsTGVmdCA9IHRhcmdldC5zY3JvbGxMZWZ0O1xuICAgICAgICB9XG4gICAgICAgIF90aGlzLnNldFNjcm9sbFBvc2l0aW9uQ2xhc3NOYW1lKCk7XG4gICAgICB9XG4gICAgICAvLyBSZW1lbWJlciBsYXN0IHNjcm9sbExlZnQgZm9yIHNjcm9sbCBkaXJlY3Rpb24gZGV0ZWN0aW5nLlxuICAgICAgX3RoaXMubGFzdFNjcm9sbExlZnQgPSB0YXJnZXQuc2Nyb2xsTGVmdDtcbiAgICB9O1xuXG4gICAgX3RoaXMuaGFuZGxlQm9keVNjcm9sbFRvcCA9IGZ1bmN0aW9uIChlKSB7XG4gICAgICB2YXIgdGFyZ2V0ID0gZS50YXJnZXQ7XG4gICAgICAvLyBGaXggaHR0cHM6Ly9naXRodWIuY29tL2FudC1kZXNpZ24vYW50LWRlc2lnbi9pc3N1ZXMvOTAzM1xuICAgICAgaWYgKGUuY3VycmVudFRhcmdldCAhPT0gdGFyZ2V0KSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIHZhciBfdGhpcyRwcm9wcyRzY3JvbGwyID0gX3RoaXMucHJvcHMuc2Nyb2xsLFxuICAgICAgICAgIHNjcm9sbCA9IF90aGlzJHByb3BzJHNjcm9sbDIgPT09IHVuZGVmaW5lZCA/IHt9IDogX3RoaXMkcHJvcHMkc2Nyb2xsMjtcbiAgICAgIHZhciBoZWFkVGFibGUgPSBfdGhpcy5oZWFkVGFibGUsXG4gICAgICAgICAgYm9keVRhYmxlID0gX3RoaXMuYm9keVRhYmxlLFxuICAgICAgICAgIGZpeGVkQ29sdW1uc0JvZHlMZWZ0ID0gX3RoaXMuZml4ZWRDb2x1bW5zQm9keUxlZnQsXG4gICAgICAgICAgZml4ZWRDb2x1bW5zQm9keVJpZ2h0ID0gX3RoaXMuZml4ZWRDb2x1bW5zQm9keVJpZ2h0O1xuXG4gICAgICBpZiAodGFyZ2V0LnNjcm9sbFRvcCAhPT0gX3RoaXMubGFzdFNjcm9sbFRvcCAmJiBzY3JvbGwueSAmJiB0YXJnZXQgIT09IGhlYWRUYWJsZSkge1xuICAgICAgICB2YXIgc2Nyb2xsVG9wID0gdGFyZ2V0LnNjcm9sbFRvcDtcbiAgICAgICAgaWYgKGZpeGVkQ29sdW1uc0JvZHlMZWZ0ICYmIHRhcmdldCAhPT0gZml4ZWRDb2x1bW5zQm9keUxlZnQpIHtcbiAgICAgICAgICBmaXhlZENvbHVtbnNCb2R5TGVmdC5zY3JvbGxUb3AgPSBzY3JvbGxUb3A7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGZpeGVkQ29sdW1uc0JvZHlSaWdodCAmJiB0YXJnZXQgIT09IGZpeGVkQ29sdW1uc0JvZHlSaWdodCkge1xuICAgICAgICAgIGZpeGVkQ29sdW1uc0JvZHlSaWdodC5zY3JvbGxUb3AgPSBzY3JvbGxUb3A7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGJvZHlUYWJsZSAmJiB0YXJnZXQgIT09IGJvZHlUYWJsZSkge1xuICAgICAgICAgIGJvZHlUYWJsZS5zY3JvbGxUb3AgPSBzY3JvbGxUb3A7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIC8vIFJlbWVtYmVyIGxhc3Qgc2Nyb2xsVG9wIGZvciBzY3JvbGwgZGlyZWN0aW9uIGRldGVjdGluZy5cbiAgICAgIF90aGlzLmxhc3RTY3JvbGxUb3AgPSB0YXJnZXQuc2Nyb2xsVG9wO1xuICAgIH07XG5cbiAgICBfdGhpcy5oYW5kbGVCb2R5U2Nyb2xsID0gZnVuY3Rpb24gKGUpIHtcbiAgICAgIF90aGlzLmhhbmRsZUJvZHlTY3JvbGxMZWZ0KGUpO1xuICAgICAgX3RoaXMuaGFuZGxlQm9keVNjcm9sbFRvcChlKTtcbiAgICB9O1xuXG4gICAgX3RoaXMuaGFuZGxlV2hlZWwgPSBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgIHZhciBfdGhpcyRwcm9wcyRzY3JvbGwzID0gX3RoaXMucHJvcHMuc2Nyb2xsLFxuICAgICAgICAgIHNjcm9sbCA9IF90aGlzJHByb3BzJHNjcm9sbDMgPT09IHVuZGVmaW5lZCA/IHt9IDogX3RoaXMkcHJvcHMkc2Nyb2xsMztcblxuICAgICAgaWYgKHdpbmRvdy5uYXZpZ2F0b3IudXNlckFnZW50Lm1hdGNoKC9UcmlkZW50XFwvN1xcLi8pICYmIHNjcm9sbC55KSB7XG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIHZhciB3ZCA9IGV2ZW50LmRlbHRhWTtcbiAgICAgICAgdmFyIHRhcmdldCA9IGV2ZW50LnRhcmdldDtcbiAgICAgICAgdmFyIGJvZHlUYWJsZSA9IF90aGlzLmJvZHlUYWJsZSxcbiAgICAgICAgICAgIGZpeGVkQ29sdW1uc0JvZHlMZWZ0ID0gX3RoaXMuZml4ZWRDb2x1bW5zQm9keUxlZnQsXG4gICAgICAgICAgICBmaXhlZENvbHVtbnNCb2R5UmlnaHQgPSBfdGhpcy5maXhlZENvbHVtbnNCb2R5UmlnaHQ7XG5cbiAgICAgICAgdmFyIHNjcm9sbFRvcCA9IDA7XG5cbiAgICAgICAgaWYgKF90aGlzLmxhc3RTY3JvbGxUb3ApIHtcbiAgICAgICAgICBzY3JvbGxUb3AgPSBfdGhpcy5sYXN0U2Nyb2xsVG9wICsgd2Q7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgc2Nyb2xsVG9wID0gd2Q7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoZml4ZWRDb2x1bW5zQm9keUxlZnQgJiYgdGFyZ2V0ICE9PSBmaXhlZENvbHVtbnNCb2R5TGVmdCkge1xuICAgICAgICAgIGZpeGVkQ29sdW1uc0JvZHlMZWZ0LnNjcm9sbFRvcCA9IHNjcm9sbFRvcDtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZml4ZWRDb2x1bW5zQm9keVJpZ2h0ICYmIHRhcmdldCAhPT0gZml4ZWRDb2x1bW5zQm9keVJpZ2h0KSB7XG4gICAgICAgICAgZml4ZWRDb2x1bW5zQm9keVJpZ2h0LnNjcm9sbFRvcCA9IHNjcm9sbFRvcDtcbiAgICAgICAgfVxuICAgICAgICBpZiAoYm9keVRhYmxlICYmIHRhcmdldCAhPT0gYm9keVRhYmxlKSB7XG4gICAgICAgICAgYm9keVRhYmxlLnNjcm9sbFRvcCA9IHNjcm9sbFRvcDtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH07XG5cbiAgICBfdGhpcy5zYXZlUmVmID0gZnVuY3Rpb24gKG5hbWUpIHtcbiAgICAgIHJldHVybiBmdW5jdGlvbiAobm9kZSkge1xuICAgICAgICBfdGhpc1tuYW1lXSA9IG5vZGU7XG4gICAgICB9O1xuICAgIH07XG5cbiAgICBbJ29uUm93Q2xpY2snLCAnb25Sb3dEb3VibGVDbGljaycsICdvblJvd0NvbnRleHRNZW51JywgJ29uUm93TW91c2VFbnRlcicsICdvblJvd01vdXNlTGVhdmUnXS5mb3JFYWNoKGZ1bmN0aW9uIChuYW1lKSB7XG4gICAgICB3YXJuaW5nT25jZShwcm9wc1tuYW1lXSA9PT0gdW5kZWZpbmVkLCBuYW1lICsgJyBpcyBkZXByZWNhdGVkLCBwbGVhc2UgdXNlIG9uUm93IGluc3RlYWQuJyk7XG4gICAgfSk7XG5cbiAgICB3YXJuaW5nT25jZShwcm9wcy5nZXRCb2R5V3JhcHBlciA9PT0gdW5kZWZpbmVkLCAnZ2V0Qm9keVdyYXBwZXIgaXMgZGVwcmVjYXRlZCwgcGxlYXNlIHVzZSBjdXN0b20gY29tcG9uZW50cyBpbnN0ZWFkLicpO1xuXG4gICAgX3RoaXMuY29sdW1uTWFuYWdlciA9IG5ldyBDb2x1bW5NYW5hZ2VyKHByb3BzLmNvbHVtbnMsIHByb3BzLmNoaWxkcmVuKTtcblxuICAgIF90aGlzLnN0b3JlID0gY3JlYXRlKHtcbiAgICAgIGN1cnJlbnRIb3ZlcktleTogbnVsbCxcbiAgICAgIGZpeGVkQ29sdW1uc0hlYWRSb3dzSGVpZ2h0OiBbXSxcbiAgICAgIGZpeGVkQ29sdW1uc0JvZHlSb3dzSGVpZ2h0OiBbXVxuICAgIH0pO1xuXG4gICAgX3RoaXMuc2V0U2Nyb2xsUG9zaXRpb24oJ2xlZnQnKTtcblxuICAgIF90aGlzLmRlYm91bmNlZFdpbmRvd1Jlc2l6ZSA9IGRlYm91bmNlKF90aGlzLmhhbmRsZVdpbmRvd1Jlc2l6ZSwgMTUwKTtcbiAgICByZXR1cm4gX3RoaXM7XG4gIH1cblxuICBUYWJsZS5wcm90b3R5cGUuZ2V0Q2hpbGRDb250ZXh0ID0gZnVuY3Rpb24gZ2V0Q2hpbGRDb250ZXh0KCkge1xuICAgIHJldHVybiB7XG4gICAgICB0YWJsZToge1xuICAgICAgICBwcm9wczogdGhpcy5wcm9wcyxcbiAgICAgICAgY29sdW1uTWFuYWdlcjogdGhpcy5jb2x1bW5NYW5hZ2VyLFxuICAgICAgICBzYXZlUmVmOiB0aGlzLnNhdmVSZWYsXG4gICAgICAgIGNvbXBvbmVudHM6IG1lcmdlKHtcbiAgICAgICAgICB0YWJsZTogJ3RhYmxlJyxcbiAgICAgICAgICBoZWFkZXI6IHtcbiAgICAgICAgICAgIHdyYXBwZXI6ICd0aGVhZCcsXG4gICAgICAgICAgICByb3c6ICd0cicsXG4gICAgICAgICAgICBjZWxsOiAndGgnXG4gICAgICAgICAgfSxcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICB3cmFwcGVyOiAndGJvZHknLFxuICAgICAgICAgICAgcm93OiAndHInLFxuICAgICAgICAgICAgY2VsbDogJ3RkJ1xuICAgICAgICAgIH1cbiAgICAgICAgfSwgdGhpcy5wcm9wcy5jb21wb25lbnRzKVxuICAgICAgfVxuICAgIH07XG4gIH07XG5cbiAgVGFibGUucHJvdG90eXBlLmNvbXBvbmVudERpZE1vdW50ID0gZnVuY3Rpb24gY29tcG9uZW50RGlkTW91bnQoKSB7XG4gICAgaWYgKHRoaXMuY29sdW1uTWFuYWdlci5pc0FueUNvbHVtbnNGaXhlZCgpKSB7XG4gICAgICB0aGlzLmhhbmRsZVdpbmRvd1Jlc2l6ZSgpO1xuICAgICAgdGhpcy5yZXNpemVFdmVudCA9IGFkZEV2ZW50TGlzdGVuZXIod2luZG93LCAncmVzaXplJywgdGhpcy5kZWJvdW5jZWRXaW5kb3dSZXNpemUpO1xuICAgIH1cbiAgfTtcblxuICBUYWJsZS5wcm90b3R5cGUuY29tcG9uZW50RGlkVXBkYXRlID0gZnVuY3Rpb24gY29tcG9uZW50RGlkVXBkYXRlKHByZXZQcm9wcykge1xuICAgIGlmICh0aGlzLmNvbHVtbk1hbmFnZXIuaXNBbnlDb2x1bW5zRml4ZWQoKSkge1xuICAgICAgdGhpcy5oYW5kbGVXaW5kb3dSZXNpemUoKTtcbiAgICAgIGlmICghdGhpcy5yZXNpemVFdmVudCkge1xuICAgICAgICB0aGlzLnJlc2l6ZUV2ZW50ID0gYWRkRXZlbnRMaXN0ZW5lcih3aW5kb3csICdyZXNpemUnLCB0aGlzLmRlYm91bmNlZFdpbmRvd1Jlc2l6ZSk7XG4gICAgICB9XG4gICAgfVxuICAgIC8vIHdoZW4gdGFibGUgY2hhbmdlcyB0byBlbXB0eSwgcmVzZXQgc2Nyb2xsTGVmdFxuICAgIGlmIChwcmV2UHJvcHMuZGF0YS5sZW5ndGggPiAwICYmIHRoaXMucHJvcHMuZGF0YS5sZW5ndGggPT09IDAgJiYgdGhpcy5oYXNTY3JvbGxYKCkpIHtcbiAgICAgIHRoaXMucmVzZXRTY3JvbGxYKCk7XG4gICAgfVxuICB9O1xuXG4gIFRhYmxlLnByb3RvdHlwZS5jb21wb25lbnRXaWxsVW5tb3VudCA9IGZ1bmN0aW9uIGNvbXBvbmVudFdpbGxVbm1vdW50KCkge1xuICAgIGlmICh0aGlzLnJlc2l6ZUV2ZW50KSB7XG4gICAgICB0aGlzLnJlc2l6ZUV2ZW50LnJlbW92ZSgpO1xuICAgIH1cbiAgICBpZiAodGhpcy5kZWJvdW5jZWRXaW5kb3dSZXNpemUpIHtcbiAgICAgIHRoaXMuZGVib3VuY2VkV2luZG93UmVzaXplLmNhbmNlbCgpO1xuICAgIH1cbiAgfTtcblxuICBUYWJsZS5wcm90b3R5cGUuc2V0U2Nyb2xsUG9zaXRpb24gPSBmdW5jdGlvbiBzZXRTY3JvbGxQb3NpdGlvbihwb3NpdGlvbikge1xuICAgIHRoaXMuc2Nyb2xsUG9zaXRpb24gPSBwb3NpdGlvbjtcbiAgICBpZiAodGhpcy50YWJsZU5vZGUpIHtcbiAgICAgIHZhciBwcmVmaXhDbHMgPSB0aGlzLnByb3BzLnByZWZpeENscztcblxuICAgICAgaWYgKHBvc2l0aW9uID09PSAnYm90aCcpIHtcbiAgICAgICAgY2xhc3Nlcyh0aGlzLnRhYmxlTm9kZSkucmVtb3ZlKG5ldyBSZWdFeHAoJ14nICsgcHJlZml4Q2xzICsgJy1zY3JvbGwtcG9zaXRpb24tLiskJykpLmFkZChwcmVmaXhDbHMgKyAnLXNjcm9sbC1wb3NpdGlvbi1sZWZ0JykuYWRkKHByZWZpeENscyArICctc2Nyb2xsLXBvc2l0aW9uLXJpZ2h0Jyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjbGFzc2VzKHRoaXMudGFibGVOb2RlKS5yZW1vdmUobmV3IFJlZ0V4cCgnXicgKyBwcmVmaXhDbHMgKyAnLXNjcm9sbC1wb3NpdGlvbi0uKyQnKSkuYWRkKHByZWZpeENscyArICctc2Nyb2xsLXBvc2l0aW9uLScgKyBwb3NpdGlvbik7XG4gICAgICB9XG4gICAgfVxuICB9O1xuXG4gIFRhYmxlLnByb3RvdHlwZS5zZXRTY3JvbGxQb3NpdGlvbkNsYXNzTmFtZSA9IGZ1bmN0aW9uIHNldFNjcm9sbFBvc2l0aW9uQ2xhc3NOYW1lKCkge1xuICAgIHZhciBub2RlID0gdGhpcy5ib2R5VGFibGU7XG4gICAgdmFyIHNjcm9sbFRvTGVmdCA9IG5vZGUuc2Nyb2xsTGVmdCA9PT0gMDtcbiAgICB2YXIgc2Nyb2xsVG9SaWdodCA9IG5vZGUuc2Nyb2xsTGVmdCArIDEgPj0gbm9kZS5jaGlsZHJlblswXS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS53aWR0aCAtIG5vZGUuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkud2lkdGg7XG4gICAgaWYgKHNjcm9sbFRvTGVmdCAmJiBzY3JvbGxUb1JpZ2h0KSB7XG4gICAgICB0aGlzLnNldFNjcm9sbFBvc2l0aW9uKCdib3RoJyk7XG4gICAgfSBlbHNlIGlmIChzY3JvbGxUb0xlZnQpIHtcbiAgICAgIHRoaXMuc2V0U2Nyb2xsUG9zaXRpb24oJ2xlZnQnKTtcbiAgICB9IGVsc2UgaWYgKHNjcm9sbFRvUmlnaHQpIHtcbiAgICAgIHRoaXMuc2V0U2Nyb2xsUG9zaXRpb24oJ3JpZ2h0Jyk7XG4gICAgfSBlbHNlIGlmICh0aGlzLnNjcm9sbFBvc2l0aW9uICE9PSAnbWlkZGxlJykge1xuICAgICAgdGhpcy5zZXRTY3JvbGxQb3NpdGlvbignbWlkZGxlJyk7XG4gICAgfVxuICB9O1xuXG4gIFRhYmxlLnByb3RvdHlwZS5yZXNldFNjcm9sbFggPSBmdW5jdGlvbiByZXNldFNjcm9sbFgoKSB7XG4gICAgaWYgKHRoaXMuaGVhZFRhYmxlKSB7XG4gICAgICB0aGlzLmhlYWRUYWJsZS5zY3JvbGxMZWZ0ID0gMDtcbiAgICB9XG4gICAgaWYgKHRoaXMuYm9keVRhYmxlKSB7XG4gICAgICB0aGlzLmJvZHlUYWJsZS5zY3JvbGxMZWZ0ID0gMDtcbiAgICB9XG4gIH07XG5cbiAgVGFibGUucHJvdG90eXBlLmhhc1Njcm9sbFggPSBmdW5jdGlvbiBoYXNTY3JvbGxYKCkge1xuICAgIHZhciBfcHJvcHMkc2Nyb2xsID0gdGhpcy5wcm9wcy5zY3JvbGwsXG4gICAgICAgIHNjcm9sbCA9IF9wcm9wcyRzY3JvbGwgPT09IHVuZGVmaW5lZCA/IHt9IDogX3Byb3BzJHNjcm9sbDtcblxuICAgIHJldHVybiAneCcgaW4gc2Nyb2xsO1xuICB9O1xuXG4gIFRhYmxlLnByb3RvdHlwZS5yZW5kZXJNYWluVGFibGUgPSBmdW5jdGlvbiByZW5kZXJNYWluVGFibGUoKSB7XG4gICAgdmFyIF9wcm9wcyA9IHRoaXMucHJvcHMsXG4gICAgICAgIHNjcm9sbCA9IF9wcm9wcy5zY3JvbGwsXG4gICAgICAgIHByZWZpeENscyA9IF9wcm9wcy5wcmVmaXhDbHM7XG5cbiAgICB2YXIgaXNBbnlDb2x1bW5zRml4ZWQgPSB0aGlzLmNvbHVtbk1hbmFnZXIuaXNBbnlDb2x1bW5zRml4ZWQoKTtcbiAgICB2YXIgc2Nyb2xsYWJsZSA9IGlzQW55Q29sdW1uc0ZpeGVkIHx8IHNjcm9sbC54IHx8IHNjcm9sbC55O1xuXG4gICAgdmFyIHRhYmxlID0gW3RoaXMucmVuZGVyVGFibGUoe1xuICAgICAgY29sdW1uczogdGhpcy5jb2x1bW5NYW5hZ2VyLmdyb3VwZWRDb2x1bW5zKCksXG4gICAgICBpc0FueUNvbHVtbnNGaXhlZDogaXNBbnlDb2x1bW5zRml4ZWRcbiAgICB9KSwgdGhpcy5yZW5kZXJFbXB0eVRleHQoKSwgdGhpcy5yZW5kZXJGb290ZXIoKV07XG5cbiAgICByZXR1cm4gc2Nyb2xsYWJsZSA/IFJlYWN0LmNyZWF0ZUVsZW1lbnQoXG4gICAgICAnZGl2JyxcbiAgICAgIHsgY2xhc3NOYW1lOiBwcmVmaXhDbHMgKyAnLXNjcm9sbCcgfSxcbiAgICAgIHRhYmxlXG4gICAgKSA6IHRhYmxlO1xuICB9O1xuXG4gIFRhYmxlLnByb3RvdHlwZS5yZW5kZXJMZWZ0Rml4ZWRUYWJsZSA9IGZ1bmN0aW9uIHJlbmRlckxlZnRGaXhlZFRhYmxlKCkge1xuICAgIHZhciBwcmVmaXhDbHMgPSB0aGlzLnByb3BzLnByZWZpeENscztcblxuXG4gICAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXG4gICAgICAnZGl2JyxcbiAgICAgIHsgY2xhc3NOYW1lOiBwcmVmaXhDbHMgKyAnLWZpeGVkLWxlZnQnIH0sXG4gICAgICB0aGlzLnJlbmRlclRhYmxlKHtcbiAgICAgICAgY29sdW1uczogdGhpcy5jb2x1bW5NYW5hZ2VyLmxlZnRDb2x1bW5zKCksXG4gICAgICAgIGZpeGVkOiAnbGVmdCdcbiAgICAgIH0pXG4gICAgKTtcbiAgfTtcblxuICBUYWJsZS5wcm90b3R5cGUucmVuZGVyUmlnaHRGaXhlZFRhYmxlID0gZnVuY3Rpb24gcmVuZGVyUmlnaHRGaXhlZFRhYmxlKCkge1xuICAgIHZhciBwcmVmaXhDbHMgPSB0aGlzLnByb3BzLnByZWZpeENscztcblxuXG4gICAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXG4gICAgICAnZGl2JyxcbiAgICAgIHsgY2xhc3NOYW1lOiBwcmVmaXhDbHMgKyAnLWZpeGVkLXJpZ2h0JyB9LFxuICAgICAgdGhpcy5yZW5kZXJUYWJsZSh7XG4gICAgICAgIGNvbHVtbnM6IHRoaXMuY29sdW1uTWFuYWdlci5yaWdodENvbHVtbnMoKSxcbiAgICAgICAgZml4ZWQ6ICdyaWdodCdcbiAgICAgIH0pXG4gICAgKTtcbiAgfTtcblxuICBUYWJsZS5wcm90b3R5cGUucmVuZGVyVGFibGUgPSBmdW5jdGlvbiByZW5kZXJUYWJsZShvcHRpb25zKSB7XG4gICAgdmFyIGNvbHVtbnMgPSBvcHRpb25zLmNvbHVtbnMsXG4gICAgICAgIGZpeGVkID0gb3B0aW9ucy5maXhlZCxcbiAgICAgICAgaXNBbnlDb2x1bW5zRml4ZWQgPSBvcHRpb25zLmlzQW55Q29sdW1uc0ZpeGVkO1xuICAgIHZhciBfcHJvcHMyID0gdGhpcy5wcm9wcyxcbiAgICAgICAgcHJlZml4Q2xzID0gX3Byb3BzMi5wcmVmaXhDbHMsXG4gICAgICAgIF9wcm9wczIkc2Nyb2xsID0gX3Byb3BzMi5zY3JvbGwsXG4gICAgICAgIHNjcm9sbCA9IF9wcm9wczIkc2Nyb2xsID09PSB1bmRlZmluZWQgPyB7fSA6IF9wcm9wczIkc2Nyb2xsO1xuXG4gICAgdmFyIHRhYmxlQ2xhc3NOYW1lID0gc2Nyb2xsLnggfHwgZml4ZWQgPyBwcmVmaXhDbHMgKyAnLWZpeGVkJyA6ICcnO1xuXG4gICAgdmFyIGhlYWRUYWJsZSA9IFJlYWN0LmNyZWF0ZUVsZW1lbnQoSGVhZFRhYmxlLCB7XG4gICAgICBrZXk6ICdoZWFkJyxcbiAgICAgIGNvbHVtbnM6IGNvbHVtbnMsXG4gICAgICBmaXhlZDogZml4ZWQsXG4gICAgICB0YWJsZUNsYXNzTmFtZTogdGFibGVDbGFzc05hbWUsXG4gICAgICBoYW5kbGVCb2R5U2Nyb2xsTGVmdDogdGhpcy5oYW5kbGVCb2R5U2Nyb2xsTGVmdCxcbiAgICAgIGV4cGFuZGVyOiB0aGlzLmV4cGFuZGVyXG4gICAgfSk7XG5cbiAgICB2YXIgYm9keVRhYmxlID0gUmVhY3QuY3JlYXRlRWxlbWVudChCb2R5VGFibGUsIHtcbiAgICAgIGtleTogJ2JvZHknLFxuICAgICAgY29sdW1uczogY29sdW1ucyxcbiAgICAgIGZpeGVkOiBmaXhlZCxcbiAgICAgIHRhYmxlQ2xhc3NOYW1lOiB0YWJsZUNsYXNzTmFtZSxcbiAgICAgIGdldFJvd0tleTogdGhpcy5nZXRSb3dLZXksXG4gICAgICBoYW5kbGVXaGVlbDogdGhpcy5oYW5kbGVXaGVlbCxcbiAgICAgIGhhbmRsZUJvZHlTY3JvbGw6IHRoaXMuaGFuZGxlQm9keVNjcm9sbCxcbiAgICAgIGV4cGFuZGVyOiB0aGlzLmV4cGFuZGVyLFxuICAgICAgaXNBbnlDb2x1bW5zRml4ZWQ6IGlzQW55Q29sdW1uc0ZpeGVkXG4gICAgfSk7XG5cbiAgICByZXR1cm4gW2hlYWRUYWJsZSwgYm9keVRhYmxlXTtcbiAgfTtcblxuICBUYWJsZS5wcm90b3R5cGUucmVuZGVyVGl0bGUgPSBmdW5jdGlvbiByZW5kZXJUaXRsZSgpIHtcbiAgICB2YXIgX3Byb3BzMyA9IHRoaXMucHJvcHMsXG4gICAgICAgIHRpdGxlID0gX3Byb3BzMy50aXRsZSxcbiAgICAgICAgcHJlZml4Q2xzID0gX3Byb3BzMy5wcmVmaXhDbHM7XG5cbiAgICByZXR1cm4gdGl0bGUgPyBSZWFjdC5jcmVhdGVFbGVtZW50KFxuICAgICAgJ2RpdicsXG4gICAgICB7IGNsYXNzTmFtZTogcHJlZml4Q2xzICsgJy10aXRsZScsIGtleTogJ3RpdGxlJyB9LFxuICAgICAgdGl0bGUodGhpcy5wcm9wcy5kYXRhKVxuICAgICkgOiBudWxsO1xuICB9O1xuXG4gIFRhYmxlLnByb3RvdHlwZS5yZW5kZXJGb290ZXIgPSBmdW5jdGlvbiByZW5kZXJGb290ZXIoKSB7XG4gICAgdmFyIF9wcm9wczQgPSB0aGlzLnByb3BzLFxuICAgICAgICBmb290ZXIgPSBfcHJvcHM0LmZvb3RlcixcbiAgICAgICAgcHJlZml4Q2xzID0gX3Byb3BzNC5wcmVmaXhDbHM7XG5cbiAgICByZXR1cm4gZm9vdGVyID8gUmVhY3QuY3JlYXRlRWxlbWVudChcbiAgICAgICdkaXYnLFxuICAgICAgeyBjbGFzc05hbWU6IHByZWZpeENscyArICctZm9vdGVyJywga2V5OiAnZm9vdGVyJyB9LFxuICAgICAgZm9vdGVyKHRoaXMucHJvcHMuZGF0YSlcbiAgICApIDogbnVsbDtcbiAgfTtcblxuICBUYWJsZS5wcm90b3R5cGUucmVuZGVyRW1wdHlUZXh0ID0gZnVuY3Rpb24gcmVuZGVyRW1wdHlUZXh0KCkge1xuICAgIHZhciBfcHJvcHM1ID0gdGhpcy5wcm9wcyxcbiAgICAgICAgZW1wdHlUZXh0ID0gX3Byb3BzNS5lbXB0eVRleHQsXG4gICAgICAgIHByZWZpeENscyA9IF9wcm9wczUucHJlZml4Q2xzLFxuICAgICAgICBkYXRhID0gX3Byb3BzNS5kYXRhO1xuXG4gICAgaWYgKGRhdGEubGVuZ3RoKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgdmFyIGVtcHR5Q2xhc3NOYW1lID0gcHJlZml4Q2xzICsgJy1wbGFjZWhvbGRlcic7XG4gICAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXG4gICAgICAnZGl2JyxcbiAgICAgIHsgY2xhc3NOYW1lOiBlbXB0eUNsYXNzTmFtZSwga2V5OiAnZW1wdHlUZXh0JyB9LFxuICAgICAgdHlwZW9mIGVtcHR5VGV4dCA9PT0gJ2Z1bmN0aW9uJyA/IGVtcHR5VGV4dCgpIDogZW1wdHlUZXh0XG4gICAgKTtcbiAgfTtcblxuICBUYWJsZS5wcm90b3R5cGUucmVuZGVyID0gZnVuY3Rpb24gcmVuZGVyKCkge1xuICAgIHZhciBfdGhpczIgPSB0aGlzO1xuXG4gICAgdmFyIHByb3BzID0gdGhpcy5wcm9wcztcbiAgICB2YXIgcHJlZml4Q2xzID0gcHJvcHMucHJlZml4Q2xzO1xuXG4gICAgaWYgKHRoaXMuc3RhdGUuY29sdW1ucykge1xuICAgICAgdGhpcy5jb2x1bW5NYW5hZ2VyLnJlc2V0KHByb3BzLmNvbHVtbnMpO1xuICAgIH0gZWxzZSBpZiAodGhpcy5zdGF0ZS5jaGlsZHJlbikge1xuICAgICAgdGhpcy5jb2x1bW5NYW5hZ2VyLnJlc2V0KG51bGwsIHByb3BzLmNoaWxkcmVuKTtcbiAgICB9XG5cbiAgICB2YXIgY2xhc3NOYW1lID0gcHJvcHMucHJlZml4Q2xzO1xuICAgIGlmIChwcm9wcy5jbGFzc05hbWUpIHtcbiAgICAgIGNsYXNzTmFtZSArPSAnICcgKyBwcm9wcy5jbGFzc05hbWU7XG4gICAgfVxuICAgIGlmIChwcm9wcy51c2VGaXhlZEhlYWRlciB8fCBwcm9wcy5zY3JvbGwgJiYgcHJvcHMuc2Nyb2xsLnkpIHtcbiAgICAgIGNsYXNzTmFtZSArPSAnICcgKyBwcmVmaXhDbHMgKyAnLWZpeGVkLWhlYWRlcic7XG4gICAgfVxuICAgIGlmICh0aGlzLnNjcm9sbFBvc2l0aW9uID09PSAnYm90aCcpIHtcbiAgICAgIGNsYXNzTmFtZSArPSAnICcgKyBwcmVmaXhDbHMgKyAnLXNjcm9sbC1wb3NpdGlvbi1sZWZ0ICcgKyBwcmVmaXhDbHMgKyAnLXNjcm9sbC1wb3NpdGlvbi1yaWdodCc7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNsYXNzTmFtZSArPSAnICcgKyBwcmVmaXhDbHMgKyAnLXNjcm9sbC1wb3NpdGlvbi0nICsgdGhpcy5zY3JvbGxQb3NpdGlvbjtcbiAgICB9XG4gICAgdmFyIGhhc0xlZnRGaXhlZCA9IHRoaXMuY29sdW1uTWFuYWdlci5pc0FueUNvbHVtbnNMZWZ0Rml4ZWQoKTtcbiAgICB2YXIgaGFzUmlnaHRGaXhlZCA9IHRoaXMuY29sdW1uTWFuYWdlci5pc0FueUNvbHVtbnNSaWdodEZpeGVkKCk7XG5cbiAgICByZXR1cm4gUmVhY3QuY3JlYXRlRWxlbWVudChcbiAgICAgIFByb3ZpZGVyLFxuICAgICAgeyBzdG9yZTogdGhpcy5zdG9yZSB9LFxuICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcbiAgICAgICAgRXhwYW5kYWJsZVRhYmxlLFxuICAgICAgICBfZXh0ZW5kcyh7fSwgcHJvcHMsIHsgY29sdW1uTWFuYWdlcjogdGhpcy5jb2x1bW5NYW5hZ2VyLCBnZXRSb3dLZXk6IHRoaXMuZ2V0Um93S2V5IH0pLFxuICAgICAgICBmdW5jdGlvbiAoZXhwYW5kZXIpIHtcbiAgICAgICAgICBfdGhpczIuZXhwYW5kZXIgPSBleHBhbmRlcjtcbiAgICAgICAgICByZXR1cm4gUmVhY3QuY3JlYXRlRWxlbWVudChcbiAgICAgICAgICAgICdkaXYnLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICByZWY6IF90aGlzMi5zYXZlUmVmKCd0YWJsZU5vZGUnKSxcbiAgICAgICAgICAgICAgY2xhc3NOYW1lOiBjbGFzc05hbWUsXG4gICAgICAgICAgICAgIHN0eWxlOiBwcm9wcy5zdHlsZSxcbiAgICAgICAgICAgICAgaWQ6IHByb3BzLmlkXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgX3RoaXMyLnJlbmRlclRpdGxlKCksXG4gICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFxuICAgICAgICAgICAgICAnZGl2JyxcbiAgICAgICAgICAgICAgeyBjbGFzc05hbWU6IHByZWZpeENscyArICctY29udGVudCcgfSxcbiAgICAgICAgICAgICAgX3RoaXMyLnJlbmRlck1haW5UYWJsZSgpLFxuICAgICAgICAgICAgICBoYXNMZWZ0Rml4ZWQgJiYgX3RoaXMyLnJlbmRlckxlZnRGaXhlZFRhYmxlKCksXG4gICAgICAgICAgICAgIGhhc1JpZ2h0Rml4ZWQgJiYgX3RoaXMyLnJlbmRlclJpZ2h0Rml4ZWRUYWJsZSgpXG4gICAgICAgICAgICApXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgKVxuICAgICk7XG4gIH07XG5cbiAgcmV0dXJuIFRhYmxlO1xufShSZWFjdC5Db21wb25lbnQpO1xuXG5UYWJsZS5wcm9wVHlwZXMgPSBfZXh0ZW5kcyh7XG4gIGRhdGE6IFByb3BUeXBlcy5hcnJheSxcbiAgdXNlRml4ZWRIZWFkZXI6IFByb3BUeXBlcy5ib29sLFxuICBjb2x1bW5zOiBQcm9wVHlwZXMuYXJyYXksXG4gIHByZWZpeENsczogUHJvcFR5cGVzLnN0cmluZyxcbiAgYm9keVN0eWxlOiBQcm9wVHlwZXMub2JqZWN0LFxuICBzdHlsZTogUHJvcFR5cGVzLm9iamVjdCxcbiAgcm93S2V5OiBQcm9wVHlwZXMub25lT2ZUeXBlKFtQcm9wVHlwZXMuc3RyaW5nLCBQcm9wVHlwZXMuZnVuY10pLFxuICByb3dDbGFzc05hbWU6IFByb3BUeXBlcy5vbmVPZlR5cGUoW1Byb3BUeXBlcy5zdHJpbmcsIFByb3BUeXBlcy5mdW5jXSksXG4gIG9uUm93OiBQcm9wVHlwZXMuZnVuYyxcbiAgb25IZWFkZXJSb3c6IFByb3BUeXBlcy5mdW5jLFxuICBvblJvd0NsaWNrOiBQcm9wVHlwZXMuZnVuYyxcbiAgb25Sb3dEb3VibGVDbGljazogUHJvcFR5cGVzLmZ1bmMsXG4gIG9uUm93Q29udGV4dE1lbnU6IFByb3BUeXBlcy5mdW5jLFxuICBvblJvd01vdXNlRW50ZXI6IFByb3BUeXBlcy5mdW5jLFxuICBvblJvd01vdXNlTGVhdmU6IFByb3BUeXBlcy5mdW5jLFxuICBzaG93SGVhZGVyOiBQcm9wVHlwZXMuYm9vbCxcbiAgdGl0bGU6IFByb3BUeXBlcy5mdW5jLFxuICBpZDogUHJvcFR5cGVzLnN0cmluZyxcbiAgZm9vdGVyOiBQcm9wVHlwZXMuZnVuYyxcbiAgZW1wdHlUZXh0OiBQcm9wVHlwZXMub25lT2ZUeXBlKFtQcm9wVHlwZXMubm9kZSwgUHJvcFR5cGVzLmZ1bmNdKSxcbiAgc2Nyb2xsOiBQcm9wVHlwZXMub2JqZWN0LFxuICByb3dSZWY6IFByb3BUeXBlcy5mdW5jLFxuICBnZXRCb2R5V3JhcHBlcjogUHJvcFR5cGVzLmZ1bmMsXG4gIGNoaWxkcmVuOiBQcm9wVHlwZXMubm9kZSxcbiAgY29tcG9uZW50czogUHJvcFR5cGVzLnNoYXBlKHtcbiAgICB0YWJsZTogUHJvcFR5cGVzLmFueSxcbiAgICBoZWFkZXI6IFByb3BUeXBlcy5zaGFwZSh7XG4gICAgICB3cmFwcGVyOiBQcm9wVHlwZXMuYW55LFxuICAgICAgcm93OiBQcm9wVHlwZXMuYW55LFxuICAgICAgY2VsbDogUHJvcFR5cGVzLmFueVxuICAgIH0pLFxuICAgIGJvZHk6IFByb3BUeXBlcy5zaGFwZSh7XG4gICAgICB3cmFwcGVyOiBQcm9wVHlwZXMuYW55LFxuICAgICAgcm93OiBQcm9wVHlwZXMuYW55LFxuICAgICAgY2VsbDogUHJvcFR5cGVzLmFueVxuICAgIH0pXG4gIH0pXG59LCBFeHBhbmRhYmxlVGFibGUuUHJvcFR5cGVzKTtcblRhYmxlLmNoaWxkQ29udGV4dFR5cGVzID0ge1xuICB0YWJsZTogUHJvcFR5cGVzLmFueSxcbiAgY29tcG9uZW50czogUHJvcFR5cGVzLmFueVxufTtcblRhYmxlLmRlZmF1bHRQcm9wcyA9IHtcbiAgZGF0YTogW10sXG4gIHVzZUZpeGVkSGVhZGVyOiBmYWxzZSxcbiAgcm93S2V5OiAna2V5JyxcbiAgcm93Q2xhc3NOYW1lOiBmdW5jdGlvbiByb3dDbGFzc05hbWUoKSB7XG4gICAgcmV0dXJuICcnO1xuICB9LFxuICBvblJvdzogZnVuY3Rpb24gb25Sb3coKSB7fSxcbiAgb25IZWFkZXJSb3c6IGZ1bmN0aW9uIG9uSGVhZGVyUm93KCkge30sXG5cbiAgcHJlZml4Q2xzOiAncmMtdGFibGUnLFxuICBib2R5U3R5bGU6IHt9LFxuICBzdHlsZToge30sXG4gIHNob3dIZWFkZXI6IHRydWUsXG4gIHNjcm9sbDoge30sXG4gIHJvd1JlZjogZnVuY3Rpb24gcm93UmVmKCkge1xuICAgIHJldHVybiBudWxsO1xuICB9LFxuICBlbXB0eVRleHQ6IGZ1bmN0aW9uIGVtcHR5VGV4dCgpIHtcbiAgICByZXR1cm4gJ05vIERhdGEnO1xuICB9XG59O1xuXG5cbnBvbHlmaWxsKFRhYmxlKTtcblxuZXhwb3J0IGRlZmF1bHQgVGFibGU7IiwiaW1wb3J0IF9leHRlbmRzIGZyb20gJ2JhYmVsLXJ1bnRpbWUvaGVscGVycy9leHRlbmRzJztcbmltcG9ydCBfY2xhc3NDYWxsQ2hlY2sgZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL2NsYXNzQ2FsbENoZWNrJztcbmltcG9ydCBfcG9zc2libGVDb25zdHJ1Y3RvclJldHVybiBmcm9tICdiYWJlbC1ydW50aW1lL2hlbHBlcnMvcG9zc2libGVDb25zdHJ1Y3RvclJldHVybic7XG5pbXBvcnQgX2luaGVyaXRzIGZyb20gJ2JhYmVsLXJ1bnRpbWUvaGVscGVycy9pbmhlcml0cyc7XG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcbmltcG9ydCBnZXQgZnJvbSAnbG9kYXNoL2dldCc7XG5cbmZ1bmN0aW9uIGlzSW52YWxpZFJlbmRlckNlbGxUZXh0KHRleHQpIHtcbiAgcmV0dXJuIHRleHQgJiYgIVJlYWN0LmlzVmFsaWRFbGVtZW50KHRleHQpICYmIE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbCh0ZXh0KSA9PT0gJ1tvYmplY3QgT2JqZWN0XSc7XG59XG5cbnZhciBUYWJsZUNlbGwgPSBmdW5jdGlvbiAoX1JlYWN0JENvbXBvbmVudCkge1xuICBfaW5oZXJpdHMoVGFibGVDZWxsLCBfUmVhY3QkQ29tcG9uZW50KTtcblxuICBmdW5jdGlvbiBUYWJsZUNlbGwoKSB7XG4gICAgdmFyIF90ZW1wLCBfdGhpcywgX3JldDtcblxuICAgIF9jbGFzc0NhbGxDaGVjayh0aGlzLCBUYWJsZUNlbGwpO1xuXG4gICAgZm9yICh2YXIgX2xlbiA9IGFyZ3VtZW50cy5sZW5ndGgsIGFyZ3MgPSBBcnJheShfbGVuKSwgX2tleSA9IDA7IF9rZXkgPCBfbGVuOyBfa2V5KyspIHtcbiAgICAgIGFyZ3NbX2tleV0gPSBhcmd1bWVudHNbX2tleV07XG4gICAgfVxuXG4gICAgcmV0dXJuIF9yZXQgPSAoX3RlbXAgPSAoX3RoaXMgPSBfcG9zc2libGVDb25zdHJ1Y3RvclJldHVybih0aGlzLCBfUmVhY3QkQ29tcG9uZW50LmNhbGwuYXBwbHkoX1JlYWN0JENvbXBvbmVudCwgW3RoaXNdLmNvbmNhdChhcmdzKSkpLCBfdGhpcyksIF90aGlzLmhhbmRsZUNsaWNrID0gZnVuY3Rpb24gKGUpIHtcbiAgICAgIHZhciBfdGhpcyRwcm9wcyA9IF90aGlzLnByb3BzLFxuICAgICAgICAgIHJlY29yZCA9IF90aGlzJHByb3BzLnJlY29yZCxcbiAgICAgICAgICBvbkNlbGxDbGljayA9IF90aGlzJHByb3BzLmNvbHVtbi5vbkNlbGxDbGljaztcblxuICAgICAgaWYgKG9uQ2VsbENsaWNrKSB7XG4gICAgICAgIG9uQ2VsbENsaWNrKHJlY29yZCwgZSk7XG4gICAgICB9XG4gICAgfSwgX3RlbXApLCBfcG9zc2libGVDb25zdHJ1Y3RvclJldHVybihfdGhpcywgX3JldCk7XG4gIH1cblxuICBUYWJsZUNlbGwucHJvdG90eXBlLnJlbmRlciA9IGZ1bmN0aW9uIHJlbmRlcigpIHtcbiAgICB2YXIgX3Byb3BzID0gdGhpcy5wcm9wcyxcbiAgICAgICAgcmVjb3JkID0gX3Byb3BzLnJlY29yZCxcbiAgICAgICAgaW5kZW50U2l6ZSA9IF9wcm9wcy5pbmRlbnRTaXplLFxuICAgICAgICBwcmVmaXhDbHMgPSBfcHJvcHMucHJlZml4Q2xzLFxuICAgICAgICBpbmRlbnQgPSBfcHJvcHMuaW5kZW50LFxuICAgICAgICBpbmRleCA9IF9wcm9wcy5pbmRleCxcbiAgICAgICAgZXhwYW5kSWNvbiA9IF9wcm9wcy5leHBhbmRJY29uLFxuICAgICAgICBjb2x1bW4gPSBfcHJvcHMuY29sdW1uLFxuICAgICAgICBCb2R5Q2VsbCA9IF9wcm9wcy5jb21wb25lbnQ7XG4gICAgdmFyIGRhdGFJbmRleCA9IGNvbHVtbi5kYXRhSW5kZXgsXG4gICAgICAgIHJlbmRlciA9IGNvbHVtbi5yZW5kZXIsXG4gICAgICAgIF9jb2x1bW4kY2xhc3NOYW1lID0gY29sdW1uLmNsYXNzTmFtZSxcbiAgICAgICAgY2xhc3NOYW1lID0gX2NvbHVtbiRjbGFzc05hbWUgPT09IHVuZGVmaW5lZCA/ICcnIDogX2NvbHVtbiRjbGFzc05hbWU7XG5cbiAgICAvLyBXZSBzaG91bGQgcmV0dXJuIHVuZGVmaW5lZCBpZiBubyBkYXRhSW5kZXggaXMgc3BlY2lmaWVkLCBidXQgaW4gb3JkZXIgdG9cbiAgICAvLyBiZSBjb21wYXRpYmxlIHdpdGggb2JqZWN0LXBhdGgncyBiZWhhdmlvciwgd2UgcmV0dXJuIHRoZSByZWNvcmQgb2JqZWN0IGluc3RlYWQuXG5cbiAgICB2YXIgdGV4dCA9IHZvaWQgMDtcbiAgICBpZiAodHlwZW9mIGRhdGFJbmRleCA9PT0gJ251bWJlcicpIHtcbiAgICAgIHRleHQgPSBnZXQocmVjb3JkLCBkYXRhSW5kZXgpO1xuICAgIH0gZWxzZSBpZiAoIWRhdGFJbmRleCB8fCBkYXRhSW5kZXgubGVuZ3RoID09PSAwKSB7XG4gICAgICB0ZXh0ID0gcmVjb3JkO1xuICAgIH0gZWxzZSB7XG4gICAgICB0ZXh0ID0gZ2V0KHJlY29yZCwgZGF0YUluZGV4KTtcbiAgICB9XG4gICAgdmFyIHRkUHJvcHMgPSB7fTtcbiAgICB2YXIgY29sU3BhbiA9IHZvaWQgMDtcbiAgICB2YXIgcm93U3BhbiA9IHZvaWQgMDtcblxuICAgIGlmIChyZW5kZXIpIHtcbiAgICAgIHRleHQgPSByZW5kZXIodGV4dCwgcmVjb3JkLCBpbmRleCk7XG4gICAgICBpZiAoaXNJbnZhbGlkUmVuZGVyQ2VsbFRleHQodGV4dCkpIHtcbiAgICAgICAgdGRQcm9wcyA9IHRleHQucHJvcHMgfHwgdGRQcm9wcztcbiAgICAgICAgY29sU3BhbiA9IHRkUHJvcHMuY29sU3BhbjtcbiAgICAgICAgcm93U3BhbiA9IHRkUHJvcHMucm93U3BhbjtcbiAgICAgICAgdGV4dCA9IHRleHQuY2hpbGRyZW47XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKGNvbHVtbi5vbkNlbGwpIHtcbiAgICAgIHRkUHJvcHMgPSBfZXh0ZW5kcyh7fSwgdGRQcm9wcywgY29sdW1uLm9uQ2VsbChyZWNvcmQpKTtcbiAgICB9XG5cbiAgICAvLyBGaXggaHR0cHM6Ly9naXRodWIuY29tL2FudC1kZXNpZ24vYW50LWRlc2lnbi9pc3N1ZXMvMTIwMlxuICAgIGlmIChpc0ludmFsaWRSZW5kZXJDZWxsVGV4dCh0ZXh0KSkge1xuICAgICAgdGV4dCA9IG51bGw7XG4gICAgfVxuXG4gICAgdmFyIGluZGVudFRleHQgPSBleHBhbmRJY29uID8gUmVhY3QuY3JlYXRlRWxlbWVudCgnc3BhbicsIHtcbiAgICAgIHN0eWxlOiB7IHBhZGRpbmdMZWZ0OiBpbmRlbnRTaXplICogaW5kZW50ICsgJ3B4JyB9LFxuICAgICAgY2xhc3NOYW1lOiBwcmVmaXhDbHMgKyAnLWluZGVudCBpbmRlbnQtbGV2ZWwtJyArIGluZGVudFxuICAgIH0pIDogbnVsbDtcblxuICAgIGlmIChyb3dTcGFuID09PSAwIHx8IGNvbFNwYW4gPT09IDApIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cblxuICAgIGlmIChjb2x1bW4uYWxpZ24pIHtcbiAgICAgIHRkUHJvcHMuc3R5bGUgPSB7IHRleHRBbGlnbjogY29sdW1uLmFsaWduIH07XG4gICAgfVxuXG4gICAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXG4gICAgICBCb2R5Q2VsbCxcbiAgICAgIF9leHRlbmRzKHsgY2xhc3NOYW1lOiBjbGFzc05hbWUsIG9uQ2xpY2s6IHRoaXMuaGFuZGxlQ2xpY2sgfSwgdGRQcm9wcyksXG4gICAgICBpbmRlbnRUZXh0LFxuICAgICAgZXhwYW5kSWNvbixcbiAgICAgIHRleHRcbiAgICApO1xuICB9O1xuXG4gIHJldHVybiBUYWJsZUNlbGw7XG59KFJlYWN0LkNvbXBvbmVudCk7XG5cblRhYmxlQ2VsbC5wcm9wVHlwZXMgPSB7XG4gIHJlY29yZDogUHJvcFR5cGVzLm9iamVjdCxcbiAgcHJlZml4Q2xzOiBQcm9wVHlwZXMuc3RyaW5nLFxuICBpbmRleDogUHJvcFR5cGVzLm51bWJlcixcbiAgaW5kZW50OiBQcm9wVHlwZXMubnVtYmVyLFxuICBpbmRlbnRTaXplOiBQcm9wVHlwZXMubnVtYmVyLFxuICBjb2x1bW46IFByb3BUeXBlcy5vYmplY3QsXG4gIGV4cGFuZEljb246IFByb3BUeXBlcy5ub2RlLFxuICBjb21wb25lbnQ6IFByb3BUeXBlcy5hbnlcbn07XG5leHBvcnQgZGVmYXVsdCBUYWJsZUNlbGw7IiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcyc7XG5pbXBvcnQgVGFibGVIZWFkZXJSb3cgZnJvbSAnLi9UYWJsZUhlYWRlclJvdyc7XG5cbmZ1bmN0aW9uIGdldEhlYWRlclJvd3MoY29sdW1ucykge1xuICB2YXIgY3VycmVudFJvdyA9IGFyZ3VtZW50cy5sZW5ndGggPiAxICYmIGFyZ3VtZW50c1sxXSAhPT0gdW5kZWZpbmVkID8gYXJndW1lbnRzWzFdIDogMDtcbiAgdmFyIHJvd3MgPSBhcmd1bWVudHNbMl07XG5cbiAgcm93cyA9IHJvd3MgfHwgW107XG4gIHJvd3NbY3VycmVudFJvd10gPSByb3dzW2N1cnJlbnRSb3ddIHx8IFtdO1xuXG4gIGNvbHVtbnMuZm9yRWFjaChmdW5jdGlvbiAoY29sdW1uKSB7XG4gICAgaWYgKGNvbHVtbi5yb3dTcGFuICYmIHJvd3MubGVuZ3RoIDwgY29sdW1uLnJvd1NwYW4pIHtcbiAgICAgIHdoaWxlIChyb3dzLmxlbmd0aCA8IGNvbHVtbi5yb3dTcGFuKSB7XG4gICAgICAgIHJvd3MucHVzaChbXSk7XG4gICAgICB9XG4gICAgfVxuICAgIHZhciBjZWxsID0ge1xuICAgICAga2V5OiBjb2x1bW4ua2V5LFxuICAgICAgY2xhc3NOYW1lOiBjb2x1bW4uY2xhc3NOYW1lIHx8ICcnLFxuICAgICAgY2hpbGRyZW46IGNvbHVtbi50aXRsZSxcbiAgICAgIGNvbHVtbjogY29sdW1uXG4gICAgfTtcbiAgICBpZiAoY29sdW1uLmNoaWxkcmVuKSB7XG4gICAgICBnZXRIZWFkZXJSb3dzKGNvbHVtbi5jaGlsZHJlbiwgY3VycmVudFJvdyArIDEsIHJvd3MpO1xuICAgIH1cbiAgICBpZiAoJ2NvbFNwYW4nIGluIGNvbHVtbikge1xuICAgICAgY2VsbC5jb2xTcGFuID0gY29sdW1uLmNvbFNwYW47XG4gICAgfVxuICAgIGlmICgncm93U3BhbicgaW4gY29sdW1uKSB7XG4gICAgICBjZWxsLnJvd1NwYW4gPSBjb2x1bW4ucm93U3BhbjtcbiAgICB9XG4gICAgaWYgKGNlbGwuY29sU3BhbiAhPT0gMCkge1xuICAgICAgcm93c1tjdXJyZW50Um93XS5wdXNoKGNlbGwpO1xuICAgIH1cbiAgfSk7XG4gIHJldHVybiByb3dzLmZpbHRlcihmdW5jdGlvbiAocm93KSB7XG4gICAgcmV0dXJuIHJvdy5sZW5ndGggPiAwO1xuICB9KTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gVGFibGVIZWFkZXIocHJvcHMsIF9yZWYpIHtcbiAgdmFyIHRhYmxlID0gX3JlZi50YWJsZTtcbiAgdmFyIGNvbXBvbmVudHMgPSB0YWJsZS5jb21wb25lbnRzO1xuICB2YXIgX3RhYmxlJHByb3BzID0gdGFibGUucHJvcHMsXG4gICAgICBwcmVmaXhDbHMgPSBfdGFibGUkcHJvcHMucHJlZml4Q2xzLFxuICAgICAgc2hvd0hlYWRlciA9IF90YWJsZSRwcm9wcy5zaG93SGVhZGVyLFxuICAgICAgb25IZWFkZXJSb3cgPSBfdGFibGUkcHJvcHMub25IZWFkZXJSb3c7XG4gIHZhciBleHBhbmRlciA9IHByb3BzLmV4cGFuZGVyLFxuICAgICAgY29sdW1ucyA9IHByb3BzLmNvbHVtbnMsXG4gICAgICBmaXhlZCA9IHByb3BzLmZpeGVkO1xuXG5cbiAgaWYgKCFzaG93SGVhZGVyKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cblxuICB2YXIgcm93cyA9IGdldEhlYWRlclJvd3MoY29sdW1ucyk7XG5cbiAgZXhwYW5kZXIucmVuZGVyRXhwYW5kSW5kZW50Q2VsbChyb3dzLCBmaXhlZCk7XG5cbiAgdmFyIEhlYWRlcldyYXBwZXIgPSBjb21wb25lbnRzLmhlYWRlci53cmFwcGVyO1xuXG4gIHJldHVybiBSZWFjdC5jcmVhdGVFbGVtZW50KFxuICAgIEhlYWRlcldyYXBwZXIsXG4gICAgeyBjbGFzc05hbWU6IHByZWZpeENscyArICctdGhlYWQnIH0sXG4gICAgcm93cy5tYXAoZnVuY3Rpb24gKHJvdywgaW5kZXgpIHtcbiAgICAgIHJldHVybiBSZWFjdC5jcmVhdGVFbGVtZW50KFRhYmxlSGVhZGVyUm93LCB7XG4gICAgICAgIGtleTogaW5kZXgsXG4gICAgICAgIGluZGV4OiBpbmRleCxcbiAgICAgICAgZml4ZWQ6IGZpeGVkLFxuICAgICAgICBjb2x1bW5zOiBjb2x1bW5zLFxuICAgICAgICByb3dzOiByb3dzLFxuICAgICAgICByb3c6IHJvdyxcbiAgICAgICAgY29tcG9uZW50czogY29tcG9uZW50cyxcbiAgICAgICAgb25IZWFkZXJSb3c6IG9uSGVhZGVyUm93XG4gICAgICB9KTtcbiAgICB9KVxuICApO1xufVxuXG5UYWJsZUhlYWRlci5wcm9wVHlwZXMgPSB7XG4gIGZpeGVkOiBQcm9wVHlwZXMuc3RyaW5nLFxuICBjb2x1bW5zOiBQcm9wVHlwZXMuYXJyYXkuaXNSZXF1aXJlZCxcbiAgZXhwYW5kZXI6IFByb3BUeXBlcy5vYmplY3QuaXNSZXF1aXJlZCxcbiAgb25IZWFkZXJSb3c6IFByb3BUeXBlcy5mdW5jXG59O1xuXG5UYWJsZUhlYWRlci5jb250ZXh0VHlwZXMgPSB7XG4gIHRhYmxlOiBQcm9wVHlwZXMuYW55XG59OyIsImltcG9ydCBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXMgZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzJztcbmltcG9ydCBfZXh0ZW5kcyBmcm9tICdiYWJlbC1ydW50aW1lL2hlbHBlcnMvZXh0ZW5kcyc7XG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcbmltcG9ydCB7IGNvbm5lY3QgfSBmcm9tICdtaW5pLXN0b3JlJztcblxuZnVuY3Rpb24gVGFibGVIZWFkZXJSb3coX3JlZikge1xuICB2YXIgcm93ID0gX3JlZi5yb3csXG4gICAgICBpbmRleCA9IF9yZWYuaW5kZXgsXG4gICAgICBoZWlnaHQgPSBfcmVmLmhlaWdodCxcbiAgICAgIGNvbXBvbmVudHMgPSBfcmVmLmNvbXBvbmVudHMsXG4gICAgICBvbkhlYWRlclJvdyA9IF9yZWYub25IZWFkZXJSb3c7XG5cbiAgdmFyIEhlYWRlclJvdyA9IGNvbXBvbmVudHMuaGVhZGVyLnJvdztcbiAgdmFyIEhlYWRlckNlbGwgPSBjb21wb25lbnRzLmhlYWRlci5jZWxsO1xuICB2YXIgcm93UHJvcHMgPSBvbkhlYWRlclJvdyhyb3cubWFwKGZ1bmN0aW9uIChjZWxsKSB7XG4gICAgcmV0dXJuIGNlbGwuY29sdW1uO1xuICB9KSwgaW5kZXgpO1xuICB2YXIgY3VzdG9tU3R5bGUgPSByb3dQcm9wcyA/IHJvd1Byb3BzLnN0eWxlIDoge307XG4gIHZhciBzdHlsZSA9IF9leHRlbmRzKHsgaGVpZ2h0OiBoZWlnaHQgfSwgY3VzdG9tU3R5bGUpO1xuXG4gIHJldHVybiBSZWFjdC5jcmVhdGVFbGVtZW50KFxuICAgIEhlYWRlclJvdyxcbiAgICBfZXh0ZW5kcyh7fSwgcm93UHJvcHMsIHsgc3R5bGU6IHN0eWxlIH0pLFxuICAgIHJvdy5tYXAoZnVuY3Rpb24gKGNlbGwsIGkpIHtcbiAgICAgIHZhciBjb2x1bW4gPSBjZWxsLmNvbHVtbixcbiAgICAgICAgICBjZWxsUHJvcHMgPSBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXMoY2VsbCwgWydjb2x1bW4nXSk7XG5cbiAgICAgIHZhciBjdXN0b21Qcm9wcyA9IGNvbHVtbi5vbkhlYWRlckNlbGwgPyBjb2x1bW4ub25IZWFkZXJDZWxsKGNvbHVtbikgOiB7fTtcbiAgICAgIGlmIChjb2x1bW4uYWxpZ24pIHtcbiAgICAgICAgY2VsbFByb3BzLnN0eWxlID0geyB0ZXh0QWxpZ246IGNvbHVtbi5hbGlnbiB9O1xuICAgICAgfVxuICAgICAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoSGVhZGVyQ2VsbCwgX2V4dGVuZHMoe30sIGNlbGxQcm9wcywgY3VzdG9tUHJvcHMsIHsga2V5OiBjb2x1bW4ua2V5IHx8IGNvbHVtbi5kYXRhSW5kZXggfHwgaSB9KSk7XG4gICAgfSlcbiAgKTtcbn1cblxuVGFibGVIZWFkZXJSb3cucHJvcFR5cGVzID0ge1xuICByb3c6IFByb3BUeXBlcy5hcnJheSxcbiAgaW5kZXg6IFByb3BUeXBlcy5udW1iZXIsXG4gIGhlaWdodDogUHJvcFR5cGVzLm9uZU9mVHlwZShbUHJvcFR5cGVzLnN0cmluZywgUHJvcFR5cGVzLm51bWJlcl0pLFxuICBjb21wb25lbnRzOiBQcm9wVHlwZXMuYW55LFxuICBvbkhlYWRlclJvdzogUHJvcFR5cGVzLmZ1bmNcbn07XG5cbmZ1bmN0aW9uIGdldFJvd0hlaWdodChzdGF0ZSwgcHJvcHMpIHtcbiAgdmFyIGZpeGVkQ29sdW1uc0hlYWRSb3dzSGVpZ2h0ID0gc3RhdGUuZml4ZWRDb2x1bW5zSGVhZFJvd3NIZWlnaHQ7XG4gIHZhciBjb2x1bW5zID0gcHJvcHMuY29sdW1ucyxcbiAgICAgIHJvd3MgPSBwcm9wcy5yb3dzLFxuICAgICAgZml4ZWQgPSBwcm9wcy5maXhlZDtcblxuICB2YXIgaGVhZGVySGVpZ2h0ID0gZml4ZWRDb2x1bW5zSGVhZFJvd3NIZWlnaHRbMF07XG5cbiAgaWYgKCFmaXhlZCkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG5cbiAgaWYgKGhlYWRlckhlaWdodCAmJiBjb2x1bW5zKSB7XG4gICAgaWYgKGhlYWRlckhlaWdodCA9PT0gJ2F1dG8nKSB7XG4gICAgICByZXR1cm4gJ2F1dG8nO1xuICAgIH1cbiAgICByZXR1cm4gaGVhZGVySGVpZ2h0IC8gcm93cy5sZW5ndGg7XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5cbmV4cG9ydCBkZWZhdWx0IGNvbm5lY3QoZnVuY3Rpb24gKHN0YXRlLCBwcm9wcykge1xuICByZXR1cm4ge1xuICAgIGhlaWdodDogZ2V0Um93SGVpZ2h0KHN0YXRlLCBwcm9wcylcbiAgfTtcbn0pKFRhYmxlSGVhZGVyUm93KTsiLCJpbXBvcnQgX2V4dGVuZHMgZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL2V4dGVuZHMnO1xuaW1wb3J0IF9jbGFzc0NhbGxDaGVjayBmcm9tICdiYWJlbC1ydW50aW1lL2hlbHBlcnMvY2xhc3NDYWxsQ2hlY2snO1xuaW1wb3J0IF9wb3NzaWJsZUNvbnN0cnVjdG9yUmV0dXJuIGZyb20gJ2JhYmVsLXJ1bnRpbWUvaGVscGVycy9wb3NzaWJsZUNvbnN0cnVjdG9yUmV0dXJuJztcbmltcG9ydCBfaW5oZXJpdHMgZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL2luaGVyaXRzJztcbmltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgUmVhY3RET00gZnJvbSAncmVhY3QtZG9tJztcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcyc7XG5pbXBvcnQgeyBjb25uZWN0IH0gZnJvbSAnbWluaS1zdG9yZSc7XG5pbXBvcnQgeyBwb2x5ZmlsbCB9IGZyb20gJ3JlYWN0LWxpZmVjeWNsZXMtY29tcGF0JztcbmltcG9ydCBUYWJsZUNlbGwgZnJvbSAnLi9UYWJsZUNlbGwnO1xuaW1wb3J0IHsgd2FybmluZ09uY2UgfSBmcm9tICcuL3V0aWxzJztcblxudmFyIFRhYmxlUm93ID0gZnVuY3Rpb24gKF9SZWFjdCRDb21wb25lbnQpIHtcbiAgX2luaGVyaXRzKFRhYmxlUm93LCBfUmVhY3QkQ29tcG9uZW50KTtcblxuICBUYWJsZVJvdy5nZXREZXJpdmVkU3RhdGVGcm9tUHJvcHMgPSBmdW5jdGlvbiBnZXREZXJpdmVkU3RhdGVGcm9tUHJvcHMobmV4dFByb3BzLCBwcmV2U3RhdGUpIHtcbiAgICBpZiAocHJldlN0YXRlLnZpc2libGUgfHwgIXByZXZTdGF0ZS52aXNpYmxlICYmIG5leHRQcm9wcy52aXNpYmxlKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBzaG91bGRSZW5kZXI6IHRydWUsXG4gICAgICAgIHZpc2libGU6IG5leHRQcm9wcy52aXNpYmxlXG4gICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgdmlzaWJsZTogbmV4dFByb3BzLnZpc2libGVcbiAgICB9O1xuICB9O1xuXG4gIGZ1bmN0aW9uIFRhYmxlUm93KHByb3BzKSB7XG4gICAgX2NsYXNzQ2FsbENoZWNrKHRoaXMsIFRhYmxlUm93KTtcblxuICAgIHZhciBfdGhpcyA9IF9wb3NzaWJsZUNvbnN0cnVjdG9yUmV0dXJuKHRoaXMsIF9SZWFjdCRDb21wb25lbnQuY2FsbCh0aGlzLCBwcm9wcykpO1xuXG4gICAgX3RoaXMub25Sb3dDbGljayA9IGZ1bmN0aW9uIChldmVudCkge1xuICAgICAgdmFyIF90aGlzJHByb3BzID0gX3RoaXMucHJvcHMsXG4gICAgICAgICAgcmVjb3JkID0gX3RoaXMkcHJvcHMucmVjb3JkLFxuICAgICAgICAgIGluZGV4ID0gX3RoaXMkcHJvcHMuaW5kZXgsXG4gICAgICAgICAgb25Sb3dDbGljayA9IF90aGlzJHByb3BzLm9uUm93Q2xpY2s7XG5cbiAgICAgIGlmIChvblJvd0NsaWNrKSB7XG4gICAgICAgIG9uUm93Q2xpY2socmVjb3JkLCBpbmRleCwgZXZlbnQpO1xuICAgICAgfVxuICAgIH07XG5cbiAgICBfdGhpcy5vblJvd0RvdWJsZUNsaWNrID0gZnVuY3Rpb24gKGV2ZW50KSB7XG4gICAgICB2YXIgX3RoaXMkcHJvcHMyID0gX3RoaXMucHJvcHMsXG4gICAgICAgICAgcmVjb3JkID0gX3RoaXMkcHJvcHMyLnJlY29yZCxcbiAgICAgICAgICBpbmRleCA9IF90aGlzJHByb3BzMi5pbmRleCxcbiAgICAgICAgICBvblJvd0RvdWJsZUNsaWNrID0gX3RoaXMkcHJvcHMyLm9uUm93RG91YmxlQ2xpY2s7XG5cbiAgICAgIGlmIChvblJvd0RvdWJsZUNsaWNrKSB7XG4gICAgICAgIG9uUm93RG91YmxlQ2xpY2socmVjb3JkLCBpbmRleCwgZXZlbnQpO1xuICAgICAgfVxuICAgIH07XG5cbiAgICBfdGhpcy5vbkNvbnRleHRNZW51ID0gZnVuY3Rpb24gKGV2ZW50KSB7XG4gICAgICB2YXIgX3RoaXMkcHJvcHMzID0gX3RoaXMucHJvcHMsXG4gICAgICAgICAgcmVjb3JkID0gX3RoaXMkcHJvcHMzLnJlY29yZCxcbiAgICAgICAgICBpbmRleCA9IF90aGlzJHByb3BzMy5pbmRleCxcbiAgICAgICAgICBvblJvd0NvbnRleHRNZW51ID0gX3RoaXMkcHJvcHMzLm9uUm93Q29udGV4dE1lbnU7XG5cbiAgICAgIGlmIChvblJvd0NvbnRleHRNZW51KSB7XG4gICAgICAgIG9uUm93Q29udGV4dE1lbnUocmVjb3JkLCBpbmRleCwgZXZlbnQpO1xuICAgICAgfVxuICAgIH07XG5cbiAgICBfdGhpcy5vbk1vdXNlRW50ZXIgPSBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgIHZhciBfdGhpcyRwcm9wczQgPSBfdGhpcy5wcm9wcyxcbiAgICAgICAgICByZWNvcmQgPSBfdGhpcyRwcm9wczQucmVjb3JkLFxuICAgICAgICAgIGluZGV4ID0gX3RoaXMkcHJvcHM0LmluZGV4LFxuICAgICAgICAgIG9uUm93TW91c2VFbnRlciA9IF90aGlzJHByb3BzNC5vblJvd01vdXNlRW50ZXIsXG4gICAgICAgICAgb25Ib3ZlciA9IF90aGlzJHByb3BzNC5vbkhvdmVyLFxuICAgICAgICAgIHJvd0tleSA9IF90aGlzJHByb3BzNC5yb3dLZXk7XG5cbiAgICAgIG9uSG92ZXIodHJ1ZSwgcm93S2V5KTtcbiAgICAgIGlmIChvblJvd01vdXNlRW50ZXIpIHtcbiAgICAgICAgb25Sb3dNb3VzZUVudGVyKHJlY29yZCwgaW5kZXgsIGV2ZW50KTtcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgX3RoaXMub25Nb3VzZUxlYXZlID0gZnVuY3Rpb24gKGV2ZW50KSB7XG4gICAgICB2YXIgX3RoaXMkcHJvcHM1ID0gX3RoaXMucHJvcHMsXG4gICAgICAgICAgcmVjb3JkID0gX3RoaXMkcHJvcHM1LnJlY29yZCxcbiAgICAgICAgICBpbmRleCA9IF90aGlzJHByb3BzNS5pbmRleCxcbiAgICAgICAgICBvblJvd01vdXNlTGVhdmUgPSBfdGhpcyRwcm9wczUub25Sb3dNb3VzZUxlYXZlLFxuICAgICAgICAgIG9uSG92ZXIgPSBfdGhpcyRwcm9wczUub25Ib3ZlcixcbiAgICAgICAgICByb3dLZXkgPSBfdGhpcyRwcm9wczUucm93S2V5O1xuXG4gICAgICBvbkhvdmVyKGZhbHNlLCByb3dLZXkpO1xuICAgICAgaWYgKG9uUm93TW91c2VMZWF2ZSkge1xuICAgICAgICBvblJvd01vdXNlTGVhdmUocmVjb3JkLCBpbmRleCwgZXZlbnQpO1xuICAgICAgfVxuICAgIH07XG5cbiAgICBfdGhpcy5zaG91bGRSZW5kZXIgPSBwcm9wcy52aXNpYmxlO1xuXG4gICAgX3RoaXMuc3RhdGUgPSB7fTtcbiAgICByZXR1cm4gX3RoaXM7XG4gIH1cblxuICBUYWJsZVJvdy5wcm90b3R5cGUuY29tcG9uZW50RGlkTW91bnQgPSBmdW5jdGlvbiBjb21wb25lbnREaWRNb3VudCgpIHtcbiAgICBpZiAodGhpcy5zdGF0ZS5zaG91bGRSZW5kZXIpIHtcbiAgICAgIHRoaXMuc2F2ZVJvd1JlZigpO1xuICAgIH1cbiAgfTtcblxuICBUYWJsZVJvdy5wcm90b3R5cGUuc2hvdWxkQ29tcG9uZW50VXBkYXRlID0gZnVuY3Rpb24gc2hvdWxkQ29tcG9uZW50VXBkYXRlKG5leHRQcm9wcykge1xuICAgIHJldHVybiAhISh0aGlzLnByb3BzLnZpc2libGUgfHwgbmV4dFByb3BzLnZpc2libGUpO1xuICB9O1xuXG4gIFRhYmxlUm93LnByb3RvdHlwZS5jb21wb25lbnREaWRVcGRhdGUgPSBmdW5jdGlvbiBjb21wb25lbnREaWRVcGRhdGUoKSB7XG4gICAgaWYgKHRoaXMuc3RhdGUuc2hvdWxkUmVuZGVyICYmICF0aGlzLnJvd1JlZikge1xuICAgICAgdGhpcy5zYXZlUm93UmVmKCk7XG4gICAgfVxuICB9O1xuXG4gIFRhYmxlUm93LnByb3RvdHlwZS5zZXRFeHBhbmVkUm93SGVpZ2h0ID0gZnVuY3Rpb24gc2V0RXhwYW5lZFJvd0hlaWdodCgpIHtcbiAgICB2YXIgX2V4dGVuZHMyO1xuXG4gICAgdmFyIF9wcm9wcyA9IHRoaXMucHJvcHMsXG4gICAgICAgIHN0b3JlID0gX3Byb3BzLnN0b3JlLFxuICAgICAgICByb3dLZXkgPSBfcHJvcHMucm93S2V5O1xuXG4gICAgdmFyIF9zdG9yZSRnZXRTdGF0ZSA9IHN0b3JlLmdldFN0YXRlKCksXG4gICAgICAgIGV4cGFuZGVkUm93c0hlaWdodCA9IF9zdG9yZSRnZXRTdGF0ZS5leHBhbmRlZFJvd3NIZWlnaHQ7XG5cbiAgICB2YXIgaGVpZ2h0ID0gdGhpcy5yb3dSZWYuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkuaGVpZ2h0O1xuICAgIGV4cGFuZGVkUm93c0hlaWdodCA9IF9leHRlbmRzKHt9LCBleHBhbmRlZFJvd3NIZWlnaHQsIChfZXh0ZW5kczIgPSB7fSwgX2V4dGVuZHMyW3Jvd0tleV0gPSBoZWlnaHQsIF9leHRlbmRzMikpO1xuICAgIHN0b3JlLnNldFN0YXRlKHsgZXhwYW5kZWRSb3dzSGVpZ2h0OiBleHBhbmRlZFJvd3NIZWlnaHQgfSk7XG4gIH07XG5cbiAgVGFibGVSb3cucHJvdG90eXBlLnNldFJvd0hlaWdodCA9IGZ1bmN0aW9uIHNldFJvd0hlaWdodCgpIHtcbiAgICB2YXIgX3Byb3BzMiA9IHRoaXMucHJvcHMsXG4gICAgICAgIHN0b3JlID0gX3Byb3BzMi5zdG9yZSxcbiAgICAgICAgaW5kZXggPSBfcHJvcHMyLmluZGV4O1xuXG4gICAgdmFyIGZpeGVkQ29sdW1uc0JvZHlSb3dzSGVpZ2h0ID0gc3RvcmUuZ2V0U3RhdGUoKS5maXhlZENvbHVtbnNCb2R5Um93c0hlaWdodC5zbGljZSgpO1xuICAgIHZhciBoZWlnaHQgPSB0aGlzLnJvd1JlZi5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5oZWlnaHQ7XG4gICAgZml4ZWRDb2x1bW5zQm9keVJvd3NIZWlnaHRbaW5kZXhdID0gaGVpZ2h0O1xuICAgIHN0b3JlLnNldFN0YXRlKHsgZml4ZWRDb2x1bW5zQm9keVJvd3NIZWlnaHQ6IGZpeGVkQ29sdW1uc0JvZHlSb3dzSGVpZ2h0IH0pO1xuICB9O1xuXG4gIFRhYmxlUm93LnByb3RvdHlwZS5nZXRTdHlsZSA9IGZ1bmN0aW9uIGdldFN0eWxlKCkge1xuICAgIHZhciBfcHJvcHMzID0gdGhpcy5wcm9wcyxcbiAgICAgICAgaGVpZ2h0ID0gX3Byb3BzMy5oZWlnaHQsXG4gICAgICAgIHZpc2libGUgPSBfcHJvcHMzLnZpc2libGU7XG5cblxuICAgIGlmIChoZWlnaHQgJiYgaGVpZ2h0ICE9PSB0aGlzLnN0eWxlLmhlaWdodCkge1xuICAgICAgdGhpcy5zdHlsZSA9IF9leHRlbmRzKHt9LCB0aGlzLnN0eWxlLCB7IGhlaWdodDogaGVpZ2h0IH0pO1xuICAgIH1cblxuICAgIGlmICghdmlzaWJsZSAmJiAhdGhpcy5zdHlsZS5kaXNwbGF5KSB7XG4gICAgICB0aGlzLnN0eWxlID0gX2V4dGVuZHMoe30sIHRoaXMuc3R5bGUsIHsgZGlzcGxheTogJ25vbmUnIH0pO1xuICAgIH1cblxuICAgIHJldHVybiB0aGlzLnN0eWxlO1xuICB9O1xuXG4gIFRhYmxlUm93LnByb3RvdHlwZS5zYXZlUm93UmVmID0gZnVuY3Rpb24gc2F2ZVJvd1JlZigpIHtcbiAgICB0aGlzLnJvd1JlZiA9IFJlYWN0RE9NLmZpbmRET01Ob2RlKHRoaXMpO1xuXG4gICAgdmFyIF9wcm9wczQgPSB0aGlzLnByb3BzLFxuICAgICAgICBpc0FueUNvbHVtbnNGaXhlZCA9IF9wcm9wczQuaXNBbnlDb2x1bW5zRml4ZWQsXG4gICAgICAgIGZpeGVkID0gX3Byb3BzNC5maXhlZCxcbiAgICAgICAgZXhwYW5kZWRSb3cgPSBfcHJvcHM0LmV4cGFuZGVkUm93LFxuICAgICAgICBhbmNlc3RvcktleXMgPSBfcHJvcHM0LmFuY2VzdG9yS2V5cztcblxuXG4gICAgaWYgKCFpc0FueUNvbHVtbnNGaXhlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmICghZml4ZWQgJiYgZXhwYW5kZWRSb3cpIHtcbiAgICAgIHRoaXMuc2V0RXhwYW5lZFJvd0hlaWdodCgpO1xuICAgIH1cblxuICAgIGlmICghZml4ZWQgJiYgYW5jZXN0b3JLZXlzLmxlbmd0aCA+PSAwKSB7XG4gICAgICB0aGlzLnNldFJvd0hlaWdodCgpO1xuICAgIH1cbiAgfTtcblxuICBUYWJsZVJvdy5wcm90b3R5cGUucmVuZGVyID0gZnVuY3Rpb24gcmVuZGVyKCkge1xuICAgIGlmICghdGhpcy5zdGF0ZS5zaG91bGRSZW5kZXIpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cblxuICAgIHZhciBfcHJvcHM1ID0gdGhpcy5wcm9wcyxcbiAgICAgICAgcHJlZml4Q2xzID0gX3Byb3BzNS5wcmVmaXhDbHMsXG4gICAgICAgIGNvbHVtbnMgPSBfcHJvcHM1LmNvbHVtbnMsXG4gICAgICAgIHJlY29yZCA9IF9wcm9wczUucmVjb3JkLFxuICAgICAgICBpbmRleCA9IF9wcm9wczUuaW5kZXgsXG4gICAgICAgIG9uUm93ID0gX3Byb3BzNS5vblJvdyxcbiAgICAgICAgaW5kZW50ID0gX3Byb3BzNS5pbmRlbnQsXG4gICAgICAgIGluZGVudFNpemUgPSBfcHJvcHM1LmluZGVudFNpemUsXG4gICAgICAgIGhvdmVyZWQgPSBfcHJvcHM1LmhvdmVyZWQsXG4gICAgICAgIGhlaWdodCA9IF9wcm9wczUuaGVpZ2h0LFxuICAgICAgICB2aXNpYmxlID0gX3Byb3BzNS52aXNpYmxlLFxuICAgICAgICBjb21wb25lbnRzID0gX3Byb3BzNS5jb21wb25lbnRzLFxuICAgICAgICBoYXNFeHBhbmRJY29uID0gX3Byb3BzNS5oYXNFeHBhbmRJY29uLFxuICAgICAgICByZW5kZXJFeHBhbmRJY29uID0gX3Byb3BzNS5yZW5kZXJFeHBhbmRJY29uLFxuICAgICAgICByZW5kZXJFeHBhbmRJY29uQ2VsbCA9IF9wcm9wczUucmVuZGVyRXhwYW5kSWNvbkNlbGw7XG5cblxuICAgIHZhciBCb2R5Um93ID0gY29tcG9uZW50cy5ib2R5LnJvdztcbiAgICB2YXIgQm9keUNlbGwgPSBjb21wb25lbnRzLmJvZHkuY2VsbDtcblxuICAgIHZhciBjbGFzc05hbWUgPSB0aGlzLnByb3BzLmNsYXNzTmFtZTtcblxuXG4gICAgaWYgKGhvdmVyZWQpIHtcbiAgICAgIGNsYXNzTmFtZSArPSAnICcgKyBwcmVmaXhDbHMgKyAnLWhvdmVyJztcbiAgICB9XG5cbiAgICB2YXIgY2VsbHMgPSBbXTtcblxuICAgIHJlbmRlckV4cGFuZEljb25DZWxsKGNlbGxzKTtcblxuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgY29sdW1ucy5sZW5ndGg7IGkrKykge1xuICAgICAgdmFyIGNvbHVtbiA9IGNvbHVtbnNbaV07XG5cbiAgICAgIHdhcm5pbmdPbmNlKGNvbHVtbi5vbkNlbGxDbGljayA9PT0gdW5kZWZpbmVkLCAnY29sdW1uW29uQ2VsbENsaWNrXSBpcyBkZXByZWNhdGVkLCBwbGVhc2UgdXNlIGNvbHVtbltvbkNlbGxdIGluc3RlYWQuJyk7XG5cbiAgICAgIGNlbGxzLnB1c2goUmVhY3QuY3JlYXRlRWxlbWVudChUYWJsZUNlbGwsIHtcbiAgICAgICAgcHJlZml4Q2xzOiBwcmVmaXhDbHMsXG4gICAgICAgIHJlY29yZDogcmVjb3JkLFxuICAgICAgICBpbmRlbnRTaXplOiBpbmRlbnRTaXplLFxuICAgICAgICBpbmRlbnQ6IGluZGVudCxcbiAgICAgICAgaW5kZXg6IGluZGV4LFxuICAgICAgICBjb2x1bW46IGNvbHVtbixcbiAgICAgICAga2V5OiBjb2x1bW4ua2V5IHx8IGNvbHVtbi5kYXRhSW5kZXgsXG4gICAgICAgIGV4cGFuZEljb246IGhhc0V4cGFuZEljb24oaSkgJiYgcmVuZGVyRXhwYW5kSWNvbigpLFxuICAgICAgICBjb21wb25lbnQ6IEJvZHlDZWxsXG4gICAgICB9KSk7XG4gICAgfVxuXG4gICAgdmFyIHJvd0NsYXNzTmFtZSA9IChwcmVmaXhDbHMgKyAnICcgKyBjbGFzc05hbWUgKyAnICcgKyBwcmVmaXhDbHMgKyAnLWxldmVsLScgKyBpbmRlbnQpLnRyaW0oKTtcblxuICAgIHZhciByb3dQcm9wcyA9IG9uUm93KHJlY29yZCwgaW5kZXgpO1xuICAgIHZhciBjdXN0b21TdHlsZSA9IHJvd1Byb3BzID8gcm93UHJvcHMuc3R5bGUgOiB7fTtcbiAgICB2YXIgc3R5bGUgPSB7IGhlaWdodDogaGVpZ2h0IH07XG5cbiAgICBpZiAoIXZpc2libGUpIHtcbiAgICAgIHN0eWxlLmRpc3BsYXkgPSAnbm9uZSc7XG4gICAgfVxuXG4gICAgc3R5bGUgPSBfZXh0ZW5kcyh7fSwgc3R5bGUsIGN1c3RvbVN0eWxlKTtcblxuICAgIHJldHVybiBSZWFjdC5jcmVhdGVFbGVtZW50KFxuICAgICAgQm9keVJvdyxcbiAgICAgIF9leHRlbmRzKHtcbiAgICAgICAgb25DbGljazogdGhpcy5vblJvd0NsaWNrLFxuICAgICAgICBvbkRvdWJsZUNsaWNrOiB0aGlzLm9uUm93RG91YmxlQ2xpY2ssXG4gICAgICAgIG9uTW91c2VFbnRlcjogdGhpcy5vbk1vdXNlRW50ZXIsXG4gICAgICAgIG9uTW91c2VMZWF2ZTogdGhpcy5vbk1vdXNlTGVhdmUsXG4gICAgICAgIG9uQ29udGV4dE1lbnU6IHRoaXMub25Db250ZXh0TWVudSxcbiAgICAgICAgY2xhc3NOYW1lOiByb3dDbGFzc05hbWVcbiAgICAgIH0sIHJvd1Byb3BzLCB7XG4gICAgICAgIHN0eWxlOiBzdHlsZVxuICAgICAgfSksXG4gICAgICBjZWxsc1xuICAgICk7XG4gIH07XG5cbiAgcmV0dXJuIFRhYmxlUm93O1xufShSZWFjdC5Db21wb25lbnQpO1xuXG5UYWJsZVJvdy5wcm9wVHlwZXMgPSB7XG4gIG9uUm93OiBQcm9wVHlwZXMuZnVuYyxcbiAgb25Sb3dDbGljazogUHJvcFR5cGVzLmZ1bmMsXG4gIG9uUm93RG91YmxlQ2xpY2s6IFByb3BUeXBlcy5mdW5jLFxuICBvblJvd0NvbnRleHRNZW51OiBQcm9wVHlwZXMuZnVuYyxcbiAgb25Sb3dNb3VzZUVudGVyOiBQcm9wVHlwZXMuZnVuYyxcbiAgb25Sb3dNb3VzZUxlYXZlOiBQcm9wVHlwZXMuZnVuYyxcbiAgcmVjb3JkOiBQcm9wVHlwZXMub2JqZWN0LFxuICBwcmVmaXhDbHM6IFByb3BUeXBlcy5zdHJpbmcsXG4gIG9uSG92ZXI6IFByb3BUeXBlcy5mdW5jLFxuICBjb2x1bW5zOiBQcm9wVHlwZXMuYXJyYXksXG4gIGhlaWdodDogUHJvcFR5cGVzLm9uZU9mVHlwZShbUHJvcFR5cGVzLnN0cmluZywgUHJvcFR5cGVzLm51bWJlcl0pLFxuICBpbmRleDogUHJvcFR5cGVzLm51bWJlcixcbiAgcm93S2V5OiBQcm9wVHlwZXMub25lT2ZUeXBlKFtQcm9wVHlwZXMuc3RyaW5nLCBQcm9wVHlwZXMubnVtYmVyXSkuaXNSZXF1aXJlZCxcbiAgY2xhc3NOYW1lOiBQcm9wVHlwZXMuc3RyaW5nLFxuICBpbmRlbnQ6IFByb3BUeXBlcy5udW1iZXIsXG4gIGluZGVudFNpemU6IFByb3BUeXBlcy5udW1iZXIsXG4gIGhhc0V4cGFuZEljb246IFByb3BUeXBlcy5mdW5jLFxuICBob3ZlcmVkOiBQcm9wVHlwZXMuYm9vbC5pc1JlcXVpcmVkLFxuICB2aXNpYmxlOiBQcm9wVHlwZXMuYm9vbC5pc1JlcXVpcmVkLFxuICBzdG9yZTogUHJvcFR5cGVzLm9iamVjdC5pc1JlcXVpcmVkLFxuICBmaXhlZDogUHJvcFR5cGVzLm9uZU9mVHlwZShbUHJvcFR5cGVzLnN0cmluZywgUHJvcFR5cGVzLmJvb2xdKSxcbiAgcmVuZGVyRXhwYW5kSWNvbjogUHJvcFR5cGVzLmZ1bmMsXG4gIHJlbmRlckV4cGFuZEljb25DZWxsOiBQcm9wVHlwZXMuZnVuYyxcbiAgY29tcG9uZW50czogUHJvcFR5cGVzLmFueSxcbiAgZXhwYW5kZWRSb3c6IFByb3BUeXBlcy5ib29sLFxuICBpc0FueUNvbHVtbnNGaXhlZDogUHJvcFR5cGVzLmJvb2wsXG4gIGFuY2VzdG9yS2V5czogUHJvcFR5cGVzLmFycmF5LmlzUmVxdWlyZWRcbn07XG5UYWJsZVJvdy5kZWZhdWx0UHJvcHMgPSB7XG4gIG9uUm93OiBmdW5jdGlvbiBvblJvdygpIHt9LFxuICBvbkhvdmVyOiBmdW5jdGlvbiBvbkhvdmVyKCkge30sXG4gIGhhc0V4cGFuZEljb246IGZ1bmN0aW9uIGhhc0V4cGFuZEljb24oKSB7fSxcbiAgcmVuZGVyRXhwYW5kSWNvbjogZnVuY3Rpb24gcmVuZGVyRXhwYW5kSWNvbigpIHt9LFxuICByZW5kZXJFeHBhbmRJY29uQ2VsbDogZnVuY3Rpb24gcmVuZGVyRXhwYW5kSWNvbkNlbGwoKSB7fVxufTtcblxuXG5mdW5jdGlvbiBnZXRSb3dIZWlnaHQoc3RhdGUsIHByb3BzKSB7XG4gIHZhciBleHBhbmRlZFJvd3NIZWlnaHQgPSBzdGF0ZS5leHBhbmRlZFJvd3NIZWlnaHQsXG4gICAgICBmaXhlZENvbHVtbnNCb2R5Um93c0hlaWdodCA9IHN0YXRlLmZpeGVkQ29sdW1uc0JvZHlSb3dzSGVpZ2h0O1xuICB2YXIgZml4ZWQgPSBwcm9wcy5maXhlZCxcbiAgICAgIGluZGV4ID0gcHJvcHMuaW5kZXgsXG4gICAgICByb3dLZXkgPSBwcm9wcy5yb3dLZXk7XG5cblxuICBpZiAoIWZpeGVkKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cblxuICBpZiAoZXhwYW5kZWRSb3dzSGVpZ2h0W3Jvd0tleV0pIHtcbiAgICByZXR1cm4gZXhwYW5kZWRSb3dzSGVpZ2h0W3Jvd0tleV07XG4gIH1cblxuICBpZiAoZml4ZWRDb2x1bW5zQm9keVJvd3NIZWlnaHRbaW5kZXhdKSB7XG4gICAgcmV0dXJuIGZpeGVkQ29sdW1uc0JvZHlSb3dzSGVpZ2h0W2luZGV4XTtcbiAgfVxuXG4gIHJldHVybiBudWxsO1xufVxuXG5wb2x5ZmlsbChUYWJsZVJvdyk7XG5cbmV4cG9ydCBkZWZhdWx0IGNvbm5lY3QoZnVuY3Rpb24gKHN0YXRlLCBwcm9wcykge1xuICB2YXIgY3VycmVudEhvdmVyS2V5ID0gc3RhdGUuY3VycmVudEhvdmVyS2V5LFxuICAgICAgZXhwYW5kZWRSb3dLZXlzID0gc3RhdGUuZXhwYW5kZWRSb3dLZXlzO1xuICB2YXIgcm93S2V5ID0gcHJvcHMucm93S2V5LFxuICAgICAgYW5jZXN0b3JLZXlzID0gcHJvcHMuYW5jZXN0b3JLZXlzO1xuXG4gIHZhciB2aXNpYmxlID0gYW5jZXN0b3JLZXlzLmxlbmd0aCA9PT0gMCB8fCBhbmNlc3RvcktleXMuZXZlcnkoZnVuY3Rpb24gKGspIHtcbiAgICByZXR1cm4gfmV4cGFuZGVkUm93S2V5cy5pbmRleE9mKGspO1xuICB9KTtcblxuICByZXR1cm4ge1xuICAgIHZpc2libGU6IHZpc2libGUsXG4gICAgaG92ZXJlZDogY3VycmVudEhvdmVyS2V5ID09PSByb3dLZXksXG4gICAgaGVpZ2h0OiBnZXRSb3dIZWlnaHQoc3RhdGUsIHByb3BzKVxuICB9O1xufSkoVGFibGVSb3cpOyIsImltcG9ydCBUYWJsZSBmcm9tICcuL1RhYmxlJztcbmltcG9ydCBDb2x1bW4gZnJvbSAnLi9Db2x1bW4nO1xuaW1wb3J0IENvbHVtbkdyb3VwIGZyb20gJy4vQ29sdW1uR3JvdXAnO1xuXG5UYWJsZS5Db2x1bW4gPSBDb2x1bW47XG5UYWJsZS5Db2x1bW5Hcm91cCA9IENvbHVtbkdyb3VwO1xuXG5leHBvcnQgZGVmYXVsdCBUYWJsZTtcbmV4cG9ydCB7IENvbHVtbiwgQ29sdW1uR3JvdXAgfTsiLCJpbXBvcnQgd2FybmluZyBmcm9tICd3YXJuaW5nJztcblxudmFyIHNjcm9sbGJhclNpemUgPSB2b2lkIDA7XG5cbi8vIE1lYXN1cmUgc2Nyb2xsYmFyIHdpZHRoIGZvciBwYWRkaW5nIGJvZHkgZHVyaW5nIG1vZGFsIHNob3cvaGlkZVxudmFyIHNjcm9sbGJhck1lYXN1cmUgPSB7XG4gIHBvc2l0aW9uOiAnYWJzb2x1dGUnLFxuICB0b3A6ICctOTk5OXB4JyxcbiAgd2lkdGg6ICc1MHB4JyxcbiAgaGVpZ2h0OiAnNTBweCcsXG4gIG92ZXJmbG93OiAnc2Nyb2xsJ1xufTtcblxuZXhwb3J0IGZ1bmN0aW9uIG1lYXN1cmVTY3JvbGxiYXIoKSB7XG4gIHZhciBkaXJlY3Rpb24gPSBhcmd1bWVudHMubGVuZ3RoID4gMCAmJiBhcmd1bWVudHNbMF0gIT09IHVuZGVmaW5lZCA/IGFyZ3VtZW50c1swXSA6ICd2ZXJ0aWNhbCc7XG5cbiAgaWYgKHR5cGVvZiBkb2N1bWVudCA9PT0gJ3VuZGVmaW5lZCcgfHwgdHlwZW9mIHdpbmRvdyA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICByZXR1cm4gMDtcbiAgfVxuICBpZiAoc2Nyb2xsYmFyU2l6ZSkge1xuICAgIHJldHVybiBzY3JvbGxiYXJTaXplO1xuICB9XG4gIHZhciBzY3JvbGxEaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgT2JqZWN0LmtleXMoc2Nyb2xsYmFyTWVhc3VyZSkuZm9yRWFjaChmdW5jdGlvbiAoc2Nyb2xsUHJvcCkge1xuICAgIHNjcm9sbERpdi5zdHlsZVtzY3JvbGxQcm9wXSA9IHNjcm9sbGJhck1lYXN1cmVbc2Nyb2xsUHJvcF07XG4gIH0pO1xuICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKHNjcm9sbERpdik7XG4gIHZhciBzaXplID0gMDtcbiAgaWYgKGRpcmVjdGlvbiA9PT0gJ3ZlcnRpY2FsJykge1xuICAgIHNpemUgPSBzY3JvbGxEaXYub2Zmc2V0V2lkdGggLSBzY3JvbGxEaXYuY2xpZW50V2lkdGg7XG4gIH0gZWxzZSBpZiAoZGlyZWN0aW9uID09PSAnaG9yaXpvbnRhbCcpIHtcbiAgICBzaXplID0gc2Nyb2xsRGl2Lm9mZnNldEhlaWdodCAtIHNjcm9sbERpdi5jbGllbnRIZWlnaHQ7XG4gIH1cblxuICBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKHNjcm9sbERpdik7XG4gIHNjcm9sbGJhclNpemUgPSBzaXplO1xuICByZXR1cm4gc2Nyb2xsYmFyU2l6ZTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGRlYm91bmNlKGZ1bmMsIHdhaXQsIGltbWVkaWF0ZSkge1xuICB2YXIgdGltZW91dCA9IHZvaWQgMDtcbiAgZnVuY3Rpb24gZGVib3VuY2VGdW5jKCkge1xuICAgIGZvciAodmFyIF9sZW4gPSBhcmd1bWVudHMubGVuZ3RoLCBhcmdzID0gQXJyYXkoX2xlbiksIF9rZXkgPSAwOyBfa2V5IDwgX2xlbjsgX2tleSsrKSB7XG4gICAgICBhcmdzW19rZXldID0gYXJndW1lbnRzW19rZXldO1xuICAgIH1cblxuICAgIHZhciBjb250ZXh0ID0gdGhpcztcbiAgICAvLyBodHRwczovL2ZiLm1lL3JlYWN0LWV2ZW50LXBvb2xpbmdcbiAgICBpZiAoYXJnc1swXSAmJiBhcmdzWzBdLnBlcnNpc3QpIHtcbiAgICAgIGFyZ3NbMF0ucGVyc2lzdCgpO1xuICAgIH1cbiAgICB2YXIgbGF0ZXIgPSBmdW5jdGlvbiBsYXRlcigpIHtcbiAgICAgIHRpbWVvdXQgPSBudWxsO1xuICAgICAgaWYgKCFpbW1lZGlhdGUpIHtcbiAgICAgICAgZnVuYy5hcHBseShjb250ZXh0LCBhcmdzKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIHZhciBjYWxsTm93ID0gaW1tZWRpYXRlICYmICF0aW1lb3V0O1xuICAgIGNsZWFyVGltZW91dCh0aW1lb3V0KTtcbiAgICB0aW1lb3V0ID0gc2V0VGltZW91dChsYXRlciwgd2FpdCk7XG4gICAgaWYgKGNhbGxOb3cpIHtcbiAgICAgIGZ1bmMuYXBwbHkoY29udGV4dCwgYXJncyk7XG4gICAgfVxuICB9XG4gIGRlYm91bmNlRnVuYy5jYW5jZWwgPSBmdW5jdGlvbiBjYW5jZWwoKSB7XG4gICAgaWYgKHRpbWVvdXQpIHtcbiAgICAgIGNsZWFyVGltZW91dCh0aW1lb3V0KTtcbiAgICAgIHRpbWVvdXQgPSBudWxsO1xuICAgIH1cbiAgfTtcbiAgcmV0dXJuIGRlYm91bmNlRnVuYztcbn1cblxudmFyIHdhcm5lZCA9IHt9O1xuZXhwb3J0IGZ1bmN0aW9uIHdhcm5pbmdPbmNlKGNvbmRpdGlvbiwgZm9ybWF0LCBhcmdzKSB7XG4gIGlmICghd2FybmVkW2Zvcm1hdF0pIHtcbiAgICB3YXJuaW5nKGNvbmRpdGlvbiwgZm9ybWF0LCBhcmdzKTtcbiAgICB3YXJuZWRbZm9ybWF0XSA9ICFjb25kaXRpb247XG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHJlbW92ZShhcnJheSwgaXRlbSkge1xuICB2YXIgaW5kZXggPSBhcnJheS5pbmRleE9mKGl0ZW0pO1xuICB2YXIgZnJvbnQgPSBhcnJheS5zbGljZSgwLCBpbmRleCk7XG4gIHZhciBsYXN0ID0gYXJyYXkuc2xpY2UoaW5kZXggKyAxLCBhcnJheS5sZW5ndGgpO1xuICByZXR1cm4gZnJvbnQuY29uY2F0KGxhc3QpO1xufSIsInZhciBjYWNoZWQgPSB2b2lkIDA7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGdldFNjcm9sbEJhclNpemUoZnJlc2gpIHtcbiAgaWYgKGZyZXNoIHx8IGNhY2hlZCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgdmFyIGlubmVyID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgaW5uZXIuc3R5bGUud2lkdGggPSAnMTAwJSc7XG4gICAgaW5uZXIuc3R5bGUuaGVpZ2h0ID0gJzIwMHB4JztcblxuICAgIHZhciBvdXRlciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIHZhciBvdXRlclN0eWxlID0gb3V0ZXIuc3R5bGU7XG5cbiAgICBvdXRlclN0eWxlLnBvc2l0aW9uID0gJ2Fic29sdXRlJztcbiAgICBvdXRlclN0eWxlLnRvcCA9IDA7XG4gICAgb3V0ZXJTdHlsZS5sZWZ0ID0gMDtcbiAgICBvdXRlclN0eWxlLnBvaW50ZXJFdmVudHMgPSAnbm9uZSc7XG4gICAgb3V0ZXJTdHlsZS52aXNpYmlsaXR5ID0gJ2hpZGRlbic7XG4gICAgb3V0ZXJTdHlsZS53aWR0aCA9ICcyMDBweCc7XG4gICAgb3V0ZXJTdHlsZS5oZWlnaHQgPSAnMTUwcHgnO1xuICAgIG91dGVyU3R5bGUub3ZlcmZsb3cgPSAnaGlkZGVuJztcblxuICAgIG91dGVyLmFwcGVuZENoaWxkKGlubmVyKTtcblxuICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQob3V0ZXIpO1xuXG4gICAgdmFyIHdpZHRoQ29udGFpbmVkID0gaW5uZXIub2Zmc2V0V2lkdGg7XG4gICAgb3V0ZXIuc3R5bGUub3ZlcmZsb3cgPSAnc2Nyb2xsJztcbiAgICB2YXIgd2lkdGhTY3JvbGwgPSBpbm5lci5vZmZzZXRXaWR0aDtcblxuICAgIGlmICh3aWR0aENvbnRhaW5lZCA9PT0gd2lkdGhTY3JvbGwpIHtcbiAgICAgIHdpZHRoU2Nyb2xsID0gb3V0ZXIuY2xpZW50V2lkdGg7XG4gICAgfVxuXG4gICAgZG9jdW1lbnQuYm9keS5yZW1vdmVDaGlsZChvdXRlcik7XG5cbiAgICBjYWNoZWQgPSB3aWR0aENvbnRhaW5lZCAtIHdpZHRoU2Nyb2xsO1xuICB9XG4gIHJldHVybiBjYWNoZWQ7XG59IiwiXG52YXIgY29udGVudCA9IHJlcXVpcmUoXCIhIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2luZGV4LmpzPz9yZWYtLTUtMSEuL3NldHRpbmcuY3NzXCIpO1xuXG5pZih0eXBlb2YgY29udGVudCA9PT0gJ3N0cmluZycpIGNvbnRlbnQgPSBbW21vZHVsZS5pZCwgY29udGVudCwgJyddXTtcblxudmFyIHRyYW5zZm9ybTtcbnZhciBpbnNlcnRJbnRvO1xuXG5cblxudmFyIG9wdGlvbnMgPSB7XCJobXJcIjp0cnVlfVxuXG5vcHRpb25zLnRyYW5zZm9ybSA9IHRyYW5zZm9ybVxub3B0aW9ucy5pbnNlcnRJbnRvID0gdW5kZWZpbmVkO1xuXG52YXIgdXBkYXRlID0gcmVxdWlyZShcIiEuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2xpYi9hZGRTdHlsZXMuanNcIikoY29udGVudCwgb3B0aW9ucyk7XG5cbmlmKGNvbnRlbnQubG9jYWxzKSBtb2R1bGUuZXhwb3J0cyA9IGNvbnRlbnQubG9jYWxzO1xuXG5pZihtb2R1bGUuaG90KSB7XG5cdG1vZHVsZS5ob3QuYWNjZXB0KFwiISEuLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9pbmRleC5qcz8/cmVmLS01LTEhLi9zZXR0aW5nLmNzc1wiLCBmdW5jdGlvbigpIHtcblx0XHR2YXIgbmV3Q29udGVudCA9IHJlcXVpcmUoXCIhIS4uLy4uLy4uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2luZGV4LmpzPz9yZWYtLTUtMSEuL3NldHRpbmcuY3NzXCIpO1xuXG5cdFx0aWYodHlwZW9mIG5ld0NvbnRlbnQgPT09ICdzdHJpbmcnKSBuZXdDb250ZW50ID0gW1ttb2R1bGUuaWQsIG5ld0NvbnRlbnQsICcnXV07XG5cblx0XHR2YXIgbG9jYWxzID0gKGZ1bmN0aW9uKGEsIGIpIHtcblx0XHRcdHZhciBrZXksIGlkeCA9IDA7XG5cblx0XHRcdGZvcihrZXkgaW4gYSkge1xuXHRcdFx0XHRpZighYiB8fCBhW2tleV0gIT09IGJba2V5XSkgcmV0dXJuIGZhbHNlO1xuXHRcdFx0XHRpZHgrKztcblx0XHRcdH1cblxuXHRcdFx0Zm9yKGtleSBpbiBiKSBpZHgtLTtcblxuXHRcdFx0cmV0dXJuIGlkeCA9PT0gMDtcblx0XHR9KGNvbnRlbnQubG9jYWxzLCBuZXdDb250ZW50LmxvY2FscykpO1xuXG5cdFx0aWYoIWxvY2FscykgdGhyb3cgbmV3IEVycm9yKCdBYm9ydGluZyBDU1MgSE1SIGR1ZSB0byBjaGFuZ2VkIGNzcy1tb2R1bGVzIGxvY2Fscy4nKTtcblxuXHRcdHVwZGF0ZShuZXdDb250ZW50KTtcblx0fSk7XG5cblx0bW9kdWxlLmhvdC5kaXNwb3NlKGZ1bmN0aW9uKCkgeyB1cGRhdGUoKTsgfSk7XG59IiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgQ2FyZCwgVGFibGUsIEJ1dHRvbiwgSWNvbiwgTW9kYWwsIEZvcm0sIElucHV0LCBtZXNzYWdlIH0gZnJvbSAnYW50ZCc7XHJcbmltcG9ydCBzZXR0aW5nU3R5bGUgZnJvbSAnLi9zZXR0aW5nLmNzcyc7XHJcbmltcG9ydCByZXF1ZXN0IGZyb20gJy4uLy4uL2hlbHBlcnMvcmVxdWVzdCc7XHJcbmNsYXNzIFNldHRpbmcgZXh0ZW5kcyBSZWFjdC5Db21wb25lbnR7XHJcbiAgc3RhdGUgPSB7XHJcbiAgICB2aXNpYmxlOiBmYWxzZSxcclxuICAgIGFkbWluOiBbXSxcclxuICAgIGFzc2lzdDogW10sXHJcbiAgICBpZDogbnVsbFxyXG4gIH07XHJcbiAgcmVuZGVyKCl7XHJcbiAgICBsZXQgeyB2aXNpYmxlLCBhZG1pbiwgYXNzaXN0LCBpZCB9ID0gdGhpcy5zdGF0ZTtcclxuICAgIGxldCB7IGdldEZpZWxkRGVjb3JhdG9yLCBnZXRGaWVsZHNFcnJvciwgaXNGaWVsZFRvdWNoZWQsIGdldEZpZWxkRXJyb3IgfSA9IHRoaXMucHJvcHMuZm9ybTtcclxuICAgIGxldCB1c2VyRXJyID0gaXNGaWVsZFRvdWNoZWQoJ25hbWUnKSAmJiBnZXRGaWVsZEVycm9yKCduYW1lJyk7XHJcbiAgICBsZXQgYWNjb3VudEVyciA9IGlzRmllbGRUb3VjaGVkKCd1c2VyJykgJiYgZ2V0RmllbGRFcnJvcigndXNlcicpO1xyXG4gICAgbGV0IHBhc3N3b3JkRXJyID0gaXNGaWVsZFRvdWNoZWQoJ3Bhc3N3b3JkJykgJiYgZ2V0RmllbGRFcnJvcigncGFzc3dvcmQnKTtcclxuICAgIGNvbnN0IG1vZGFsRm9vdGVyID0gKFxyXG4gICAgICA8Zm9vdGVyPlxyXG4gICAgICAgIDxCdXR0b24gb25DbGljaz17dGhpcy5jbG9zZU1vZGFsfT7lj5bmtog8L0J1dHRvbj5cclxuICAgICAgICA8QnV0dG9uIHR5cGU9J3ByaW1hcnknIG9uQ2xpY2s9e3RoaXMubW9kYWxFbnN1cmV9IGRpc2FibGVkPXt0aGlzLmhhc0Vycm9ycyhnZXRGaWVsZHNFcnJvcigpKX0+56Gu6K6kPC9CdXR0b24+XHJcbiAgICAgIDwvZm9vdGVyPlxyXG4gICAgKTtcclxuICAgIGxldCBBZGRNb2RhbCA9IChcclxuICAgICAgPE1vZGFsIHdpZHRoPXs2NTB9IHRpdGxlPXtpZCA/ICfkv67mlLnotKblj7flr4bnoIEnIDogJ+aWsOWinuWuoeaguOWRmOi0puWPtyd9IGRlc3Ryb3lPbkNsb3NlPXt0cnVlfSB2aXNpYmxlPXt2aXNpYmxlfSBmb290ZXI9e21vZGFsRm9vdGVyfSBvbkNhbmNlbD17dGhpcy5jbG9zZU1vZGFsfT5cclxuICAgICAgICAgIDxGb3JtIGNsYXNzTmFtZT17c2V0dGluZ1N0eWxlLmZvcm19PlxyXG4gICAgICAgICAgICA8Rm9ybS5JdGVtIGxhYmVsPSflp5PlkI0nIGhlbHA9e3VzZXJFcnIgPyB1c2VyRXJyIDogbnVsbH0gdmFsaWRhdGVTdGF0dXM9e3VzZXJFcnIgPyAnZXJyb3InOiAnJ30+XHJcbiAgICAgICAgICAgICAge2dldEZpZWxkRGVjb3JhdG9yKCduYW1lJywge1xyXG4gICAgICAgICAgICAgICAgcnVsZXM6IFt7XHJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICBtZXNzYWdlOiAn5aeT5ZCN5LiN6IO95Li656m6J1xyXG4gICAgICAgICAgICAgICAgfV1cclxuICAgICAgICAgICAgICB9KShcclxuICAgICAgICAgICAgICAgIDxJbnB1dCBzaXplPSdsYXJnZScgZGlzYWJsZWQ9eyEhaWR9Lz5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgPEZvcm0uSXRlbSBsYWJlbD0n55m76ZmG6LSm5Y+3JyBoZWxwPXthY2NvdW50RXJyID8gdXNlckVyciA6IG51bGx9IHZhbGlkYXRlU3RhdHVzPXthY2NvdW50RXJyID8gJ2Vycm9yJzogJyd9PlxyXG4gICAgICAgICAgICAgIHtnZXRGaWVsZERlY29yYXRvcigndXNlcicsICB7XHJcbiAgICAgICAgICAgICAgICBydWxlczogW3tcclxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWQ6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6ICfotKblj7fkuI3og73kuLrnqbonXHJcbiAgICAgICAgICAgICAgICB9XVxyXG4gICAgICAgICAgICAgIH0pKFxyXG4gICAgICAgICAgICAgICAgPElucHV0IHNpemU9J2xhcmdlJyBkaXNhYmxlZD17ISFpZH0vPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICA8Rm9ybS5JdGVtIGxhYmVsPSflr4bnoIEnIGhlbHA9e3Bhc3N3b3JkRXJyID8gdXNlckVyciA6IG51bGx9IHZhbGlkYXRlU3RhdHVzPXtwYXNzd29yZEVyciA/ICdlcnJvcic6ICcnfT5cclxuICAgICAgICAgICAgICB7Z2V0RmllbGREZWNvcmF0b3IoJ3Bhc3N3b3JkJywge1xyXG4gICAgICAgICAgICAgICAgcnVsZXM6IFt7XHJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICBtZXNzYWdlOiAn5a+G56CB5LiN6IO95Li656m6J1xyXG4gICAgICAgICAgICAgICAgfV1cclxuICAgICAgICAgICAgICB9KShcclxuICAgICAgICAgICAgICAgIDxJbnB1dCBzaXplPSdsYXJnZScvPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgPC9Gb3JtPlxyXG4gICAgICA8L01vZGFsPlxyXG4gICAgKTtcclxuICAgIGNvbnN0IGFkbWluQ29sdW1ucyA9IFt7XHJcbiAgICAgIHRpdGxlOiAn5aeT5ZCNJyxcclxuICAgICAgZGF0YUluZGV4OiAnbmFtZSdcclxuICAgIH0sIHtcclxuICAgICAgdGl0bGU6ICfnmbvpmYbotKblj7cnLFxyXG4gICAgICBkYXRhSW5kZXg6ICd0aGVfdXNlcidcclxuICAgIH0sIHtcclxuICAgICAgdGl0bGU6ICfmt7vliqDml7bpl7QnLFxyXG4gICAgICBkYXRhSW5kZXg6ICdjcmVhdGVfdGltZScsXHJcbiAgICAgIHJlbmRlcjogdGV4dCA9PiA8c3Bhbj57dGV4dCB8fCAnLSd9PC9zcGFuPlxyXG4gICAgfSx7XHJcbiAgICAgIHRpdGxlOiAn5LiK5qyh55m76ZmG5pe26Ze0JyxcclxuICAgICAgZGF0YUluZGV4OiAnbGFzdF90aW1lJyxcclxuICAgICAgcmVuZGVyOiB0ZXh0ID0+IDxzcGFuPnt0ZXh0IHx8ICctJ308L3NwYW4+XHJcbiAgICB9LCB7XHJcbiAgICAgIHRpdGxlOiAn5pON5L2cJyxcclxuICAgICAgcmVuZGVyOiAodGV4dCwgcmVjb3JkKSA9PiAoPHNwYW4+XHJcbiAgICAgICAgPGEgb25DbGljaz17KCkgPT4gdGhpcy5zZXRBY2NvdW50KHJlY29yZCl9PuS/ruaUuTwvYT5cclxuICAgICAgPC9zcGFuPilcclxuICAgIH1dO1xyXG4gICAgY29uc3QgYXNzaXN0Q29sdW1ucyA9IFt7XHJcbiAgICAgIHRpdGxlOiAn5aeT5ZCNJyxcclxuICAgICAgZGF0YUluZGV4OiAnbmFtZSdcclxuICAgIH0sIHtcclxuICAgICAgdGl0bGU6ICfnmbvpmYbotKblj7cnLFxyXG4gICAgICBkYXRhSW5kZXg6ICd0aGVfdXNlcidcclxuICAgIH0sIHtcclxuICAgICAgdGl0bGU6ICfmt7vliqDml7bpl7QnLFxyXG4gICAgICBkYXRhSW5kZXg6ICdjcmVhdGVfdGltZScsXHJcbiAgICAgIHJlbmRlcjogdGV4dCA9PiA8c3Bhbj57dGV4dCB8fCAnLSd9PC9zcGFuPlxyXG4gICAgfSx7XHJcbiAgICAgIHRpdGxlOiAn5LiK5qyh55m76ZmG5pe26Ze0JyxcclxuICAgICAgZGF0YUluZGV4OiAnbGFzdF90aW1lJyxcclxuICAgICAgcmVuZGVyOiB0ZXh0ID0+IDxzcGFuPnt0ZXh0IHx8ICctJ308L3NwYW4+XHJcbiAgICB9LCB7XHJcbiAgICAgIHRpdGxlOiAn5pON5L2cJyxcclxuICAgICAgcmVuZGVyOiAodGV4dCwgcmVjb3JkKSA9PiAoPHNwYW4+XHJcbiAgICAgICAge2FkbWluLmxlbmd0aCA8IDEgPyAoPGEgb25DbGljaz17KCkgPT4gdGhpcy5zZXRBY2NvdW50KHJlY29yZCl9PuS/ruaUuTwvYT4pIDogbnVsbH1cclxuICAgICAgICB7YWRtaW4ubGVuZ3RoID4gMCA/ICg8YSBvbkNsaWNrPXsoKSA9PiB0aGlzLmRlbGV0ZUFjY291bnQocmVjb3JkLmlkKX0+5Yig6ZmkPC9hPikgOiBudWxsfVxyXG4gICAgICA8L3NwYW4+KVxyXG4gICAgfV07XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2PlxyXG4gICAgICAgIHtcclxuICAgICAgICAgIGFkbWluLmxlbmd0aCA8IDEgPyBudWxsIDogKFxyXG4gICAgICAgICAgICA8Q2FyZFxyXG4gICAgICAgICAgICAgIHRpdGxlPSfnrqHnkIblkZgnXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtzZXR0aW5nU3R5bGVbXCJjYXJkLW1hcmdpblwiXX0+XHJcbiAgICAgICAgICAgICAgPFRhYmxlIGNvbHVtbnM9e2FkbWluQ29sdW1uc30gZGF0YVNvdXJjZT17YWRtaW59IHBhZ2luYXRpb249e2ZhbHNlfSByb3dLZXk9J2lkJy8+XHJcbiAgICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICAgIClcclxuICAgICAgICB9XHJcbiAgICAgICAgPENhcmRcclxuICAgICAgICAgIHRpdGxlPSflrqHmoLjlkZgnXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPFRhYmxlIGNvbHVtbnM9e2Fzc2lzdENvbHVtbnN9IGRhdGFTb3VyY2U9e2Fzc2lzdH0gcGFnaW5hdGlvbj17ZmFsc2V9IHJvd0tleT0naWQnLz5cclxuICAgICAgICAgIHthZG1pbi5sZW5ndGggPCAxID8gbnVsbCA6IChcclxuICAgICAgICAgICAgPEJ1dHRvbiBjbGFzc05hbWU9e3NldHRpbmdTdHlsZVsnYWRkLWFjY291bnQnXX0gc2l6ZT0nbGFyZ2UnIG9uQ2xpY2s9e3RoaXMuaGFuZGxlQWRkfT5cclxuICAgICAgICAgICAgICA8SWNvbiB0eXBlPSdwbHVzJy8+5re75YqgXHJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICAge0FkZE1vZGFsfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIClcclxuICB9XHJcbiAgY29tcG9uZW50RGlkTW91bnQoKXtcclxuICAgIHRoaXMucHJvcHMuZm9ybS52YWxpZGF0ZUZpZWxkcygpO1xyXG4gICAgdGhpcy5nZXRBY2NvdW50TGlzdCgpO1xyXG4gIH1cclxuICBoYXNFcnJvcnMgPSAoZXJyb3JzKSA9PiB7XHJcbiAgICByZXR1cm4gT2JqZWN0LmtleXMoZXJyb3JzKS5zb21lKGtleSA9PiBlcnJvcnNba2V5XSk7XHJcbiAgfTtcclxuICBoYW5kbGVBZGQgPSAoKSA9PiB7XHJcbiAgICB0aGlzLnNldFN0YXRlKHtcclxuICAgICAgdmlzaWJsZTogdHJ1ZVxyXG4gICAgfSwgKCkgPT4ge1xyXG4gICAgICB0aGlzLnByb3BzLmZvcm0udmFsaWRhdGVGaWVsZHMoKTtcclxuICAgIH0pXHJcbiAgfTtcclxuICBjbG9zZU1vZGFsID0gKCkgPT4ge1xyXG4gICAgdGhpcy5zZXRTdGF0ZSh7XHJcbiAgICAgIHZpc2libGU6IGZhbHNlLFxyXG4gICAgICBpZDonJ1xyXG4gICAgfSlcclxuICB9O1xyXG4gIGdldEFjY291bnRMaXN0ID0gKCkgPT4ge1xyXG4gICAgcmVxdWVzdCh7XHJcbiAgICAgIHVybDogJy9hcGkvd2ViX2FjY291bnRfbGlzdCcsXHJcbiAgICAgIGRhdGE6e30sXHJcbiAgICAgIHN1Y2Nlc3M6ICh7IGRhdGEgfSkgPT4ge1xyXG4gICAgICAgIGxldCBhZG1pbiA9IFtdLFxyXG4gICAgICAgICAgYXNzaXN0ID0gW107XHJcbiAgICAgICAgZGF0YS5tYXAocGVyID0+IHtcclxuICAgICAgICAgIGlmKHBlci50eXBlID09PSAwKXtcclxuICAgICAgICAgICAgYWRtaW4ucHVzaChwZXIpO1xyXG4gICAgICAgICAgfWVsc2UgaWYocGVyLnR5cGUgPT09IDEpIHtcclxuICAgICAgICAgICAgYXNzaXN0LnB1c2gocGVyKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgICAgICB0aGlzLnNldFN0YXRlKHtcclxuICAgICAgICAgIGFkbWluLFxyXG4gICAgICAgICAgYXNzaXN0XHJcbiAgICAgICAgfSlcclxuICAgICAgfVxyXG4gICAgfSlcclxuICB9O1xyXG4gIHNldEFjY291bnQgPSAodXNlciA9IHt9KSA9PiB7XHJcbiAgICAgIHRoaXMuc2V0U3RhdGUoe1xyXG4gICAgICAgIGlkOiB1c2VyLmlkLFxyXG4gICAgICAgIHZpc2libGU6IHRydWVcclxuICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgIHRoaXMucHJvcHMuZm9ybS52YWxpZGF0ZUZpZWxkcygpO1xyXG4gICAgICAgIGlmKHVzZXIpe1xyXG4gICAgICAgICAgdGhpcy5wcm9wcy5mb3JtLnNldEZpZWxkc1ZhbHVlKHtcclxuICAgICAgICAgICAgbmFtZTogdXNlci5uYW1lLFxyXG4gICAgICAgICAgICB1c2VyOiB1c2VyLnRoZV91c2VyXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgIH0pXHJcbiAgfTtcclxuICByZW5ld0FjY291bnRQYXNzd29yZCA9IChpZCkgPT4ge1xyXG4gICAgbGV0IHZhbHVlcyA9IHRoaXMucHJvcHMuZm9ybS5nZXRGaWVsZHNWYWx1ZSgpO1xyXG4gICAgICByZXF1ZXN0KHtcclxuICAgICAgICB1cmw6ICcvYXBpL3dlYl9tb2RpZnknLFxyXG4gICAgICAgIGRhdGE6e1xyXG4gICAgICAgICAgaWQsXHJcbiAgICAgICAgICB0eXBlOiAxLFxyXG4gICAgICAgICAgdGhlX3Bhc3N3b3JkOiB2YWx1ZXNbJ3Bhc3N3b3JkJ11cclxuICAgICAgICB9LFxyXG4gICAgICAgIHN1Y2Nlc3M6ICh7IGRhdGEgfSkgPT4ge1xyXG4gICAgICAgICAgdGhpcy5jbG9zZU1vZGFsKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG4gIH07XHJcbiAgZGVsZXRlQWNjb3VudCA9IChpZCkgPT4ge1xyXG4gICAgcmVxdWVzdCh7XHJcbiAgICAgIHVybDogJy9hcGkvd2ViX21vZGlmeScsXHJcbiAgICAgIGRhdGE6IHtcclxuICAgICAgICBpZCxcclxuICAgICAgICB0eXBlOiAwXHJcbiAgICAgIH0sXHJcbiAgICAgIHN1Y2Nlc3M6ICh7IGRhdGEgfSkgPT4ge1xyXG4gICAgICAgIHRoaXMuZ2V0QWNjb3VudExpc3QoKTtcclxuICAgICAgfVxyXG4gICAgfSlcclxuICB9O1xyXG4gIG1vZGFsRW5zdXJlID0gKCkgPT4ge1xyXG4gICAgbGV0IGlkID0gdGhpcy5zdGF0ZS5pZDtcclxuICAgIGlmKGlkKXtcclxuICAgICAgdGhpcy5yZW5ld0FjY291bnRQYXNzd29yZChpZCk7XHJcbiAgICB9ZWxzZXtcclxuICAgICAgdGhpcy5yZXF1ZXN0QWRkKCk7XHJcbiAgICB9XHJcbiAgfTtcclxuICByZXF1ZXN0QWRkID0gKCkgPT4ge1xyXG4gICAgbGV0IHsgbmFtZSwgdXNlciwgcGFzc3dvcmQgfSA9IHRoaXMucHJvcHMuZm9ybS5nZXRGaWVsZHNWYWx1ZSgpO1xyXG4gICAgcmVxdWVzdCh7XHJcbiAgICAgIHVybDogJy9hcGkvd2ViX3JlZ2lzdGVyJyxcclxuICAgICAgZGF0YToge1xyXG4gICAgICAgIG5hbWUsXHJcbiAgICAgICAgdXNlcixcclxuICAgICAgICBwYXNzd29yZFxyXG4gICAgICB9LFxyXG4gICAgICBzdWNjZXNzOiAoKSA9PiB7XHJcbiAgICAgICAgdGhpcy5jbG9zZU1vZGFsKCk7XHJcbiAgICAgICAgdGhpcy5nZXRBY2NvdW50TGlzdCgpO1xyXG4gICAgICB9LFxyXG4gICAgICBmYWlsOiAocmVzKSA9PiB7XHJcbiAgICAgICAgbWVzc2FnZS5lcnJvcihyZXMubXNnKTtcclxuICAgICAgfVxyXG4gICAgfSlcclxuICB9XHJcbn1cclxubGV0IFNldHRpbmdGb3JtID0gRm9ybS5jcmVhdGUoKShTZXR0aW5nKTtcclxuZXhwb3J0IGRlZmF1bHQgU2V0dGluZ0Zvcm07Il0sInNvdXJjZVJvb3QiOiIifQ==