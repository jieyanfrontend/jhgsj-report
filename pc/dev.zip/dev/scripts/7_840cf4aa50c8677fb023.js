(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[7],{

/***/ "../node_modules/antd/es/card/style/index.css":
/*!****************************************************!*\
  !*** ../node_modules/antd/es/card/style/index.css ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../css-loader!./index.css */ "../node_modules/css-loader/index.js!../node_modules/antd/es/card/style/index.css");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../style-loader/lib/addStyles.js */ "../node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(true) {
	module.hot.accept(/*! !../../../../css-loader!./index.css */ "../node_modules/css-loader/index.js!../node_modules/antd/es/card/style/index.css", function(__WEBPACK_OUTDATED_DEPENDENCIES__) { (function() {
		var newContent = __webpack_require__(/*! !../../../../css-loader!./index.css */ "../node_modules/css-loader/index.js!../node_modules/antd/es/card/style/index.css");

		if(typeof newContent === 'string') newContent = [[module.i, newContent, '']];

		var locals = (function(a, b) {
			var key, idx = 0;

			for(key in a) {
				if(!b || a[key] !== b[key]) return false;
				idx++;
			}

			for(key in b) idx--;

			return idx === 0;
		}(content.locals, newContent.locals));

		if(!locals) throw new Error('Aborting CSS HMR due to changed css-modules locals.');

		update(newContent);
	})(__WEBPACK_OUTDATED_DEPENDENCIES__); });

	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "../node_modules/antd/es/pagination/style/index.css":
/*!**********************************************************!*\
  !*** ../node_modules/antd/es/pagination/style/index.css ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../css-loader!./index.css */ "../node_modules/css-loader/index.js!../node_modules/antd/es/pagination/style/index.css");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../style-loader/lib/addStyles.js */ "../node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(true) {
	module.hot.accept(/*! !../../../../css-loader!./index.css */ "../node_modules/css-loader/index.js!../node_modules/antd/es/pagination/style/index.css", function(__WEBPACK_OUTDATED_DEPENDENCIES__) { (function() {
		var newContent = __webpack_require__(/*! !../../../../css-loader!./index.css */ "../node_modules/css-loader/index.js!../node_modules/antd/es/pagination/style/index.css");

		if(typeof newContent === 'string') newContent = [[module.i, newContent, '']];

		var locals = (function(a, b) {
			var key, idx = 0;

			for(key in a) {
				if(!b || a[key] !== b[key]) return false;
				idx++;
			}

			for(key in b) idx--;

			return idx === 0;
		}(content.locals, newContent.locals));

		if(!locals) throw new Error('Aborting CSS HMR due to changed css-modules locals.');

		update(newContent);
	})(__WEBPACK_OUTDATED_DEPENDENCIES__); });

	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "../node_modules/antd/es/select/style/index.css":
/*!******************************************************!*\
  !*** ../node_modules/antd/es/select/style/index.css ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../css-loader!./index.css */ "../node_modules/css-loader/index.js!../node_modules/antd/es/select/style/index.css");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../style-loader/lib/addStyles.js */ "../node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(true) {
	module.hot.accept(/*! !../../../../css-loader!./index.css */ "../node_modules/css-loader/index.js!../node_modules/antd/es/select/style/index.css", function(__WEBPACK_OUTDATED_DEPENDENCIES__) { (function() {
		var newContent = __webpack_require__(/*! !../../../../css-loader!./index.css */ "../node_modules/css-loader/index.js!../node_modules/antd/es/select/style/index.css");

		if(typeof newContent === 'string') newContent = [[module.i, newContent, '']];

		var locals = (function(a, b) {
			var key, idx = 0;

			for(key in a) {
				if(!b || a[key] !== b[key]) return false;
				idx++;
			}

			for(key in b) idx--;

			return idx === 0;
		}(content.locals, newContent.locals));

		if(!locals) throw new Error('Aborting CSS HMR due to changed css-modules locals.');

		update(newContent);
	})(__WEBPACK_OUTDATED_DEPENDENCIES__); });

	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "../node_modules/antd/es/spin/style/index.css":
/*!****************************************************!*\
  !*** ../node_modules/antd/es/spin/style/index.css ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../css-loader!./index.css */ "../node_modules/css-loader/index.js!../node_modules/antd/es/spin/style/index.css");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../style-loader/lib/addStyles.js */ "../node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(true) {
	module.hot.accept(/*! !../../../../css-loader!./index.css */ "../node_modules/css-loader/index.js!../node_modules/antd/es/spin/style/index.css", function(__WEBPACK_OUTDATED_DEPENDENCIES__) { (function() {
		var newContent = __webpack_require__(/*! !../../../../css-loader!./index.css */ "../node_modules/css-loader/index.js!../node_modules/antd/es/spin/style/index.css");

		if(typeof newContent === 'string') newContent = [[module.i, newContent, '']];

		var locals = (function(a, b) {
			var key, idx = 0;

			for(key in a) {
				if(!b || a[key] !== b[key]) return false;
				idx++;
			}

			for(key in b) idx--;

			return idx === 0;
		}(content.locals, newContent.locals));

		if(!locals) throw new Error('Aborting CSS HMR due to changed css-modules locals.');

		update(newContent);
	})(__WEBPACK_OUTDATED_DEPENDENCIES__); });

	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "../node_modules/antd/es/tabs/style/index.css":
/*!****************************************************!*\
  !*** ../node_modules/antd/es/tabs/style/index.css ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../css-loader!./index.css */ "../node_modules/css-loader/index.js!../node_modules/antd/es/tabs/style/index.css");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../style-loader/lib/addStyles.js */ "../node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(true) {
	module.hot.accept(/*! !../../../../css-loader!./index.css */ "../node_modules/css-loader/index.js!../node_modules/antd/es/tabs/style/index.css", function(__WEBPACK_OUTDATED_DEPENDENCIES__) { (function() {
		var newContent = __webpack_require__(/*! !../../../../css-loader!./index.css */ "../node_modules/css-loader/index.js!../node_modules/antd/es/tabs/style/index.css");

		if(typeof newContent === 'string') newContent = [[module.i, newContent, '']];

		var locals = (function(a, b) {
			var key, idx = 0;

			for(key in a) {
				if(!b || a[key] !== b[key]) return false;
				idx++;
			}

			for(key in b) idx--;

			return idx === 0;
		}(content.locals, newContent.locals));

		if(!locals) throw new Error('Aborting CSS HMR due to changed css-modules locals.');

		update(newContent);
	})(__WEBPACK_OUTDATED_DEPENDENCIES__); });

	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "../node_modules/css-loader/index.js!../node_modules/antd/es/card/style/index.css":
/*!*******************************************************************************!*\
  !*** ../node_modules/css-loader!../node_modules/antd/es/card/style/index.css ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../css-loader/lib/css-base.js */ "../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "/* stylelint-disable at-rule-empty-line-before,at-rule-name-space-after,at-rule-no-unknown */\n/* stylelint-disable no-duplicate-selectors */\n/* stylelint-disable declaration-bang-space-before,no-duplicate-selectors */\n/* stylelint-disable declaration-bang-space-before,no-duplicate-selectors,string-no-newline */\n.ant-card {\n  font-family: \"Monospaced Number\", \"Chinese Quote\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"PingFang SC\", \"Hiragino Sans GB\", \"Microsoft YaHei\", \"Helvetica Neue\", Helvetica, Arial, sans-serif;\n  font-size: 14px;\n  line-height: 1.5;\n  color: rgba(0, 0, 0, 0.65);\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  margin: 0;\n  padding: 0;\n  list-style: none;\n  background: #fff;\n  border-radius: 2px;\n  position: relative;\n  -webkit-transition: all .3s;\n  transition: all .3s;\n}\n.ant-card-hoverable {\n  cursor: pointer;\n}\n.ant-card-hoverable:hover {\n  -webkit-box-shadow: 0 2px 8px rgba(0, 0, 0, 0.09);\n          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.09);\n  border-color: rgba(0, 0, 0, 0.09);\n}\n.ant-card-bordered {\n  border: 1px solid #e8e8e8;\n}\n.ant-card-head {\n  background: #fff;\n  border-bottom: 1px solid #e8e8e8;\n  padding: 0 24px;\n  border-radius: 2px 2px 0 0;\n  zoom: 1;\n  margin-bottom: -1px;\n  min-height: 48px;\n}\n.ant-card-head:before,\n.ant-card-head:after {\n  content: \" \";\n  display: table;\n}\n.ant-card-head:after {\n  clear: both;\n  visibility: hidden;\n  font-size: 0;\n  height: 0;\n}\n.ant-card-head-wrapper {\n  display: -webkit-box;\n  display: -webkit-flex;\n  display: -ms-flexbox;\n  display: flex;\n}\n.ant-card-head-title {\n  font-size: 16px;\n  padding: 16px 0;\n  text-overflow: ellipsis;\n  overflow: hidden;\n  white-space: nowrap;\n  color: rgba(0, 0, 0, 0.85);\n  font-weight: 500;\n  display: inline-block;\n  -webkit-box-flex: 1;\n  -webkit-flex: 1;\n      -ms-flex: 1;\n          flex: 1;\n}\n.ant-card-head .ant-tabs {\n  margin-bottom: -17px;\n  clear: both;\n}\n.ant-card-head .ant-tabs-bar {\n  border-bottom: 1px solid #e8e8e8;\n}\n.ant-card-extra {\n  float: right;\n  padding: 17.5px 0;\n  text-align: right;\n  margin-left: auto;\n}\n.ant-card-body {\n  padding: 24px;\n  zoom: 1;\n}\n.ant-card-body:before,\n.ant-card-body:after {\n  content: \" \";\n  display: table;\n}\n.ant-card-body:after {\n  clear: both;\n  visibility: hidden;\n  font-size: 0;\n  height: 0;\n}\n.ant-card-contain-grid:not(.ant-card-loading) {\n  margin: -1px 0 0 -1px;\n  padding: 0;\n}\n.ant-card-grid {\n  border-radius: 0;\n  border: 0;\n  -webkit-box-shadow: 1px 0 0 0 #e8e8e8, 0 1px 0 0 #e8e8e8, 1px 1px 0 0 #e8e8e8, 1px 0 0 0 #e8e8e8 inset, 0 1px 0 0 #e8e8e8 inset;\n          box-shadow: 1px 0 0 0 #e8e8e8, 0 1px 0 0 #e8e8e8, 1px 1px 0 0 #e8e8e8, 1px 0 0 0 #e8e8e8 inset, 0 1px 0 0 #e8e8e8 inset;\n  width: 33.33%;\n  float: left;\n  padding: 24px;\n  -webkit-transition: all .3s;\n  transition: all .3s;\n}\n.ant-card-grid:hover {\n  position: relative;\n  z-index: 1;\n  -webkit-box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);\n          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);\n}\n.ant-card-contain-tabs .ant-card-head-title {\n  padding-bottom: 0;\n  min-height: 32px;\n}\n.ant-card-contain-tabs .ant-card-extra {\n  padding-bottom: 0;\n}\n.ant-card-cover > * {\n  width: 100%;\n  display: block;\n}\n.ant-card-actions {\n  border-top: 1px solid #e8e8e8;\n  background: #fafafa;\n  zoom: 1;\n  list-style: none;\n  margin: 0;\n  padding: 0;\n}\n.ant-card-actions:before,\n.ant-card-actions:after {\n  content: \" \";\n  display: table;\n}\n.ant-card-actions:after {\n  clear: both;\n  visibility: hidden;\n  font-size: 0;\n  height: 0;\n}\n.ant-card-actions > li {\n  float: left;\n  text-align: center;\n  margin: 12px 0;\n  color: rgba(0, 0, 0, 0.45);\n}\n.ant-card-actions > li > span {\n  display: inline-block;\n  font-size: 14px;\n  cursor: pointer;\n  line-height: 22px;\n  min-width: 32px;\n  position: relative;\n}\n.ant-card-actions > li > span:hover {\n  color: #1890ff;\n  -webkit-transition: color .3s;\n  transition: color .3s;\n}\n.ant-card-actions > li > span > .anticon {\n  font-size: 16px;\n  line-height: 22px;\n  display: block;\n  width: 100%;\n}\n.ant-card-actions > li > span a {\n  color: rgba(0, 0, 0, 0.45);\n  line-height: 22px;\n  display: inline-block;\n  width: 100%;\n}\n.ant-card-actions > li > span a:hover {\n  color: #1890ff;\n}\n.ant-card-actions > li:not(:last-child) {\n  border-right: 1px solid #e8e8e8;\n}\n.ant-card-wider-padding .ant-card-head {\n  padding: 0 32px;\n}\n.ant-card-wider-padding .ant-card-body {\n  padding: 24px 32px;\n}\n.ant-card-padding-transition .ant-card-head,\n.ant-card-padding-transition .ant-card-body {\n  -webkit-transition: padding .3s;\n  transition: padding .3s;\n}\n.ant-card-type-inner .ant-card-head {\n  padding: 0 24px;\n  background: #fafafa;\n}\n.ant-card-type-inner .ant-card-head-title {\n  padding: 12px 0;\n  font-size: 14px;\n}\n.ant-card-type-inner .ant-card-body {\n  padding: 16px 24px;\n}\n.ant-card-type-inner .ant-card-extra {\n  padding: 13.5px 0;\n}\n.ant-card-meta {\n  margin: -4px 0;\n  zoom: 1;\n}\n.ant-card-meta:before,\n.ant-card-meta:after {\n  content: \" \";\n  display: table;\n}\n.ant-card-meta:after {\n  clear: both;\n  visibility: hidden;\n  font-size: 0;\n  height: 0;\n}\n.ant-card-meta-avatar {\n  padding-right: 16px;\n  float: left;\n}\n.ant-card-meta-detail {\n  overflow: hidden;\n}\n.ant-card-meta-detail > div:not(:last-child) {\n  margin-bottom: 8px;\n}\n.ant-card-meta-title {\n  font-size: 16px;\n  text-overflow: ellipsis;\n  overflow: hidden;\n  white-space: nowrap;\n  color: rgba(0, 0, 0, 0.85);\n  font-weight: 500;\n}\n.ant-card-meta-description {\n  color: rgba(0, 0, 0, 0.45);\n}\n.ant-card-loading .ant-card-body {\n  -webkit-user-select: none;\n     -moz-user-select: none;\n      -ms-user-select: none;\n          user-select: none;\n}\n.ant-card-loading-content p {\n  margin: 0;\n}\n.ant-card-loading-block {\n  height: 14px;\n  margin: 4px 0;\n  border-radius: 2px;\n  background: -webkit-gradient(linear, left top, right top, from(rgba(207, 216, 220, 0.2)), color-stop(rgba(207, 216, 220, 0.4)), to(rgba(207, 216, 220, 0.2)));\n  background: -webkit-linear-gradient(left, rgba(207, 216, 220, 0.2), rgba(207, 216, 220, 0.4), rgba(207, 216, 220, 0.2));\n  background: linear-gradient(90deg, rgba(207, 216, 220, 0.2), rgba(207, 216, 220, 0.4), rgba(207, 216, 220, 0.2));\n  -webkit-animation: card-loading 1.4s ease infinite;\n          animation: card-loading 1.4s ease infinite;\n  background-size: 600% 600%;\n}\n@-webkit-keyframes card-loading {\n  0%,\n  100% {\n    background-position: 0 50%;\n  }\n  50% {\n    background-position: 100% 50%;\n  }\n}\n@keyframes card-loading {\n  0%,\n  100% {\n    background-position: 0 50%;\n  }\n  50% {\n    background-position: 100% 50%;\n  }\n}\n", ""]);

// exports


/***/ }),

/***/ "../node_modules/css-loader/index.js!../node_modules/antd/es/pagination/style/index.css":
/*!*************************************************************************************!*\
  !*** ../node_modules/css-loader!../node_modules/antd/es/pagination/style/index.css ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../css-loader/lib/css-base.js */ "../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "/* stylelint-disable at-rule-empty-line-before,at-rule-name-space-after,at-rule-no-unknown */\n/* stylelint-disable no-duplicate-selectors */\n/* stylelint-disable declaration-bang-space-before,no-duplicate-selectors */\n/* stylelint-disable declaration-bang-space-before,no-duplicate-selectors,string-no-newline */\n.ant-pagination {\n  font-family: \"Monospaced Number\", \"Chinese Quote\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"PingFang SC\", \"Hiragino Sans GB\", \"Microsoft YaHei\", \"Helvetica Neue\", Helvetica, Arial, sans-serif;\n  font-size: 14px;\n  line-height: 1.5;\n  color: rgba(0, 0, 0, 0.65);\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  margin: 0;\n  padding: 0;\n  list-style: none;\n}\n.ant-pagination ul,\n.ant-pagination ol {\n  margin: 0;\n  padding: 0;\n  list-style: none;\n}\n.ant-pagination:after {\n  content: \" \";\n  display: block;\n  height: 0;\n  clear: both;\n  overflow: hidden;\n  visibility: hidden;\n}\n.ant-pagination-total-text {\n  display: inline-block;\n  vertical-align: middle;\n  height: 32px;\n  line-height: 30px;\n  margin-right: 8px;\n}\n.ant-pagination-item {\n  cursor: pointer;\n  border-radius: 4px;\n  -webkit-user-select: none;\n     -moz-user-select: none;\n      -ms-user-select: none;\n          user-select: none;\n  min-width: 32px;\n  height: 32px;\n  line-height: 30px;\n  text-align: center;\n  list-style: none;\n  display: inline-block;\n  vertical-align: middle;\n  border: 1px solid #d9d9d9;\n  background-color: #fff;\n  margin-right: 8px;\n  font-family: Arial;\n  outline: 0;\n}\n.ant-pagination-item a {\n  text-decoration: none;\n  color: rgba(0, 0, 0, 0.65);\n  -webkit-transition: none;\n  transition: none;\n  margin: 0 6px;\n}\n.ant-pagination-item:focus,\n.ant-pagination-item:hover {\n  -webkit-transition: all .3s;\n  transition: all .3s;\n  border-color: #1890ff;\n}\n.ant-pagination-item:focus a,\n.ant-pagination-item:hover a {\n  color: #1890ff;\n}\n.ant-pagination-item-active {\n  border-color: #1890ff;\n  font-weight: 500;\n}\n.ant-pagination-item-active a {\n  color: #1890ff;\n}\n.ant-pagination-item-active:focus,\n.ant-pagination-item-active:hover {\n  border-color: #40a9ff;\n}\n.ant-pagination-item-active:focus a,\n.ant-pagination-item-active:hover a {\n  color: #40a9ff;\n}\n.ant-pagination-jump-prev,\n.ant-pagination-jump-next {\n  outline: 0;\n}\n.ant-pagination-jump-prev:after,\n.ant-pagination-jump-next:after {\n  content: \"\\2022\\2022\\2022\";\n  display: block;\n  letter-spacing: 2px;\n  color: rgba(0, 0, 0, 0.25);\n  text-align: center;\n}\n.ant-pagination-jump-prev:focus:after,\n.ant-pagination-jump-next:focus:after,\n.ant-pagination-jump-prev:hover:after,\n.ant-pagination-jump-next:hover:after {\n  color: #1890ff;\n  display: inline-block;\n  font-size: 12px;\n  font-size: 8px \\9;\n  -webkit-transform: scale(0.66666667) rotate(0deg);\n      -ms-transform: scale(0.66666667) rotate(0deg);\n          transform: scale(0.66666667) rotate(0deg);\n  letter-spacing: -1px;\n  font-family: \"anticon\";\n}\n:root .ant-pagination-jump-prev:focus:after,\n:root .ant-pagination-jump-next:focus:after,\n:root .ant-pagination-jump-prev:hover:after,\n:root .ant-pagination-jump-next:hover:after {\n  font-size: 12px;\n}\n.ant-pagination-jump-prev:focus:after,\n.ant-pagination-jump-prev:hover:after {\n  content: \"\\E620\\E620\";\n}\n.ant-pagination-jump-next:focus:after,\n.ant-pagination-jump-next:hover:after {\n  content: \"\\E61F\\E61F\";\n}\n.ant-pagination-prev,\n.ant-pagination-jump-prev,\n.ant-pagination-jump-next {\n  margin-right: 8px;\n}\n.ant-pagination-prev,\n.ant-pagination-next,\n.ant-pagination-jump-prev,\n.ant-pagination-jump-next {\n  font-family: Arial;\n  cursor: pointer;\n  color: rgba(0, 0, 0, 0.65);\n  border-radius: 4px;\n  list-style: none;\n  min-width: 32px;\n  height: 32px;\n  line-height: 32px;\n  text-align: center;\n  -webkit-transition: all .3s;\n  transition: all .3s;\n  display: inline-block;\n  vertical-align: middle;\n}\n.ant-pagination-prev,\n.ant-pagination-next {\n  outline: 0;\n}\n.ant-pagination-prev a,\n.ant-pagination-next a {\n  color: rgba(0, 0, 0, 0.65);\n  -webkit-user-select: none;\n     -moz-user-select: none;\n      -ms-user-select: none;\n          user-select: none;\n}\n.ant-pagination-prev:hover a,\n.ant-pagination-next:hover a {\n  border-color: #40a9ff;\n}\n.ant-pagination-prev .ant-pagination-item-link,\n.ant-pagination-next .ant-pagination-item-link {\n  border: 1px solid #d9d9d9;\n  background-color: #fff;\n  border-radius: 4px;\n  outline: none;\n  display: block;\n  -webkit-transition: all .3s;\n  transition: all .3s;\n}\n.ant-pagination-prev .ant-pagination-item-link:after,\n.ant-pagination-next .ant-pagination-item-link:after {\n  font-size: 12px;\n  display: block;\n  height: 30px;\n  font-family: \"anticon\";\n  text-align: center;\n  font-weight: 500;\n}\n.ant-pagination-prev:focus .ant-pagination-item-link,\n.ant-pagination-next:focus .ant-pagination-item-link,\n.ant-pagination-prev:hover .ant-pagination-item-link,\n.ant-pagination-next:hover .ant-pagination-item-link {\n  border-color: #1890ff;\n  color: #1890ff;\n}\n.ant-pagination-prev .ant-pagination-item-link:after {\n  content: \"\\E620\";\n  display: block;\n}\n.ant-pagination-next .ant-pagination-item-link:after {\n  content: \"\\E61F\";\n  display: block;\n}\n.ant-pagination-disabled,\n.ant-pagination-disabled:hover,\n.ant-pagination-disabled:focus {\n  cursor: not-allowed;\n}\n.ant-pagination-disabled a,\n.ant-pagination-disabled:hover a,\n.ant-pagination-disabled:focus a,\n.ant-pagination-disabled .ant-pagination-item-link,\n.ant-pagination-disabled:hover .ant-pagination-item-link,\n.ant-pagination-disabled:focus .ant-pagination-item-link {\n  border-color: #d9d9d9;\n  color: rgba(0, 0, 0, 0.25);\n  cursor: not-allowed;\n}\n.ant-pagination-slash {\n  margin: 0 10px 0 5px;\n}\n.ant-pagination-options {\n  display: inline-block;\n  vertical-align: middle;\n  margin-left: 16px;\n}\n.ant-pagination-options-size-changer.ant-select {\n  display: inline-block;\n  margin-right: 8px;\n}\n.ant-pagination-options-quick-jumper {\n  display: inline-block;\n  vertical-align: top;\n  height: 32px;\n  line-height: 32px;\n}\n.ant-pagination-options-quick-jumper input {\n  position: relative;\n  display: inline-block;\n  padding: 4px 11px;\n  width: 100%;\n  height: 32px;\n  font-size: 14px;\n  line-height: 1.5;\n  color: rgba(0, 0, 0, 0.65);\n  background-color: #fff;\n  background-image: none;\n  border: 1px solid #d9d9d9;\n  border-radius: 4px;\n  -webkit-transition: all .3s;\n  transition: all .3s;\n  margin: 0 8px;\n  width: 50px;\n}\n.ant-pagination-options-quick-jumper input::-moz-placeholder {\n  color: #bfbfbf;\n  opacity: 1;\n}\n.ant-pagination-options-quick-jumper input:-ms-input-placeholder {\n  color: #bfbfbf;\n}\n.ant-pagination-options-quick-jumper input::-webkit-input-placeholder {\n  color: #bfbfbf;\n}\n.ant-pagination-options-quick-jumper input:hover {\n  border-color: #40a9ff;\n}\n.ant-pagination-options-quick-jumper input:focus {\n  border-color: #40a9ff;\n  outline: 0;\n  -webkit-box-shadow: 0 0 0 2px rgba(24, 144, 255, 0.2);\n          box-shadow: 0 0 0 2px rgba(24, 144, 255, 0.2);\n}\n.ant-pagination-options-quick-jumper input-disabled {\n  background-color: #f5f5f5;\n  opacity: 1;\n  cursor: not-allowed;\n  color: rgba(0, 0, 0, 0.25);\n}\n.ant-pagination-options-quick-jumper input-disabled:hover {\n  border-color: #e6d8d8;\n}\ntextarea.ant-pagination-options-quick-jumper input {\n  max-width: 100%;\n  height: auto;\n  vertical-align: bottom;\n  -webkit-transition: all .3s, height 0s;\n  transition: all .3s, height 0s;\n  min-height: 32px;\n}\n.ant-pagination-options-quick-jumper input-lg {\n  padding: 6px 11px;\n  height: 40px;\n  font-size: 16px;\n}\n.ant-pagination-options-quick-jumper input-sm {\n  padding: 1px 7px;\n  height: 24px;\n}\n.ant-pagination-simple .ant-pagination-prev,\n.ant-pagination-simple .ant-pagination-next {\n  height: 24px;\n  line-height: 24px;\n  vertical-align: top;\n}\n.ant-pagination-simple .ant-pagination-prev .ant-pagination-item-link,\n.ant-pagination-simple .ant-pagination-next .ant-pagination-item-link {\n  border: 0;\n  height: 24px;\n}\n.ant-pagination-simple .ant-pagination-prev .ant-pagination-item-link:after,\n.ant-pagination-simple .ant-pagination-next .ant-pagination-item-link:after {\n  height: 24px;\n  line-height: 24px;\n}\n.ant-pagination-simple .ant-pagination-simple-pager {\n  display: inline-block;\n  margin-right: 8px;\n  height: 24px;\n}\n.ant-pagination-simple .ant-pagination-simple-pager input {\n  margin-right: 8px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  background-color: #fff;\n  border-radius: 4px;\n  border: 1px solid #d9d9d9;\n  outline: none;\n  padding: 0 6px;\n  height: 100%;\n  text-align: center;\n  -webkit-transition: border-color 0.3s;\n  transition: border-color 0.3s;\n}\n.ant-pagination-simple .ant-pagination-simple-pager input:hover {\n  border-color: #1890ff;\n}\n.ant-pagination.mini .ant-pagination-total-text,\n.ant-pagination.mini .ant-pagination-simple-pager {\n  height: 24px;\n  line-height: 24px;\n}\n.ant-pagination.mini .ant-pagination-item {\n  margin: 0;\n  min-width: 24px;\n  height: 24px;\n  line-height: 22px;\n}\n.ant-pagination.mini .ant-pagination-item:not(.ant-pagination-item-active) {\n  background: transparent;\n  border-color: transparent;\n}\n.ant-pagination.mini .ant-pagination-prev,\n.ant-pagination.mini .ant-pagination-next {\n  margin: 0;\n  min-width: 24px;\n  height: 24px;\n  line-height: 24px;\n}\n.ant-pagination.mini .ant-pagination-prev .ant-pagination-item-link,\n.ant-pagination.mini .ant-pagination-next .ant-pagination-item-link {\n  border-color: transparent;\n  background: transparent;\n}\n.ant-pagination.mini .ant-pagination-prev .ant-pagination-item-link:after,\n.ant-pagination.mini .ant-pagination-next .ant-pagination-item-link:after {\n  height: 24px;\n  line-height: 24px;\n}\n.ant-pagination.mini .ant-pagination-jump-prev,\n.ant-pagination.mini .ant-pagination-jump-next {\n  height: 24px;\n  line-height: 24px;\n  margin-right: 0;\n}\n.ant-pagination.mini .ant-pagination-options {\n  margin-left: 2px;\n}\n.ant-pagination.mini .ant-pagination-options-quick-jumper {\n  height: 24px;\n  line-height: 24px;\n}\n.ant-pagination.mini .ant-pagination-options-quick-jumper input {\n  padding: 1px 7px;\n  height: 24px;\n  width: 44px;\n}\n@media only screen and (max-width: 992px) {\n  .ant-pagination-item-after-jump-prev,\n  .ant-pagination-item-before-jump-next {\n    display: none;\n  }\n}\n@media only screen and (max-width: 576px) {\n  .ant-pagination-options {\n    display: none;\n  }\n}\n", ""]);

// exports


/***/ }),

/***/ "../node_modules/css-loader/index.js!../node_modules/antd/es/select/style/index.css":
/*!*********************************************************************************!*\
  !*** ../node_modules/css-loader!../node_modules/antd/es/select/style/index.css ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../css-loader/lib/css-base.js */ "../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "/* stylelint-disable at-rule-empty-line-before,at-rule-name-space-after,at-rule-no-unknown */\n/* stylelint-disable no-duplicate-selectors */\n/* stylelint-disable declaration-bang-space-before,no-duplicate-selectors */\n/* stylelint-disable declaration-bang-space-before,no-duplicate-selectors,string-no-newline */\n.ant-select {\n  font-family: \"Monospaced Number\", \"Chinese Quote\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"PingFang SC\", \"Hiragino Sans GB\", \"Microsoft YaHei\", \"Helvetica Neue\", Helvetica, Arial, sans-serif;\n  font-size: 14px;\n  line-height: 1.5;\n  color: rgba(0, 0, 0, 0.65);\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  margin: 0;\n  padding: 0;\n  list-style: none;\n  display: inline-block;\n  position: relative;\n}\n.ant-select ul,\n.ant-select ol {\n  margin: 0;\n  padding: 0;\n  list-style: none;\n}\n.ant-select > ul > li > a {\n  padding: 0;\n  background-color: #fff;\n}\n.ant-select-arrow {\n  display: inline-block;\n  font-style: normal;\n  vertical-align: baseline;\n  text-align: center;\n  text-transform: none;\n  text-rendering: optimizeLegibility;\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n  position: absolute;\n  top: 50%;\n  right: 11px;\n  line-height: 1;\n  margin-top: -6px;\n  -webkit-transform-origin: 50% 50%;\n      -ms-transform-origin: 50% 50%;\n          transform-origin: 50% 50%;\n  color: rgba(0, 0, 0, 0.25);\n  font-size: 12px;\n}\n.ant-select-arrow:before {\n  display: block;\n  font-family: \"anticon\" !important;\n}\n.ant-select-arrow * {\n  display: none;\n}\n.ant-select-arrow:before {\n  content: '\\E61D';\n  -webkit-transition: -webkit-transform .3s;\n  transition: -webkit-transform .3s;\n  transition: transform .3s;\n  transition: transform .3s, -webkit-transform .3s;\n}\n.ant-select-selection {\n  outline: none;\n  -webkit-user-select: none;\n     -moz-user-select: none;\n      -ms-user-select: none;\n          user-select: none;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  display: block;\n  background-color: #fff;\n  border-radius: 4px;\n  border: 1px solid #d9d9d9;\n  border-top-width: 1.02px;\n  -webkit-transition: all 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n  transition: all 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n}\n.ant-select-selection:hover {\n  border-color: #40a9ff;\n}\n.ant-select-focused .ant-select-selection,\n.ant-select-selection:focus,\n.ant-select-selection:active {\n  border-color: #40a9ff;\n  outline: 0;\n  -webkit-box-shadow: 0 0 0 2px rgba(24, 144, 255, 0.2);\n          box-shadow: 0 0 0 2px rgba(24, 144, 255, 0.2);\n}\n.ant-select-selection__clear {\n  display: inline-block;\n  font-style: normal;\n  vertical-align: baseline;\n  text-align: center;\n  text-transform: none;\n  text-rendering: auto;\n  opacity: 0;\n  position: absolute;\n  right: 11px;\n  z-index: 1;\n  background: #fff;\n  top: 50%;\n  font-size: 12px;\n  color: rgba(0, 0, 0, 0.25);\n  width: 12px;\n  height: 12px;\n  margin-top: -6px;\n  line-height: 12px;\n  cursor: pointer;\n  -webkit-transition: color 0.3s ease, opacity 0.15s ease;\n  transition: color 0.3s ease, opacity 0.15s ease;\n}\n.ant-select-selection__clear:before {\n  display: block;\n  font-family: 'anticon';\n  text-rendering: optimizeLegibility;\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n  content: \"\\E62E\";\n}\n.ant-select-selection__clear:hover {\n  color: rgba(0, 0, 0, 0.45);\n}\n.ant-select-selection:hover .ant-select-selection__clear {\n  opacity: 1;\n}\n.ant-select-selection-selected-value {\n  float: left;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  max-width: 100%;\n  padding-right: 20px;\n}\n.ant-select-disabled {\n  color: rgba(0, 0, 0, 0.25);\n}\n.ant-select-disabled .ant-select-selection {\n  background: #f5f5f5;\n  cursor: not-allowed;\n}\n.ant-select-disabled .ant-select-selection:hover,\n.ant-select-disabled .ant-select-selection:focus,\n.ant-select-disabled .ant-select-selection:active {\n  border-color: #d9d9d9;\n  -webkit-box-shadow: none;\n          box-shadow: none;\n}\n.ant-select-disabled .ant-select-selection__clear {\n  display: none;\n  visibility: hidden;\n  pointer-events: none;\n}\n.ant-select-disabled .ant-select-selection--multiple .ant-select-selection__choice {\n  background: #f5f5f5;\n  color: #aaa;\n  padding-right: 10px;\n}\n.ant-select-disabled .ant-select-selection--multiple .ant-select-selection__choice__remove {\n  display: none;\n}\n.ant-select-selection--single {\n  height: 32px;\n  position: relative;\n  cursor: pointer;\n}\n.ant-select-selection__rendered {\n  display: block;\n  margin-left: 11px;\n  margin-right: 11px;\n  position: relative;\n  line-height: 30px;\n}\n.ant-select-selection__rendered:after {\n  content: '.';\n  visibility: hidden;\n  pointer-events: none;\n  display: inline-block;\n  width: 0;\n}\n.ant-select-lg {\n  font-size: 16px;\n}\n.ant-select-lg .ant-select-selection--single {\n  height: 40px;\n}\n.ant-select-lg .ant-select-selection__rendered {\n  line-height: 38px;\n}\n.ant-select-lg .ant-select-selection--multiple {\n  min-height: 40px;\n}\n.ant-select-lg .ant-select-selection--multiple .ant-select-selection__rendered li {\n  height: 32px;\n  line-height: 32px;\n}\n.ant-select-lg .ant-select-selection--multiple .ant-select-selection__clear {\n  top: 20px;\n}\n.ant-select-sm .ant-select-selection--single {\n  height: 24px;\n}\n.ant-select-sm .ant-select-selection__rendered {\n  line-height: 22px;\n  margin: 0 7px;\n}\n.ant-select-sm .ant-select-selection--multiple {\n  min-height: 24px;\n}\n.ant-select-sm .ant-select-selection--multiple .ant-select-selection__rendered li {\n  height: 16px;\n  line-height: 14px;\n}\n.ant-select-sm .ant-select-selection--multiple .ant-select-selection__clear {\n  top: 12px;\n}\n.ant-select-sm .ant-select-selection__clear,\n.ant-select-sm .ant-select-arrow {\n  right: 8px;\n}\n.ant-select-disabled .ant-select-selection__choice__remove {\n  color: rgba(0, 0, 0, 0.25);\n  cursor: default;\n}\n.ant-select-disabled .ant-select-selection__choice__remove:hover {\n  color: rgba(0, 0, 0, 0.25);\n}\n.ant-select-search__field__wrap {\n  display: inline-block;\n  position: relative;\n}\n.ant-select-selection__placeholder,\n.ant-select-search__field__placeholder {\n  position: absolute;\n  top: 50%;\n  left: 0;\n  right: 9px;\n  color: #bfbfbf;\n  line-height: 20px;\n  height: 20px;\n  max-width: 100%;\n  margin-top: -10px;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  text-align: left;\n}\n.ant-select-search__field__placeholder {\n  left: 12px;\n}\n.ant-select-search__field__mirror {\n  position: absolute;\n  top: 0;\n  left: -9999px;\n  white-space: pre;\n  pointer-events: none;\n}\n.ant-select-search--inline {\n  position: absolute;\n  height: 100%;\n  width: 100%;\n}\n.ant-select-search--inline .ant-select-search__field__wrap {\n  width: 100%;\n  height: 100%;\n}\n.ant-select-search--inline .ant-select-search__field {\n  border-width: 0;\n  font-size: 100%;\n  height: 100%;\n  width: 100%;\n  background: transparent;\n  outline: 0;\n  border-radius: 4px;\n  line-height: 1;\n}\n.ant-select-search--inline > i {\n  float: right;\n}\n.ant-select-selection--multiple {\n  min-height: 32px;\n  cursor: text;\n  padding-bottom: 3px;\n  zoom: 1;\n}\n.ant-select-selection--multiple:before,\n.ant-select-selection--multiple:after {\n  content: \" \";\n  display: table;\n}\n.ant-select-selection--multiple:after {\n  clear: both;\n  visibility: hidden;\n  font-size: 0;\n  height: 0;\n}\n.ant-select-selection--multiple .ant-select-search--inline {\n  float: left;\n  position: static;\n  width: auto;\n  padding: 0;\n  max-width: 100%;\n}\n.ant-select-selection--multiple .ant-select-search--inline .ant-select-search__field {\n  max-width: 100%;\n  width: 0.75em;\n}\n.ant-select-selection--multiple .ant-select-selection__rendered {\n  margin-left: 5px;\n  margin-bottom: -3px;\n  height: auto;\n}\n.ant-select-selection--multiple .ant-select-selection__placeholder {\n  margin-left: 6px;\n}\n.ant-select-selection--multiple > ul > li,\n.ant-select-selection--multiple .ant-select-selection__rendered > ul > li {\n  margin-top: 3px;\n  height: 24px;\n  line-height: 22px;\n}\n.ant-select-selection--multiple .ant-select-selection__choice {\n  color: rgba(0, 0, 0, 0.65);\n  background-color: #fafafa;\n  border: 1px solid #e8e8e8;\n  border-radius: 2px;\n  cursor: default;\n  float: left;\n  margin-right: 4px;\n  max-width: 99%;\n  position: relative;\n  overflow: hidden;\n  -webkit-transition: padding 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n  transition: padding 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n  padding: 0 20px 0 10px;\n}\n.ant-select-selection--multiple .ant-select-selection__choice__disabled {\n  padding: 0 10px;\n}\n.ant-select-selection--multiple .ant-select-selection__choice__content {\n  display: inline-block;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  max-width: 100%;\n  -webkit-transition: margin 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n  transition: margin 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n}\n.ant-select-selection--multiple .ant-select-selection__choice__remove {\n  font-style: normal;\n  vertical-align: baseline;\n  text-align: center;\n  text-transform: none;\n  line-height: 1;\n  text-rendering: optimizeLegibility;\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n  color: rgba(0, 0, 0, 0.45);\n  line-height: inherit;\n  cursor: pointer;\n  font-weight: bold;\n  -webkit-transition: all .3s;\n  transition: all .3s;\n  display: inline-block;\n  font-size: 12px;\n  font-size: 10px \\9;\n  -webkit-transform: scale(0.83333333) rotate(0deg);\n      -ms-transform: scale(0.83333333) rotate(0deg);\n          transform: scale(0.83333333) rotate(0deg);\n  position: absolute;\n  right: 4px;\n}\n.ant-select-selection--multiple .ant-select-selection__choice__remove:before {\n  display: block;\n  font-family: \"anticon\" !important;\n}\n:root .ant-select-selection--multiple .ant-select-selection__choice__remove {\n  font-size: 12px;\n}\n.ant-select-selection--multiple .ant-select-selection__choice__remove:hover {\n  color: #404040;\n}\n.ant-select-selection--multiple .ant-select-selection__choice__remove:before {\n  content: \"\\E633\";\n}\n.ant-select-selection--multiple .ant-select-selection__clear {\n  top: 16px;\n}\n.ant-select-allow-clear .ant-select-selection--multiple .ant-select-selection__rendered {\n  margin-right: 20px;\n}\n.ant-select-open .ant-select-arrow:before {\n  -webkit-transform: rotate(180deg);\n      -ms-transform: rotate(180deg);\n          transform: rotate(180deg);\n}\n.ant-select-open .ant-select-selection {\n  border-color: #40a9ff;\n  outline: 0;\n  -webkit-box-shadow: 0 0 0 2px rgba(24, 144, 255, 0.2);\n          box-shadow: 0 0 0 2px rgba(24, 144, 255, 0.2);\n}\n.ant-select-combobox .ant-select-arrow {\n  display: none;\n}\n.ant-select-combobox .ant-select-search--inline {\n  height: 100%;\n  width: 100%;\n  float: none;\n}\n.ant-select-combobox .ant-select-search__field__wrap {\n  width: 100%;\n  height: 100%;\n}\n.ant-select-combobox .ant-select-search__field {\n  width: 100%;\n  height: 100%;\n  position: relative;\n  z-index: 1;\n  -webkit-transition: all 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n  transition: all 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n  -webkit-box-shadow: none;\n          box-shadow: none;\n}\n.ant-select-combobox.ant-select-allow-clear .ant-select-selection:hover .ant-select-selection__rendered {\n  margin-right: 20px;\n}\n.ant-select-dropdown {\n  font-family: \"Monospaced Number\", \"Chinese Quote\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"PingFang SC\", \"Hiragino Sans GB\", \"Microsoft YaHei\", \"Helvetica Neue\", Helvetica, Arial, sans-serif;\n  line-height: 1.5;\n  color: rgba(0, 0, 0, 0.65);\n  margin: 0;\n  padding: 0;\n  list-style: none;\n  background-color: #fff;\n  -webkit-box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);\n          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);\n  border-radius: 4px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  z-index: 1050;\n  left: -9999px;\n  top: -9999px;\n  position: absolute;\n  outline: none;\n  font-size: 14px;\n}\n.ant-select-dropdown.slide-up-enter.slide-up-enter-active.ant-select-dropdown-placement-bottomLeft,\n.ant-select-dropdown.slide-up-appear.slide-up-appear-active.ant-select-dropdown-placement-bottomLeft {\n  -webkit-animation-name: antSlideUpIn;\n          animation-name: antSlideUpIn;\n}\n.ant-select-dropdown.slide-up-enter.slide-up-enter-active.ant-select-dropdown-placement-topLeft,\n.ant-select-dropdown.slide-up-appear.slide-up-appear-active.ant-select-dropdown-placement-topLeft {\n  -webkit-animation-name: antSlideDownIn;\n          animation-name: antSlideDownIn;\n}\n.ant-select-dropdown.slide-up-leave.slide-up-leave-active.ant-select-dropdown-placement-bottomLeft {\n  -webkit-animation-name: antSlideUpOut;\n          animation-name: antSlideUpOut;\n}\n.ant-select-dropdown.slide-up-leave.slide-up-leave-active.ant-select-dropdown-placement-topLeft {\n  -webkit-animation-name: antSlideDownOut;\n          animation-name: antSlideDownOut;\n}\n.ant-select-dropdown-hidden {\n  display: none;\n}\n.ant-select-dropdown-menu {\n  outline: none;\n  margin-bottom: 0;\n  padding-left: 0;\n  list-style: none;\n  max-height: 250px;\n  overflow: auto;\n}\n.ant-select-dropdown-menu-item-group-list {\n  margin: 0;\n  padding: 0;\n}\n.ant-select-dropdown-menu-item-group-list > .ant-select-dropdown-menu-item {\n  padding-left: 20px;\n}\n.ant-select-dropdown-menu-item-group-title {\n  color: rgba(0, 0, 0, 0.45);\n  padding: 0 12px;\n  height: 32px;\n  line-height: 32px;\n  font-size: 12px;\n}\n.ant-select-dropdown-menu-item {\n  position: relative;\n  display: block;\n  padding: 5px 12px;\n  line-height: 22px;\n  font-weight: normal;\n  color: rgba(0, 0, 0, 0.65);\n  white-space: nowrap;\n  cursor: pointer;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  -webkit-transition: background 0.3s ease;\n  transition: background 0.3s ease;\n}\n.ant-select-dropdown-menu-item:hover {\n  background-color: #e6f7ff;\n}\n.ant-select-dropdown-menu-item:first-child {\n  border-radius: 4px 4px 0 0;\n}\n.ant-select-dropdown-menu-item:last-child {\n  border-radius: 0 0 4px 4px;\n}\n.ant-select-dropdown-menu-item-disabled {\n  color: rgba(0, 0, 0, 0.25);\n  cursor: not-allowed;\n}\n.ant-select-dropdown-menu-item-disabled:hover {\n  color: rgba(0, 0, 0, 0.25);\n  background-color: #fff;\n  cursor: not-allowed;\n}\n.ant-select-dropdown-menu-item-selected,\n.ant-select-dropdown-menu-item-selected:hover {\n  background-color: #fafafa;\n  font-weight: 600;\n  color: rgba(0, 0, 0, 0.65);\n}\n.ant-select-dropdown-menu-item-active {\n  background-color: #e6f7ff;\n}\n.ant-select-dropdown-menu-item-divider {\n  height: 1px;\n  margin: 1px 0;\n  overflow: hidden;\n  background-color: #e8e8e8;\n  line-height: 0;\n}\n.ant-select-dropdown.ant-select-dropdown--multiple .ant-select-dropdown-menu-item:after {\n  font-family: 'anticon';\n  text-rendering: optimizeLegibility;\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n  content: \"\\E632\";\n  color: transparent;\n  display: inline-block;\n  font-size: 12px;\n  font-size: 10px \\9;\n  -webkit-transform: scale(0.83333333) rotate(0deg);\n      -ms-transform: scale(0.83333333) rotate(0deg);\n          transform: scale(0.83333333) rotate(0deg);\n  -webkit-transition: all 0.2s ease;\n  transition: all 0.2s ease;\n  position: absolute;\n  top: 50%;\n  -webkit-transform: translateY(-50%);\n      -ms-transform: translateY(-50%);\n          transform: translateY(-50%);\n  right: 12px;\n  font-weight: bold;\n  text-shadow: 0 0.1px 0, 0.1px 0 0, 0 -0.1px 0, -0.1px 0;\n}\n:root .ant-select-dropdown.ant-select-dropdown--multiple .ant-select-dropdown-menu-item:after {\n  font-size: 12px;\n}\n.ant-select-dropdown.ant-select-dropdown--multiple .ant-select-dropdown-menu-item:hover:after {\n  color: #ddd;\n}\n.ant-select-dropdown.ant-select-dropdown--multiple .ant-select-dropdown-menu-item-disabled:after {\n  display: none;\n}\n.ant-select-dropdown.ant-select-dropdown--multiple .ant-select-dropdown-menu-item-selected:after,\n.ant-select-dropdown.ant-select-dropdown--multiple .ant-select-dropdown-menu-item-selected:hover:after {\n  color: #1890ff;\n  display: inline-block;\n}\n.ant-select-dropdown-container-open .ant-select-dropdown,\n.ant-select-dropdown-open .ant-select-dropdown {\n  display: block;\n}\n", ""]);

// exports


/***/ }),

/***/ "../node_modules/css-loader/index.js!../node_modules/antd/es/spin/style/index.css":
/*!*******************************************************************************!*\
  !*** ../node_modules/css-loader!../node_modules/antd/es/spin/style/index.css ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../css-loader/lib/css-base.js */ "../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "/* stylelint-disable at-rule-empty-line-before,at-rule-name-space-after,at-rule-no-unknown */\n/* stylelint-disable no-duplicate-selectors */\n/* stylelint-disable declaration-bang-space-before,no-duplicate-selectors */\n/* stylelint-disable declaration-bang-space-before,no-duplicate-selectors,string-no-newline */\n.ant-spin {\n  font-family: \"Monospaced Number\", \"Chinese Quote\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"PingFang SC\", \"Hiragino Sans GB\", \"Microsoft YaHei\", \"Helvetica Neue\", Helvetica, Arial, sans-serif;\n  font-size: 14px;\n  line-height: 1.5;\n  color: rgba(0, 0, 0, 0.65);\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  margin: 0;\n  padding: 0;\n  list-style: none;\n  color: #1890ff;\n  vertical-align: middle;\n  text-align: center;\n  opacity: 0;\n  position: absolute;\n  -webkit-transition: -webkit-transform 0.3s cubic-bezier(0.78, 0.14, 0.15, 0.86);\n  transition: -webkit-transform 0.3s cubic-bezier(0.78, 0.14, 0.15, 0.86);\n  transition: transform 0.3s cubic-bezier(0.78, 0.14, 0.15, 0.86);\n  transition: transform 0.3s cubic-bezier(0.78, 0.14, 0.15, 0.86), -webkit-transform 0.3s cubic-bezier(0.78, 0.14, 0.15, 0.86);\n  display: none;\n}\n.ant-spin-spinning {\n  opacity: 1;\n  position: static;\n  display: inline-block;\n}\n.ant-spin-nested-loading {\n  position: relative;\n}\n.ant-spin-nested-loading > div > .ant-spin {\n  position: absolute;\n  height: 100%;\n  max-height: 320px;\n  width: 100%;\n  z-index: 4;\n}\n.ant-spin-nested-loading > div > .ant-spin .ant-spin-dot {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  margin: -10px;\n}\n.ant-spin-nested-loading > div > .ant-spin .ant-spin-text {\n  position: absolute;\n  top: 50%;\n  width: 100%;\n  padding-top: 5px;\n  text-shadow: 0 1px 2px #fff;\n}\n.ant-spin-nested-loading > div > .ant-spin.ant-spin-show-text .ant-spin-dot {\n  margin-top: -20px;\n}\n.ant-spin-nested-loading > div > .ant-spin-sm .ant-spin-dot {\n  margin: -7px;\n}\n.ant-spin-nested-loading > div > .ant-spin-sm .ant-spin-text {\n  padding-top: 2px;\n}\n.ant-spin-nested-loading > div > .ant-spin-sm.ant-spin-show-text .ant-spin-dot {\n  margin-top: -17px;\n}\n.ant-spin-nested-loading > div > .ant-spin-lg .ant-spin-dot {\n  margin: -16px;\n}\n.ant-spin-nested-loading > div > .ant-spin-lg .ant-spin-text {\n  padding-top: 11px;\n}\n.ant-spin-nested-loading > div > .ant-spin-lg.ant-spin-show-text .ant-spin-dot {\n  margin-top: -26px;\n}\n.ant-spin-container {\n  position: relative;\n  zoom: 1;\n}\n.ant-spin-container:before,\n.ant-spin-container:after {\n  content: \" \";\n  display: table;\n}\n.ant-spin-container:after {\n  clear: both;\n  visibility: hidden;\n  font-size: 0;\n  height: 0;\n}\n.ant-spin-blur {\n  overflow: hidden;\n  opacity: 0.7;\n  -webkit-filter: blur(0.5px);\n  filter: blur(0.5px);\n  /* autoprefixer: off */\n  filter: progid\\:DXImageTransform\\.Microsoft\\.Blur(PixelRadius\\=1, MakeShadow\\=false);\n  -webkit-transform: translateZ(0);\n}\n.ant-spin-blur:after {\n  content: '';\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 0;\n  bottom: 0;\n  background: #fff;\n  opacity: 0.3;\n  -webkit-transition: all .3s;\n  transition: all .3s;\n  z-index: 10;\n}\n.ant-spin-tip {\n  color: rgba(0, 0, 0, 0.45);\n}\n.ant-spin-dot {\n  position: relative;\n  display: inline-block;\n  width: 20px;\n  height: 20px;\n}\n.ant-spin-dot i {\n  width: 9px;\n  height: 9px;\n  border-radius: 100%;\n  background-color: #1890ff;\n  -webkit-transform: scale(0.75);\n      -ms-transform: scale(0.75);\n          transform: scale(0.75);\n  display: block;\n  position: absolute;\n  opacity: 0.3;\n  -webkit-animation: antSpinMove 1s infinite linear alternate;\n          animation: antSpinMove 1s infinite linear alternate;\n  -webkit-transform-origin: 50% 50%;\n      -ms-transform-origin: 50% 50%;\n          transform-origin: 50% 50%;\n}\n.ant-spin-dot i:nth-child(1) {\n  left: 0;\n  top: 0;\n}\n.ant-spin-dot i:nth-child(2) {\n  right: 0;\n  top: 0;\n  -webkit-animation-delay: 0.4s;\n          animation-delay: 0.4s;\n}\n.ant-spin-dot i:nth-child(3) {\n  right: 0;\n  bottom: 0;\n  -webkit-animation-delay: 0.8s;\n          animation-delay: 0.8s;\n}\n.ant-spin-dot i:nth-child(4) {\n  left: 0;\n  bottom: 0;\n  -webkit-animation-delay: 1.2s;\n          animation-delay: 1.2s;\n}\n.ant-spin-dot-spin {\n  -webkit-transform: rotate(45deg);\n      -ms-transform: rotate(45deg);\n          transform: rotate(45deg);\n  -webkit-animation: antRotate 1.2s infinite linear;\n          animation: antRotate 1.2s infinite linear;\n}\n.ant-spin-sm .ant-spin-dot {\n  width: 14px;\n  height: 14px;\n}\n.ant-spin-sm .ant-spin-dot i {\n  width: 6px;\n  height: 6px;\n}\n.ant-spin-lg .ant-spin-dot {\n  width: 32px;\n  height: 32px;\n}\n.ant-spin-lg .ant-spin-dot i {\n  width: 14px;\n  height: 14px;\n}\n.ant-spin.ant-spin-show-text .ant-spin-text {\n  display: block;\n}\n@media all and (-ms-high-contrast: none), (-ms-high-contrast: active) {\n  /* IE10+ */\n  .ant-spin-blur {\n    background: #fff;\n    opacity: 0.5;\n  }\n}\n@-webkit-keyframes antSpinMove {\n  to {\n    opacity: 1;\n  }\n}\n@keyframes antSpinMove {\n  to {\n    opacity: 1;\n  }\n}\n@-webkit-keyframes antRotate {\n  to {\n    -webkit-transform: rotate(405deg);\n            transform: rotate(405deg);\n  }\n}\n@keyframes antRotate {\n  to {\n    -webkit-transform: rotate(405deg);\n            transform: rotate(405deg);\n  }\n}\n", ""]);

// exports


/***/ }),

/***/ "../node_modules/css-loader/index.js!../node_modules/antd/es/tabs/style/index.css":
/*!*******************************************************************************!*\
  !*** ../node_modules/css-loader!../node_modules/antd/es/tabs/style/index.css ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../css-loader/lib/css-base.js */ "../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "/* stylelint-disable at-rule-empty-line-before,at-rule-name-space-after,at-rule-no-unknown */\n/* stylelint-disable no-duplicate-selectors */\n/* stylelint-disable declaration-bang-space-before,no-duplicate-selectors */\n/* stylelint-disable declaration-bang-space-before,no-duplicate-selectors,string-no-newline */\n.ant-tabs.ant-tabs-card > .ant-tabs-bar .ant-tabs-nav-container {\n  height: 40px;\n}\n.ant-tabs.ant-tabs-card > .ant-tabs-bar .ant-tabs-ink-bar {\n  visibility: hidden;\n}\n.ant-tabs.ant-tabs-card > .ant-tabs-bar .ant-tabs-tab {\n  margin: 0;\n  border: 1px solid #e8e8e8;\n  border-bottom: 0;\n  border-radius: 4px 4px 0 0;\n  background: #fafafa;\n  margin-right: 2px;\n  padding: 0 16px;\n  -webkit-transition: all 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n  transition: all 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n  line-height: 38px;\n}\n.ant-tabs.ant-tabs-card > .ant-tabs-bar .ant-tabs-tab-active {\n  background: #fff;\n  border-color: #e8e8e8;\n  color: #1890ff;\n  padding-bottom: 1px;\n}\n.ant-tabs.ant-tabs-card > .ant-tabs-bar .ant-tabs-tab-inactive {\n  padding: 0;\n}\n.ant-tabs.ant-tabs-card > .ant-tabs-bar .ant-tabs-nav-wrap {\n  margin-bottom: 0;\n}\n.ant-tabs.ant-tabs-card > .ant-tabs-bar .ant-tabs-tab .anticon-close {\n  color: rgba(0, 0, 0, 0.45);\n  -webkit-transition: all .3s;\n  transition: all .3s;\n  font-size: 12px;\n  margin-left: 3px;\n  margin-right: -5px;\n  overflow: hidden;\n  vertical-align: middle;\n  width: 16px;\n  height: 16px;\n  height: 14px;\n}\n.ant-tabs.ant-tabs-card > .ant-tabs-bar .ant-tabs-tab .anticon-close:hover {\n  color: rgba(0, 0, 0, 0.85);\n}\n.ant-tabs.ant-tabs-card .ant-tabs-content > .ant-tabs-tabpane,\n.ant-tabs.ant-tabs-editable-card .ant-tabs-content > .ant-tabs-tabpane {\n  -webkit-transition: none !important;\n  transition: none !important;\n}\n.ant-tabs.ant-tabs-card .ant-tabs-content > .ant-tabs-tabpane-inactive,\n.ant-tabs.ant-tabs-editable-card .ant-tabs-content > .ant-tabs-tabpane-inactive {\n  overflow: hidden;\n}\n.ant-tabs.ant-tabs-card > .ant-tabs-bar .ant-tabs-tab:hover .anticon-close {\n  opacity: 1;\n}\n.ant-tabs-extra-content {\n  line-height: 40px;\n}\n.ant-tabs-extra-content .ant-tabs-new-tab {\n  width: 20px;\n  height: 20px;\n  line-height: 20px;\n  text-align: center;\n  cursor: pointer;\n  border-radius: 2px;\n  border: 1px solid #e8e8e8;\n  font-size: 12px;\n  color: rgba(0, 0, 0, 0.65);\n  -webkit-transition: all .3s;\n  transition: all .3s;\n}\n.ant-tabs-extra-content .ant-tabs-new-tab:hover {\n  color: #1890ff;\n  border-color: #1890ff;\n}\n.ant-tabs-vertical.ant-tabs-card > .ant-tabs-bar .ant-tabs-nav-container {\n  height: auto;\n}\n.ant-tabs-vertical.ant-tabs-card > .ant-tabs-bar .ant-tabs-tab {\n  border-bottom: 1px solid #e8e8e8;\n  margin-bottom: 8px;\n}\n.ant-tabs-vertical.ant-tabs-card > .ant-tabs-bar .ant-tabs-tab-active {\n  padding-bottom: 4px;\n}\n.ant-tabs-vertical.ant-tabs-card > .ant-tabs-bar .ant-tabs-tab:last-child {\n  margin-bottom: 8px;\n}\n.ant-tabs-vertical.ant-tabs-card > .ant-tabs-bar .ant-tabs-new-tab {\n  width: 90%;\n}\n.ant-tabs-vertical.ant-tabs-card.ant-tabs-left > .ant-tabs-bar .ant-tabs-nav-wrap {\n  margin-right: 0;\n}\n.ant-tabs-vertical.ant-tabs-card.ant-tabs-left > .ant-tabs-bar .ant-tabs-tab {\n  border-right: 0;\n  border-radius: 4px 0 0 4px;\n  margin-right: 1px;\n}\n.ant-tabs-vertical.ant-tabs-card.ant-tabs-left > .ant-tabs-bar .ant-tabs-tab-active {\n  margin-right: -1px;\n  padding-right: 18px;\n}\n.ant-tabs-vertical.ant-tabs-card.ant-tabs-right > .ant-tabs-bar .ant-tabs-nav-wrap {\n  margin-left: 0;\n}\n.ant-tabs-vertical.ant-tabs-card.ant-tabs-right > .ant-tabs-bar .ant-tabs-tab {\n  border-left: 0;\n  border-radius: 0 4px 4px 0;\n  margin-left: 1px;\n}\n.ant-tabs-vertical.ant-tabs-card.ant-tabs-right > .ant-tabs-bar .ant-tabs-tab-active {\n  margin-left: -1px;\n  padding-left: 18px;\n}\n.ant-tabs.ant-tabs-card.ant-tabs-bottom > .ant-tabs-bar .ant-tabs-tab {\n  border-bottom: 1px solid #e8e8e8;\n  border-top: 0;\n  border-radius: 0 0 4px 4px;\n}\n.ant-tabs.ant-tabs-card.ant-tabs-bottom > .ant-tabs-bar .ant-tabs-tab-active {\n  color: #1890ff;\n  padding-bottom: 0;\n  padding-top: 1px;\n}\n.ant-tabs {\n  font-family: \"Monospaced Number\", \"Chinese Quote\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"PingFang SC\", \"Hiragino Sans GB\", \"Microsoft YaHei\", \"Helvetica Neue\", Helvetica, Arial, sans-serif;\n  font-size: 14px;\n  line-height: 1.5;\n  color: rgba(0, 0, 0, 0.65);\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  margin: 0;\n  padding: 0;\n  list-style: none;\n  position: relative;\n  overflow: hidden;\n  zoom: 1;\n}\n.ant-tabs:before,\n.ant-tabs:after {\n  content: \" \";\n  display: table;\n}\n.ant-tabs:after {\n  clear: both;\n  visibility: hidden;\n  font-size: 0;\n  height: 0;\n}\n.ant-tabs-ink-bar {\n  z-index: 1;\n  position: absolute;\n  left: 0;\n  bottom: 1px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  height: 2px;\n  background-color: #1890ff;\n  -webkit-transform-origin: 0 0;\n      -ms-transform-origin: 0 0;\n          transform-origin: 0 0;\n}\n.ant-tabs-bar {\n  border-bottom: 1px solid #e8e8e8;\n  margin: 0 0 16px 0;\n  outline: none;\n  -webkit-transition: padding 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n  transition: padding 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n}\n.ant-tabs-nav-container {\n  overflow: hidden;\n  font-size: 14px;\n  line-height: 1.5;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  position: relative;\n  white-space: nowrap;\n  margin-bottom: -1px;\n  -webkit-transition: padding 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n  transition: padding 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n  zoom: 1;\n}\n.ant-tabs-nav-container:before,\n.ant-tabs-nav-container:after {\n  content: \" \";\n  display: table;\n}\n.ant-tabs-nav-container:after {\n  clear: both;\n  visibility: hidden;\n  font-size: 0;\n  height: 0;\n}\n.ant-tabs-nav-container-scrolling {\n  padding-left: 32px;\n  padding-right: 32px;\n}\n.ant-tabs-bottom .ant-tabs-bar {\n  border-bottom: none;\n  border-top: 1px solid #e8e8e8;\n}\n.ant-tabs-bottom .ant-tabs-ink-bar {\n  bottom: auto;\n  top: 1px;\n}\n.ant-tabs-bottom .ant-tabs-nav-container {\n  margin-bottom: 0;\n  margin-top: -1px;\n}\n.ant-tabs-tab-prev,\n.ant-tabs-tab-next {\n  -webkit-user-select: none;\n     -moz-user-select: none;\n      -ms-user-select: none;\n          user-select: none;\n  z-index: 2;\n  width: 0;\n  height: 100%;\n  cursor: pointer;\n  border: 0;\n  background-color: transparent;\n  position: absolute;\n  text-align: center;\n  color: rgba(0, 0, 0, 0.45);\n  -webkit-transition: width 0.3s cubic-bezier(0.645, 0.045, 0.355, 1), opacity 0.3s cubic-bezier(0.645, 0.045, 0.355, 1), color 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n  transition: width 0.3s cubic-bezier(0.645, 0.045, 0.355, 1), opacity 0.3s cubic-bezier(0.645, 0.045, 0.355, 1), color 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n  opacity: 0;\n  pointer-events: none;\n}\n.ant-tabs-tab-prev.ant-tabs-tab-arrow-show,\n.ant-tabs-tab-next.ant-tabs-tab-arrow-show {\n  opacity: 1;\n  width: 32px;\n  height: 100%;\n  pointer-events: auto;\n}\n.ant-tabs-tab-prev:hover,\n.ant-tabs-tab-next:hover {\n  color: rgba(0, 0, 0, 0.65);\n}\n.ant-tabs-tab-prev-icon,\n.ant-tabs-tab-next-icon {\n  font-style: normal;\n  font-weight: bold;\n  font-variant: normal;\n  line-height: inherit;\n  vertical-align: baseline;\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  -webkit-transform: translate(-50%, -50%);\n      -ms-transform: translate(-50%, -50%);\n          transform: translate(-50%, -50%);\n  text-align: center;\n  text-transform: none;\n}\n.ant-tabs-tab-prev-icon:before,\n.ant-tabs-tab-next-icon:before {\n  display: block;\n  font-family: \"anticon\" !important;\n  display: inline-block;\n  font-size: 12px;\n  font-size: 10px \\9;\n  -webkit-transform: scale(0.83333333) rotate(0deg);\n      -ms-transform: scale(0.83333333) rotate(0deg);\n          transform: scale(0.83333333) rotate(0deg);\n}\n:root .ant-tabs-tab-prev-icon:before,\n:root .ant-tabs-tab-next-icon:before {\n  font-size: 12px;\n}\n.ant-tabs-tab-btn-disabled {\n  cursor: not-allowed;\n}\n.ant-tabs-tab-btn-disabled,\n.ant-tabs-tab-btn-disabled:hover {\n  color: rgba(0, 0, 0, 0.25);\n}\n.ant-tabs-tab-next {\n  right: 2px;\n}\n.ant-tabs-tab-next-icon:before {\n  content: \"\\E61F\";\n}\n.ant-tabs-tab-prev {\n  left: 0;\n}\n.ant-tabs-tab-prev-icon:before {\n  content: \"\\E620\";\n}\n:root .ant-tabs-tab-prev {\n  -webkit-filter: none;\n          filter: none;\n}\n.ant-tabs-nav-wrap {\n  overflow: hidden;\n  margin-bottom: -1px;\n}\n.ant-tabs-nav-scroll {\n  overflow: hidden;\n  white-space: nowrap;\n}\n.ant-tabs-nav {\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  padding-left: 0;\n  -webkit-transition: -webkit-transform 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n  transition: -webkit-transform 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n  transition: transform 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n  transition: transform 0.3s cubic-bezier(0.645, 0.045, 0.355, 1), -webkit-transform 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n  position: relative;\n  margin: 0;\n  list-style: none;\n  display: inline-block;\n}\n.ant-tabs-nav:before,\n.ant-tabs-nav:after {\n  display: table;\n  content: \" \";\n}\n.ant-tabs-nav:after {\n  clear: both;\n}\n.ant-tabs-nav .ant-tabs-tab-disabled {\n  pointer-events: none;\n  cursor: default;\n  color: rgba(0, 0, 0, 0.25);\n}\n.ant-tabs-nav .ant-tabs-tab {\n  display: inline-block;\n  height: 100%;\n  margin: 0 32px 0 0;\n  padding: 12px 16px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  position: relative;\n  -webkit-transition: color 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n  transition: color 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n  cursor: pointer;\n  text-decoration: none;\n}\n.ant-tabs-nav .ant-tabs-tab:last-child {\n  margin-right: 0;\n}\n.ant-tabs-nav .ant-tabs-tab:hover {\n  color: #40a9ff;\n}\n.ant-tabs-nav .ant-tabs-tab:active {\n  color: #096dd9;\n}\n.ant-tabs-nav .ant-tabs-tab .anticon {\n  margin-right: 8px;\n}\n.ant-tabs-nav .ant-tabs-tab-active {\n  color: #1890ff;\n  font-weight: 500;\n}\n.ant-tabs-large .ant-tabs-nav-container {\n  font-size: 16px;\n}\n.ant-tabs-large .ant-tabs-tab {\n  padding: 16px;\n}\n.ant-tabs-small .ant-tabs-nav-container {\n  font-size: 14px;\n}\n.ant-tabs-small .ant-tabs-tab {\n  padding: 8px 16px;\n}\n.ant-tabs:not(.ant-tabs-vertical) > .ant-tabs-content {\n  width: 100%;\n}\n.ant-tabs:not(.ant-tabs-vertical) > .ant-tabs-content > .ant-tabs-tabpane {\n  -webkit-flex-shrink: 0;\n      -ms-flex-negative: 0;\n          flex-shrink: 0;\n  width: 100%;\n  -webkit-transition: opacity .45s;\n  transition: opacity .45s;\n  opacity: 1;\n}\n.ant-tabs:not(.ant-tabs-vertical) > .ant-tabs-content > .ant-tabs-tabpane-inactive {\n  opacity: 0;\n  height: 0;\n  padding: 0 !important;\n  pointer-events: none;\n}\n.ant-tabs:not(.ant-tabs-vertical) > .ant-tabs-content-animated {\n  display: -webkit-box;\n  display: -webkit-flex;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n  -webkit-flex-direction: row;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  will-change: margin-left;\n  -webkit-transition: margin-left 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n  transition: margin-left 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n}\n.ant-tabs-vertical > .ant-tabs-bar {\n  border-bottom: 0;\n  height: 100%;\n}\n.ant-tabs-vertical > .ant-tabs-bar-tab-prev,\n.ant-tabs-vertical > .ant-tabs-bar-tab-next {\n  width: 32px;\n  height: 0;\n  -webkit-transition: height 0.3s cubic-bezier(0.645, 0.045, 0.355, 1), opacity 0.3s cubic-bezier(0.645, 0.045, 0.355, 1), color 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n  transition: height 0.3s cubic-bezier(0.645, 0.045, 0.355, 1), opacity 0.3s cubic-bezier(0.645, 0.045, 0.355, 1), color 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n}\n.ant-tabs-vertical > .ant-tabs-bar-tab-prev.ant-tabs-tab-arrow-show,\n.ant-tabs-vertical > .ant-tabs-bar-tab-next.ant-tabs-tab-arrow-show {\n  width: 100%;\n  height: 32px;\n}\n.ant-tabs-vertical > .ant-tabs-bar .ant-tabs-tab {\n  float: none;\n  margin: 0 0 16px 0;\n  padding: 8px 24px;\n  display: block;\n}\n.ant-tabs-vertical > .ant-tabs-bar .ant-tabs-tab:last-child {\n  margin-bottom: 0;\n}\n.ant-tabs-vertical > .ant-tabs-bar .ant-tabs-extra-content {\n  text-align: center;\n}\n.ant-tabs-vertical > .ant-tabs-bar .ant-tabs-nav-scroll {\n  width: auto;\n}\n.ant-tabs-vertical > .ant-tabs-bar .ant-tabs-nav-container,\n.ant-tabs-vertical > .ant-tabs-bar .ant-tabs-nav-wrap {\n  height: 100%;\n}\n.ant-tabs-vertical > .ant-tabs-bar .ant-tabs-nav-container {\n  margin-bottom: 0;\n}\n.ant-tabs-vertical > .ant-tabs-bar .ant-tabs-nav-container.ant-tabs-nav-container-scrolling {\n  padding: 32px 0;\n}\n.ant-tabs-vertical > .ant-tabs-bar .ant-tabs-nav-wrap {\n  margin-bottom: 0;\n}\n.ant-tabs-vertical > .ant-tabs-bar .ant-tabs-nav {\n  width: 100%;\n}\n.ant-tabs-vertical > .ant-tabs-bar .ant-tabs-ink-bar {\n  width: 2px;\n  left: auto;\n  height: auto;\n  top: 0;\n}\n.ant-tabs-vertical > .ant-tabs-bar .ant-tabs-tab-next {\n  width: 100%;\n  bottom: 0;\n  height: 32px;\n}\n.ant-tabs-vertical > .ant-tabs-bar .ant-tabs-tab-next-icon:before {\n  content: \"\\E61D\";\n}\n.ant-tabs-vertical > .ant-tabs-bar .ant-tabs-tab-prev {\n  top: 0;\n  width: 100%;\n  height: 32px;\n}\n.ant-tabs-vertical > .ant-tabs-bar .ant-tabs-tab-prev-icon:before {\n  content: \"\\E61E\";\n}\n.ant-tabs-vertical > .ant-tabs-content {\n  overflow: hidden;\n  width: auto;\n  margin-top: 0 !important;\n}\n.ant-tabs-vertical.ant-tabs-left > .ant-tabs-bar {\n  float: left;\n  border-right: 1px solid #e8e8e8;\n  margin-right: -1px;\n  margin-bottom: 0;\n}\n.ant-tabs-vertical.ant-tabs-left > .ant-tabs-bar .ant-tabs-tab {\n  text-align: right;\n}\n.ant-tabs-vertical.ant-tabs-left > .ant-tabs-bar .ant-tabs-nav-container {\n  margin-right: -1px;\n}\n.ant-tabs-vertical.ant-tabs-left > .ant-tabs-bar .ant-tabs-nav-wrap {\n  margin-right: -1px;\n}\n.ant-tabs-vertical.ant-tabs-left > .ant-tabs-bar .ant-tabs-ink-bar {\n  right: 1px;\n}\n.ant-tabs-vertical.ant-tabs-left > .ant-tabs-content {\n  padding-left: 24px;\n  border-left: 1px solid #e8e8e8;\n}\n.ant-tabs-vertical.ant-tabs-right > .ant-tabs-bar {\n  float: right;\n  border-left: 1px solid #e8e8e8;\n  margin-left: -1px;\n  margin-bottom: 0;\n}\n.ant-tabs-vertical.ant-tabs-right > .ant-tabs-bar .ant-tabs-nav-container {\n  margin-left: -1px;\n}\n.ant-tabs-vertical.ant-tabs-right > .ant-tabs-bar .ant-tabs-nav-wrap {\n  margin-left: -1px;\n}\n.ant-tabs-vertical.ant-tabs-right > .ant-tabs-bar .ant-tabs-ink-bar {\n  left: 1px;\n}\n.ant-tabs-vertical.ant-tabs-right > .ant-tabs-content {\n  padding-right: 24px;\n  border-right: 1px solid #e8e8e8;\n}\n.ant-tabs-bottom > .ant-tabs-bar {\n  margin-bottom: 0;\n  margin-top: 16px;\n}\n.ant-tabs-top .ant-tabs-ink-bar-animated,\n.ant-tabs-bottom .ant-tabs-ink-bar-animated {\n  -webkit-transition: width 0.3s cubic-bezier(0.645, 0.045, 0.355, 1), -webkit-transform 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n  transition: width 0.3s cubic-bezier(0.645, 0.045, 0.355, 1), -webkit-transform 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n  transition: transform 0.3s cubic-bezier(0.645, 0.045, 0.355, 1), width 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n  transition: transform 0.3s cubic-bezier(0.645, 0.045, 0.355, 1), width 0.3s cubic-bezier(0.645, 0.045, 0.355, 1), -webkit-transform 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n}\n.ant-tabs-left .ant-tabs-ink-bar-animated,\n.ant-tabs-right .ant-tabs-ink-bar-animated {\n  -webkit-transition: height 0.3s cubic-bezier(0.645, 0.045, 0.355, 1), -webkit-transform 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n  transition: height 0.3s cubic-bezier(0.645, 0.045, 0.355, 1), -webkit-transform 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n  transition: transform 0.3s cubic-bezier(0.645, 0.045, 0.355, 1), height 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n  transition: transform 0.3s cubic-bezier(0.645, 0.045, 0.355, 1), height 0.3s cubic-bezier(0.645, 0.045, 0.355, 1), -webkit-transform 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);\n}\n.no-flex > .ant-tabs-content-animated,\n.ant-tabs-no-animation > .ant-tabs-content-animated,\n.ant-tabs-vertical > .ant-tabs-content-animated {\n  -webkit-transform: none !important;\n      -ms-transform: none !important;\n          transform: none !important;\n  margin-left: 0 !important;\n}\n.no-flex > .ant-tabs-content > .ant-tabs-tabpane-inactive,\n.ant-tabs-no-animation > .ant-tabs-content > .ant-tabs-tabpane-inactive,\n.ant-tabs-vertical > .ant-tabs-content > .ant-tabs-tabpane-inactive {\n  display: none;\n}\n", ""]);

// exports


/***/ }),

/***/ "../node_modules/lodash/debounce.js":
/*!******************************************!*\
  !*** ../node_modules/lodash/debounce.js ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(/*! ./isObject */ "../node_modules/lodash/isObject.js"),
    now = __webpack_require__(/*! ./now */ "../node_modules/lodash/now.js"),
    toNumber = __webpack_require__(/*! ./toNumber */ "../node_modules/lodash/toNumber.js");

/** Error message constants. */
var FUNC_ERROR_TEXT = 'Expected a function';

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeMax = Math.max,
    nativeMin = Math.min;

/**
 * Creates a debounced function that delays invoking `func` until after `wait`
 * milliseconds have elapsed since the last time the debounced function was
 * invoked. The debounced function comes with a `cancel` method to cancel
 * delayed `func` invocations and a `flush` method to immediately invoke them.
 * Provide `options` to indicate whether `func` should be invoked on the
 * leading and/or trailing edge of the `wait` timeout. The `func` is invoked
 * with the last arguments provided to the debounced function. Subsequent
 * calls to the debounced function return the result of the last `func`
 * invocation.
 *
 * **Note:** If `leading` and `trailing` options are `true`, `func` is
 * invoked on the trailing edge of the timeout only if the debounced function
 * is invoked more than once during the `wait` timeout.
 *
 * If `wait` is `0` and `leading` is `false`, `func` invocation is deferred
 * until to the next tick, similar to `setTimeout` with a timeout of `0`.
 *
 * See [David Corbacho's article](https://css-tricks.com/debouncing-throttling-explained-examples/)
 * for details over the differences between `_.debounce` and `_.throttle`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Function
 * @param {Function} func The function to debounce.
 * @param {number} [wait=0] The number of milliseconds to delay.
 * @param {Object} [options={}] The options object.
 * @param {boolean} [options.leading=false]
 *  Specify invoking on the leading edge of the timeout.
 * @param {number} [options.maxWait]
 *  The maximum time `func` is allowed to be delayed before it's invoked.
 * @param {boolean} [options.trailing=true]
 *  Specify invoking on the trailing edge of the timeout.
 * @returns {Function} Returns the new debounced function.
 * @example
 *
 * // Avoid costly calculations while the window size is in flux.
 * jQuery(window).on('resize', _.debounce(calculateLayout, 150));
 *
 * // Invoke `sendMail` when clicked, debouncing subsequent calls.
 * jQuery(element).on('click', _.debounce(sendMail, 300, {
 *   'leading': true,
 *   'trailing': false
 * }));
 *
 * // Ensure `batchLog` is invoked once after 1 second of debounced calls.
 * var debounced = _.debounce(batchLog, 250, { 'maxWait': 1000 });
 * var source = new EventSource('/stream');
 * jQuery(source).on('message', debounced);
 *
 * // Cancel the trailing debounced invocation.
 * jQuery(window).on('popstate', debounced.cancel);
 */
function debounce(func, wait, options) {
  var lastArgs,
      lastThis,
      maxWait,
      result,
      timerId,
      lastCallTime,
      lastInvokeTime = 0,
      leading = false,
      maxing = false,
      trailing = true;

  if (typeof func != 'function') {
    throw new TypeError(FUNC_ERROR_TEXT);
  }
  wait = toNumber(wait) || 0;
  if (isObject(options)) {
    leading = !!options.leading;
    maxing = 'maxWait' in options;
    maxWait = maxing ? nativeMax(toNumber(options.maxWait) || 0, wait) : maxWait;
    trailing = 'trailing' in options ? !!options.trailing : trailing;
  }

  function invokeFunc(time) {
    var args = lastArgs,
        thisArg = lastThis;

    lastArgs = lastThis = undefined;
    lastInvokeTime = time;
    result = func.apply(thisArg, args);
    return result;
  }

  function leadingEdge(time) {
    // Reset any `maxWait` timer.
    lastInvokeTime = time;
    // Start the timer for the trailing edge.
    timerId = setTimeout(timerExpired, wait);
    // Invoke the leading edge.
    return leading ? invokeFunc(time) : result;
  }

  function remainingWait(time) {
    var timeSinceLastCall = time - lastCallTime,
        timeSinceLastInvoke = time - lastInvokeTime,
        timeWaiting = wait - timeSinceLastCall;

    return maxing
      ? nativeMin(timeWaiting, maxWait - timeSinceLastInvoke)
      : timeWaiting;
  }

  function shouldInvoke(time) {
    var timeSinceLastCall = time - lastCallTime,
        timeSinceLastInvoke = time - lastInvokeTime;

    // Either this is the first call, activity has stopped and we're at the
    // trailing edge, the system time has gone backwards and we're treating
    // it as the trailing edge, or we've hit the `maxWait` limit.
    return (lastCallTime === undefined || (timeSinceLastCall >= wait) ||
      (timeSinceLastCall < 0) || (maxing && timeSinceLastInvoke >= maxWait));
  }

  function timerExpired() {
    var time = now();
    if (shouldInvoke(time)) {
      return trailingEdge(time);
    }
    // Restart the timer.
    timerId = setTimeout(timerExpired, remainingWait(time));
  }

  function trailingEdge(time) {
    timerId = undefined;

    // Only invoke if we have `lastArgs` which means `func` has been
    // debounced at least once.
    if (trailing && lastArgs) {
      return invokeFunc(time);
    }
    lastArgs = lastThis = undefined;
    return result;
  }

  function cancel() {
    if (timerId !== undefined) {
      clearTimeout(timerId);
    }
    lastInvokeTime = 0;
    lastArgs = lastCallTime = lastThis = timerId = undefined;
  }

  function flush() {
    return timerId === undefined ? result : trailingEdge(now());
  }

  function debounced() {
    var time = now(),
        isInvoking = shouldInvoke(time);

    lastArgs = arguments;
    lastThis = this;
    lastCallTime = time;

    if (isInvoking) {
      if (timerId === undefined) {
        return leadingEdge(lastCallTime);
      }
      if (maxing) {
        // Handle invocations in a tight loop.
        timerId = setTimeout(timerExpired, wait);
        return invokeFunc(lastCallTime);
      }
    }
    if (timerId === undefined) {
      timerId = setTimeout(timerExpired, wait);
    }
    return result;
  }
  debounced.cancel = cancel;
  debounced.flush = flush;
  return debounced;
}

module.exports = debounce;


/***/ }),

/***/ "../node_modules/lodash/now.js":
/*!*************************************!*\
  !*** ../node_modules/lodash/now.js ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var root = __webpack_require__(/*! ./_root */ "../node_modules/lodash/_root.js");

/**
 * Gets the timestamp of the number of milliseconds that have elapsed since
 * the Unix epoch (1 January 1970 00:00:00 UTC).
 *
 * @static
 * @memberOf _
 * @since 2.4.0
 * @category Date
 * @returns {number} Returns the timestamp.
 * @example
 *
 * _.defer(function(stamp) {
 *   console.log(_.now() - stamp);
 * }, _.now());
 * // => Logs the number of milliseconds it took for the deferred invocation.
 */
var now = function() {
  return root.Date.now();
};

module.exports = now;


/***/ }),

/***/ "../node_modules/lodash/toNumber.js":
/*!******************************************!*\
  !*** ../node_modules/lodash/toNumber.js ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(/*! ./isObject */ "../node_modules/lodash/isObject.js"),
    isSymbol = __webpack_require__(/*! ./isSymbol */ "../node_modules/lodash/isSymbol.js");

/** Used as references for various `Number` constants. */
var NAN = 0 / 0;

/** Used to match leading and trailing whitespace. */
var reTrim = /^\s+|\s+$/g;

/** Used to detect bad signed hexadecimal string values. */
var reIsBadHex = /^[-+]0x[0-9a-f]+$/i;

/** Used to detect binary string values. */
var reIsBinary = /^0b[01]+$/i;

/** Used to detect octal string values. */
var reIsOctal = /^0o[0-7]+$/i;

/** Built-in method references without a dependency on `root`. */
var freeParseInt = parseInt;

/**
 * Converts `value` to a number.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to process.
 * @returns {number} Returns the number.
 * @example
 *
 * _.toNumber(3.2);
 * // => 3.2
 *
 * _.toNumber(Number.MIN_VALUE);
 * // => 5e-324
 *
 * _.toNumber(Infinity);
 * // => Infinity
 *
 * _.toNumber('3.2');
 * // => 3.2
 */
function toNumber(value) {
  if (typeof value == 'number') {
    return value;
  }
  if (isSymbol(value)) {
    return NAN;
  }
  if (isObject(value)) {
    var other = typeof value.valueOf == 'function' ? value.valueOf() : value;
    value = isObject(other) ? (other + '') : other;
  }
  if (typeof value != 'string') {
    return value === 0 ? value : +value;
  }
  value = value.replace(reTrim, '');
  var isBinary = reIsBinary.test(value);
  return (isBinary || reIsOctal.test(value))
    ? freeParseInt(value.slice(2), isBinary ? 2 : 8)
    : (reIsBadHex.test(value) ? NAN : +value);
}

module.exports = toNumber;


/***/ }),

/***/ "../node_modules/rc-calendar/es/locale/en_US.js":
/*!******************************************************!*\
  !*** ../node_modules/rc-calendar/es/locale/en_US.js ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  today: 'Today',
  now: 'Now',
  backToToday: 'Back to today',
  ok: 'Ok',
  clear: 'Clear',
  month: 'Month',
  year: 'Year',
  timeSelect: 'Select time',
  dateSelect: 'Select date',
  monthSelect: 'Choose a month',
  yearSelect: 'Choose a year',
  decadeSelect: 'Choose a decade',
  yearFormat: 'YYYY',
  dateFormat: 'M/D/YYYY',
  dayFormat: 'D',
  dateTimeFormat: 'M/D/YYYY HH:mm:ss',
  monthBeforeYear: true,
  previousMonth: 'Previous month (PageUp)',
  nextMonth: 'Next month (PageDown)',
  previousYear: 'Last year (Control + left)',
  nextYear: 'Next year (Control + right)',
  previousDecade: 'Last decade',
  nextDecade: 'Next decade',
  previousCentury: 'Last century',
  nextCentury: 'Next century'
});

/***/ }),

/***/ "../node_modules/rc-pagination/es/KeyCode.js":
/*!***************************************************!*\
  !*** ../node_modules/rc-pagination/es/KeyCode.js ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  ZERO: 48,
  NINE: 57,

  NUMPAD_ZERO: 96,
  NUMPAD_NINE: 105,

  BACKSPACE: 8,
  DELETE: 46,
  ENTER: 13,

  ARROW_UP: 38,
  ARROW_DOWN: 40
});

/***/ }),

/***/ "../node_modules/rc-pagination/es/Options.js":
/*!***************************************************!*\
  !*** ../node_modules/rc-pagination/es/Options.js ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! babel-runtime/helpers/classCallCheck */ "../node_modules/babel-runtime/helpers/classCallCheck.js");
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! babel-runtime/helpers/createClass */ "../node_modules/babel-runtime/helpers/createClass.js");
/* harmony import */ var babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! babel-runtime/helpers/possibleConstructorReturn */ "../node_modules/babel-runtime/helpers/possibleConstructorReturn.js");
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! babel-runtime/helpers/inherits */ "../node_modules/babel-runtime/helpers/inherits.js");
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _KeyCode__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./KeyCode */ "../node_modules/rc-pagination/es/KeyCode.js");








var Options = function (_React$Component) {
  babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3___default()(Options, _React$Component);

  function Options(props) {
    babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default()(this, Options);

    var _this = babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2___default()(this, (Options.__proto__ || Object.getPrototypeOf(Options)).call(this, props));

    _this.buildOptionText = function (value) {
      return value + ' ' + _this.props.locale.items_per_page;
    };

    _this.changeSize = function (value) {
      _this.props.changeSize(Number(value));
    };

    _this.handleChange = function (e) {
      _this.setState({
        goInputText: e.target.value
      });
    };

    _this.go = function (e) {
      var val = _this.state.goInputText;
      if (val === '') {
        return;
      }
      val = isNaN(val) ? _this.props.current : Number(val);
      if (e.keyCode === _KeyCode__WEBPACK_IMPORTED_MODULE_6__["default"].ENTER || e.type === 'click') {
        _this.setState({
          goInputText: ''
        });
        _this.props.quickGo(val);
      }
    };

    _this.state = {
      goInputText: ''
    };
    return _this;
  }

  babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default()(Options, [{
    key: 'render',
    value: function render() {
      var props = this.props;
      var state = this.state;
      var locale = props.locale;
      var prefixCls = props.rootPrefixCls + '-options';
      var changeSize = props.changeSize;
      var quickGo = props.quickGo;
      var goButton = props.goButton;
      var buildOptionText = props.buildOptionText || this.buildOptionText;
      var Select = props.selectComponentClass;
      var changeSelect = null;
      var goInput = null;
      var gotoButton = null;

      if (!(changeSize || quickGo)) {
        return null;
      }

      if (changeSize && Select) {
        var Option = Select.Option;
        var pageSize = props.pageSize || props.pageSizeOptions[0];
        var options = props.pageSizeOptions.map(function (opt, i) {
          return react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
            Option,
            { key: i, value: opt },
            buildOptionText(opt)
          );
        });

        changeSelect = react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
          Select,
          {
            prefixCls: props.selectPrefixCls,
            showSearch: false,
            className: prefixCls + '-size-changer',
            optionLabelProp: 'children',
            dropdownMatchSelectWidth: false,
            value: pageSize.toString(),
            onChange: this.changeSize,
            getPopupContainer: function getPopupContainer(triggerNode) {
              return triggerNode.parentNode;
            }
          },
          options
        );
      }

      if (quickGo) {
        if (goButton) {
          if (typeof goButton === 'boolean') {
            gotoButton = react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
              'button',
              {
                type: 'button',
                onClick: this.go,
                onKeyUp: this.go
              },
              locale.jump_to_confirm
            );
          } else {
            gotoButton = react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
              'span',
              {
                onClick: this.go,
                onKeyUp: this.go
              },
              goButton
            );
          }
        }
        goInput = react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
          'div',
          { className: prefixCls + '-quick-jumper' },
          locale.jump_to,
          react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement('input', {
            type: 'text',
            value: state.goInputText,
            onChange: this.handleChange,
            onKeyUp: this.go
          }),
          locale.page,
          gotoButton
        );
      }

      return react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
        'li',
        { className: '' + prefixCls },
        changeSelect,
        goInput
      );
    }
  }]);

  return Options;
}(react__WEBPACK_IMPORTED_MODULE_4___default.a.Component);

Options.propTypes = {
  changeSize: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.func,
  quickGo: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.func,
  selectComponentClass: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.func,
  current: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.number,
  pageSizeOptions: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.string),
  pageSize: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.number,
  buildOptionText: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.func,
  locale: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.object
};
Options.defaultProps = {
  pageSizeOptions: ['10', '20', '30', '40']
};


/* harmony default export */ __webpack_exports__["default"] = (Options);

/***/ }),

/***/ "../node_modules/rc-pagination/es/Pager.js":
/*!*************************************************!*\
  !*** ../node_modules/rc-pagination/es/Pager.js ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);



var Pager = function Pager(props) {
  var prefixCls = props.rootPrefixCls + '-item';
  var cls = prefixCls + ' ' + prefixCls + '-' + props.page;

  if (props.active) {
    cls = cls + ' ' + prefixCls + '-active';
  }

  if (props.className) {
    cls = cls + ' ' + props.className;
  }

  var handleClick = function handleClick() {
    props.onClick(props.page);
  };

  var handleKeyPress = function handleKeyPress(e) {
    props.onKeyPress(e, props.onClick, props.page);
  };

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
    'li',
    {
      title: props.showTitle ? props.page : null,
      className: cls,
      onClick: handleClick,
      onKeyPress: handleKeyPress,
      tabIndex: '0'
    },
    props.itemRender(props.page, 'page', react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
      'a',
      null,
      props.page
    ))
  );
};

Pager.propTypes = {
  page: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number,
  active: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool,
  last: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool,
  locale: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  className: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  showTitle: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool,
  rootPrefixCls: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  onClick: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func,
  onKeyPress: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func,
  itemRender: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func
};

/* harmony default export */ __webpack_exports__["default"] = (Pager);

/***/ }),

/***/ "../node_modules/rc-pagination/es/Pagination.js":
/*!******************************************************!*\
  !*** ../node_modules/rc-pagination/es/Pagination.js ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! babel-runtime/helpers/classCallCheck */ "../node_modules/babel-runtime/helpers/classCallCheck.js");
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! babel-runtime/helpers/createClass */ "../node_modules/babel-runtime/helpers/createClass.js");
/* harmony import */ var babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! babel-runtime/helpers/possibleConstructorReturn */ "../node_modules/babel-runtime/helpers/possibleConstructorReturn.js");
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! babel-runtime/helpers/inherits */ "../node_modules/babel-runtime/helpers/inherits.js");
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _Pager__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./Pager */ "../node_modules/rc-pagination/es/Pager.js");
/* harmony import */ var _Options__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./Options */ "../node_modules/rc-pagination/es/Options.js");
/* harmony import */ var _KeyCode__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./KeyCode */ "../node_modules/rc-pagination/es/KeyCode.js");
/* harmony import */ var _locale_zh_CN__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./locale/zh_CN */ "../node_modules/rc-pagination/es/locale/zh_CN.js");











function noop() {}

function isInteger(value) {
  return typeof value === 'number' && isFinite(value) && Math.floor(value) === value;
}

function defaultItemRender(page, type, element) {
  return element;
}

var Pagination = function (_React$Component) {
  babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3___default()(Pagination, _React$Component);

  function Pagination(props) {
    babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default()(this, Pagination);

    var _this = babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2___default()(this, (Pagination.__proto__ || Object.getPrototypeOf(Pagination)).call(this, props));

    _initialiseProps.call(_this);

    var hasOnChange = props.onChange !== noop;
    var hasCurrent = 'current' in props;
    if (hasCurrent && !hasOnChange) {
      console.warn('Warning: You provided a `current` prop to a Pagination component without an `onChange` handler. This will render a read-only component.'); // eslint-disable-line
    }

    var current = props.defaultCurrent;
    if ('current' in props) {
      current = props.current;
    }

    var pageSize = props.defaultPageSize;
    if ('pageSize' in props) {
      pageSize = props.pageSize;
    }

    _this.state = {
      current: current,
      currentInputValue: current,
      pageSize: pageSize
    };
    return _this;
  }

  babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default()(Pagination, [{
    key: 'componentWillReceiveProps',
    value: function componentWillReceiveProps(nextProps) {
      if ('current' in nextProps) {
        this.setState({
          current: nextProps.current,
          currentInputValue: nextProps.current
        });
      }

      if ('pageSize' in nextProps) {
        var newState = {};
        var current = this.state.current;
        var newCurrent = this.calculatePage(nextProps.pageSize);
        current = current > newCurrent ? newCurrent : current;
        if (!('current' in nextProps)) {
          newState.current = current;
          newState.currentInputValue = current;
        }
        newState.pageSize = nextProps.pageSize;
        this.setState(newState);
      }
    }
  }, {
    key: 'componentDidUpdate',
    value: function componentDidUpdate(prevProps, prevState) {
      // When current page change, fix focused style of prev item
      // A hacky solution of https://github.com/ant-design/ant-design/issues/8948
      var prefixCls = this.props.prefixCls;

      if (prevState.current !== this.state.current && this.paginationNode) {
        var lastCurrentNode = this.paginationNode.querySelector('.' + prefixCls + '-item-' + prevState.current);
        if (lastCurrentNode && document.activeElement === lastCurrentNode) {
          lastCurrentNode.blur();
        }
      }
    }
  }, {
    key: 'getJumpPrevPage',
    value: function getJumpPrevPage() {
      return Math.max(1, this.state.current - (this.props.showLessItems ? 3 : 5));
    }
  }, {
    key: 'getJumpNextPage',
    value: function getJumpNextPage() {
      return Math.min(this.calculatePage(), this.state.current + (this.props.showLessItems ? 3 : 5));
    }
  }, {
    key: 'getJumpPrevPage',
    value: function getJumpPrevPage() {
      return Math.max(1, this.state.current - (this.props.showLessItems ? 3 : 5));
    }
  }, {
    key: 'getJumpNextPage',
    value: function getJumpNextPage() {
      return Math.min(this.calculatePage(), this.state.current + (this.props.showLessItems ? 3 : 5));
    }
  }, {
    key: 'render',
    value: function render() {
      // When hideOnSinglePage is true and there is only 1 page, hide the pager
      if (this.props.hideOnSinglePage === true && this.props.total <= this.state.pageSize) {
        return null;
      }

      var props = this.props;
      var locale = props.locale;

      var prefixCls = props.prefixCls;
      var allPages = this.calculatePage();
      var pagerList = [];
      var jumpPrev = null;
      var jumpNext = null;
      var firstPager = null;
      var lastPager = null;
      var gotoButton = null;

      var goButton = props.showQuickJumper && props.showQuickJumper.goButton;
      var pageBufferSize = props.showLessItems ? 1 : 2;
      var _state = this.state,
          current = _state.current,
          pageSize = _state.pageSize;


      var prevPage = current - 1 > 0 ? current - 1 : 0;
      var nextPage = current + 1 < allPages ? current + 1 : allPages;

      if (props.simple) {
        if (goButton) {
          if (typeof goButton === 'boolean') {
            gotoButton = react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
              'button',
              {
                type: 'button',
                onClick: this.handleGoTO,
                onKeyUp: this.handleGoTO
              },
              locale.jump_to_confirm
            );
          } else {
            gotoButton = react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
              'span',
              {
                onClick: this.handleGoTO,
                onKeyUp: this.handleGoTO
              },
              goButton
            );
          }
          gotoButton = react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
            'li',
            {
              title: props.showTitle ? '' + locale.jump_to + this.state.current + '/' + allPages : null,
              className: prefixCls + '-simple-pager'
            },
            gotoButton
          );
        }

        return react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
          'ul',
          { className: prefixCls + ' ' + prefixCls + '-simple ' + props.className, style: props.style },
          react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
            'li',
            {
              title: props.showTitle ? locale.prev_page : null,
              onClick: this.prev,
              tabIndex: this.hasPrev() ? 0 : null,
              onKeyPress: this.runIfEnterPrev,
              className: (this.hasPrev() ? '' : prefixCls + '-disabled') + ' ' + prefixCls + '-prev',
              'aria-disabled': !this.hasPrev()
            },
            props.itemRender(prevPage, 'prev', react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement('a', { className: prefixCls + '-item-link' }))
          ),
          react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
            'li',
            {
              title: props.showTitle ? this.state.current + '/' + allPages : null,
              className: prefixCls + '-simple-pager'
            },
            react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement('input', {
              type: 'text',
              value: this.state.currentInputValue,
              onKeyDown: this.handleKeyDown,
              onKeyUp: this.handleKeyUp,
              onChange: this.handleKeyUp,
              size: '3'
            }),
            react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
              'span',
              { className: prefixCls + '-slash' },
              '\uFF0F'
            ),
            allPages
          ),
          react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
            'li',
            {
              title: props.showTitle ? locale.next_page : null,
              onClick: this.next,
              tabIndex: this.hasPrev() ? 0 : null,
              onKeyPress: this.runIfEnterNext,
              className: (this.hasNext() ? '' : prefixCls + '-disabled') + ' ' + prefixCls + '-next',
              'aria-disabled': !this.hasNext()
            },
            props.itemRender(nextPage, 'next', react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement('a', { className: prefixCls + '-item-link' }))
          ),
          gotoButton
        );
      }

      if (allPages <= 5 + pageBufferSize * 2) {
        for (var i = 1; i <= allPages; i++) {
          var active = this.state.current === i;
          pagerList.push(react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_Pager__WEBPACK_IMPORTED_MODULE_6__["default"], {
            locale: locale,
            rootPrefixCls: prefixCls,
            onClick: this.handleChange,
            onKeyPress: this.runIfEnter,
            key: i,
            page: i,
            active: active,
            showTitle: props.showTitle,
            itemRender: props.itemRender
          }));
        }
      } else {
        var prevItemTitle = props.showLessItems ? locale.prev_3 : locale.prev_5;
        var nextItemTitle = props.showLessItems ? locale.next_3 : locale.next_5;
        if (props.showPrevNextJumpers) {
          jumpPrev = react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
            'li',
            {
              title: props.showTitle ? prevItemTitle : null,
              key: 'prev',
              onClick: this.jumpPrev,
              tabIndex: '0',
              onKeyPress: this.runIfEnterJumpPrev,
              className: prefixCls + '-jump-prev'
            },
            props.itemRender(this.getJumpPrevPage(), 'jump-prev', react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement('a', { className: prefixCls + '-item-link' }))
          );
          jumpNext = react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
            'li',
            {
              title: props.showTitle ? nextItemTitle : null,
              key: 'next',
              tabIndex: '0',
              onClick: this.jumpNext,
              onKeyPress: this.runIfEnterJumpNext,
              className: prefixCls + '-jump-next'
            },
            props.itemRender(this.getJumpNextPage(), 'jump-next', react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement('a', { className: prefixCls + '-item-link' }))
          );
        }
        lastPager = react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_Pager__WEBPACK_IMPORTED_MODULE_6__["default"], {
          locale: props.locale,
          last: true,
          rootPrefixCls: prefixCls,
          onClick: this.handleChange,
          onKeyPress: this.runIfEnter,
          key: allPages,
          page: allPages,
          active: false,
          showTitle: props.showTitle,
          itemRender: props.itemRender
        });
        firstPager = react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_Pager__WEBPACK_IMPORTED_MODULE_6__["default"], {
          locale: props.locale,
          rootPrefixCls: prefixCls,
          onClick: this.handleChange,
          onKeyPress: this.runIfEnter,
          key: 1,
          page: 1,
          active: false,
          showTitle: props.showTitle,
          itemRender: props.itemRender
        });

        var left = Math.max(1, current - pageBufferSize);
        var right = Math.min(current + pageBufferSize, allPages);

        if (current - 1 <= pageBufferSize) {
          right = 1 + pageBufferSize * 2;
        }

        if (allPages - current <= pageBufferSize) {
          left = allPages - pageBufferSize * 2;
        }

        for (var _i = left; _i <= right; _i++) {
          var _active = current === _i;
          pagerList.push(react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_Pager__WEBPACK_IMPORTED_MODULE_6__["default"], {
            locale: props.locale,
            rootPrefixCls: prefixCls,
            onClick: this.handleChange,
            onKeyPress: this.runIfEnter,
            key: _i,
            page: _i,
            active: _active,
            showTitle: props.showTitle,
            itemRender: props.itemRender
          }));
        }

        if (current - 1 >= pageBufferSize * 2 && current !== 1 + 2) {
          pagerList[0] = react__WEBPACK_IMPORTED_MODULE_4___default.a.cloneElement(pagerList[0], {
            className: prefixCls + '-item-after-jump-prev'
          });
          pagerList.unshift(jumpPrev);
        }
        if (allPages - current >= pageBufferSize * 2 && current !== allPages - 2) {
          pagerList[pagerList.length - 1] = react__WEBPACK_IMPORTED_MODULE_4___default.a.cloneElement(pagerList[pagerList.length - 1], {
            className: prefixCls + '-item-before-jump-next'
          });
          pagerList.push(jumpNext);
        }

        if (left !== 1) {
          pagerList.unshift(firstPager);
        }
        if (right !== allPages) {
          pagerList.push(lastPager);
        }
      }

      var totalText = null;

      if (props.showTotal) {
        totalText = react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
          'li',
          { className: prefixCls + '-total-text' },
          props.showTotal(props.total, [(current - 1) * pageSize + 1, current * pageSize > props.total ? props.total : current * pageSize])
        );
      }
      var prevDisabled = !this.hasPrev();
      var nextDisabled = !this.hasNext();
      return react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
        'ul',
        {
          className: prefixCls + ' ' + props.className,
          style: props.style,
          unselectable: 'unselectable',
          ref: this.savePaginationNode
        },
        totalText,
        react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
          'li',
          {
            title: props.showTitle ? locale.prev_page : null,
            onClick: this.prev,
            tabIndex: prevDisabled ? null : 0,
            onKeyPress: this.runIfEnterPrev,
            className: (!prevDisabled ? '' : prefixCls + '-disabled') + ' ' + prefixCls + '-prev',
            'aria-disabled': prevDisabled
          },
          props.itemRender(prevPage, 'prev', react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement('a', { className: prefixCls + '-item-link' }))
        ),
        pagerList,
        react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
          'li',
          {
            title: props.showTitle ? locale.next_page : null,
            onClick: this.next,
            tabIndex: nextDisabled ? null : 0,
            onKeyPress: this.runIfEnterNext,
            className: (!nextDisabled ? '' : prefixCls + '-disabled') + ' ' + prefixCls + '-next',
            'aria-disabled': nextDisabled
          },
          props.itemRender(nextPage, 'next', react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement('a', { className: prefixCls + '-item-link' }))
        ),
        react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_Options__WEBPACK_IMPORTED_MODULE_7__["default"], {
          locale: props.locale,
          rootPrefixCls: prefixCls,
          selectComponentClass: props.selectComponentClass,
          selectPrefixCls: props.selectPrefixCls,
          changeSize: this.props.showSizeChanger ? this.changePageSize : null,
          current: this.state.current,
          pageSize: this.state.pageSize,
          pageSizeOptions: this.props.pageSizeOptions,
          quickGo: this.props.showQuickJumper ? this.handleChange : null,
          goButton: goButton
        })
      );
    }
  }]);

  return Pagination;
}(react__WEBPACK_IMPORTED_MODULE_4___default.a.Component);

Pagination.propTypes = {
  prefixCls: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.string,
  current: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.number,
  defaultCurrent: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.number,
  total: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.number,
  pageSize: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.number,
  defaultPageSize: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.number,
  onChange: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.func,
  hideOnSinglePage: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.bool,
  showSizeChanger: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.bool,
  showLessItems: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.bool,
  onShowSizeChange: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.func,
  selectComponentClass: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.func,
  showPrevNextJumpers: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.bool,
  showQuickJumper: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.bool, prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.object]),
  showTitle: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.bool,
  pageSizeOptions: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.string),
  showTotal: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.func,
  locale: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.object,
  style: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.object,
  itemRender: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.func
};
Pagination.defaultProps = {
  defaultCurrent: 1,
  total: 0,
  defaultPageSize: 10,
  onChange: noop,
  className: '',
  selectPrefixCls: 'rc-select',
  prefixCls: 'rc-pagination',
  selectComponentClass: null,
  hideOnSinglePage: false,
  showPrevNextJumpers: true,
  showQuickJumper: false,
  showSizeChanger: false,
  showLessItems: false,
  showTitle: true,
  onShowSizeChange: noop,
  locale: _locale_zh_CN__WEBPACK_IMPORTED_MODULE_9__["default"],
  style: {},
  itemRender: defaultItemRender
};

var _initialiseProps = function _initialiseProps() {
  var _this2 = this;

  this.savePaginationNode = function (node) {
    _this2.paginationNode = node;
  };

  this.calculatePage = function (p) {
    var pageSize = p;
    if (typeof pageSize === 'undefined') {
      pageSize = _this2.state.pageSize;
    }
    return Math.floor((_this2.props.total - 1) / pageSize) + 1;
  };

  this.isValid = function (page) {
    return isInteger(page) && page >= 1 && page !== _this2.state.current;
  };

  this.handleKeyDown = function (e) {
    if (e.keyCode === _KeyCode__WEBPACK_IMPORTED_MODULE_8__["default"].ARROW_UP || e.keyCode === _KeyCode__WEBPACK_IMPORTED_MODULE_8__["default"].ARROW_DOWN) {
      e.preventDefault();
    }
  };

  this.handleKeyUp = function (e) {
    var inputValue = e.target.value;
    var currentInputValue = _this2.state.currentInputValue;
    var value = void 0;

    if (inputValue === '') {
      value = inputValue;
    } else if (isNaN(Number(inputValue))) {
      value = currentInputValue;
    } else {
      value = Number(inputValue);
    }

    if (value !== currentInputValue) {
      _this2.setState({
        currentInputValue: value
      });
    }

    if (e.keyCode === _KeyCode__WEBPACK_IMPORTED_MODULE_8__["default"].ENTER) {
      _this2.handleChange(value);
    } else if (e.keyCode === _KeyCode__WEBPACK_IMPORTED_MODULE_8__["default"].ARROW_UP) {
      _this2.handleChange(value - 1);
    } else if (e.keyCode === _KeyCode__WEBPACK_IMPORTED_MODULE_8__["default"].ARROW_DOWN) {
      _this2.handleChange(value + 1);
    }
  };

  this.changePageSize = function (size) {
    var current = _this2.state.current;
    var newCurrent = _this2.calculatePage(size);
    current = current > newCurrent ? newCurrent : current;
    if (typeof size === 'number') {
      if (!('pageSize' in _this2.props)) {
        _this2.setState({
          pageSize: size
        });
      }
      if (!('current' in _this2.props)) {
        _this2.setState({
          current: current,
          currentInputValue: current
        });
      }
    }
    _this2.props.onShowSizeChange(current, size);
  };

  this.handleChange = function (p) {
    var page = p;
    if (_this2.isValid(page)) {
      if (page > _this2.calculatePage()) {
        page = _this2.calculatePage();
      }

      if (!('current' in _this2.props)) {
        _this2.setState({
          current: page,
          currentInputValue: page
        });
      }

      var pageSize = _this2.state.pageSize;
      _this2.props.onChange(page, pageSize);

      return page;
    }

    return _this2.state.current;
  };

  this.prev = function () {
    if (_this2.hasPrev()) {
      _this2.handleChange(_this2.state.current - 1);
    }
  };

  this.next = function () {
    if (_this2.hasNext()) {
      _this2.handleChange(_this2.state.current + 1);
    }
  };

  this.jumpPrev = function () {
    _this2.handleChange(_this2.getJumpPrevPage());
  };

  this.jumpNext = function () {
    _this2.handleChange(_this2.getJumpNextPage());
  };

  this.hasPrev = function () {
    return _this2.state.current > 1;
  };

  this.hasNext = function () {
    return _this2.state.current < _this2.calculatePage();
  };

  this.runIfEnter = function (event, callback) {
    for (var _len = arguments.length, restParams = Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) {
      restParams[_key - 2] = arguments[_key];
    }

    if (event.key === 'Enter' || event.charCode === 13) {
      callback.apply(undefined, restParams);
    }
  };

  this.runIfEnterPrev = function (e) {
    _this2.runIfEnter(e, _this2.prev);
  };

  this.runIfEnterNext = function (e) {
    _this2.runIfEnter(e, _this2.next);
  };

  this.runIfEnterJumpPrev = function (e) {
    _this2.runIfEnter(e, _this2.jumpPrev);
  };

  this.runIfEnterJumpNext = function (e) {
    _this2.runIfEnter(e, _this2.jumpNext);
  };

  this.handleGoTO = function (e) {
    if (e.keyCode === _KeyCode__WEBPACK_IMPORTED_MODULE_8__["default"].ENTER || e.type === 'click') {
      _this2.handleChange(_this2.state.currentInputValue);
    }
  };
};

/* harmony default export */ __webpack_exports__["default"] = (Pagination);

/***/ }),

/***/ "../node_modules/rc-pagination/es/index.js":
/*!*************************************************!*\
  !*** ../node_modules/rc-pagination/es/index.js ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Pagination__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Pagination */ "../node_modules/rc-pagination/es/Pagination.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _Pagination__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "../node_modules/rc-pagination/es/locale/en_US.js":
/*!********************************************************!*\
  !*** ../node_modules/rc-pagination/es/locale/en_US.js ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  // Options.jsx
  items_per_page: '/ page',
  jump_to: 'Goto',
  jump_to_confirm: 'confirm',
  page: '',

  // Pagination.jsx
  prev_page: 'Previous Page',
  next_page: 'Next Page',
  prev_5: 'Previous 5 Pages',
  next_5: 'Next 5 Pages',
  prev_3: 'Previous 3 Pages',
  next_3: 'Next 3 Pages'
});

/***/ }),

/***/ "../node_modules/rc-pagination/es/locale/zh_CN.js":
/*!********************************************************!*\
  !*** ../node_modules/rc-pagination/es/locale/zh_CN.js ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  // Options.jsx
  items_per_page: '条/页',
  jump_to: '跳至',
  jump_to_confirm: '确定',
  page: '页',

  // Pagination.jsx
  prev_page: '上一页',
  next_page: '下一页',
  prev_5: '向前 5 页',
  next_5: '向后 5 页',
  prev_3: '向前 3 页',
  next_3: '向后 3 页'
});

/***/ }),

/***/ "../node_modules/rc-select/es/DropdownMenu.js":
/*!****************************************************!*\
  !*** ../node_modules/rc-select/es/DropdownMenu.js ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! babel-runtime/helpers/extends */ "../node_modules/babel-runtime/helpers/extends.js");
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! babel-runtime/helpers/classCallCheck */ "../node_modules/babel-runtime/helpers/classCallCheck.js");
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! babel-runtime/helpers/possibleConstructorReturn */ "../node_modules/babel-runtime/helpers/possibleConstructorReturn.js");
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! babel-runtime/helpers/inherits */ "../node_modules/babel-runtime/helpers/inherits.js");
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-dom */ "../node_modules/react-dom/index.js");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var rc_util_es_Children_toArray__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rc-util/es/Children/toArray */ "../node_modules/rc-util/es/Children/toArray.js");
/* harmony import */ var rc_menu__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rc-menu */ "../node_modules/rc-menu/es/index.js");
/* harmony import */ var dom_scroll_into_view__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! dom-scroll-into-view */ "../node_modules/dom-scroll-into-view/lib/index.js");
/* harmony import */ var dom_scroll_into_view__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(dom_scroll_into_view__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./util */ "../node_modules/rc-select/es/util.js");












var DropdownMenu = function (_React$Component) {
  babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3___default()(DropdownMenu, _React$Component);

  function DropdownMenu() {
    var _temp, _this, _ret;

    babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1___default()(this, DropdownMenu);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2___default()(this, _React$Component.call.apply(_React$Component, [this].concat(args))), _this), _this.scrollActiveItemToView = function () {
      // scroll into view
      var itemComponent = Object(react_dom__WEBPACK_IMPORTED_MODULE_5__["findDOMNode"])(_this.firstActiveItem);
      var props = _this.props;

      if (itemComponent) {
        var scrollIntoViewOpts = {
          onlyScrollIfNeeded: true
        };
        if ((!props.value || props.value.length === 0) && props.firstActiveValue) {
          scrollIntoViewOpts.alignWithTop = true;
        }

        dom_scroll_into_view__WEBPACK_IMPORTED_MODULE_9___default()(itemComponent, Object(react_dom__WEBPACK_IMPORTED_MODULE_5__["findDOMNode"])(_this.menuRef), scrollIntoViewOpts);
      }
    }, _temp), babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2___default()(_this, _ret);
  }

  DropdownMenu.prototype.componentWillMount = function componentWillMount() {
    this.lastInputValue = this.props.inputValue;
  };

  DropdownMenu.prototype.componentDidMount = function componentDidMount() {
    this.scrollActiveItemToView();
    this.lastVisible = this.props.visible;
  };

  DropdownMenu.prototype.shouldComponentUpdate = function shouldComponentUpdate(nextProps) {
    if (!nextProps.visible) {
      this.lastVisible = false;
    }
    // freeze when hide
    return nextProps.visible;
  };

  DropdownMenu.prototype.componentDidUpdate = function componentDidUpdate(prevProps) {
    var props = this.props;
    if (!prevProps.visible && props.visible) {
      this.scrollActiveItemToView();
    }
    this.lastVisible = props.visible;
    this.lastInputValue = props.inputValue;
  };

  DropdownMenu.prototype.renderMenu = function renderMenu() {
    var _this2 = this;

    var props = this.props;
    var menuItems = props.menuItems,
        defaultActiveFirstOption = props.defaultActiveFirstOption,
        value = props.value,
        prefixCls = props.prefixCls,
        multiple = props.multiple,
        onMenuSelect = props.onMenuSelect,
        inputValue = props.inputValue,
        firstActiveValue = props.firstActiveValue,
        backfillValue = props.backfillValue;

    if (menuItems && menuItems.length) {
      var menuProps = {};
      if (multiple) {
        menuProps.onDeselect = props.onMenuDeselect;
        menuProps.onSelect = onMenuSelect;
      } else {
        menuProps.onClick = onMenuSelect;
      }

      var selectedKeys = Object(_util__WEBPACK_IMPORTED_MODULE_10__["getSelectKeys"])(menuItems, value);
      var activeKeyProps = {};

      var clonedMenuItems = menuItems;
      if (selectedKeys.length || firstActiveValue) {
        if (props.visible && !this.lastVisible) {
          activeKeyProps.activeKey = selectedKeys[0] || firstActiveValue;
        }
        var foundFirst = false;
        // set firstActiveItem via cloning menus
        // for scroll into view
        var clone = function clone(item) {
          if (!foundFirst && selectedKeys.indexOf(item.key) !== -1 || !foundFirst && !selectedKeys.length && firstActiveValue.indexOf(item.key) !== -1) {
            foundFirst = true;
            return Object(react__WEBPACK_IMPORTED_MODULE_4__["cloneElement"])(item, {
              ref: function ref(_ref) {
                _this2.firstActiveItem = _ref;
              }
            });
          }
          return item;
        };

        clonedMenuItems = menuItems.map(function (item) {
          if (item.type.isMenuItemGroup) {
            var children = Object(rc_util_es_Children_toArray__WEBPACK_IMPORTED_MODULE_7__["default"])(item.props.children).map(clone);
            return Object(react__WEBPACK_IMPORTED_MODULE_4__["cloneElement"])(item, {}, children);
          }
          return clone(item);
        });
      }

      // clear activeKey when inputValue change
      var lastValue = value && value[value.length - 1];
      if (inputValue !== this.lastInputValue && (!lastValue || lastValue !== backfillValue)) {
        activeKeyProps.activeKey = '';
      }

      return react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
        rc_menu__WEBPACK_IMPORTED_MODULE_8__["default"],
        babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({
          ref: Object(_util__WEBPACK_IMPORTED_MODULE_10__["saveRef"])(this, 'menuRef'),
          style: this.props.dropdownMenuStyle,
          defaultActiveFirst: defaultActiveFirstOption
        }, activeKeyProps, {
          multiple: multiple
        }, menuProps, {
          selectedKeys: selectedKeys,
          prefixCls: prefixCls + '-menu'
        }),
        clonedMenuItems
      );
    }
    return null;
  };

  DropdownMenu.prototype.render = function render() {
    var renderMenu = this.renderMenu();
    return renderMenu ? react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
      'div',
      {
        style: { overflow: 'auto' },
        onFocus: this.props.onPopupFocus,
        onMouseDown: _util__WEBPACK_IMPORTED_MODULE_10__["preventDefaultEvent"],
        onScroll: this.props.onPopupScroll
      },
      renderMenu
    ) : null;
  };

  return DropdownMenu;
}(react__WEBPACK_IMPORTED_MODULE_4___default.a.Component);

DropdownMenu.propTypes = {
  defaultActiveFirstOption: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.bool,
  value: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.any,
  dropdownMenuStyle: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.object,
  multiple: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.bool,
  onPopupFocus: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.func,
  onPopupScroll: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.func,
  onMenuDeSelect: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.func,
  onMenuSelect: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.func,
  prefixCls: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.string,
  menuItems: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.any,
  inputValue: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.string,
  visible: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.bool
};
/* harmony default export */ __webpack_exports__["default"] = (DropdownMenu);


DropdownMenu.displayName = 'DropdownMenu';

/***/ }),

/***/ "../node_modules/rc-select/es/OptGroup.js":
/*!************************************************!*\
  !*** ../node_modules/rc-select/es/OptGroup.js ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! babel-runtime/helpers/classCallCheck */ "../node_modules/babel-runtime/helpers/classCallCheck.js");
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! babel-runtime/helpers/possibleConstructorReturn */ "../node_modules/babel-runtime/helpers/possibleConstructorReturn.js");
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! babel-runtime/helpers/inherits */ "../node_modules/babel-runtime/helpers/inherits.js");
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);





var OptGroup = function (_React$Component) {
  babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2___default()(OptGroup, _React$Component);

  function OptGroup() {
    babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default()(this, OptGroup);

    return babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_1___default()(this, _React$Component.apply(this, arguments));
  }

  return OptGroup;
}(react__WEBPACK_IMPORTED_MODULE_3___default.a.Component);

OptGroup.isSelectOptGroup = true;
/* harmony default export */ __webpack_exports__["default"] = (OptGroup);

/***/ }),

/***/ "../node_modules/rc-select/es/Option.js":
/*!**********************************************!*\
  !*** ../node_modules/rc-select/es/Option.js ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! babel-runtime/helpers/classCallCheck */ "../node_modules/babel-runtime/helpers/classCallCheck.js");
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! babel-runtime/helpers/possibleConstructorReturn */ "../node_modules/babel-runtime/helpers/possibleConstructorReturn.js");
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! babel-runtime/helpers/inherits */ "../node_modules/babel-runtime/helpers/inherits.js");
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_4__);






var Option = function (_React$Component) {
  babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2___default()(Option, _React$Component);

  function Option() {
    babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default()(this, Option);

    return babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_1___default()(this, _React$Component.apply(this, arguments));
  }

  return Option;
}(react__WEBPACK_IMPORTED_MODULE_3___default.a.Component);

Option.propTypes = {
  value: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.number])
};
Option.isSelectOption = true;
/* harmony default export */ __webpack_exports__["default"] = (Option);

/***/ }),

/***/ "../node_modules/rc-select/es/PropTypes.js":
/*!*************************************************!*\
  !*** ../node_modules/rc-select/es/PropTypes.js ***!
  \*************************************************/
/*! exports provided: SelectPropTypes */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SelectPropTypes", function() { return SelectPropTypes; });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);


function valueType(props, propName, componentName) {
  var basicType = prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string, prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number]);

  var labelInValueShape = prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.shape({
    key: basicType.isRequired,
    label: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.node
  });
  if (props.labelInValue) {
    var validate = prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.arrayOf(labelInValueShape), labelInValueShape]);
    var error = validate.apply(undefined, arguments);
    if (error) {
      return new Error('Invalid prop `' + propName + '` supplied to `' + componentName + '`, ' + ('when you set `labelInValue` to `true`, `' + propName + '` should in ') + 'shape of `{ key: string | number, label?: ReactNode }`.');
    }
  } else if ((props.mode === 'multiple' || props.mode === 'tags' || props.multiple || props.tags) && props[propName] === '') {
    return new Error('Invalid prop `' + propName + '` of type `string` supplied to `' + componentName + '`, ' + 'expected `array` when `multiple` or `tags` is `true`.');
  } else {
    var _validate = prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.arrayOf(basicType), basicType]);
    return _validate.apply(undefined, arguments);
  }
}

var SelectPropTypes = {
  defaultActiveFirstOption: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  multiple: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  filterOption: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.any,
  children: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.any,
  showSearch: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  disabled: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  allowClear: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  showArrow: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  tags: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  prefixCls: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  className: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  transitionName: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  optionLabelProp: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  optionFilterProp: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  animation: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  choiceTransitionName: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string,
  onChange: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  onBlur: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  onFocus: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  onSelect: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  onSearch: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  onPopupScroll: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  onMouseEnter: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  onMouseLeave: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  onInputKeyDown: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  placeholder: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.any,
  onDeselect: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  labelInValue: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.bool,
  value: valueType,
  defaultValue: valueType,
  dropdownStyle: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.object,
  maxTagTextLength: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  maxTagCount: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.number,
  maxTagPlaceholder: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.node, prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func]),
  tokenSeparators: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string),
  getInputElement: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.func,
  showAction: prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_0___default.a.string)
};

/***/ }),

/***/ "../node_modules/rc-select/es/Select.js":
/*!**********************************************!*\
  !*** ../node_modules/rc-select/es/Select.js ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! babel-runtime/helpers/extends */ "../node_modules/babel-runtime/helpers/extends.js");
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! babel-runtime/helpers/classCallCheck */ "../node_modules/babel-runtime/helpers/classCallCheck.js");
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! babel-runtime/helpers/possibleConstructorReturn */ "../node_modules/babel-runtime/helpers/possibleConstructorReturn.js");
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! babel-runtime/helpers/inherits */ "../node_modules/babel-runtime/helpers/inherits.js");
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-dom */ "../node_modules/react-dom/index.js");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var rc_util_es_KeyCode__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rc-util/es/KeyCode */ "../node_modules/rc-util/es/KeyCode.js");
/* harmony import */ var rc_util_es_Children_toArray__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rc-util/es/Children/toArray */ "../node_modules/rc-util/es/Children/toArray.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! classnames */ "../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var rc_animate__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rc-animate */ "../node_modules/rc-animate/es/Animate.js");
/* harmony import */ var component_classes__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! component-classes */ "../node_modules/component-classes/index.js");
/* harmony import */ var component_classes__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(component_classes__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var rc_menu__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rc-menu */ "../node_modules/rc-menu/es/index.js");
/* harmony import */ var warning__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! warning */ "../node_modules/warning/browser.js");
/* harmony import */ var warning__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(warning__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _Option__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./Option */ "../node_modules/rc-select/es/Option.js");
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./util */ "../node_modules/rc-select/es/util.js");
/* harmony import */ var _SelectTrigger__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./SelectTrigger */ "../node_modules/rc-select/es/SelectTrigger.js");
/* harmony import */ var _PropTypes__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./PropTypes */ "../node_modules/rc-select/es/PropTypes.js");




/* eslint func-names: 1 */















function noop() {}

function chaining() {
  for (var _len = arguments.length, fns = Array(_len), _key = 0; _key < _len; _key++) {
    fns[_key] = arguments[_key];
  }

  return function () {
    for (var _len2 = arguments.length, args = Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
      args[_key2] = arguments[_key2];
    }

    // eslint-disable-line
    // eslint-disable-line
    for (var i = 0; i < fns.length; i++) {
      if (fns[i] && typeof fns[i] === 'function') {
        fns[i].apply(this, args);
      }
    }
  };
}

var Select = function (_React$Component) {
  babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3___default()(Select, _React$Component);

  function Select(props) {
    babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1___default()(this, Select);

    var _this = babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2___default()(this, _React$Component.call(this, props));

    _initialiseProps.call(_this);

    var value = _this.getValueFromProps(props);
    var optionsInfo = _this.getOptionsInfoFromProps(props);
    var inputValue = '';
    if (props.combobox) {
      inputValue = value.length ? _this.getLabelBySingleValue(value[0], optionsInfo) : '';
    }
    var open = props.open;
    if (open === undefined) {
      open = props.defaultOpen;
    }
    _this.state = {
      value: value,
      inputValue: inputValue,
      open: open,
      optionsInfo: optionsInfo
    };
    _this.adjustOpenState();
    return _this;
  }

  Select.prototype.componentDidMount = function componentDidMount() {
    if (this.props.autoFocus) {
      this.focus();
    }
  };

  Select.prototype.componentWillUpdate = function componentWillUpdate(nextProps, nextState) {
    this.props = nextProps;
    this.state = nextState;
    this.adjustOpenState();
  };

  Select.prototype.componentDidUpdate = function componentDidUpdate() {
    if (Object(_util__WEBPACK_IMPORTED_MODULE_14__["isMultipleOrTags"])(this.props)) {
      var inputNode = this.getInputDOMNode();
      var mirrorNode = this.getInputMirrorDOMNode();
      if (inputNode.value) {
        inputNode.style.width = '';
        inputNode.style.width = mirrorNode.clientWidth + 'px';
      } else {
        inputNode.style.width = '';
      }
    }
  };

  Select.prototype.componentWillUnmount = function componentWillUnmount() {
    this.clearFocusTime();
    this.clearBlurTime();
    this.clearAdjustTimer();
    if (this.dropdownContainer) {
      react_dom__WEBPACK_IMPORTED_MODULE_5___default.a.unmountComponentAtNode(this.dropdownContainer);
      document.body.removeChild(this.dropdownContainer);
      this.dropdownContainer = null;
    }
  };

  // combobox ignore


  Select.prototype.focus = function focus() {
    if (Object(_util__WEBPACK_IMPORTED_MODULE_14__["isSingleMode"])(this.props)) {
      this.selectionRef.focus();
    } else {
      this.getInputDOMNode().focus();
    }
  };

  Select.prototype.blur = function blur() {
    if (Object(_util__WEBPACK_IMPORTED_MODULE_14__["isSingleMode"])(this.props)) {
      this.selectionRef.blur();
    } else {
      this.getInputDOMNode().blur();
    }
  };

  Select.prototype.renderClear = function renderClear() {
    var _props = this.props,
        prefixCls = _props.prefixCls,
        allowClear = _props.allowClear;
    var _state = this.state,
        value = _state.value,
        inputValue = _state.inputValue;

    var clear = react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement('span', babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({
      key: 'clear',
      onMouseDown: _util__WEBPACK_IMPORTED_MODULE_14__["preventDefaultEvent"],
      style: _util__WEBPACK_IMPORTED_MODULE_14__["UNSELECTABLE_STYLE"]
    }, _util__WEBPACK_IMPORTED_MODULE_14__["UNSELECTABLE_ATTRIBUTE"], {
      className: prefixCls + '-selection__clear',
      onClick: this.onClearSelection
    }));
    if (!allowClear) {
      return null;
    }
    if (Object(_util__WEBPACK_IMPORTED_MODULE_14__["isCombobox"])(this.props)) {
      if (inputValue) {
        return clear;
      }
      return null;
    }
    if (inputValue || value.length) {
      return clear;
    }
    return null;
  };

  Select.prototype.render = function render() {
    var _rootCls;

    var props = this.props;
    var multiple = Object(_util__WEBPACK_IMPORTED_MODULE_14__["isMultipleOrTags"])(props);
    var state = this.state;
    var className = props.className,
        disabled = props.disabled,
        prefixCls = props.prefixCls;

    var ctrlNode = this.renderTopControlNode();
    var extraSelectionProps = {};
    var open = this.state.open;

    var options = this._options;
    if (!Object(_util__WEBPACK_IMPORTED_MODULE_14__["isMultipleOrTagsOrCombobox"])(props)) {
      extraSelectionProps = {
        onKeyDown: this.onKeyDown,
        tabIndex: props.disabled ? -1 : 0
      };
    }
    var rootCls = (_rootCls = {}, _rootCls[className] = !!className, _rootCls[prefixCls] = 1, _rootCls[prefixCls + '-open'] = open, _rootCls[prefixCls + '-focused'] = open || !!this._focused, _rootCls[prefixCls + '-combobox'] = Object(_util__WEBPACK_IMPORTED_MODULE_14__["isCombobox"])(props), _rootCls[prefixCls + '-disabled'] = disabled, _rootCls[prefixCls + '-enabled'] = !disabled, _rootCls[prefixCls + '-allow-clear'] = !!props.allowClear, _rootCls);
    return react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
      _SelectTrigger__WEBPACK_IMPORTED_MODULE_15__["default"],
      {
        onPopupFocus: this.onPopupFocus,
        onMouseEnter: this.props.onMouseEnter,
        onMouseLeave: this.props.onMouseLeave,
        dropdownAlign: props.dropdownAlign,
        dropdownClassName: props.dropdownClassName,
        dropdownMatchSelectWidth: props.dropdownMatchSelectWidth,
        defaultActiveFirstOption: props.defaultActiveFirstOption,
        dropdownMenuStyle: props.dropdownMenuStyle,
        transitionName: props.transitionName,
        animation: props.animation,
        prefixCls: props.prefixCls,
        dropdownStyle: props.dropdownStyle,
        combobox: props.combobox,
        showSearch: props.showSearch,
        options: options,
        multiple: multiple,
        disabled: disabled,
        visible: open,
        inputValue: state.inputValue,
        value: state.value,
        backfillValue: state.backfillValue,
        firstActiveValue: props.firstActiveValue,
        onDropdownVisibleChange: this.onDropdownVisibleChange,
        getPopupContainer: props.getPopupContainer,
        onMenuSelect: this.onMenuSelect,
        onMenuDeselect: this.onMenuDeselect,
        onPopupScroll: props.onPopupScroll,
        showAction: props.showAction,
        ref: Object(_util__WEBPACK_IMPORTED_MODULE_14__["saveRef"])(this, 'selectTriggerRef')
      },
      react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
        'div',
        {
          style: props.style,
          ref: Object(_util__WEBPACK_IMPORTED_MODULE_14__["saveRef"])(this, 'rootRef'),
          onBlur: this.onOuterBlur,
          onFocus: this.onOuterFocus,
          className: classnames__WEBPACK_IMPORTED_MODULE_8___default()(rootCls)
        },
        react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
          'div',
          babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({
            ref: Object(_util__WEBPACK_IMPORTED_MODULE_14__["saveRef"])(this, 'selectionRef'),
            key: 'selection',
            className: prefixCls + '-selection\n            ' + prefixCls + '-selection--' + (multiple ? 'multiple' : 'single'),
            role: 'combobox',
            'aria-autocomplete': 'list',
            'aria-haspopup': 'true',
            'aria-expanded': open
          }, extraSelectionProps),
          ctrlNode,
          this.renderClear(),
          multiple || !props.showArrow ? null : react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
            'span',
            babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({
              key: 'arrow',
              className: prefixCls + '-arrow',
              style: _util__WEBPACK_IMPORTED_MODULE_14__["UNSELECTABLE_STYLE"]
            }, _util__WEBPACK_IMPORTED_MODULE_14__["UNSELECTABLE_ATTRIBUTE"], {
              onClick: this.onArrowClick
            }),
            react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement('b', null)
          )
        )
      )
    );
  };

  return Select;
}(react__WEBPACK_IMPORTED_MODULE_4___default.a.Component);

Select.propTypes = _PropTypes__WEBPACK_IMPORTED_MODULE_16__["SelectPropTypes"];
Select.defaultProps = {
  prefixCls: 'rc-select',
  defaultOpen: false,
  labelInValue: false,
  defaultActiveFirstOption: true,
  showSearch: true,
  allowClear: false,
  placeholder: '',
  onChange: noop,
  onFocus: noop,
  onBlur: noop,
  onSelect: noop,
  onSearch: noop,
  onDeselect: noop,
  onInputKeyDown: noop,
  showArrow: true,
  dropdownMatchSelectWidth: true,
  dropdownStyle: {},
  dropdownMenuStyle: {},
  optionFilterProp: 'value',
  optionLabelProp: 'value',
  notFoundContent: 'Not Found',
  backfill: false,
  showAction: ['click'],
  tokenSeparators: []
};

var _initialiseProps = function _initialiseProps() {
  var _this2 = this;

  this.componentWillReceiveProps = function (nextProps) {
    var optionsInfo = _this2.getOptionsInfoFromProps(nextProps);
    _this2.setState({
      optionsInfo: optionsInfo
    });
    if ('value' in nextProps) {
      var value = _this2.getValueFromProps(nextProps);
      _this2.setState({
        value: value
      }, _this2.forcePopupAlign);
      if (nextProps.combobox) {
        _this2.setState({
          inputValue: value.length ? _this2.getLabelBySingleValue(value[0], optionsInfo) : ''
        });
      }
    }
  };

  this.onInputChange = function (event) {
    var tokenSeparators = _this2.props.tokenSeparators;

    var val = event.target.value;
    if (Object(_util__WEBPACK_IMPORTED_MODULE_14__["isMultipleOrTags"])(_this2.props) && tokenSeparators.length && Object(_util__WEBPACK_IMPORTED_MODULE_14__["includesSeparators"])(val, tokenSeparators)) {
      var nextValue = _this2.getValueByInput(val);
      if (nextValue !== undefined) {
        _this2.fireChange(nextValue);
      }
      _this2.setOpenState(false, true);
      _this2.setInputValue('', false);
      return;
    }
    _this2.setInputValue(val);
    _this2.setState({
      open: true
    });
    if (Object(_util__WEBPACK_IMPORTED_MODULE_14__["isCombobox"])(_this2.props)) {
      _this2.fireChange([val]);
    }
  };

  this.onDropdownVisibleChange = function (open) {
    if (open && !_this2._focused) {
      _this2.clearBlurTime();
      _this2.timeoutFocus();
      _this2._focused = true;
      _this2.updateFocusClassName();
    }
    _this2.setOpenState(open);
  };

  this.onKeyDown = function (event) {
    var props = _this2.props;
    if (props.disabled) {
      return;
    }
    var keyCode = event.keyCode;
    if (_this2.state.open && !_this2.getInputDOMNode()) {
      _this2.onInputKeyDown(event);
    } else if (keyCode === rc_util_es_KeyCode__WEBPACK_IMPORTED_MODULE_6__["default"].ENTER || keyCode === rc_util_es_KeyCode__WEBPACK_IMPORTED_MODULE_6__["default"].DOWN) {
      _this2.setOpenState(true);
      event.preventDefault();
    }
  };

  this.onInputKeyDown = function (event) {
    var props = _this2.props;
    if (props.disabled) {
      return;
    }
    var state = _this2.state;
    var keyCode = event.keyCode;
    if (Object(_util__WEBPACK_IMPORTED_MODULE_14__["isMultipleOrTags"])(props) && !event.target.value && keyCode === rc_util_es_KeyCode__WEBPACK_IMPORTED_MODULE_6__["default"].BACKSPACE) {
      event.preventDefault();
      var value = state.value;

      if (value.length) {
        _this2.removeSelected(value[value.length - 1]);
      }
      return;
    }
    if (keyCode === rc_util_es_KeyCode__WEBPACK_IMPORTED_MODULE_6__["default"].DOWN) {
      if (!state.open) {
        _this2.openIfHasChildren();
        event.preventDefault();
        event.stopPropagation();
        return;
      }
    } else if (keyCode === rc_util_es_KeyCode__WEBPACK_IMPORTED_MODULE_6__["default"].ESC) {
      if (state.open) {
        _this2.setOpenState(false);
        event.preventDefault();
        event.stopPropagation();
      }
      return;
    }

    if (state.open) {
      var menu = _this2.selectTriggerRef.getInnerMenu();
      if (menu && menu.onKeyDown(event, _this2.handleBackfill)) {
        event.preventDefault();
        event.stopPropagation();
      }
    }
  };

  this.onMenuSelect = function (_ref) {
    var item = _ref.item;

    var value = _this2.state.value;
    var props = _this2.props;
    var selectedValue = Object(_util__WEBPACK_IMPORTED_MODULE_14__["getValuePropValue"])(item);
    var lastValue = value[value.length - 1];
    _this2.fireSelect(selectedValue);
    if (Object(_util__WEBPACK_IMPORTED_MODULE_14__["isMultipleOrTags"])(props)) {
      if (Object(_util__WEBPACK_IMPORTED_MODULE_14__["findIndexInValueBySingleValue"])(value, selectedValue) !== -1) {
        return;
      }
      value = value.concat([selectedValue]);
    } else {
      if (Object(_util__WEBPACK_IMPORTED_MODULE_14__["isCombobox"])(props)) {
        _this2.skipAdjustOpen = true;
        _this2.clearAdjustTimer();
        _this2.skipAdjustOpenTimer = setTimeout(function () {
          _this2.skipAdjustOpen = false;
        }, 0);
      }
      if (lastValue && lastValue === selectedValue && selectedValue !== _this2.state.backfillValue) {
        _this2.setOpenState(false, true);
        return;
      }
      value = [selectedValue];
      _this2.setOpenState(false, true);
    }
    _this2.fireChange(value);
    var inputValue = void 0;
    if (Object(_util__WEBPACK_IMPORTED_MODULE_14__["isCombobox"])(props)) {
      inputValue = Object(_util__WEBPACK_IMPORTED_MODULE_14__["getPropValue"])(item, props.optionLabelProp);
    } else {
      inputValue = '';
    }
    _this2.setInputValue(inputValue, false);
  };

  this.onMenuDeselect = function (_ref2) {
    var item = _ref2.item,
        domEvent = _ref2.domEvent;

    if (domEvent.type === 'click') {
      _this2.removeSelected(Object(_util__WEBPACK_IMPORTED_MODULE_14__["getValuePropValue"])(item));
    }
    _this2.setInputValue('', false);
  };

  this.onArrowClick = function (e) {
    e.stopPropagation();
    e.preventDefault();
    if (!_this2.props.disabled) {
      _this2.setOpenState(!_this2.state.open, !_this2.state.open);
    }
  };

  this.onPlaceholderClick = function () {
    if (_this2.getInputDOMNode()) {
      _this2.getInputDOMNode().focus();
    }
  };

  this.onOuterFocus = function (e) {
    if (_this2.props.disabled) {
      e.preventDefault();
      return;
    }
    _this2.clearBlurTime();
    if (!Object(_util__WEBPACK_IMPORTED_MODULE_14__["isMultipleOrTagsOrCombobox"])(_this2.props) && e.target === _this2.getInputDOMNode()) {
      return;
    }
    if (_this2._focused) {
      return;
    }
    _this2._focused = true;
    _this2.updateFocusClassName();
    _this2.timeoutFocus();
  };

  this.onPopupFocus = function () {
    // fix ie scrollbar, focus element again
    _this2.maybeFocus(true, true);
  };

  this.onOuterBlur = function (e) {
    if (_this2.props.disabled) {
      e.preventDefault();
      return;
    }
    _this2.blurTimer = setTimeout(function () {
      _this2._focused = false;
      _this2.updateFocusClassName();
      var props = _this2.props;
      var value = _this2.state.value;
      var inputValue = _this2.state.inputValue;

      if (Object(_util__WEBPACK_IMPORTED_MODULE_14__["isSingleMode"])(props) && props.showSearch && inputValue && props.defaultActiveFirstOption) {
        var options = _this2._options || [];
        if (options.length) {
          var firstOption = Object(_util__WEBPACK_IMPORTED_MODULE_14__["findFirstMenuItem"])(options);
          if (firstOption) {
            value = [Object(_util__WEBPACK_IMPORTED_MODULE_14__["getValuePropValue"])(firstOption)];
            _this2.fireChange(value);
          }
        }
      } else if (Object(_util__WEBPACK_IMPORTED_MODULE_14__["isMultipleOrTags"])(props) && inputValue) {
        // why not use setState?
        _this2.state.inputValue = _this2.getInputDOMNode().value = '';

        value = _this2.getValueByInput(inputValue);
        if (value !== undefined) {
          _this2.fireChange(value);
        }
      }
      props.onBlur(_this2.getVLForOnChange(value));
      _this2.setOpenState(false);
    }, 10);
  };

  this.onClearSelection = function (event) {
    var props = _this2.props;
    var state = _this2.state;
    if (props.disabled) {
      return;
    }
    var inputValue = state.inputValue,
        value = state.value;

    event.stopPropagation();
    if (inputValue || value.length) {
      if (value.length) {
        _this2.fireChange([]);
      }
      _this2.setOpenState(false, true);
      if (inputValue) {
        _this2.setInputValue('');
      }
    }
  };

  this.onChoiceAnimationLeave = function () {
    _this2.forcePopupAlign();
  };

  this.getValueFromProps = function (props) {
    var value = [];
    if ('value' in props) {
      value = Object(_util__WEBPACK_IMPORTED_MODULE_14__["toArray"])(props.value);
    } else {
      value = Object(_util__WEBPACK_IMPORTED_MODULE_14__["toArray"])(props.defaultValue);
    }
    if (props.labelInValue) {
      value = value.map(function (v) {
        return v.key;
      });
    }
    return value;
  };

  this.getOptionsInfoFromProps = function (props) {
    var options = _this2.getOptionsFromChildren(props.children);
    var oldOptionsInfo = _this2.state ? _this2.state.optionsInfo : {};
    var value = _this2.state ? _this2.state.value : [];
    var optionsInfo = {};
    options.forEach(function (option) {
      var singleValue = Object(_util__WEBPACK_IMPORTED_MODULE_14__["getValuePropValue"])(option);
      optionsInfo[Object(_util__WEBPACK_IMPORTED_MODULE_14__["getMapKey"])(singleValue)] = {
        option: option,
        value: singleValue,
        label: _this2.getLabelFromOption(option),
        title: option.props.title
      };
    });
    value.forEach(function (v) {
      var key = Object(_util__WEBPACK_IMPORTED_MODULE_14__["getMapKey"])(v);
      if (!optionsInfo[key]) {
        optionsInfo[key] = oldOptionsInfo[key];
      }
    });
    return optionsInfo;
  };

  this.getOptionInfoBySingleValue = function (value, optionsInfo) {
    var info = void 0;
    optionsInfo = optionsInfo || _this2.state.optionsInfo;
    if (optionsInfo[Object(_util__WEBPACK_IMPORTED_MODULE_14__["getMapKey"])(value)]) {
      info = optionsInfo[Object(_util__WEBPACK_IMPORTED_MODULE_14__["getMapKey"])(value)];
    }
    if (info) {
      return info;
    }
    var defaultLabel = value;
    if (_this2.props.labelInValue) {
      var label = Object(_util__WEBPACK_IMPORTED_MODULE_14__["getLabelFromPropsValue"])(_this2.props.value, value);
      if (label !== undefined) {
        defaultLabel = label;
      }
    }
    var defaultInfo = {
      option: react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
        _Option__WEBPACK_IMPORTED_MODULE_13__["default"],
        { value: value, key: value },
        value
      ),
      value: value,
      label: defaultLabel
    };
    return defaultInfo;
  };

  this.getOptionBySingleValue = function (value) {
    var _getOptionInfoBySingl = _this2.getOptionInfoBySingleValue(value),
        option = _getOptionInfoBySingl.option;

    return option;
  };

  this.getOptionsBySingleValue = function (values) {
    return values.map(function (value) {
      return _this2.getOptionBySingleValue(value);
    });
  };

  this.getOptionsFromChildren = function (children) {
    var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];

    react__WEBPACK_IMPORTED_MODULE_4___default.a.Children.forEach(children, function (child) {
      if (!child) {
        return;
      }
      if (child.type.isSelectOptGroup) {
        _this2.getOptionsFromChildren(child.props.children, options);
      } else {
        options.push(child);
      }
    });
    return options;
  };

  this.getValueByLabel = function (label) {
    if (label === undefined) {
      return null;
    }
    var value = null;
    Object.keys(_this2.state.optionsInfo).forEach(function (key) {
      var info = _this2.state.optionsInfo[key];
      if (Object(_util__WEBPACK_IMPORTED_MODULE_14__["toArray"])(info.label).join('') === label) {
        value = info.value;
      }
    });
    return value;
  };

  this.getLabelFromOption = function (option) {
    return Object(_util__WEBPACK_IMPORTED_MODULE_14__["getPropValue"])(option, _this2.props.optionLabelProp);
  };

  this.getVLBySingleValue = function (value) {
    if (_this2.props.labelInValue) {
      return {
        key: value,
        label: _this2.getLabelBySingleValue(value)
      };
    }
    return value;
  };

  this.getVLForOnChange = function (vls_) {
    var vls = vls_;
    if (vls !== undefined) {
      if (!_this2.props.labelInValue) {
        vls = vls.map(function (v) {
          return v;
        });
      } else {
        vls = vls.map(function (vl) {
          return {
            key: vl,
            label: _this2.getLabelBySingleValue(vl)
          };
        });
      }
      return Object(_util__WEBPACK_IMPORTED_MODULE_14__["isMultipleOrTags"])(_this2.props) ? vls : vls[0];
    }
    return vls;
  };

  this.getLabelBySingleValue = function (value, optionsInfo) {
    var _getOptionInfoBySingl2 = _this2.getOptionInfoBySingleValue(value, optionsInfo),
        label = _getOptionInfoBySingl2.label;

    return label;
  };

  this.getDropdownContainer = function () {
    if (!_this2.dropdownContainer) {
      _this2.dropdownContainer = document.createElement('div');
      document.body.appendChild(_this2.dropdownContainer);
    }
    return _this2.dropdownContainer;
  };

  this.getPlaceholderElement = function () {
    var props = _this2.props,
        state = _this2.state;

    var hidden = false;
    if (state.inputValue) {
      hidden = true;
    }
    if (state.value.length) {
      hidden = true;
    }
    if (Object(_util__WEBPACK_IMPORTED_MODULE_14__["isCombobox"])(props) && state.value.length === 1 && !state.value[0]) {
      hidden = false;
    }
    var placeholder = props.placeholder;
    if (placeholder) {
      return react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
        'div',
        babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({
          onMouseDown: _util__WEBPACK_IMPORTED_MODULE_14__["preventDefaultEvent"],
          style: babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({
            display: hidden ? 'none' : 'block'
          }, _util__WEBPACK_IMPORTED_MODULE_14__["UNSELECTABLE_STYLE"])
        }, _util__WEBPACK_IMPORTED_MODULE_14__["UNSELECTABLE_ATTRIBUTE"], {
          onClick: _this2.onPlaceholderClick,
          className: props.prefixCls + '-selection__placeholder'
        }),
        placeholder
      );
    }
    return null;
  };

  this.getInputElement = function () {
    var _classnames;

    var props = _this2.props;
    var inputElement = props.getInputElement ? props.getInputElement() : react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement('input', { id: props.id, autoComplete: 'off' });
    var inputCls = classnames__WEBPACK_IMPORTED_MODULE_8___default()(inputElement.props.className, (_classnames = {}, _classnames[props.prefixCls + '-search__field'] = true, _classnames));
    // https://github.com/ant-design/ant-design/issues/4992#issuecomment-281542159
    // Add space to the end of the inputValue as the width measurement tolerance
    return react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
      'div',
      { className: props.prefixCls + '-search__field__wrap' },
      react__WEBPACK_IMPORTED_MODULE_4___default.a.cloneElement(inputElement, {
        ref: Object(_util__WEBPACK_IMPORTED_MODULE_14__["saveRef"])(_this2, 'inputRef'),
        onChange: _this2.onInputChange,
        onKeyDown: chaining(_this2.onInputKeyDown, inputElement.props.onKeyDown, _this2.props.onInputKeyDown),
        value: _this2.state.inputValue,
        disabled: props.disabled,
        className: inputCls
      }),
      react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
        'span',
        {
          ref: Object(_util__WEBPACK_IMPORTED_MODULE_14__["saveRef"])(_this2, 'inputMirrorRef'),
          className: props.prefixCls + '-search__field__mirror'
        },
        _this2.state.inputValue,
        '\xA0'
      )
    );
  };

  this.getInputDOMNode = function () {
    return _this2.topCtrlRef ? _this2.topCtrlRef.querySelector('input,textarea,div[contentEditable]') : _this2.inputRef;
  };

  this.getInputMirrorDOMNode = function () {
    return _this2.inputMirrorRef;
  };

  this.getPopupDOMNode = function () {
    return _this2.selectTriggerRef.getPopupDOMNode();
  };

  this.getPopupMenuComponent = function () {
    return _this2.selectTriggerRef.getInnerMenu();
  };

  this.setOpenState = function (open, needFocus) {
    var props = _this2.props,
        state = _this2.state;

    if (state.open === open) {
      _this2.maybeFocus(open, needFocus);
      return;
    }
    var nextState = {
      open: open,
      backfillValue: undefined
    };
    // clear search input value when open is false in singleMode.
    if (!open && Object(_util__WEBPACK_IMPORTED_MODULE_14__["isSingleMode"])(props) && props.showSearch) {
      _this2.setInputValue('');
    }
    if (!open) {
      _this2.maybeFocus(open, needFocus);
    }
    _this2.setState(nextState, function () {
      if (open) {
        _this2.maybeFocus(open, needFocus);
      }
    });
  };

  this.setInputValue = function (inputValue) {
    var fireSearch = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;

    if (inputValue !== _this2.state.inputValue) {
      _this2.setState({
        inputValue: inputValue
      }, _this2.forcePopupAlign);
      if (fireSearch) {
        _this2.props.onSearch(inputValue);
      }
    }
  };

  this.getValueByInput = function (string) {
    var _props2 = _this2.props,
        multiple = _props2.multiple,
        tokenSeparators = _props2.tokenSeparators;

    var nextValue = _this2.state.value;
    var hasNewValue = false;
    Object(_util__WEBPACK_IMPORTED_MODULE_14__["splitBySeparators"])(string, tokenSeparators).forEach(function (label) {
      var selectedValue = [label];
      if (multiple) {
        var value = _this2.getValueByLabel(label);
        if (value && Object(_util__WEBPACK_IMPORTED_MODULE_14__["findIndexInValueBySingleValue"])(nextValue, value) === -1) {
          nextValue = nextValue.concat(value);
          hasNewValue = true;
          _this2.fireSelect(value);
        }
      } else {
        // tag
        if (Object(_util__WEBPACK_IMPORTED_MODULE_14__["findIndexInValueBySingleValue"])(nextValue, label) === -1) {
          nextValue = nextValue.concat(selectedValue);
          hasNewValue = true;
          _this2.fireSelect(label);
        }
      }
    });
    return hasNewValue ? nextValue : undefined;
  };

  this.handleBackfill = function (item) {
    if (!_this2.props.backfill || !(Object(_util__WEBPACK_IMPORTED_MODULE_14__["isSingleMode"])(_this2.props) || Object(_util__WEBPACK_IMPORTED_MODULE_14__["isCombobox"])(_this2.props))) {
      return;
    }

    var key = Object(_util__WEBPACK_IMPORTED_MODULE_14__["getValuePropValue"])(item);

    if (Object(_util__WEBPACK_IMPORTED_MODULE_14__["isCombobox"])(_this2.props)) {
      _this2.setInputValue(key, false);
    }

    _this2.setState({
      value: [key],
      backfillValue: key
    });
  };

  this.filterOption = function (input, child) {
    var defaultFilter = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : _util__WEBPACK_IMPORTED_MODULE_14__["defaultFilterFn"];
    var value = _this2.state.value;

    var lastValue = value[value.length - 1];
    if (!input || lastValue && lastValue === _this2.state.backfillValue) {
      return true;
    }
    var filterFn = _this2.props.filterOption;
    if ('filterOption' in _this2.props) {
      if (_this2.props.filterOption === true) {
        filterFn = defaultFilter;
      }
    } else {
      filterFn = defaultFilter;
    }

    if (!filterFn) {
      return true;
    } else if (typeof filterFn === 'function') {
      return filterFn.call(_this2, input, child);
    } else if (child.props.disabled) {
      return false;
    }
    return true;
  };

  this.timeoutFocus = function () {
    if (_this2.focusTimer) {
      _this2.clearFocusTime();
    }
    _this2.focusTimer = setTimeout(function () {
      _this2.props.onFocus();
    }, 10);
  };

  this.clearFocusTime = function () {
    if (_this2.focusTimer) {
      clearTimeout(_this2.focusTimer);
      _this2.focusTimer = null;
    }
  };

  this.clearBlurTime = function () {
    if (_this2.blurTimer) {
      clearTimeout(_this2.blurTimer);
      _this2.blurTimer = null;
    }
  };

  this.clearAdjustTimer = function () {
    if (_this2.skipAdjustOpenTimer) {
      clearTimeout(_this2.skipAdjustOpenTimer);
      _this2.skipAdjustOpenTimer = null;
    }
  };

  this.updateFocusClassName = function () {
    var rootRef = _this2.rootRef,
        props = _this2.props;
    // avoid setState and its side effect

    if (_this2._focused) {
      component_classes__WEBPACK_IMPORTED_MODULE_10___default()(rootRef).add(props.prefixCls + '-focused');
    } else {
      component_classes__WEBPACK_IMPORTED_MODULE_10___default()(rootRef).remove(props.prefixCls + '-focused');
    }
  };

  this.maybeFocus = function (open, needFocus) {
    if (needFocus || open) {
      var input = _this2.getInputDOMNode();
      var _document = document,
          activeElement = _document.activeElement;

      if (input && (open || Object(_util__WEBPACK_IMPORTED_MODULE_14__["isMultipleOrTagsOrCombobox"])(_this2.props))) {
        if (activeElement !== input) {
          input.focus();
          _this2._focused = true;
        }
      } else {
        if (activeElement !== _this2.selectionRef) {
          _this2.selectionRef.focus();
          _this2._focused = true;
        }
      }
    }
  };

  this.removeSelected = function (selectedKey) {
    var props = _this2.props;
    if (props.disabled || _this2.isChildDisabled(selectedKey)) {
      return;
    }
    var value = _this2.state.value.filter(function (singleValue) {
      return singleValue !== selectedKey;
    });
    var canMultiple = Object(_util__WEBPACK_IMPORTED_MODULE_14__["isMultipleOrTags"])(props);

    if (canMultiple) {
      var event = selectedKey;
      if (props.labelInValue) {
        event = {
          key: selectedKey,
          label: _this2.getLabelBySingleValue(selectedKey)
        };
      }
      props.onDeselect(event, _this2.getOptionBySingleValue(selectedKey));
    }
    _this2.fireChange(value);
  };

  this.openIfHasChildren = function () {
    var props = _this2.props;
    if (react__WEBPACK_IMPORTED_MODULE_4___default.a.Children.count(props.children) || Object(_util__WEBPACK_IMPORTED_MODULE_14__["isSingleMode"])(props)) {
      _this2.setOpenState(true);
    }
  };

  this.fireSelect = function (value) {
    _this2.props.onSelect(_this2.getVLBySingleValue(value), _this2.getOptionBySingleValue(value));
  };

  this.fireChange = function (value) {
    var props = _this2.props;
    if (!('value' in props)) {
      _this2.setState({
        value: value
      }, _this2.forcePopupAlign);
    }
    var vls = _this2.getVLForOnChange(value);
    var options = _this2.getOptionsBySingleValue(value);
    props.onChange(vls, Object(_util__WEBPACK_IMPORTED_MODULE_14__["isMultipleOrTags"])(_this2.props) ? options : options[0]);
  };

  this.isChildDisabled = function (key) {
    return Object(rc_util_es_Children_toArray__WEBPACK_IMPORTED_MODULE_7__["default"])(_this2.props.children).some(function (child) {
      var childValue = Object(_util__WEBPACK_IMPORTED_MODULE_14__["getValuePropValue"])(child);
      return childValue === key && child.props && child.props.disabled;
    });
  };

  this.adjustOpenState = function () {
    if (_this2.skipAdjustOpen) {
      return;
    }
    var open = _this2.state.open;

    var options = [];
    // If hidden menu due to no options, then it should be calculated again
    if (open || _this2.hiddenForNoOptions) {
      options = _this2.renderFilterOptions();
    }
    _this2._options = options;

    if (Object(_util__WEBPACK_IMPORTED_MODULE_14__["isMultipleOrTagsOrCombobox"])(_this2.props) || !_this2.props.showSearch) {
      if (open && !options.length) {
        open = false;
        _this2.hiddenForNoOptions = true;
      }
      // Keep menu open if there are options and hidden for no options before
      if (_this2.hiddenForNoOptions && options.length) {
        open = true;
        _this2.hiddenForNoOptions = false;
      }
    }
    _this2.state.open = open;
  };

  this.forcePopupAlign = function () {
    _this2.selectTriggerRef.triggerRef.forcePopupAlign();
  };

  this.renderFilterOptions = function () {
    var inputValue = _this2.state.inputValue;
    var _props3 = _this2.props,
        children = _props3.children,
        tags = _props3.tags,
        filterOption = _props3.filterOption,
        notFoundContent = _props3.notFoundContent;

    var menuItems = [];
    var childrenKeys = [];
    var options = _this2.renderFilterOptionsFromChildren(children, childrenKeys, menuItems);
    if (tags) {
      // tags value must be string
      var value = _this2.state.value || [];
      value = value.filter(function (singleValue) {
        return childrenKeys.indexOf(singleValue) === -1 && (!inputValue || String(singleValue).indexOf(String(inputValue)) > -1);
      });
      value.forEach(function (singleValue) {
        var key = singleValue;
        var menuItem = react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
          rc_menu__WEBPACK_IMPORTED_MODULE_11__["Item"],
          {
            style: _util__WEBPACK_IMPORTED_MODULE_14__["UNSELECTABLE_STYLE"],
            attribute: _util__WEBPACK_IMPORTED_MODULE_14__["UNSELECTABLE_ATTRIBUTE"],
            value: key,
            key: key
          },
          key
        );
        options.push(menuItem);
        menuItems.push(menuItem);
      });
      if (inputValue) {
        var notFindInputItem = menuItems.every(function (option) {
          // this.filterOption return true has two meaning,
          // 1, some one exists after filtering
          // 2, filterOption is set to false
          // condition 2 does not mean the option has same value with inputValue
          var filterFn = function filterFn() {
            return Object(_util__WEBPACK_IMPORTED_MODULE_14__["getValuePropValue"])(option) === inputValue;
          };
          if (filterOption !== false) {
            return !_this2.filterOption.call(_this2, inputValue, option, filterFn);
          }
          return !filterFn();
        });
        if (notFindInputItem) {
          options.unshift(react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
            rc_menu__WEBPACK_IMPORTED_MODULE_11__["Item"],
            {
              style: _util__WEBPACK_IMPORTED_MODULE_14__["UNSELECTABLE_STYLE"],
              attribute: _util__WEBPACK_IMPORTED_MODULE_14__["UNSELECTABLE_ATTRIBUTE"],
              value: inputValue,
              key: inputValue
            },
            inputValue
          ));
        }
      }
    }

    if (!options.length && notFoundContent) {
      options = [react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
        rc_menu__WEBPACK_IMPORTED_MODULE_11__["Item"],
        {
          style: _util__WEBPACK_IMPORTED_MODULE_14__["UNSELECTABLE_STYLE"],
          attribute: _util__WEBPACK_IMPORTED_MODULE_14__["UNSELECTABLE_ATTRIBUTE"],
          disabled: true,
          value: 'NOT_FOUND',
          key: 'NOT_FOUND'
        },
        notFoundContent
      )];
    }
    return options;
  };

  this.renderFilterOptionsFromChildren = function (children, childrenKeys, menuItems) {
    var sel = [];
    var props = _this2.props;
    var inputValue = _this2.state.inputValue;

    var tags = props.tags;
    react__WEBPACK_IMPORTED_MODULE_4___default.a.Children.forEach(children, function (child) {
      if (!child) {
        return;
      }
      if (child.type.isSelectOptGroup) {
        var innerItems = _this2.renderFilterOptionsFromChildren(child.props.children, childrenKeys, menuItems);
        if (innerItems.length) {
          var label = child.props.label;
          var key = child.key;
          if (!key && typeof label === 'string') {
            key = label;
          } else if (!label && key) {
            label = key;
          }
          sel.push(react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
            rc_menu__WEBPACK_IMPORTED_MODULE_11__["ItemGroup"],
            { key: key, title: label },
            innerItems
          ));
        }
        return;
      }

      warning__WEBPACK_IMPORTED_MODULE_12___default()(child.type.isSelectOption, 'the children of `Select` should be `Select.Option` or `Select.OptGroup`, ' + ('instead of `' + (child.type.name || child.type.displayName || child.type) + '`.'));

      var childValue = Object(_util__WEBPACK_IMPORTED_MODULE_14__["getValuePropValue"])(child);

      Object(_util__WEBPACK_IMPORTED_MODULE_14__["validateOptionValue"])(childValue, _this2.props);

      if (_this2.filterOption(inputValue, child)) {
        var menuItem = react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(rc_menu__WEBPACK_IMPORTED_MODULE_11__["Item"], babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({
          style: _util__WEBPACK_IMPORTED_MODULE_14__["UNSELECTABLE_STYLE"],
          attribute: _util__WEBPACK_IMPORTED_MODULE_14__["UNSELECTABLE_ATTRIBUTE"],
          value: childValue,
          key: childValue
        }, child.props));
        sel.push(menuItem);
        menuItems.push(menuItem);
      }
      if (tags && !child.props.disabled) {
        childrenKeys.push(childValue);
      }
    });

    return sel;
  };

  this.renderTopControlNode = function () {
    var _state2 = _this2.state,
        value = _state2.value,
        open = _state2.open,
        inputValue = _state2.inputValue;

    var props = _this2.props;
    var choiceTransitionName = props.choiceTransitionName,
        prefixCls = props.prefixCls,
        maxTagTextLength = props.maxTagTextLength,
        maxTagCount = props.maxTagCount,
        maxTagPlaceholder = props.maxTagPlaceholder,
        showSearch = props.showSearch;

    var className = prefixCls + '-selection__rendered';
    // search input is inside topControlNode in single, multiple & combobox. 2016/04/13
    var innerNode = null;
    if (Object(_util__WEBPACK_IMPORTED_MODULE_14__["isSingleMode"])(props)) {
      var selectedValue = null;
      if (value.length) {
        var showSelectedValue = false;
        var opacity = 1;
        if (!showSearch) {
          showSelectedValue = true;
        } else {
          if (open) {
            showSelectedValue = !inputValue;
            if (showSelectedValue) {
              opacity = 0.4;
            }
          } else {
            showSelectedValue = true;
          }
        }
        var singleValue = value[0];

        var _getOptionInfoBySingl3 = _this2.getOptionInfoBySingleValue(singleValue),
            label = _getOptionInfoBySingl3.label,
            title = _getOptionInfoBySingl3.title;

        selectedValue = react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
          'div',
          {
            key: 'value',
            className: prefixCls + '-selection-selected-value',
            title: title || label,
            style: {
              display: showSelectedValue ? 'block' : 'none',
              opacity: opacity
            }
          },
          label
        );
      }
      if (!showSearch) {
        innerNode = [selectedValue];
      } else {
        innerNode = [selectedValue, react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
          'div',
          {
            className: prefixCls + '-search ' + prefixCls + '-search--inline',
            key: 'input',
            style: {
              display: open ? 'block' : 'none'
            }
          },
          _this2.getInputElement()
        )];
      }
    } else {
      var selectedValueNodes = [];
      var limitedCountValue = value;
      var maxTagPlaceholderEl = void 0;
      if (maxTagCount !== undefined && value.length > maxTagCount) {
        limitedCountValue = limitedCountValue.slice(0, maxTagCount);
        var omittedValues = _this2.getVLForOnChange(value.slice(maxTagCount, value.length));
        var content = '+ ' + (value.length - maxTagCount) + ' ...';
        if (maxTagPlaceholder) {
          content = typeof maxTagPlaceholder === 'function' ? maxTagPlaceholder(omittedValues) : maxTagPlaceholder;
        }
        maxTagPlaceholderEl = react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
          'li',
          babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({
            style: _util__WEBPACK_IMPORTED_MODULE_14__["UNSELECTABLE_STYLE"]
          }, _util__WEBPACK_IMPORTED_MODULE_14__["UNSELECTABLE_ATTRIBUTE"], {
            onMouseDown: _util__WEBPACK_IMPORTED_MODULE_14__["preventDefaultEvent"],
            className: prefixCls + '-selection__choice ' + prefixCls + '-selection__choice__disabled',
            key: 'maxTagPlaceholder',
            title: content
          }),
          react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
            'div',
            { className: prefixCls + '-selection__choice__content' },
            content
          )
        );
      }
      if (Object(_util__WEBPACK_IMPORTED_MODULE_14__["isMultipleOrTags"])(props)) {
        selectedValueNodes = limitedCountValue.map(function (singleValue) {
          var info = _this2.getOptionInfoBySingleValue(singleValue);
          var content = info.label;
          var title = info.title || content;
          if (maxTagTextLength && typeof content === 'string' && content.length > maxTagTextLength) {
            content = content.slice(0, maxTagTextLength) + '...';
          }
          var disabled = _this2.isChildDisabled(singleValue);
          var choiceClassName = disabled ? prefixCls + '-selection__choice ' + prefixCls + '-selection__choice__disabled' : prefixCls + '-selection__choice';
          return react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
            'li',
            babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({
              style: _util__WEBPACK_IMPORTED_MODULE_14__["UNSELECTABLE_STYLE"]
            }, _util__WEBPACK_IMPORTED_MODULE_14__["UNSELECTABLE_ATTRIBUTE"], {
              onMouseDown: _util__WEBPACK_IMPORTED_MODULE_14__["preventDefaultEvent"],
              className: choiceClassName,
              key: singleValue,
              title: title
            }),
            react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
              'div',
              { className: prefixCls + '-selection__choice__content' },
              content
            ),
            disabled ? null : react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement('span', {
              className: prefixCls + '-selection__choice__remove',
              onClick: _this2.removeSelected.bind(_this2, singleValue)
            })
          );
        });
      }
      if (maxTagPlaceholderEl) {
        selectedValueNodes.push(maxTagPlaceholderEl);
      }
      selectedValueNodes.push(react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
        'li',
        {
          className: prefixCls + '-search ' + prefixCls + '-search--inline',
          key: '__input'
        },
        _this2.getInputElement()
      ));

      if (Object(_util__WEBPACK_IMPORTED_MODULE_14__["isMultipleOrTags"])(props) && choiceTransitionName) {
        innerNode = react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
          rc_animate__WEBPACK_IMPORTED_MODULE_9__["default"],
          {
            onLeave: _this2.onChoiceAnimationLeave,
            component: 'ul',
            transitionName: choiceTransitionName
          },
          selectedValueNodes
        );
      } else {
        innerNode = react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
          'ul',
          null,
          selectedValueNodes
        );
      }
    }
    return react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(
      'div',
      { className: className, ref: Object(_util__WEBPACK_IMPORTED_MODULE_14__["saveRef"])(_this2, 'topCtrlRef') },
      _this2.getPlaceholderElement(),
      innerNode
    );
  };
};

/* harmony default export */ __webpack_exports__["default"] = (Select);


Select.displayName = 'Select';

/***/ }),

/***/ "../node_modules/rc-select/es/SelectTrigger.js":
/*!*****************************************************!*\
  !*** ../node_modules/rc-select/es/SelectTrigger.js ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! babel-runtime/helpers/objectWithoutProperties */ "../node_modules/babel-runtime/helpers/objectWithoutProperties.js");
/* harmony import */ var babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! babel-runtime/helpers/extends */ "../node_modules/babel-runtime/helpers/extends.js");
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! babel-runtime/helpers/classCallCheck */ "../node_modules/babel-runtime/helpers/classCallCheck.js");
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! babel-runtime/helpers/possibleConstructorReturn */ "../node_modules/babel-runtime/helpers/possibleConstructorReturn.js");
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! babel-runtime/helpers/inherits */ "../node_modules/babel-runtime/helpers/inherits.js");
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var rc_trigger__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rc-trigger */ "../node_modules/rc-trigger/es/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! classnames */ "../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _DropdownMenu__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./DropdownMenu */ "../node_modules/rc-select/es/DropdownMenu.js");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react-dom */ "../node_modules/react-dom/index.js");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./util */ "../node_modules/rc-select/es/util.js");













rc_trigger__WEBPACK_IMPORTED_MODULE_5__["default"].displayName = 'Trigger';

var BUILT_IN_PLACEMENTS = {
  bottomLeft: {
    points: ['tl', 'bl'],
    offset: [0, 4],
    overflow: {
      adjustX: 0,
      adjustY: 1
    }
  },
  topLeft: {
    points: ['bl', 'tl'],
    offset: [0, -4],
    overflow: {
      adjustX: 0,
      adjustY: 1
    }
  }
};

var SelectTrigger = function (_React$Component) {
  babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_4___default()(SelectTrigger, _React$Component);

  function SelectTrigger() {
    var _temp, _this, _ret;

    babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_2___default()(this, SelectTrigger);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3___default()(this, _React$Component.call.apply(_React$Component, [this].concat(args))), _this), _this.state = {
      dropdownWidth: null
    }, _this.setDropdownWidth = function () {
      var width = react_dom__WEBPACK_IMPORTED_MODULE_10___default.a.findDOMNode(_this).offsetWidth;
      if (width !== _this.state.dropdownWidth) {
        _this.setState({ dropdownWidth: width });
      }
    }, _this.getInnerMenu = function () {
      return _this.dropdownMenuRef && _this.dropdownMenuRef.menuRef;
    }, _this.getPopupDOMNode = function () {
      return _this.triggerRef.getPopupDomNode();
    }, _this.getDropdownElement = function (newProps) {
      var props = _this.props;
      return react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement(_DropdownMenu__WEBPACK_IMPORTED_MODULE_9__["default"], babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_1___default()({
        ref: Object(_util__WEBPACK_IMPORTED_MODULE_11__["saveRef"])(_this, 'dropdownMenuRef')
      }, newProps, {
        prefixCls: _this.getDropdownPrefixCls(),
        onMenuSelect: props.onMenuSelect,
        onMenuDeselect: props.onMenuDeselect,
        onPopupScroll: props.onPopupScroll,
        value: props.value,
        backfillValue: props.backfillValue,
        firstActiveValue: props.firstActiveValue,
        defaultActiveFirstOption: props.defaultActiveFirstOption,
        dropdownMenuStyle: props.dropdownMenuStyle
      }));
    }, _this.getDropdownTransitionName = function () {
      var props = _this.props;
      var transitionName = props.transitionName;
      if (!transitionName && props.animation) {
        transitionName = _this.getDropdownPrefixCls() + '-' + props.animation;
      }
      return transitionName;
    }, _this.getDropdownPrefixCls = function () {
      return _this.props.prefixCls + '-dropdown';
    }, _temp), babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3___default()(_this, _ret);
  }

  SelectTrigger.prototype.componentDidMount = function componentDidMount() {
    this.setDropdownWidth();
  };

  SelectTrigger.prototype.componentDidUpdate = function componentDidUpdate() {
    this.setDropdownWidth();
  };

  SelectTrigger.prototype.render = function render() {
    var _popupClassName;

    var _props = this.props,
        onPopupFocus = _props.onPopupFocus,
        props = babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_0___default()(_props, ['onPopupFocus']);

    var multiple = props.multiple,
        visible = props.visible,
        inputValue = props.inputValue,
        dropdownAlign = props.dropdownAlign,
        disabled = props.disabled,
        showSearch = props.showSearch,
        dropdownClassName = props.dropdownClassName,
        dropdownStyle = props.dropdownStyle,
        dropdownMatchSelectWidth = props.dropdownMatchSelectWidth;

    var dropdownPrefixCls = this.getDropdownPrefixCls();
    var popupClassName = (_popupClassName = {}, _popupClassName[dropdownClassName] = !!dropdownClassName, _popupClassName[dropdownPrefixCls + '--' + (multiple ? 'multiple' : 'single')] = 1, _popupClassName);
    var popupElement = this.getDropdownElement({
      menuItems: props.options,
      onPopupFocus: onPopupFocus,
      multiple: multiple,
      inputValue: inputValue,
      visible: visible
    });
    var hideAction = void 0;
    if (disabled) {
      hideAction = [];
    } else if (Object(_util__WEBPACK_IMPORTED_MODULE_11__["isSingleMode"])(props) && !showSearch) {
      hideAction = ['click'];
    } else {
      hideAction = ['blur'];
    }
    var popupStyle = babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_1___default()({}, dropdownStyle);
    var widthProp = dropdownMatchSelectWidth ? 'width' : 'minWidth';
    if (this.state.dropdownWidth) {
      popupStyle[widthProp] = this.state.dropdownWidth + 'px';
    }

    return react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement(
      rc_trigger__WEBPACK_IMPORTED_MODULE_5__["default"],
      babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_1___default()({}, props, {
        showAction: disabled ? [] : this.props.showAction,
        hideAction: hideAction,
        ref: Object(_util__WEBPACK_IMPORTED_MODULE_11__["saveRef"])(this, 'triggerRef'),
        popupPlacement: 'bottomLeft',
        builtinPlacements: BUILT_IN_PLACEMENTS,
        prefixCls: dropdownPrefixCls,
        popupTransitionName: this.getDropdownTransitionName(),
        onPopupVisibleChange: props.onDropdownVisibleChange,
        popup: popupElement,
        popupAlign: dropdownAlign,
        popupVisible: visible,
        getPopupContainer: props.getPopupContainer,
        popupClassName: classnames__WEBPACK_IMPORTED_MODULE_8___default()(popupClassName),
        popupStyle: popupStyle
      }),
      props.children
    );
  };

  return SelectTrigger;
}(react__WEBPACK_IMPORTED_MODULE_6___default.a.Component);

SelectTrigger.propTypes = {
  onPopupFocus: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.func,
  onPopupScroll: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.func,
  dropdownMatchSelectWidth: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.bool,
  dropdownAlign: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.object,
  visible: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.bool,
  disabled: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.bool,
  showSearch: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.bool,
  dropdownClassName: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.string,
  multiple: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.bool,
  inputValue: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.string,
  filterOption: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.any,
  options: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.any,
  prefixCls: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.string,
  popupClassName: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.string,
  children: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.any,
  showAction: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.string)
};
/* harmony default export */ __webpack_exports__["default"] = (SelectTrigger);


SelectTrigger.displayName = 'SelectTrigger';

/***/ }),

/***/ "../node_modules/rc-select/es/index.js":
/*!*********************************************!*\
  !*** ../node_modules/rc-select/es/index.js ***!
  \*********************************************/
/*! exports provided: Option, OptGroup, SelectPropTypes, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Select__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Select */ "../node_modules/rc-select/es/Select.js");
/* harmony import */ var _Option__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Option */ "../node_modules/rc-select/es/Option.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Option", function() { return _Option__WEBPACK_IMPORTED_MODULE_1__["default"]; });

/* harmony import */ var _PropTypes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./PropTypes */ "../node_modules/rc-select/es/PropTypes.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SelectPropTypes", function() { return _PropTypes__WEBPACK_IMPORTED_MODULE_2__["SelectPropTypes"]; });

/* harmony import */ var _OptGroup__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./OptGroup */ "../node_modules/rc-select/es/OptGroup.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "OptGroup", function() { return _OptGroup__WEBPACK_IMPORTED_MODULE_3__["default"]; });





_Select__WEBPACK_IMPORTED_MODULE_0__["default"].Option = _Option__WEBPACK_IMPORTED_MODULE_1__["default"];
_Select__WEBPACK_IMPORTED_MODULE_0__["default"].OptGroup = _OptGroup__WEBPACK_IMPORTED_MODULE_3__["default"];

/* harmony default export */ __webpack_exports__["default"] = (_Select__WEBPACK_IMPORTED_MODULE_0__["default"]);

/***/ }),

/***/ "../node_modules/rc-select/es/util.js":
/*!********************************************!*\
  !*** ../node_modules/rc-select/es/util.js ***!
  \********************************************/
/*! exports provided: getValuePropValue, getPropValue, isMultiple, isCombobox, isMultipleOrTags, isMultipleOrTagsOrCombobox, isSingleMode, toArray, getMapKey, preventDefaultEvent, findIndexInValueBySingleValue, getLabelFromPropsValue, getSelectKeys, UNSELECTABLE_STYLE, UNSELECTABLE_ATTRIBUTE, findFirstMenuItem, includesSeparators, splitBySeparators, defaultFilterFn, validateOptionValue, saveRef */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getValuePropValue", function() { return getValuePropValue; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getPropValue", function() { return getPropValue; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isMultiple", function() { return isMultiple; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isCombobox", function() { return isCombobox; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isMultipleOrTags", function() { return isMultipleOrTags; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isMultipleOrTagsOrCombobox", function() { return isMultipleOrTagsOrCombobox; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isSingleMode", function() { return isSingleMode; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "toArray", function() { return toArray; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getMapKey", function() { return getMapKey; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "preventDefaultEvent", function() { return preventDefaultEvent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "findIndexInValueBySingleValue", function() { return findIndexInValueBySingleValue; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLabelFromPropsValue", function() { return getLabelFromPropsValue; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSelectKeys", function() { return getSelectKeys; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UNSELECTABLE_STYLE", function() { return UNSELECTABLE_STYLE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UNSELECTABLE_ATTRIBUTE", function() { return UNSELECTABLE_ATTRIBUTE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "findFirstMenuItem", function() { return findFirstMenuItem; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "includesSeparators", function() { return includesSeparators; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "splitBySeparators", function() { return splitBySeparators; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "defaultFilterFn", function() { return defaultFilterFn; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "validateOptionValue", function() { return validateOptionValue; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "saveRef", function() { return saveRef; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);


function getValuePropValue(child) {
  var props = child.props;
  if ('value' in props) {
    return props.value;
  }
  if (child.key) {
    return child.key;
  }
  if (child.type && child.type.isSelectOptGroup && props.label) {
    return props.label;
  }
  throw new Error('Need at least a key or a value or a label (only for OptGroup) for ' + child);
}

function getPropValue(child, prop) {
  if (prop === 'value') {
    return getValuePropValue(child);
  }
  return child.props[prop];
}

function isMultiple(props) {
  return props.multiple;
}

function isCombobox(props) {
  return props.combobox;
}

function isMultipleOrTags(props) {
  return props.multiple || props.tags;
}

function isMultipleOrTagsOrCombobox(props) {
  return isMultipleOrTags(props) || isCombobox(props);
}

function isSingleMode(props) {
  return !isMultipleOrTagsOrCombobox(props);
}

function toArray(value) {
  var ret = value;
  if (value === undefined) {
    ret = [];
  } else if (!Array.isArray(value)) {
    ret = [value];
  }
  return ret;
}

function getMapKey(value) {
  return typeof value + '-' + value;
}

function preventDefaultEvent(e) {
  e.preventDefault();
}

function findIndexInValueBySingleValue(value, singleValue) {
  var index = -1;
  for (var i = 0; i < value.length; i++) {
    if (value[i] === singleValue) {
      index = i;
      break;
    }
  }
  return index;
}

function getLabelFromPropsValue(value, key) {
  var label = void 0;
  value = toArray(value);
  for (var i = 0; i < value.length; i++) {
    if (value[i].key === key) {
      label = value[i].label;
      break;
    }
  }
  return label;
}

function getSelectKeys(menuItems, value) {
  if (value === null || value === undefined) {
    return [];
  }
  var selectedKeys = [];
  react__WEBPACK_IMPORTED_MODULE_0___default.a.Children.forEach(menuItems, function (item) {
    if (item.type.isMenuItemGroup) {
      selectedKeys = selectedKeys.concat(getSelectKeys(item.props.children, value));
    } else {
      var itemValue = getValuePropValue(item);
      var itemKey = item.key;
      if (findIndexInValueBySingleValue(value, itemValue) !== -1 && itemKey) {
        selectedKeys.push(itemKey);
      }
    }
  });
  return selectedKeys;
}

var UNSELECTABLE_STYLE = {
  userSelect: 'none',
  WebkitUserSelect: 'none'
};

var UNSELECTABLE_ATTRIBUTE = {
  unselectable: 'unselectable'
};

function findFirstMenuItem(children) {
  for (var i = 0; i < children.length; i++) {
    var child = children[i];
    if (child.type.isMenuItemGroup) {
      var found = findFirstMenuItem(child.props.children);
      if (found) {
        return found;
      }
    } else if (!child.props.disabled) {
      return child;
    }
  }
  return null;
}

function includesSeparators(string, separators) {
  for (var i = 0; i < separators.length; ++i) {
    if (string.lastIndexOf(separators[i]) > 0) {
      return true;
    }
  }
  return false;
}

function splitBySeparators(string, separators) {
  var reg = new RegExp('[' + separators.join() + ']');
  return string.split(reg).filter(function (token) {
    return token;
  });
}

function defaultFilterFn(input, child) {
  if (child.props.disabled) {
    return false;
  }
  var value = toArray(getPropValue(child, this.props.optionFilterProp)).join('');
  return value.toLowerCase().indexOf(input.toLowerCase()) > -1;
}

function validateOptionValue(value, props) {
  if (isSingleMode(props) || isMultiple(props)) {
    return;
  }
  if (typeof value !== 'string') {
    throw new Error('Invalid `value` of type `' + typeof value + '` supplied to Option, ' + 'expected `string` when `tags/combobox` is `true`.');
  }
}

function saveRef(instance, name) {
  return function (node) {
    instance[name] = node;
  };
}

/***/ }),

/***/ "../node_modules/rc-tabs/es/InkTabBarMixin.js":
/*!****************************************************!*\
  !*** ../node_modules/rc-tabs/es/InkTabBarMixin.js ***!
  \****************************************************/
/*! exports provided: getScroll, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getScroll", function() { return getScroll; });
/* harmony import */ var babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! babel-runtime/helpers/defineProperty */ "../node_modules/babel-runtime/helpers/defineProperty.js");
/* harmony import */ var babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./utils */ "../node_modules/rc-tabs/es/utils.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! classnames */ "../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);





var isDev = "development" !== 'production';

function getScroll(w, top) {
  var ret = w['page' + (top ? 'Y' : 'X') + 'Offset'];
  var method = 'scroll' + (top ? 'Top' : 'Left');
  if (typeof ret !== 'number') {
    var d = w.document;
    // ie6,7,8 standard mode
    ret = d.documentElement[method];
    if (typeof ret !== 'number') {
      // quirks mode
      ret = d.body[method];
    }
  }
  return ret;
}

function offset(elem) {
  var box = void 0;
  var x = void 0;
  var y = void 0;
  var doc = elem.ownerDocument;
  var body = doc.body;
  var docElem = doc && doc.documentElement;
  box = elem.getBoundingClientRect();
  x = box.left;
  y = box.top;
  x -= docElem.clientLeft || body.clientLeft || 0;
  y -= docElem.clientTop || body.clientTop || 0;
  var w = doc.defaultView || doc.parentWindow;
  x += getScroll(w);
  y += getScroll(w, true);
  return {
    left: x, top: y
  };
}

function _componentDidUpdate(component, init) {
  var styles = component.props.styles;

  var rootNode = component.root;
  var wrapNode = component.nav || rootNode;
  var containerOffset = offset(wrapNode);
  var inkBarNode = component.inkBar;
  var activeTab = component.activeTab;
  var inkBarNodeStyle = inkBarNode.style;
  var tabBarPosition = component.props.tabBarPosition;
  if (init) {
    // prevent mount animation
    inkBarNodeStyle.display = 'none';
  }
  if (activeTab) {
    var tabNode = activeTab;
    var tabOffset = offset(tabNode);
    var transformSupported = Object(_utils__WEBPACK_IMPORTED_MODULE_1__["isTransformSupported"])(inkBarNodeStyle);
    if (tabBarPosition === 'top' || tabBarPosition === 'bottom') {
      var left = tabOffset.left - containerOffset.left;
      var width = tabNode.offsetWidth;

      // If tabNode'width width equal to wrapNode'width when tabBarPosition is top or bottom
      // It means no css working, then ink bar should not have width until css is loaded
      // Fix https://github.com/ant-design/ant-design/issues/7564
      if (width === rootNode.offsetWidth) {
        width = 0;
      } else if (styles.inkBar && styles.inkBar.width !== undefined) {
        width = parseFloat(styles.inkBar.width, 10);
        if (width) {
          left = left + (tabNode.offsetWidth - width) / 2;
        }
      }
      // use 3d gpu to optimize render
      if (transformSupported) {
        Object(_utils__WEBPACK_IMPORTED_MODULE_1__["setTransform"])(inkBarNodeStyle, 'translate3d(' + left + 'px,0,0)');
        inkBarNodeStyle.width = width + 'px';
        inkBarNodeStyle.height = '';
      } else {
        inkBarNodeStyle.left = left + 'px';
        inkBarNodeStyle.top = '';
        inkBarNodeStyle.bottom = '';
        inkBarNodeStyle.right = wrapNode.offsetWidth - left - width + 'px';
      }
    } else {
      var top = tabOffset.top - containerOffset.top;
      var height = tabNode.offsetHeight;
      if (styles.inkBar && styles.inkBar.height !== undefined) {
        height = parseFloat(styles.inkBar.height, 10);
        if (height) {
          top = top + (tabNode.offsetHeight - height) / 2;
        }
      }
      if (transformSupported) {
        Object(_utils__WEBPACK_IMPORTED_MODULE_1__["setTransform"])(inkBarNodeStyle, 'translate3d(0,' + top + 'px,0)');
        inkBarNodeStyle.height = height + 'px';
        inkBarNodeStyle.width = '';
      } else {
        inkBarNodeStyle.left = '';
        inkBarNodeStyle.right = '';
        inkBarNodeStyle.top = top + 'px';
        inkBarNodeStyle.bottom = wrapNode.offsetHeight - top - height + 'px';
      }
    }
  }
  inkBarNodeStyle.display = activeTab ? 'block' : 'none';
}

/* harmony default export */ __webpack_exports__["default"] = ({
  getDefaultProps: function getDefaultProps() {
    return {
      inkBarAnimated: true
    };
  },
  componentDidUpdate: function componentDidUpdate() {
    _componentDidUpdate(this);
  },
  componentDidMount: function componentDidMount() {
    var _this = this;

    if (isDev) {
      // https://github.com/ant-design/ant-design/issues/8678
      this.timeout = setTimeout(function () {
        _componentDidUpdate(_this, true);
      }, 0);
    } else {
      _componentDidUpdate(this, true);
    }
  },
  componentWillUnmount: function componentWillUnmount() {
    clearTimeout(this.timeout);
  },
  getInkBarNode: function getInkBarNode() {
    var _classnames;

    var _props = this.props,
        prefixCls = _props.prefixCls,
        styles = _props.styles,
        inkBarAnimated = _props.inkBarAnimated;

    var className = prefixCls + '-ink-bar';
    var classes = classnames__WEBPACK_IMPORTED_MODULE_3___default()((_classnames = {}, babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(_classnames, className, true), babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(_classnames, inkBarAnimated ? className + '-animated' : className + '-no-animated', true), _classnames));
    return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement('div', {
      style: styles.inkBar,
      className: classes,
      key: 'inkBar',
      ref: this.saveRef('inkBar')
    });
  }
});

/***/ }),

/***/ "../node_modules/rc-tabs/es/KeyCode.js":
/*!*********************************************!*\
  !*** ../node_modules/rc-tabs/es/KeyCode.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  /**
   * LEFT
   */
  LEFT: 37, // also NUM_WEST
  /**
   * UP
   */
  UP: 38, // also NUM_NORTH
  /**
   * RIGHT
   */
  RIGHT: 39, // also NUM_EAST
  /**
   * DOWN
   */
  DOWN: 40 // also NUM_SOUTH
});

/***/ }),

/***/ "../node_modules/rc-tabs/es/RefMixin.js":
/*!**********************************************!*\
  !*** ../node_modules/rc-tabs/es/RefMixin.js ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  saveRef: function saveRef(name) {
    var _this = this;

    return function (node) {
      _this[name] = node;
    };
  }
});

/***/ }),

/***/ "../node_modules/rc-tabs/es/ScrollableInkTabBar.js":
/*!*********************************************************!*\
  !*** ../node_modules/rc-tabs/es/ScrollableInkTabBar.js ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var create_react_class__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! create-react-class */ "../node_modules/create-react-class/index.js");
/* harmony import */ var create_react_class__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(create_react_class__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _InkTabBarMixin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./InkTabBarMixin */ "../node_modules/rc-tabs/es/InkTabBarMixin.js");
/* harmony import */ var _ScrollableTabBarMixin__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ScrollableTabBarMixin */ "../node_modules/rc-tabs/es/ScrollableTabBarMixin.js");
/* harmony import */ var _TabBarMixin__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./TabBarMixin */ "../node_modules/rc-tabs/es/TabBarMixin.js");
/* harmony import */ var _RefMixin__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./RefMixin */ "../node_modules/rc-tabs/es/RefMixin.js");






var ScrollableInkTabBar = create_react_class__WEBPACK_IMPORTED_MODULE_0___default()({
  displayName: 'ScrollableInkTabBar',
  mixins: [_RefMixin__WEBPACK_IMPORTED_MODULE_4__["default"], _TabBarMixin__WEBPACK_IMPORTED_MODULE_3__["default"], _InkTabBarMixin__WEBPACK_IMPORTED_MODULE_1__["default"], _ScrollableTabBarMixin__WEBPACK_IMPORTED_MODULE_2__["default"]],
  render: function render() {
    var inkBarNode = this.getInkBarNode();
    var tabs = this.getTabs();
    var scrollbarNode = this.getScrollBarNode([inkBarNode, tabs]);
    return this.getRootNode(scrollbarNode);
  }
});

/* harmony default export */ __webpack_exports__["default"] = (ScrollableInkTabBar);

/***/ }),

/***/ "../node_modules/rc-tabs/es/ScrollableTabBarMixin.js":
/*!***********************************************************!*\
  !*** ../node_modules/rc-tabs/es/ScrollableTabBarMixin.js ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! babel-runtime/helpers/defineProperty */ "../node_modules/babel-runtime/helpers/defineProperty.js");
/* harmony import */ var babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! classnames */ "../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./utils */ "../node_modules/rc-tabs/es/utils.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var rc_util_es_Dom_addEventListener__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rc-util/es/Dom/addEventListener */ "../node_modules/rc-util/es/Dom/addEventListener.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! lodash/debounce */ "../node_modules/lodash/debounce.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_5__);







/* harmony default export */ __webpack_exports__["default"] = ({
  getDefaultProps: function getDefaultProps() {
    return {
      scrollAnimated: true,
      onPrevClick: function onPrevClick() {},
      onNextClick: function onNextClick() {}
    };
  },
  getInitialState: function getInitialState() {
    this.offset = 0;
    return {
      next: false,
      prev: false
    };
  },
  componentDidMount: function componentDidMount() {
    var _this = this;

    this.componentDidUpdate();
    this.debouncedResize = lodash_debounce__WEBPACK_IMPORTED_MODULE_5___default()(function () {
      _this.setNextPrev();
      _this.scrollToActiveTab();
    }, 200);
    this.resizeEvent = Object(rc_util_es_Dom_addEventListener__WEBPACK_IMPORTED_MODULE_4__["default"])(window, 'resize', this.debouncedResize);
  },
  componentDidUpdate: function componentDidUpdate(prevProps) {
    var props = this.props;
    if (prevProps && prevProps.tabBarPosition !== props.tabBarPosition) {
      this.setOffset(0);
      return;
    }
    var nextPrev = this.setNextPrev();
        
    if (this.isNextPrevShown(this.state) !== this.isNextPrevShown(nextPrev)) {
      this.setState({}, this.scrollToActiveTab);
    } else if (!prevProps || props.activeKey !== prevProps.activeKey) {
            this.scrollToActiveTab();
    }
  },
  componentWillUnmount: function componentWillUnmount() {
    if (this.resizeEvent) {
      this.resizeEvent.remove();
    }
    if (this.debouncedResize && this.debouncedResize.cancel) {
      this.debouncedResize.cancel();
    }
  },
  setNextPrev: function setNextPrev() {
    var navNode = this.nav;
    var navNodeWH = this.getScrollWH(navNode);
    var containerWH = this.getOffsetWH(this.container);
    var navWrapNodeWH = this.getOffsetWH(this.navWrap);
    var offset = this.offset;

    var minOffset = containerWH - navNodeWH;
    var _state = this.state,
        next = _state.next,
        prev = _state.prev;

    if (minOffset >= 0) {
      next = false;
      this.setOffset(0, false);
      offset = 0;
    } else if (minOffset < offset) {
      next = true;
    } else {
      next = false;
                        var realOffset = navWrapNodeWH - navNodeWH;
      this.setOffset(realOffset, false);
      offset = realOffset;
    }

    if (offset < 0) {
      prev = true;
    } else {
      prev = false;
    }

    this.setNext(next);
    this.setPrev(prev);
    return {
      next: next,
      prev: prev
    };
  },
  getOffsetWH: function getOffsetWH(node) {
    var tabBarPosition = this.props.tabBarPosition;
    var prop = 'offsetWidth';
    if (tabBarPosition === 'left' || tabBarPosition === 'right') {
      prop = 'offsetHeight';
    }
    return node[prop];
  },
  getScrollWH: function getScrollWH(node) {
    var tabBarPosition = this.props.tabBarPosition;
    var prop = 'scrollWidth';
    if (tabBarPosition === 'left' || tabBarPosition === 'right') {
      prop = 'scrollHeight';
    }
    return node[prop];
  },
  getOffsetLT: function getOffsetLT(node) {
    var tabBarPosition = this.props.tabBarPosition;
    var prop = 'left';
    if (tabBarPosition === 'left' || tabBarPosition === 'right') {
      prop = 'top';
    }
    return node.getBoundingClientRect()[prop];
  },
  setOffset: function setOffset(offset) {
    var checkNextPrev = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;

    var target = Math.min(0, offset);
    if (this.offset !== target) {
      this.offset = target;
      var navOffset = {};
      var tabBarPosition = this.props.tabBarPosition;
      var navStyle = this.nav.style;
      var transformSupported = Object(_utils__WEBPACK_IMPORTED_MODULE_2__["isTransformSupported"])(navStyle);
      if (tabBarPosition === 'left' || tabBarPosition === 'right') {
        if (transformSupported) {
          navOffset = {
            value: 'translate3d(0,' + target + 'px,0)'
          };
        } else {
          navOffset = {
            name: 'top',
            value: target + 'px'
          };
        }
      } else {
        if (transformSupported) {
          navOffset = {
            value: 'translate3d(' + target + 'px,0,0)'
          };
        } else {
          navOffset = {
            name: 'left',
            value: target + 'px'
          };
        }
      }
      if (transformSupported) {
        Object(_utils__WEBPACK_IMPORTED_MODULE_2__["setTransform"])(navStyle, navOffset.value);
      } else {
        navStyle[navOffset.name] = navOffset.value;
      }
      if (checkNextPrev) {
        this.setNextPrev();
      }
    }
  },
  setPrev: function setPrev(v) {
    if (this.state.prev !== v) {
      this.setState({
        prev: v
      });
    }
  },
  setNext: function setNext(v) {
    if (this.state.next !== v) {
      this.setState({
        next: v
      });
    }
  },
  isNextPrevShown: function isNextPrevShown(state) {
    if (state) {
      return state.next || state.prev;
    }
    return this.state.next || this.state.prev;
  },
  prevTransitionEnd: function prevTransitionEnd(e) {
    if (e.propertyName !== 'opacity') {
      return;
    }
    var container = this.container;

    this.scrollToActiveTab({
      target: container,
      currentTarget: container
    });
  },
  scrollToActiveTab: function scrollToActiveTab(e) {
    var activeTab = this.activeTab,
        navWrap = this.navWrap;

    if (e && e.target !== e.currentTarget || !activeTab) {
      return;
    }

        var needToSroll = this.isNextPrevShown() && this.lastNextPrevShown;
    this.lastNextPrevShown = this.isNextPrevShown();
    if (!needToSroll) {
      return;
    }

    var activeTabWH = this.getScrollWH(activeTab);
    var navWrapNodeWH = this.getOffsetWH(navWrap);
    var offset = this.offset;

    var wrapOffset = this.getOffsetLT(navWrap);
    var activeTabOffset = this.getOffsetLT(activeTab);
    if (wrapOffset > activeTabOffset) {
      offset += wrapOffset - activeTabOffset;
      this.setOffset(offset);
    } else if (wrapOffset + navWrapNodeWH < activeTabOffset + activeTabWH) {
      offset -= activeTabOffset + activeTabWH - (wrapOffset + navWrapNodeWH);
      this.setOffset(offset);
    }
  },
  prev: function prev(e) {
    this.props.onPrevClick(e);
    var navWrapNode = this.navWrap;
    var navWrapNodeWH = this.getOffsetWH(navWrapNode);
    var offset = this.offset;

    this.setOffset(offset + navWrapNodeWH);
  },
  next: function next(e) {
    this.props.onNextClick(e);
    var navWrapNode = this.navWrap;
    var navWrapNodeWH = this.getOffsetWH(navWrapNode);
    var offset = this.offset;

    this.setOffset(offset - navWrapNodeWH);
  },
  getScrollBarNode: function getScrollBarNode(content) {
    var _classnames, _classnames2, _classnames3, _classnames4;

    var _state2 = this.state,
        next = _state2.next,
        prev = _state2.prev;
    var _props = this.props,
        prefixCls = _props.prefixCls,
        scrollAnimated = _props.scrollAnimated;

    var showNextPrev = prev || next;

    var prevButton = react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(
      'span',
      {
        onClick: prev ? this.prev : null,
        unselectable: 'unselectable',
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()((_classnames = {}, babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(_classnames, prefixCls + '-tab-prev', 1), babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(_classnames, prefixCls + '-tab-btn-disabled', !prev), babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(_classnames, prefixCls + '-tab-arrow-show', showNextPrev), _classnames)),
        onTransitionEnd: this.prevTransitionEnd
      },
      react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement('span', { className: prefixCls + '-tab-prev-icon' })
    );

    var nextButton = react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(
      'span',
      {
        onClick: next ? this.next : null,
        unselectable: 'unselectable',
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()((_classnames2 = {}, babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(_classnames2, prefixCls + '-tab-next', 1), babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(_classnames2, prefixCls + '-tab-btn-disabled', !next), babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(_classnames2, prefixCls + '-tab-arrow-show', showNextPrev), _classnames2))
      },
      react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement('span', { className: prefixCls + '-tab-next-icon' })
    );

    var navClassName = prefixCls + '-nav';
    var navClasses = classnames__WEBPACK_IMPORTED_MODULE_1___default()((_classnames3 = {}, babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(_classnames3, navClassName, true), babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(_classnames3, scrollAnimated ? navClassName + '-animated' : navClassName + '-no-animated', true), _classnames3));

    return react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(
      'div',
      {
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()((_classnames4 = {}, babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(_classnames4, prefixCls + '-nav-container', 1), babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(_classnames4, prefixCls + '-nav-container-scrolling', showNextPrev), _classnames4)),
        key: 'container',
        ref: this.saveRef('container')
      },
      prevButton,
      nextButton,
      react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(
        'div',
        { className: prefixCls + '-nav-wrap', ref: this.saveRef('navWrap') },
        react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(
          'div',
          { className: prefixCls + '-nav-scroll' },
          react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(
            'div',
            { className: navClasses, ref: this.saveRef('nav') },
            content
          )
        )
      )
    );
  }
});

/***/ }),

/***/ "../node_modules/rc-tabs/es/TabBarMixin.js":
/*!*************************************************!*\
  !*** ../node_modules/rc-tabs/es/TabBarMixin.js ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! babel-runtime/helpers/defineProperty */ "../node_modules/babel-runtime/helpers/defineProperty.js");
/* harmony import */ var babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! babel-runtime/helpers/objectWithoutProperties */ "../node_modules/babel-runtime/helpers/objectWithoutProperties.js");
/* harmony import */ var babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! babel-runtime/helpers/extends */ "../node_modules/babel-runtime/helpers/extends.js");
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! classnames */ "../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var warning__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! warning */ "../node_modules/warning/browser.js");
/* harmony import */ var warning__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(warning__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./utils */ "../node_modules/rc-tabs/es/utils.js");








/* harmony default export */ __webpack_exports__["default"] = ({
  getDefaultProps: function getDefaultProps() {
    return {
      styles: {}
    };
  },
  onTabClick: function onTabClick(key) {
    this.props.onTabClick(key);
  },
  getTabs: function getTabs() {
    var _this = this;

    var _props = this.props,
        children = _props.panels,
        activeKey = _props.activeKey,
        prefixCls = _props.prefixCls,
        tabBarGutter = _props.tabBarGutter;

    var rst = [];

    react__WEBPACK_IMPORTED_MODULE_3___default.a.Children.forEach(children, function (child, index) {
      if (!child) {
        return;
      }
      var key = child.key;
      var cls = activeKey === key ? prefixCls + '-tab-active' : '';
      cls += ' ' + prefixCls + '-tab';
      var events = {};
      if (child.props.disabled) {
        cls += ' ' + prefixCls + '-tab-disabled';
      } else {
        events = {
          onClick: _this.onTabClick.bind(_this, key)
        };
      }
      var ref = {};
      if (activeKey === key) {
        ref.ref = _this.saveRef('activeTab');
      }
      warning__WEBPACK_IMPORTED_MODULE_5___default()('tab' in child.props, 'There must be `tab` property on children of Tabs.');
      rst.push(react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(
        'div',
        babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_2___default()({
          role: 'tab',
          'aria-disabled': child.props.disabled ? 'true' : 'false',
          'aria-selected': activeKey === key ? 'true' : 'false'
        }, events, {
          className: cls,
          key: key,
          style: { marginRight: tabBarGutter && index === children.length - 1 ? 0 : tabBarGutter }
        }, ref),
        child.props.tab
      ));
    });

    return rst;
  },
  getRootNode: function getRootNode(contents) {
    var _props2 = this.props,
        prefixCls = _props2.prefixCls,
        onKeyDown = _props2.onKeyDown,
        className = _props2.className,
        extraContent = _props2.extraContent,
        style = _props2.style,
        tabBarPosition = _props2.tabBarPosition,
        restProps = babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1___default()(_props2, ['prefixCls', 'onKeyDown', 'className', 'extraContent', 'style', 'tabBarPosition']);

    var cls = classnames__WEBPACK_IMPORTED_MODULE_4___default()(prefixCls + '-bar', babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()({}, className, !!className));
    var topOrBottom = tabBarPosition === 'top' || tabBarPosition === 'bottom';
    var tabBarExtraContentStyle = topOrBottom ? { float: 'right' } : {};
    var extraContentStyle = extraContent && extraContent.props ? extraContent.props.style : {};
    var children = contents;
    if (extraContent) {
      children = [Object(react__WEBPACK_IMPORTED_MODULE_3__["cloneElement"])(extraContent, {
        key: 'extra',
        style: babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_2___default()({}, tabBarExtraContentStyle, extraContentStyle)
      }), Object(react__WEBPACK_IMPORTED_MODULE_3__["cloneElement"])(contents, { key: 'content' })];
      children = topOrBottom ? children : children.reverse();
    }
    return react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(
      'div',
      babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_2___default()({
        role: 'tablist',
        className: cls,
        tabIndex: '0',
        ref: this.saveRef('root'),
        onKeyDown: onKeyDown,
        style: style
      }, Object(_utils__WEBPACK_IMPORTED_MODULE_6__["getDataAttr"])(restProps)),
      children
    );
  }
});

/***/ }),

/***/ "../node_modules/rc-tabs/es/TabContent.js":
/*!************************************************!*\
  !*** ../node_modules/rc-tabs/es/TabContent.js ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! babel-runtime/helpers/extends */ "../node_modules/babel-runtime/helpers/extends.js");
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! babel-runtime/helpers/defineProperty */ "../node_modules/babel-runtime/helpers/defineProperty.js");
/* harmony import */ var babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var create_react_class__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! create-react-class */ "../node_modules/create-react-class/index.js");
/* harmony import */ var create_react_class__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(create_react_class__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! classnames */ "../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./utils */ "../node_modules/rc-tabs/es/utils.js");








var TabContent = create_react_class__WEBPACK_IMPORTED_MODULE_3___default()({
  displayName: 'TabContent',
  propTypes: {
    animated: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.bool,
    animatedWithMargin: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.bool,
    prefixCls: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.string,
    children: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.any,
    activeKey: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.string,
    style: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.any,
    tabBarPosition: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.string
  },
  getDefaultProps: function getDefaultProps() {
    return {
      animated: true
    };
  },
  getTabPanes: function getTabPanes() {
    var props = this.props;
    var activeKey = props.activeKey;
    var children = props.children;
    var newChildren = [];

    react__WEBPACK_IMPORTED_MODULE_2___default.a.Children.forEach(children, function (child) {
      if (!child) {
        return;
      }
      var key = child.key;
      var active = activeKey === key;
      newChildren.push(react__WEBPACK_IMPORTED_MODULE_2___default.a.cloneElement(child, {
        active: active,
        destroyInactiveTabPane: props.destroyInactiveTabPane,
        rootPrefixCls: props.prefixCls
      }));
    });

    return newChildren;
  },
  render: function render() {
    var _classnames;

    var props = this.props;
    var prefixCls = props.prefixCls,
        children = props.children,
        activeKey = props.activeKey,
        tabBarPosition = props.tabBarPosition,
        animated = props.animated,
        animatedWithMargin = props.animatedWithMargin;
    var style = props.style;

    var classes = classnames__WEBPACK_IMPORTED_MODULE_5___default()((_classnames = {}, babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(_classnames, prefixCls + '-content', true), babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(_classnames, animated ? prefixCls + '-content-animated' : prefixCls + '-content-no-animated', true), _classnames));
    if (animated) {
      var activeIndex = Object(_utils__WEBPACK_IMPORTED_MODULE_6__["getActiveIndex"])(children, activeKey);
      if (activeIndex !== -1) {
        var animatedStyle = animatedWithMargin ? Object(_utils__WEBPACK_IMPORTED_MODULE_6__["getMarginStyle"])(activeIndex, tabBarPosition) : Object(_utils__WEBPACK_IMPORTED_MODULE_6__["getTransformPropValue"])(Object(_utils__WEBPACK_IMPORTED_MODULE_6__["getTransformByIndex"])(activeIndex, tabBarPosition));
        style = babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({}, style, animatedStyle);
      } else {
        style = babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({}, style, {
          display: 'none'
        });
      }
    }
    return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(
      'div',
      {
        className: classes,
        style: style
      },
      this.getTabPanes()
    );
  }
});

/* harmony default export */ __webpack_exports__["default"] = (TabContent);

/***/ }),

/***/ "../node_modules/rc-tabs/es/TabPane.js":
/*!*********************************************!*\
  !*** ../node_modules/rc-tabs/es/TabPane.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! babel-runtime/helpers/extends */ "../node_modules/babel-runtime/helpers/extends.js");
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! babel-runtime/helpers/defineProperty */ "../node_modules/babel-runtime/helpers/defineProperty.js");
/* harmony import */ var babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! babel-runtime/helpers/objectWithoutProperties */ "../node_modules/babel-runtime/helpers/objectWithoutProperties.js");
/* harmony import */ var babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var create_react_class__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! create-react-class */ "../node_modules/create-react-class/index.js");
/* harmony import */ var create_react_class__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(create_react_class__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! classnames */ "../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./utils */ "../node_modules/rc-tabs/es/utils.js");









var TabPane = create_react_class__WEBPACK_IMPORTED_MODULE_5___default()({
  displayName: 'TabPane',
  propTypes: {
    className: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.string,
    active: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.bool,
    style: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.any,
    destroyInactiveTabPane: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.bool,
    forceRender: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.bool,
    placeholder: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.node
  },
  getDefaultProps: function getDefaultProps() {
    return { placeholder: null };
  },
  render: function render() {
    var _classnames;

    var _props = this.props,
        className = _props.className,
        destroyInactiveTabPane = _props.destroyInactiveTabPane,
        active = _props.active,
        forceRender = _props.forceRender,
        rootPrefixCls = _props.rootPrefixCls,
        style = _props.style,
        children = _props.children,
        placeholder = _props.placeholder,
        restProps = babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_2___default()(_props, ['className', 'destroyInactiveTabPane', 'active', 'forceRender', 'rootPrefixCls', 'style', 'children', 'placeholder']);

    this._isActived = this._isActived || active;
    var prefixCls = rootPrefixCls + '-tabpane';
    var cls = classnames__WEBPACK_IMPORTED_MODULE_6___default()((_classnames = {}, babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(_classnames, prefixCls, 1), babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(_classnames, prefixCls + '-inactive', !active), babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(_classnames, prefixCls + '-active', active), babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(_classnames, className, className), _classnames));
    var isRender = destroyInactiveTabPane ? active : this._isActived;
    return react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(
      'div',
      babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({
        style: style,
        role: 'tabpanel',
        'aria-hidden': active ? 'false' : 'true',
        className: cls
      }, Object(_utils__WEBPACK_IMPORTED_MODULE_7__["getDataAttr"])(restProps)),
      isRender || forceRender ? children : placeholder
    );
  }
});

/* harmony default export */ __webpack_exports__["default"] = (TabPane);

/***/ }),

/***/ "../node_modules/rc-tabs/es/Tabs.js":
/*!******************************************!*\
  !*** ../node_modules/rc-tabs/es/Tabs.js ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! babel-runtime/helpers/extends */ "../node_modules/babel-runtime/helpers/extends.js");
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! babel-runtime/helpers/defineProperty */ "../node_modules/babel-runtime/helpers/defineProperty.js");
/* harmony import */ var babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! babel-runtime/helpers/objectWithoutProperties */ "../node_modules/babel-runtime/helpers/objectWithoutProperties.js");
/* harmony import */ var babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! babel-runtime/helpers/classCallCheck */ "../node_modules/babel-runtime/helpers/classCallCheck.js");
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! babel-runtime/helpers/createClass */ "../node_modules/babel-runtime/helpers/createClass.js");
/* harmony import */ var babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! babel-runtime/helpers/possibleConstructorReturn */ "../node_modules/babel-runtime/helpers/possibleConstructorReturn.js");
/* harmony import */ var babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! babel-runtime/helpers/inherits */ "../node_modules/babel-runtime/helpers/inherits.js");
/* harmony import */ var babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! prop-types */ "../node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _KeyCode__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./KeyCode */ "../node_modules/rc-tabs/es/KeyCode.js");
/* harmony import */ var _TabPane__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./TabPane */ "../node_modules/rc-tabs/es/TabPane.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! classnames */ "../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./utils */ "../node_modules/rc-tabs/es/utils.js");














function noop() {}

function getDefaultActiveKey(props) {
  var activeKey = void 0;
  react__WEBPACK_IMPORTED_MODULE_7___default.a.Children.forEach(props.children, function (child) {
    if (child && !activeKey && !child.props.disabled) {
      activeKey = child.key;
    }
  });
  return activeKey;
}

function activeKeyIsValid(props, key) {
  var keys = react__WEBPACK_IMPORTED_MODULE_7___default.a.Children.map(props.children, function (child) {
    return child && child.key;
  });
  return keys.indexOf(key) >= 0;
}

var Tabs = function (_React$Component) {
  babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_6___default()(Tabs, _React$Component);

  function Tabs(props) {
    babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_3___default()(this, Tabs);

    var _this = babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5___default()(this, (Tabs.__proto__ || Object.getPrototypeOf(Tabs)).call(this, props));

    _initialiseProps.call(_this);

    var activeKey = void 0;
    if ('activeKey' in props) {
      activeKey = props.activeKey;
    } else if ('defaultActiveKey' in props) {
      activeKey = props.defaultActiveKey;
    } else {
      activeKey = getDefaultActiveKey(props);
    }

    _this.state = {
      activeKey: activeKey
    };
    return _this;
  }

  babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_4___default()(Tabs, [{
    key: 'componentWillReceiveProps',
    value: function componentWillReceiveProps(nextProps) {
      if ('activeKey' in nextProps) {
        this.setState({
          activeKey: nextProps.activeKey
        });
      } else if (!activeKeyIsValid(nextProps, this.state.activeKey)) {
        // https://github.com/ant-design/ant-design/issues/7093
        this.setState({
          activeKey: getDefaultActiveKey(nextProps)
        });
      }
    }
  }, {
    key: 'render',
    value: function render() {
      var _classnames;

      var props = this.props;

      var prefixCls = props.prefixCls,
          tabBarPosition = props.tabBarPosition,
          className = props.className,
          renderTabContent = props.renderTabContent,
          renderTabBar = props.renderTabBar,
          destroyInactiveTabPane = props.destroyInactiveTabPane,
          restProps = babel_runtime_helpers_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_2___default()(props, ['prefixCls', 'tabBarPosition', 'className', 'renderTabContent', 'renderTabBar', 'destroyInactiveTabPane']);

      var cls = classnames__WEBPACK_IMPORTED_MODULE_11___default()((_classnames = {}, babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(_classnames, prefixCls, 1), babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(_classnames, prefixCls + '-' + tabBarPosition, 1), babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(_classnames, className, !!className), _classnames));

      this.tabBar = renderTabBar();
      var contents = [react__WEBPACK_IMPORTED_MODULE_7___default.a.cloneElement(this.tabBar, {
        prefixCls: prefixCls,
        key: 'tabBar',
        onKeyDown: this.onNavKeyDown,
        tabBarPosition: tabBarPosition,
        onTabClick: this.onTabClick,
        panels: props.children,
        activeKey: this.state.activeKey
      }), react__WEBPACK_IMPORTED_MODULE_7___default.a.cloneElement(renderTabContent(), {
        prefixCls: prefixCls,
        tabBarPosition: tabBarPosition,
        activeKey: this.state.activeKey,
        destroyInactiveTabPane: destroyInactiveTabPane,
        children: props.children,
        onChange: this.setActiveKey,
        key: 'tabContent'
      })];
      if (tabBarPosition === 'bottom') {
        contents.reverse();
      }
      return react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(
        'div',
        babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({
          className: cls,
          style: props.style
        }, Object(_utils__WEBPACK_IMPORTED_MODULE_12__["getDataAttr"])(restProps)),
        contents
      );
    }
  }]);

  return Tabs;
}(react__WEBPACK_IMPORTED_MODULE_7___default.a.Component);

var _initialiseProps = function _initialiseProps() {
  var _this2 = this;

  this.onTabClick = function (activeKey) {
    if (_this2.tabBar.props.onTabClick) {
      _this2.tabBar.props.onTabClick(activeKey);
    }
    _this2.setActiveKey(activeKey);
  };

  this.onNavKeyDown = function (e) {
    var eventKeyCode = e.keyCode;
    if (eventKeyCode === _KeyCode__WEBPACK_IMPORTED_MODULE_9__["default"].RIGHT || eventKeyCode === _KeyCode__WEBPACK_IMPORTED_MODULE_9__["default"].DOWN) {
      e.preventDefault();
      var nextKey = _this2.getNextActiveKey(true);
      _this2.onTabClick(nextKey);
    } else if (eventKeyCode === _KeyCode__WEBPACK_IMPORTED_MODULE_9__["default"].LEFT || eventKeyCode === _KeyCode__WEBPACK_IMPORTED_MODULE_9__["default"].UP) {
      e.preventDefault();
      var previousKey = _this2.getNextActiveKey(false);
      _this2.onTabClick(previousKey);
    }
  };

  this.setActiveKey = function (activeKey) {
    if (_this2.state.activeKey !== activeKey) {
      if (!('activeKey' in _this2.props)) {
        _this2.setState({
          activeKey: activeKey
        });
      }
      _this2.props.onChange(activeKey);
    }
  };

  this.getNextActiveKey = function (next) {
    var activeKey = _this2.state.activeKey;
    var children = [];
    react__WEBPACK_IMPORTED_MODULE_7___default.a.Children.forEach(_this2.props.children, function (c) {
      if (c && !c.props.disabled) {
        if (next) {
          children.push(c);
        } else {
          children.unshift(c);
        }
      }
    });
    var length = children.length;
    var ret = length && children[0].key;
    children.forEach(function (child, i) {
      if (child.key === activeKey) {
        if (i === length - 1) {
          ret = children[0].key;
        } else {
          ret = children[i + 1].key;
        }
      }
    });
    return ret;
  };
};

/* harmony default export */ __webpack_exports__["default"] = (Tabs);


Tabs.propTypes = {
  destroyInactiveTabPane: prop_types__WEBPACK_IMPORTED_MODULE_8___default.a.bool,
  renderTabBar: prop_types__WEBPACK_IMPORTED_MODULE_8___default.a.func.isRequired,
  renderTabContent: prop_types__WEBPACK_IMPORTED_MODULE_8___default.a.func.isRequired,
  onChange: prop_types__WEBPACK_IMPORTED_MODULE_8___default.a.func,
  children: prop_types__WEBPACK_IMPORTED_MODULE_8___default.a.any,
  prefixCls: prop_types__WEBPACK_IMPORTED_MODULE_8___default.a.string,
  className: prop_types__WEBPACK_IMPORTED_MODULE_8___default.a.string,
  tabBarPosition: prop_types__WEBPACK_IMPORTED_MODULE_8___default.a.string,
  style: prop_types__WEBPACK_IMPORTED_MODULE_8___default.a.object,
  activeKey: prop_types__WEBPACK_IMPORTED_MODULE_8___default.a.string,
  defaultActiveKey: prop_types__WEBPACK_IMPORTED_MODULE_8___default.a.string
};

Tabs.defaultProps = {
  prefixCls: 'rc-tabs',
  destroyInactiveTabPane: false,
  onChange: noop,
  tabBarPosition: 'top',
  style: {}
};

Tabs.TabPane = _TabPane__WEBPACK_IMPORTED_MODULE_10__["default"];

/***/ }),

/***/ "../node_modules/rc-tabs/es/index.js":
/*!*******************************************!*\
  !*** ../node_modules/rc-tabs/es/index.js ***!
  \*******************************************/
/*! exports provided: default, TabPane, TabContent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Tabs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Tabs */ "../node_modules/rc-tabs/es/Tabs.js");
/* harmony import */ var _TabPane__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TabPane */ "../node_modules/rc-tabs/es/TabPane.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "TabPane", function() { return _TabPane__WEBPACK_IMPORTED_MODULE_1__["default"]; });

/* harmony import */ var _TabContent__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./TabContent */ "../node_modules/rc-tabs/es/TabContent.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "TabContent", function() { return _TabContent__WEBPACK_IMPORTED_MODULE_2__["default"]; });





/* harmony default export */ __webpack_exports__["default"] = (_Tabs__WEBPACK_IMPORTED_MODULE_0__["default"]);


/***/ }),

/***/ "../node_modules/rc-tabs/es/utils.js":
/*!*******************************************!*\
  !*** ../node_modules/rc-tabs/es/utils.js ***!
  \*******************************************/
/*! exports provided: toArray, getActiveIndex, getActiveKey, setTransform, isTransformSupported, setTransition, getTransformPropValue, isVertical, getTransformByIndex, getMarginStyle, getStyle, setPxStyle, getDataAttr */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "toArray", function() { return toArray; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getActiveIndex", function() { return getActiveIndex; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getActiveKey", function() { return getActiveKey; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setTransform", function() { return setTransform; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isTransformSupported", function() { return isTransformSupported; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setTransition", function() { return setTransition; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getTransformPropValue", function() { return getTransformPropValue; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isVertical", function() { return isVertical; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getTransformByIndex", function() { return getTransformByIndex; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getMarginStyle", function() { return getMarginStyle; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getStyle", function() { return getStyle; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setPxStyle", function() { return setPxStyle; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getDataAttr", function() { return getDataAttr; });
/* harmony import */ var babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! babel-runtime/helpers/defineProperty */ "../node_modules/babel-runtime/helpers/defineProperty.js");
/* harmony import */ var babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);



function toArray(children) {
  // allow [c,[a,b]]
  var c = [];
  react__WEBPACK_IMPORTED_MODULE_1___default.a.Children.forEach(children, function (child) {
    if (child) {
      c.push(child);
    }
  });
  return c;
}

function getActiveIndex(children, activeKey) {
  var c = toArray(children);
  for (var i = 0; i < c.length; i++) {
    if (c[i].key === activeKey) {
      return i;
    }
  }
  return -1;
}

function getActiveKey(children, index) {
  var c = toArray(children);
  return c[index].key;
}

function setTransform(style, v) {
  style.transform = v;
  style.webkitTransform = v;
  style.mozTransform = v;
}

function isTransformSupported(style) {
  return 'transform' in style || 'webkitTransform' in style || 'MozTransform' in style;
}

function setTransition(style, v) {
  style.transition = v;
  style.webkitTransition = v;
  style.MozTransition = v;
}
function getTransformPropValue(v) {
  return {
    transform: v,
    WebkitTransform: v,
    MozTransform: v
  };
}

function isVertical(tabBarPosition) {
  return tabBarPosition === 'left' || tabBarPosition === 'right';
}

function getTransformByIndex(index, tabBarPosition) {
  var translate = isVertical(tabBarPosition) ? 'translateY' : 'translateX';
  return translate + '(' + -index * 100 + '%) translateZ(0)';
}

function getMarginStyle(index, tabBarPosition) {
  var marginDirection = isVertical(tabBarPosition) ? 'marginTop' : 'marginLeft';
  return babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()({}, marginDirection, -index * 100 + '%');
}

function getStyle(el, property) {
  return +getComputedStyle(el).getPropertyValue(property).replace('px', '');
}

function setPxStyle(el, value, vertical) {
  value = vertical ? '0px, ' + value + 'px, 0px' : value + 'px, 0px, 0px';
  setTransform(el.style, 'translate3d(' + value + ')');
}

function getDataAttr(props) {
  return Object.keys(props).reduce(function (prev, key) {
    if (key.substr(0, 5) === 'aria-' || key.substr(0, 5) === 'data-' || key === 'role') {
      prev[key] = props[key];
    }
    return prev;
  }, {});
}

/***/ }),

/***/ "../node_modules/rc-util/es/Children/toArray.js":
/*!******************************************************!*\
  !*** ../node_modules/rc-util/es/Children/toArray.js ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return toArray; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);


function toArray(children) {
  var ret = [];
  react__WEBPACK_IMPORTED_MODULE_0___default.a.Children.forEach(children, function (c) {
    ret.push(c);
  });
  return ret;
}

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2FudGQvZXMvY2FyZC9zdHlsZS9pbmRleC5jc3M/OTYxNCIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2FudGQvZXMvcGFnaW5hdGlvbi9zdHlsZS9pbmRleC5jc3M/MmYxMiIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2FudGQvZXMvc2VsZWN0L3N0eWxlL2luZGV4LmNzcz81ZDU1Iiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvYW50ZC9lcy9zcGluL3N0eWxlL2luZGV4LmNzcz82NmU1Iiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvYW50ZC9lcy90YWJzL3N0eWxlL2luZGV4LmNzcz9mYmMwIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvYW50ZC9lcy9jYXJkL3N0eWxlL2luZGV4LmNzcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2FudGQvZXMvcGFnaW5hdGlvbi9zdHlsZS9pbmRleC5jc3MiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9hbnRkL2VzL3NlbGVjdC9zdHlsZS9pbmRleC5jc3MiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9hbnRkL2VzL3NwaW4vc3R5bGUvaW5kZXguY3NzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvYW50ZC9lcy90YWJzL3N0eWxlL2luZGV4LmNzcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2xvZGFzaC9kZWJvdW5jZS5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2xvZGFzaC9ub3cuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9sb2Rhc2gvdG9OdW1iZXIuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9yYy1jYWxlbmRhci9lcy9sb2NhbGUvZW5fVVMuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9yYy1wYWdpbmF0aW9uL2VzL0tleUNvZGUuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9yYy1wYWdpbmF0aW9uL2VzL09wdGlvbnMuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9yYy1wYWdpbmF0aW9uL2VzL1BhZ2VyLmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvcmMtcGFnaW5hdGlvbi9lcy9QYWdpbmF0aW9uLmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvcmMtcGFnaW5hdGlvbi9lcy9sb2NhbGUvZW5fVVMuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9yYy1wYWdpbmF0aW9uL2VzL2xvY2FsZS96aF9DTi5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL3JjLXNlbGVjdC9lcy9Ecm9wZG93bk1lbnUuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9yYy1zZWxlY3QvZXMvT3B0R3JvdXAuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9yYy1zZWxlY3QvZXMvT3B0aW9uLmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvcmMtc2VsZWN0L2VzL1Byb3BUeXBlcy5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL3JjLXNlbGVjdC9lcy9TZWxlY3QuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9yYy1zZWxlY3QvZXMvU2VsZWN0VHJpZ2dlci5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL3JjLXNlbGVjdC9lcy9pbmRleC5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL3JjLXNlbGVjdC9lcy91dGlsLmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvcmMtdGFicy9lcy9JbmtUYWJCYXJNaXhpbi5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL3JjLXRhYnMvZXMvS2V5Q29kZS5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL3JjLXRhYnMvZXMvUmVmTWl4aW4uanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9yYy10YWJzL2VzL1Njcm9sbGFibGVJbmtUYWJCYXIuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9yYy10YWJzL2VzL1Njcm9sbGFibGVUYWJCYXJNaXhpbi5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL3JjLXRhYnMvZXMvVGFiQmFyTWl4aW4uanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9yYy10YWJzL2VzL1RhYkNvbnRlbnQuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9yYy10YWJzL2VzL1RhYlBhbmUuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9yYy10YWJzL2VzL1RhYnMuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9yYy10YWJzL2VzL2luZGV4LmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvcmMtdGFicy9lcy91dGlscy5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL3JjLXV0aWwvZXMvQ2hpbGRyZW4vdG9BcnJheS5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTs7OztBQUlBLGVBQWU7O0FBRWY7QUFDQTs7QUFFQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBLEdBQUc7O0FBRUg7O0FBRUE7QUFDQSxFQUFFOztBQUVGLGdDQUFnQyxVQUFVLEVBQUU7QUFDNUMsQzs7Ozs7Ozs7Ozs7O0FDM0NBOztBQUVBOztBQUVBO0FBQ0E7Ozs7QUFJQSxlQUFlOztBQUVmO0FBQ0E7O0FBRUE7O0FBRUE7O0FBRUE7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQSxHQUFHOztBQUVIOztBQUVBO0FBQ0EsRUFBRTs7QUFFRixnQ0FBZ0MsVUFBVSxFQUFFO0FBQzVDLEM7Ozs7Ozs7Ozs7OztBQzNDQTs7QUFFQTs7QUFFQTtBQUNBOzs7O0FBSUEsZUFBZTs7QUFFZjtBQUNBOztBQUVBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0EsR0FBRzs7QUFFSDs7QUFFQTtBQUNBLEVBQUU7O0FBRUYsZ0NBQWdDLFVBQVUsRUFBRTtBQUM1QyxDOzs7Ozs7Ozs7Ozs7QUMzQ0E7O0FBRUE7O0FBRUE7QUFDQTs7OztBQUlBLGVBQWU7O0FBRWY7QUFDQTs7QUFFQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBLEdBQUc7O0FBRUg7O0FBRUE7QUFDQSxFQUFFOztBQUVGLGdDQUFnQyxVQUFVLEVBQUU7QUFDNUMsQzs7Ozs7Ozs7Ozs7O0FDM0NBOztBQUVBOztBQUVBO0FBQ0E7Ozs7QUFJQSxlQUFlOztBQUVmO0FBQ0E7O0FBRUE7O0FBRUE7O0FBRUE7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQSxHQUFHOztBQUVIOztBQUVBO0FBQ0EsRUFBRTs7QUFFRixnQ0FBZ0MsVUFBVSxFQUFFO0FBQzVDLEM7Ozs7Ozs7Ozs7O0FDNUNBO0FBQ0E7OztBQUdBO0FBQ0EsaVdBQWtXLGlPQUFpTyxvQkFBb0IscUJBQXFCLCtCQUErQixtQ0FBbUMsbUNBQW1DLGNBQWMsZUFBZSxxQkFBcUIscUJBQXFCLHVCQUF1Qix1QkFBdUIsZ0NBQWdDLHdCQUF3QixHQUFHLHVCQUF1QixvQkFBb0IsR0FBRyw2QkFBNkIsc0RBQXNELHNEQUFzRCxzQ0FBc0MsR0FBRyxzQkFBc0IsOEJBQThCLEdBQUcsa0JBQWtCLHFCQUFxQixxQ0FBcUMsb0JBQW9CLCtCQUErQixZQUFZLHdCQUF3QixxQkFBcUIsR0FBRyxnREFBZ0QsbUJBQW1CLG1CQUFtQixHQUFHLHdCQUF3QixnQkFBZ0IsdUJBQXVCLGlCQUFpQixjQUFjLEdBQUcsMEJBQTBCLHlCQUF5QiwwQkFBMEIseUJBQXlCLGtCQUFrQixHQUFHLHdCQUF3QixvQkFBb0Isb0JBQW9CLDRCQUE0QixxQkFBcUIsd0JBQXdCLCtCQUErQixxQkFBcUIsMEJBQTBCLHdCQUF3QixvQkFBb0Isb0JBQW9CLG9CQUFvQixHQUFHLDRCQUE0Qix5QkFBeUIsZ0JBQWdCLEdBQUcsZ0NBQWdDLHFDQUFxQyxHQUFHLG1CQUFtQixpQkFBaUIsc0JBQXNCLHNCQUFzQixzQkFBc0IsR0FBRyxrQkFBa0Isa0JBQWtCLFlBQVksR0FBRyxnREFBZ0QsbUJBQW1CLG1CQUFtQixHQUFHLHdCQUF3QixnQkFBZ0IsdUJBQXVCLGlCQUFpQixjQUFjLEdBQUcsaURBQWlELDBCQUEwQixlQUFlLEdBQUcsa0JBQWtCLHFCQUFxQixjQUFjLG9JQUFvSSxvSUFBb0ksa0JBQWtCLGdCQUFnQixrQkFBa0IsZ0NBQWdDLHdCQUF3QixHQUFHLHdCQUF3Qix1QkFBdUIsZUFBZSxzREFBc0Qsc0RBQXNELEdBQUcsK0NBQStDLHNCQUFzQixxQkFBcUIsR0FBRywwQ0FBMEMsc0JBQXNCLEdBQUcsdUJBQXVCLGdCQUFnQixtQkFBbUIsR0FBRyxxQkFBcUIsa0NBQWtDLHdCQUF3QixZQUFZLHFCQUFxQixjQUFjLGVBQWUsR0FBRyxzREFBc0QsbUJBQW1CLG1CQUFtQixHQUFHLDJCQUEyQixnQkFBZ0IsdUJBQXVCLGlCQUFpQixjQUFjLEdBQUcsMEJBQTBCLGdCQUFnQix1QkFBdUIsbUJBQW1CLCtCQUErQixHQUFHLGlDQUFpQywwQkFBMEIsb0JBQW9CLG9CQUFvQixzQkFBc0Isb0JBQW9CLHVCQUF1QixHQUFHLHVDQUF1QyxtQkFBbUIsa0NBQWtDLDBCQUEwQixHQUFHLDRDQUE0QyxvQkFBb0Isc0JBQXNCLG1CQUFtQixnQkFBZ0IsR0FBRyxtQ0FBbUMsK0JBQStCLHNCQUFzQiwwQkFBMEIsZ0JBQWdCLEdBQUcseUNBQXlDLG1CQUFtQixHQUFHLDJDQUEyQyxvQ0FBb0MsR0FBRywwQ0FBMEMsb0JBQW9CLEdBQUcsMENBQTBDLHVCQUF1QixHQUFHLDZGQUE2RixvQ0FBb0MsNEJBQTRCLEdBQUcsdUNBQXVDLG9CQUFvQix3QkFBd0IsR0FBRyw2Q0FBNkMsb0JBQW9CLG9CQUFvQixHQUFHLHVDQUF1Qyx1QkFBdUIsR0FBRyx3Q0FBd0Msc0JBQXNCLEdBQUcsa0JBQWtCLG1CQUFtQixZQUFZLEdBQUcsZ0RBQWdELG1CQUFtQixtQkFBbUIsR0FBRyx3QkFBd0IsZ0JBQWdCLHVCQUF1QixpQkFBaUIsY0FBYyxHQUFHLHlCQUF5Qix3QkFBd0IsZ0JBQWdCLEdBQUcseUJBQXlCLHFCQUFxQixHQUFHLGdEQUFnRCx1QkFBdUIsR0FBRyx3QkFBd0Isb0JBQW9CLDRCQUE0QixxQkFBcUIsd0JBQXdCLCtCQUErQixxQkFBcUIsR0FBRyw4QkFBOEIsK0JBQStCLEdBQUcsb0NBQW9DLDhCQUE4Qiw4QkFBOEIsOEJBQThCLDhCQUE4QixHQUFHLCtCQUErQixjQUFjLEdBQUcsMkJBQTJCLGlCQUFpQixrQkFBa0IsdUJBQXVCLGtLQUFrSyw0SEFBNEgscUhBQXFILHVEQUF1RCx1REFBdUQsK0JBQStCLEdBQUcsbUNBQW1DLGlCQUFpQixpQ0FBaUMsS0FBSyxTQUFTLG9DQUFvQyxLQUFLLEdBQUcsMkJBQTJCLGlCQUFpQixpQ0FBaUMsS0FBSyxTQUFTLG9DQUFvQyxLQUFLLEdBQUc7O0FBRXJ2Tjs7Ozs7Ozs7Ozs7O0FDUEE7QUFDQTs7O0FBR0E7QUFDQSx1V0FBd1csaU9BQWlPLG9CQUFvQixxQkFBcUIsK0JBQStCLG1DQUFtQyxtQ0FBbUMsY0FBYyxlQUFlLHFCQUFxQixHQUFHLDJDQUEyQyxjQUFjLGVBQWUscUJBQXFCLEdBQUcseUJBQXlCLG1CQUFtQixtQkFBbUIsY0FBYyxnQkFBZ0IscUJBQXFCLHVCQUF1QixHQUFHLDhCQUE4QiwwQkFBMEIsMkJBQTJCLGlCQUFpQixzQkFBc0Isc0JBQXNCLEdBQUcsd0JBQXdCLG9CQUFvQix1QkFBdUIsOEJBQThCLDhCQUE4Qiw4QkFBOEIsOEJBQThCLG9CQUFvQixpQkFBaUIsc0JBQXNCLHVCQUF1QixxQkFBcUIsMEJBQTBCLDJCQUEyQiw4QkFBOEIsMkJBQTJCLHNCQUFzQix1QkFBdUIsZUFBZSxHQUFHLDBCQUEwQiwwQkFBMEIsK0JBQStCLDZCQUE2QixxQkFBcUIsa0JBQWtCLEdBQUcsMkRBQTJELGdDQUFnQyx3QkFBd0IsMEJBQTBCLEdBQUcsK0RBQStELG1CQUFtQixHQUFHLCtCQUErQiwwQkFBMEIscUJBQXFCLEdBQUcsaUNBQWlDLG1CQUFtQixHQUFHLHlFQUF5RSwwQkFBMEIsR0FBRyw2RUFBNkUsbUJBQW1CLEdBQUcseURBQXlELGVBQWUsR0FBRyxxRUFBcUUsb0NBQW9DLG1CQUFtQix3QkFBd0IsK0JBQStCLHVCQUF1QixHQUFHLGlLQUFpSyxtQkFBbUIsMEJBQTBCLG9CQUFvQix1QkFBdUIsc0RBQXNELHNEQUFzRCxzREFBc0QseUJBQXlCLDZCQUE2QixHQUFHLHlMQUF5TCxvQkFBb0IsR0FBRyxpRkFBaUYsOEJBQThCLEdBQUcsaUZBQWlGLDhCQUE4QixHQUFHLGdGQUFnRixzQkFBc0IsR0FBRyx1R0FBdUcsdUJBQXVCLG9CQUFvQiwrQkFBK0IsdUJBQXVCLHFCQUFxQixvQkFBb0IsaUJBQWlCLHNCQUFzQix1QkFBdUIsZ0NBQWdDLHdCQUF3QiwwQkFBMEIsMkJBQTJCLEdBQUcsK0NBQStDLGVBQWUsR0FBRyxtREFBbUQsK0JBQStCLDhCQUE4Qiw4QkFBOEIsOEJBQThCLDhCQUE4QixHQUFHLCtEQUErRCwwQkFBMEIsR0FBRyxtR0FBbUcsOEJBQThCLDJCQUEyQix1QkFBdUIsa0JBQWtCLG1CQUFtQixnQ0FBZ0Msd0JBQXdCLEdBQUcsK0dBQStHLG9CQUFvQixtQkFBbUIsaUJBQWlCLDZCQUE2Qix1QkFBdUIscUJBQXFCLEdBQUcsNk5BQTZOLDBCQUEwQixtQkFBbUIsR0FBRyx3REFBd0Qsd0JBQXdCLG1CQUFtQixHQUFHLHdEQUF3RCx3QkFBd0IsbUJBQW1CLEdBQUcsOEZBQThGLHdCQUF3QixHQUFHLCtRQUErUSwwQkFBMEIsK0JBQStCLHdCQUF3QixHQUFHLHlCQUF5Qix5QkFBeUIsR0FBRywyQkFBMkIsMEJBQTBCLDJCQUEyQixzQkFBc0IsR0FBRyxtREFBbUQsMEJBQTBCLHNCQUFzQixHQUFHLHdDQUF3QywwQkFBMEIsd0JBQXdCLGlCQUFpQixzQkFBc0IsR0FBRyw4Q0FBOEMsdUJBQXVCLDBCQUEwQixzQkFBc0IsZ0JBQWdCLGlCQUFpQixvQkFBb0IscUJBQXFCLCtCQUErQiwyQkFBMkIsMkJBQTJCLDhCQUE4Qix1QkFBdUIsZ0NBQWdDLHdCQUF3QixrQkFBa0IsZ0JBQWdCLEdBQUcsZ0VBQWdFLG1CQUFtQixlQUFlLEdBQUcsb0VBQW9FLG1CQUFtQixHQUFHLHlFQUF5RSxtQkFBbUIsR0FBRyxvREFBb0QsMEJBQTBCLEdBQUcsb0RBQW9ELDBCQUEwQixlQUFlLDBEQUEwRCwwREFBMEQsR0FBRyx1REFBdUQsOEJBQThCLGVBQWUsd0JBQXdCLCtCQUErQixHQUFHLDZEQUE2RCwwQkFBMEIsR0FBRyxzREFBc0Qsb0JBQW9CLGlCQUFpQiwyQkFBMkIsMkNBQTJDLG1DQUFtQyxxQkFBcUIsR0FBRyxpREFBaUQsc0JBQXNCLGlCQUFpQixvQkFBb0IsR0FBRyxpREFBaUQscUJBQXFCLGlCQUFpQixHQUFHLDZGQUE2RixpQkFBaUIsc0JBQXNCLHdCQUF3QixHQUFHLGlKQUFpSixjQUFjLGlCQUFpQixHQUFHLDZKQUE2SixpQkFBaUIsc0JBQXNCLEdBQUcsdURBQXVELDBCQUEwQixzQkFBc0IsaUJBQWlCLEdBQUcsNkRBQTZELHNCQUFzQixtQ0FBbUMsbUNBQW1DLDJCQUEyQix1QkFBdUIsOEJBQThCLGtCQUFrQixtQkFBbUIsaUJBQWlCLHVCQUF1QiwwQ0FBMEMsa0NBQWtDLEdBQUcsbUVBQW1FLDBCQUEwQixHQUFHLHVHQUF1RyxpQkFBaUIsc0JBQXNCLEdBQUcsNkNBQTZDLGNBQWMsb0JBQW9CLGlCQUFpQixzQkFBc0IsR0FBRyw4RUFBOEUsNEJBQTRCLDhCQUE4QixHQUFHLHlGQUF5RixjQUFjLG9CQUFvQixpQkFBaUIsc0JBQXNCLEdBQUcsNklBQTZJLDhCQUE4Qiw0QkFBNEIsR0FBRyx5SkFBeUosaUJBQWlCLHNCQUFzQixHQUFHLG1HQUFtRyxpQkFBaUIsc0JBQXNCLG9CQUFvQixHQUFHLGdEQUFnRCxxQkFBcUIsR0FBRyw2REFBNkQsaUJBQWlCLHNCQUFzQixHQUFHLG1FQUFtRSxxQkFBcUIsaUJBQWlCLGdCQUFnQixHQUFHLDZDQUE2QyxvRkFBb0Ysb0JBQW9CLEtBQUssR0FBRyw2Q0FBNkMsNkJBQTZCLG9CQUFvQixLQUFLLEdBQUc7O0FBRXBoVjs7Ozs7Ozs7Ozs7O0FDUEE7QUFDQTs7O0FBR0E7QUFDQSxtV0FBb1csaU9BQWlPLG9CQUFvQixxQkFBcUIsK0JBQStCLG1DQUFtQyxtQ0FBbUMsY0FBYyxlQUFlLHFCQUFxQiwwQkFBMEIsdUJBQXVCLEdBQUcsbUNBQW1DLGNBQWMsZUFBZSxxQkFBcUIsR0FBRyw2QkFBNkIsZUFBZSwyQkFBMkIsR0FBRyxxQkFBcUIsMEJBQTBCLHVCQUF1Qiw2QkFBNkIsdUJBQXVCLHlCQUF5Qix1Q0FBdUMsd0NBQXdDLHVDQUF1Qyx1QkFBdUIsYUFBYSxnQkFBZ0IsbUJBQW1CLHFCQUFxQixzQ0FBc0Msc0NBQXNDLHNDQUFzQywrQkFBK0Isb0JBQW9CLEdBQUcsNEJBQTRCLG1CQUFtQix3Q0FBd0MsR0FBRyx1QkFBdUIsa0JBQWtCLEdBQUcsNEJBQTRCLHNCQUFzQiw4Q0FBOEMsc0NBQXNDLDhCQUE4QixxREFBcUQsR0FBRyx5QkFBeUIsa0JBQWtCLDhCQUE4Qiw4QkFBOEIsOEJBQThCLDhCQUE4QixtQ0FBbUMsbUNBQW1DLG1CQUFtQiwyQkFBMkIsdUJBQXVCLDhCQUE4Qiw2QkFBNkIsc0VBQXNFLDhEQUE4RCxHQUFHLCtCQUErQiwwQkFBMEIsR0FBRywwR0FBMEcsMEJBQTBCLGVBQWUsMERBQTBELDBEQUEwRCxHQUFHLGdDQUFnQywwQkFBMEIsdUJBQXVCLDZCQUE2Qix1QkFBdUIseUJBQXlCLHlCQUF5QixlQUFlLHVCQUF1QixnQkFBZ0IsZUFBZSxxQkFBcUIsYUFBYSxvQkFBb0IsK0JBQStCLGdCQUFnQixpQkFBaUIscUJBQXFCLHNCQUFzQixvQkFBb0IsNERBQTRELG9EQUFvRCxHQUFHLHVDQUF1QyxtQkFBbUIsMkJBQTJCLHVDQUF1Qyx3Q0FBd0MsdUNBQXVDLHdCQUF3QixHQUFHLHNDQUFzQywrQkFBK0IsR0FBRyw0REFBNEQsZUFBZSxHQUFHLHdDQUF3QyxnQkFBZ0IscUJBQXFCLDRCQUE0Qix3QkFBd0Isb0JBQW9CLHdCQUF3QixHQUFHLHdCQUF3QiwrQkFBK0IsR0FBRyw4Q0FBOEMsd0JBQXdCLHdCQUF3QixHQUFHLDJKQUEySiwwQkFBMEIsNkJBQTZCLDZCQUE2QixHQUFHLHFEQUFxRCxrQkFBa0IsdUJBQXVCLHlCQUF5QixHQUFHLHNGQUFzRix3QkFBd0IsZ0JBQWdCLHdCQUF3QixHQUFHLDhGQUE4RixrQkFBa0IsR0FBRyxpQ0FBaUMsaUJBQWlCLHVCQUF1QixvQkFBb0IsR0FBRyxtQ0FBbUMsbUJBQW1CLHNCQUFzQix1QkFBdUIsdUJBQXVCLHNCQUFzQixHQUFHLHlDQUF5QyxpQkFBaUIsdUJBQXVCLHlCQUF5QiwwQkFBMEIsYUFBYSxHQUFHLGtCQUFrQixvQkFBb0IsR0FBRyxnREFBZ0QsaUJBQWlCLEdBQUcsa0RBQWtELHNCQUFzQixHQUFHLGtEQUFrRCxxQkFBcUIsR0FBRyxxRkFBcUYsaUJBQWlCLHNCQUFzQixHQUFHLCtFQUErRSxjQUFjLEdBQUcsZ0RBQWdELGlCQUFpQixHQUFHLGtEQUFrRCxzQkFBc0Isa0JBQWtCLEdBQUcsa0RBQWtELHFCQUFxQixHQUFHLHFGQUFxRixpQkFBaUIsc0JBQXNCLEdBQUcsK0VBQStFLGNBQWMsR0FBRyxrRkFBa0YsZUFBZSxHQUFHLDhEQUE4RCwrQkFBK0Isb0JBQW9CLEdBQUcsb0VBQW9FLCtCQUErQixHQUFHLG1DQUFtQywwQkFBMEIsdUJBQXVCLEdBQUcsK0VBQStFLHVCQUF1QixhQUFhLFlBQVksZUFBZSxtQkFBbUIsc0JBQXNCLGlCQUFpQixvQkFBb0Isc0JBQXNCLHFCQUFxQiw0QkFBNEIsd0JBQXdCLHFCQUFxQixHQUFHLDBDQUEwQyxlQUFlLEdBQUcscUNBQXFDLHVCQUF1QixXQUFXLGtCQUFrQixxQkFBcUIseUJBQXlCLEdBQUcsOEJBQThCLHVCQUF1QixpQkFBaUIsZ0JBQWdCLEdBQUcsOERBQThELGdCQUFnQixpQkFBaUIsR0FBRyx3REFBd0Qsb0JBQW9CLG9CQUFvQixpQkFBaUIsZ0JBQWdCLDRCQUE0QixlQUFlLHVCQUF1QixtQkFBbUIsR0FBRyxrQ0FBa0MsaUJBQWlCLEdBQUcsbUNBQW1DLHFCQUFxQixpQkFBaUIsd0JBQXdCLFlBQVksR0FBRyxrRkFBa0YsbUJBQW1CLG1CQUFtQixHQUFHLHlDQUF5QyxnQkFBZ0IsdUJBQXVCLGlCQUFpQixjQUFjLEdBQUcsOERBQThELGdCQUFnQixxQkFBcUIsZ0JBQWdCLGVBQWUsb0JBQW9CLEdBQUcsd0ZBQXdGLG9CQUFvQixrQkFBa0IsR0FBRyxtRUFBbUUscUJBQXFCLHdCQUF3QixpQkFBaUIsR0FBRyxzRUFBc0UscUJBQXFCLEdBQUcseUhBQXlILG9CQUFvQixpQkFBaUIsc0JBQXNCLEdBQUcsaUVBQWlFLCtCQUErQiw4QkFBOEIsOEJBQThCLHVCQUF1QixvQkFBb0IsZ0JBQWdCLHNCQUFzQixtQkFBbUIsdUJBQXVCLHFCQUFxQiwwRUFBMEUsa0VBQWtFLDJCQUEyQixHQUFHLDJFQUEyRSxvQkFBb0IsR0FBRywwRUFBMEUsMEJBQTBCLHdCQUF3QixxQkFBcUIsNEJBQTRCLG9CQUFvQix5RUFBeUUsaUVBQWlFLEdBQUcseUVBQXlFLHVCQUF1Qiw2QkFBNkIsdUJBQXVCLHlCQUF5QixtQkFBbUIsdUNBQXVDLHdDQUF3Qyx1Q0FBdUMsK0JBQStCLHlCQUF5QixvQkFBb0Isc0JBQXNCLGdDQUFnQyx3QkFBd0IsMEJBQTBCLG9CQUFvQix3QkFBd0Isc0RBQXNELHNEQUFzRCxzREFBc0QsdUJBQXVCLGVBQWUsR0FBRyxnRkFBZ0YsbUJBQW1CLHdDQUF3QyxHQUFHLCtFQUErRSxvQkFBb0IsR0FBRywrRUFBK0UsbUJBQW1CLEdBQUcsZ0ZBQWdGLHdCQUF3QixHQUFHLGdFQUFnRSxjQUFjLEdBQUcsMkZBQTJGLHVCQUF1QixHQUFHLDZDQUE2QyxzQ0FBc0Msc0NBQXNDLHNDQUFzQyxHQUFHLDBDQUEwQywwQkFBMEIsZUFBZSwwREFBMEQsMERBQTBELEdBQUcsMENBQTBDLGtCQUFrQixHQUFHLG1EQUFtRCxpQkFBaUIsZ0JBQWdCLGdCQUFnQixHQUFHLHdEQUF3RCxnQkFBZ0IsaUJBQWlCLEdBQUcsa0RBQWtELGdCQUFnQixpQkFBaUIsdUJBQXVCLGVBQWUsc0VBQXNFLDhEQUE4RCw2QkFBNkIsNkJBQTZCLEdBQUcsMkdBQTJHLHVCQUF1QixHQUFHLHdCQUF3QixpT0FBaU8scUJBQXFCLCtCQUErQixjQUFjLGVBQWUscUJBQXFCLDJCQUEyQixzREFBc0Qsc0RBQXNELHVCQUF1QixtQ0FBbUMsbUNBQW1DLGtCQUFrQixrQkFBa0IsaUJBQWlCLHVCQUF1QixrQkFBa0Isb0JBQW9CLEdBQUcsNk1BQTZNLHlDQUF5Qyx5Q0FBeUMsR0FBRyx1TUFBdU0sMkNBQTJDLDJDQUEyQyxHQUFHLHNHQUFzRywwQ0FBMEMsMENBQTBDLEdBQUcsbUdBQW1HLDRDQUE0Qyw0Q0FBNEMsR0FBRywrQkFBK0Isa0JBQWtCLEdBQUcsNkJBQTZCLGtCQUFrQixxQkFBcUIsb0JBQW9CLHFCQUFxQixzQkFBc0IsbUJBQW1CLEdBQUcsNkNBQTZDLGNBQWMsZUFBZSxHQUFHLDhFQUE4RSx1QkFBdUIsR0FBRyw4Q0FBOEMsK0JBQStCLG9CQUFvQixpQkFBaUIsc0JBQXNCLG9CQUFvQixHQUFHLGtDQUFrQyx1QkFBdUIsbUJBQW1CLHNCQUFzQixzQkFBc0Isd0JBQXdCLCtCQUErQix3QkFBd0Isb0JBQW9CLHFCQUFxQiw0QkFBNEIsNkNBQTZDLHFDQUFxQyxHQUFHLHdDQUF3Qyw4QkFBOEIsR0FBRyw4Q0FBOEMsK0JBQStCLEdBQUcsNkNBQTZDLCtCQUErQixHQUFHLDJDQUEyQywrQkFBK0Isd0JBQXdCLEdBQUcsaURBQWlELCtCQUErQiwyQkFBMkIsd0JBQXdCLEdBQUcsMkZBQTJGLDhCQUE4QixxQkFBcUIsK0JBQStCLEdBQUcseUNBQXlDLDhCQUE4QixHQUFHLDBDQUEwQyxnQkFBZ0Isa0JBQWtCLHFCQUFxQiw4QkFBOEIsbUJBQW1CLEdBQUcsMkZBQTJGLDJCQUEyQix1Q0FBdUMsd0NBQXdDLHVDQUF1Qyx3QkFBd0IsdUJBQXVCLDBCQUEwQixvQkFBb0Isd0JBQXdCLHNEQUFzRCxzREFBc0Qsc0RBQXNELHNDQUFzQyw4QkFBOEIsdUJBQXVCLGFBQWEsd0NBQXdDLHdDQUF3Qyx3Q0FBd0MsZ0JBQWdCLHNCQUFzQiw0REFBNEQsR0FBRyxpR0FBaUcsb0JBQW9CLEdBQUcsaUdBQWlHLGdCQUFnQixHQUFHLG9HQUFvRyxrQkFBa0IsR0FBRyw2TUFBNk0sbUJBQW1CLDBCQUEwQixHQUFHLDZHQUE2RyxtQkFBbUIsR0FBRzs7QUFFajBnQjs7Ozs7Ozs7Ozs7O0FDUEE7QUFDQTs7O0FBR0E7QUFDQSxpV0FBa1csaU9BQWlPLG9CQUFvQixxQkFBcUIsK0JBQStCLG1DQUFtQyxtQ0FBbUMsY0FBYyxlQUFlLHFCQUFxQixtQkFBbUIsMkJBQTJCLHVCQUF1QixlQUFlLHVCQUF1QixvRkFBb0YsNEVBQTRFLG9FQUFvRSxpSUFBaUksa0JBQWtCLEdBQUcsc0JBQXNCLGVBQWUscUJBQXFCLDBCQUEwQixHQUFHLDRCQUE0Qix1QkFBdUIsR0FBRyw4Q0FBOEMsdUJBQXVCLGlCQUFpQixzQkFBc0IsZ0JBQWdCLGVBQWUsR0FBRyw0REFBNEQsdUJBQXVCLGFBQWEsY0FBYyxrQkFBa0IsR0FBRyw2REFBNkQsdUJBQXVCLGFBQWEsZ0JBQWdCLHFCQUFxQixnQ0FBZ0MsR0FBRywrRUFBK0Usc0JBQXNCLEdBQUcsK0RBQStELGlCQUFpQixHQUFHLGdFQUFnRSxxQkFBcUIsR0FBRyxrRkFBa0Ysc0JBQXNCLEdBQUcsK0RBQStELGtCQUFrQixHQUFHLGdFQUFnRSxzQkFBc0IsR0FBRyxrRkFBa0Ysc0JBQXNCLEdBQUcsdUJBQXVCLHVCQUF1QixZQUFZLEdBQUcsMERBQTBELG1CQUFtQixtQkFBbUIsR0FBRyw2QkFBNkIsZ0JBQWdCLHVCQUF1QixpQkFBaUIsY0FBYyxHQUFHLGtCQUFrQixxQkFBcUIsaUJBQWlCLGdDQUFnQyx3QkFBd0IseUhBQXlILHFDQUFxQyxHQUFHLHdCQUF3QixnQkFBZ0IsdUJBQXVCLFlBQVksYUFBYSxXQUFXLGNBQWMscUJBQXFCLGlCQUFpQixnQ0FBZ0Msd0JBQXdCLGdCQUFnQixHQUFHLGlCQUFpQiwrQkFBK0IsR0FBRyxpQkFBaUIsdUJBQXVCLDBCQUEwQixnQkFBZ0IsaUJBQWlCLEdBQUcsbUJBQW1CLGVBQWUsZ0JBQWdCLHdCQUF3Qiw4QkFBOEIsbUNBQW1DLG1DQUFtQyxtQ0FBbUMsbUJBQW1CLHVCQUF1QixpQkFBaUIsZ0VBQWdFLGdFQUFnRSxzQ0FBc0Msc0NBQXNDLHNDQUFzQyxHQUFHLGdDQUFnQyxZQUFZLFdBQVcsR0FBRyxnQ0FBZ0MsYUFBYSxXQUFXLGtDQUFrQyxrQ0FBa0MsR0FBRyxnQ0FBZ0MsYUFBYSxjQUFjLGtDQUFrQyxrQ0FBa0MsR0FBRyxnQ0FBZ0MsWUFBWSxjQUFjLGtDQUFrQyxrQ0FBa0MsR0FBRyxzQkFBc0IscUNBQXFDLHFDQUFxQyxxQ0FBcUMsc0RBQXNELHNEQUFzRCxHQUFHLDhCQUE4QixnQkFBZ0IsaUJBQWlCLEdBQUcsZ0NBQWdDLGVBQWUsZ0JBQWdCLEdBQUcsOEJBQThCLGdCQUFnQixpQkFBaUIsR0FBRyxnQ0FBZ0MsZ0JBQWdCLGlCQUFpQixHQUFHLCtDQUErQyxtQkFBbUIsR0FBRyx5RUFBeUUsbUNBQW1DLHVCQUF1QixtQkFBbUIsS0FBSyxHQUFHLGtDQUFrQyxRQUFRLGlCQUFpQixLQUFLLEdBQUcsMEJBQTBCLFFBQVEsaUJBQWlCLEtBQUssR0FBRyxnQ0FBZ0MsUUFBUSx3Q0FBd0Msd0NBQXdDLEtBQUssR0FBRyx3QkFBd0IsUUFBUSx3Q0FBd0Msd0NBQXdDLEtBQUssR0FBRzs7QUFFMzJLOzs7Ozs7Ozs7Ozs7QUNQQTtBQUNBOzs7QUFHQTtBQUNBLHVaQUF3WixpQkFBaUIsR0FBRyw2REFBNkQsdUJBQXVCLEdBQUcseURBQXlELGNBQWMsOEJBQThCLHFCQUFxQiwrQkFBK0Isd0JBQXdCLHNCQUFzQixvQkFBb0Isc0VBQXNFLDhEQUE4RCxzQkFBc0IsR0FBRyxnRUFBZ0UscUJBQXFCLDBCQUEwQixtQkFBbUIsd0JBQXdCLEdBQUcsa0VBQWtFLGVBQWUsR0FBRyw4REFBOEQscUJBQXFCLEdBQUcsd0VBQXdFLCtCQUErQixnQ0FBZ0Msd0JBQXdCLG9CQUFvQixxQkFBcUIsdUJBQXVCLHFCQUFxQiwyQkFBMkIsZ0JBQWdCLGlCQUFpQixpQkFBaUIsR0FBRyw4RUFBOEUsK0JBQStCLEdBQUcsMElBQTBJLHdDQUF3QyxnQ0FBZ0MsR0FBRyw0SkFBNEoscUJBQXFCLEdBQUcsOEVBQThFLGVBQWUsR0FBRywyQkFBMkIsc0JBQXNCLEdBQUcsNkNBQTZDLGdCQUFnQixpQkFBaUIsc0JBQXNCLHVCQUF1QixvQkFBb0IsdUJBQXVCLDhCQUE4QixvQkFBb0IsK0JBQStCLGdDQUFnQyx3QkFBd0IsR0FBRyxtREFBbUQsbUJBQW1CLDBCQUEwQixHQUFHLDRFQUE0RSxpQkFBaUIsR0FBRyxrRUFBa0UscUNBQXFDLHVCQUF1QixHQUFHLHlFQUF5RSx3QkFBd0IsR0FBRyw2RUFBNkUsdUJBQXVCLEdBQUcsc0VBQXNFLGVBQWUsR0FBRyxxRkFBcUYsb0JBQW9CLEdBQUcsZ0ZBQWdGLG9CQUFvQiwrQkFBK0Isc0JBQXNCLEdBQUcsdUZBQXVGLHVCQUF1Qix3QkFBd0IsR0FBRyxzRkFBc0YsbUJBQW1CLEdBQUcsaUZBQWlGLG1CQUFtQiwrQkFBK0IscUJBQXFCLEdBQUcsd0ZBQXdGLHNCQUFzQix1QkFBdUIsR0FBRyx5RUFBeUUscUNBQXFDLGtCQUFrQiwrQkFBK0IsR0FBRyxnRkFBZ0YsbUJBQW1CLHNCQUFzQixxQkFBcUIsR0FBRyxhQUFhLGlPQUFpTyxvQkFBb0IscUJBQXFCLCtCQUErQixtQ0FBbUMsbUNBQW1DLGNBQWMsZUFBZSxxQkFBcUIsdUJBQXVCLHFCQUFxQixZQUFZLEdBQUcsc0NBQXNDLG1CQUFtQixtQkFBbUIsR0FBRyxtQkFBbUIsZ0JBQWdCLHVCQUF1QixpQkFBaUIsY0FBYyxHQUFHLHFCQUFxQixlQUFlLHVCQUF1QixZQUFZLGdCQUFnQixtQ0FBbUMsbUNBQW1DLGdCQUFnQiw4QkFBOEIsa0NBQWtDLGtDQUFrQyxrQ0FBa0MsR0FBRyxpQkFBaUIscUNBQXFDLHVCQUF1QixrQkFBa0IsMEVBQTBFLGtFQUFrRSxHQUFHLDJCQUEyQixxQkFBcUIsb0JBQW9CLHFCQUFxQixtQ0FBbUMsbUNBQW1DLHVCQUF1Qix3QkFBd0Isd0JBQXdCLDBFQUEwRSxrRUFBa0UsWUFBWSxHQUFHLGtFQUFrRSxtQkFBbUIsbUJBQW1CLEdBQUcsaUNBQWlDLGdCQUFnQix1QkFBdUIsaUJBQWlCLGNBQWMsR0FBRyxxQ0FBcUMsdUJBQXVCLHdCQUF3QixHQUFHLGtDQUFrQyx3QkFBd0Isa0NBQWtDLEdBQUcsc0NBQXNDLGlCQUFpQixhQUFhLEdBQUcsNENBQTRDLHFCQUFxQixxQkFBcUIsR0FBRywyQ0FBMkMsOEJBQThCLDhCQUE4Qiw4QkFBOEIsOEJBQThCLGVBQWUsYUFBYSxpQkFBaUIsb0JBQW9CLGNBQWMsa0NBQWtDLHVCQUF1Qix1QkFBdUIsK0JBQStCLDRLQUE0SyxvS0FBb0ssZUFBZSx5QkFBeUIsR0FBRywyRkFBMkYsZUFBZSxnQkFBZ0IsaUJBQWlCLHlCQUF5QixHQUFHLHVEQUF1RCwrQkFBK0IsR0FBRyxxREFBcUQsdUJBQXVCLHNCQUFzQix5QkFBeUIseUJBQXlCLDZCQUE2Qix1QkFBdUIsYUFBYSxjQUFjLDZDQUE2Qyw2Q0FBNkMsNkNBQTZDLHVCQUF1Qix5QkFBeUIsR0FBRyxtRUFBbUUsbUJBQW1CLHdDQUF3QywwQkFBMEIsb0JBQW9CLHdCQUF3QixzREFBc0Qsc0RBQXNELHNEQUFzRCxHQUFHLCtFQUErRSxvQkFBb0IsR0FBRyw4QkFBOEIsd0JBQXdCLEdBQUcsaUVBQWlFLCtCQUErQixHQUFHLHNCQUFzQixlQUFlLEdBQUcsa0NBQWtDLHdCQUF3QixHQUFHLHNCQUFzQixZQUFZLEdBQUcsa0NBQWtDLHdCQUF3QixHQUFHLDRCQUE0Qix5QkFBeUIseUJBQXlCLEdBQUcsc0JBQXNCLHFCQUFxQix3QkFBd0IsR0FBRyx3QkFBd0IscUJBQXFCLHdCQUF3QixHQUFHLGlCQUFpQixtQ0FBbUMsbUNBQW1DLG9CQUFvQixvRkFBb0YsNEVBQTRFLG9FQUFvRSxpSUFBaUksdUJBQXVCLGNBQWMscUJBQXFCLDBCQUEwQixHQUFHLDhDQUE4QyxtQkFBbUIsbUJBQW1CLEdBQUcsdUJBQXVCLGdCQUFnQixHQUFHLHdDQUF3Qyx5QkFBeUIsb0JBQW9CLCtCQUErQixHQUFHLCtCQUErQiwwQkFBMEIsaUJBQWlCLHVCQUF1Qix1QkFBdUIsbUNBQW1DLG1DQUFtQyx1QkFBdUIsd0VBQXdFLGdFQUFnRSxvQkFBb0IsMEJBQTBCLEdBQUcsMENBQTBDLG9CQUFvQixHQUFHLHFDQUFxQyxtQkFBbUIsR0FBRyxzQ0FBc0MsbUJBQW1CLEdBQUcsd0NBQXdDLHNCQUFzQixHQUFHLHNDQUFzQyxtQkFBbUIscUJBQXFCLEdBQUcsMkNBQTJDLG9CQUFvQixHQUFHLGlDQUFpQyxrQkFBa0IsR0FBRywyQ0FBMkMsb0JBQW9CLEdBQUcsaUNBQWlDLHNCQUFzQixHQUFHLHlEQUF5RCxnQkFBZ0IsR0FBRyw2RUFBNkUsMkJBQTJCLDZCQUE2QiwyQkFBMkIsZ0JBQWdCLHFDQUFxQyw2QkFBNkIsZUFBZSxHQUFHLHNGQUFzRixlQUFlLGNBQWMsMEJBQTBCLHlCQUF5QixHQUFHLGtFQUFrRSx5QkFBeUIsMEJBQTBCLHlCQUF5QixrQkFBa0IsbUNBQW1DLGtDQUFrQyxnQ0FBZ0MsZ0NBQWdDLGdDQUFnQyw2QkFBNkIsOEVBQThFLHNFQUFzRSxHQUFHLHNDQUFzQyxxQkFBcUIsaUJBQWlCLEdBQUcsNkZBQTZGLGdCQUFnQixjQUFjLDZLQUE2SyxxS0FBcUssR0FBRyw2SUFBNkksZ0JBQWdCLGlCQUFpQixHQUFHLG9EQUFvRCxnQkFBZ0IsdUJBQXVCLHNCQUFzQixtQkFBbUIsR0FBRywrREFBK0QscUJBQXFCLEdBQUcsOERBQThELHVCQUF1QixHQUFHLDJEQUEyRCxnQkFBZ0IsR0FBRyxzSEFBc0gsaUJBQWlCLEdBQUcsOERBQThELHFCQUFxQixHQUFHLCtGQUErRixvQkFBb0IsR0FBRyx5REFBeUQscUJBQXFCLEdBQUcsb0RBQW9ELGdCQUFnQixHQUFHLHdEQUF3RCxlQUFlLGVBQWUsaUJBQWlCLFdBQVcsR0FBRyx5REFBeUQsZ0JBQWdCLGNBQWMsaUJBQWlCLEdBQUcscUVBQXFFLHdCQUF3QixHQUFHLHlEQUF5RCxXQUFXLGdCQUFnQixpQkFBaUIsR0FBRyxxRUFBcUUsd0JBQXdCLEdBQUcsMENBQTBDLHFCQUFxQixnQkFBZ0IsNkJBQTZCLEdBQUcsb0RBQW9ELGdCQUFnQixvQ0FBb0MsdUJBQXVCLHFCQUFxQixHQUFHLGtFQUFrRSxzQkFBc0IsR0FBRyw0RUFBNEUsdUJBQXVCLEdBQUcsdUVBQXVFLHVCQUF1QixHQUFHLHNFQUFzRSxlQUFlLEdBQUcsd0RBQXdELHVCQUF1QixtQ0FBbUMsR0FBRyxxREFBcUQsaUJBQWlCLG1DQUFtQyxzQkFBc0IscUJBQXFCLEdBQUcsNkVBQTZFLHNCQUFzQixHQUFHLHdFQUF3RSxzQkFBc0IsR0FBRyx1RUFBdUUsY0FBYyxHQUFHLHlEQUF5RCx3QkFBd0Isb0NBQW9DLEdBQUcsb0NBQW9DLHFCQUFxQixxQkFBcUIsR0FBRywwRkFBMEYscUlBQXFJLDZIQUE2SCxxSEFBcUgsa0xBQWtMLEdBQUcsMEZBQTBGLHNJQUFzSSw4SEFBOEgsc0hBQXNILG1MQUFtTCxHQUFHLGlKQUFpSix1Q0FBdUMsdUNBQXVDLHVDQUF1Qyw4QkFBOEIsR0FBRyw2TUFBNk0sa0JBQWtCLEdBQUc7O0FBRS9oaEI7Ozs7Ozs7Ozs7OztBQ1BBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsU0FBUztBQUNwQixXQUFXLE9BQU87QUFDbEIsV0FBVyxPQUFPLFlBQVk7QUFDOUIsV0FBVyxRQUFRO0FBQ25CO0FBQ0EsV0FBVyxPQUFPO0FBQ2xCO0FBQ0EsV0FBVyxRQUFRO0FBQ25CO0FBQ0EsYUFBYSxTQUFTO0FBQ3RCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0EsOENBQThDLGtCQUFrQjtBQUNoRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7Ozs7Ozs7Ozs7O0FDN0xBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhLE9BQU87QUFDcEI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7Ozs7Ozs7Ozs7O0FDdEJBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLEVBQUU7QUFDYixhQUFhLE9BQU87QUFDcEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7Ozs7Ozs7Ozs7Ozs7O0FDakVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHOzs7Ozs7Ozs7Ozs7O0FDMUJBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsRzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNiQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYSxxQkFBcUI7QUFDbEM7QUFDQTtBQUNBLFNBQVM7O0FBRVQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWU7QUFDZjtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxlQUFlO0FBQ2Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyx5Q0FBeUM7QUFDcEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxTQUFTLDRCQUE0QjtBQUNyQztBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7O0FBRUg7QUFDQSxDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFHQSx3RTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNwS0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLHNFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3JEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSw4SkFBOEo7QUFDOUo7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZUFBZTtBQUNmO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWU7QUFDZjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsV0FBVyw0RkFBNEY7QUFDdkc7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiLGdIQUF5RSxzQ0FBc0M7QUFDL0c7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQSxlQUFlLGtDQUFrQztBQUNqRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYixnSEFBeUUsc0NBQXNDO0FBQy9HO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsdUJBQXVCLGVBQWU7QUFDdEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2IsbUlBQTRGLHNDQUFzQztBQUNsSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYixtSUFBNEYsc0NBQXNDO0FBQ2xJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUzs7QUFFVDtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUEsMkJBQTJCLGFBQWE7QUFDeEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsdUNBQXVDO0FBQ2xEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWCw4R0FBdUUsc0NBQXNDO0FBQzdHO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1gsOEdBQXVFLHNDQUFzQztBQUM3RztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLEdBQUc7O0FBRUg7QUFDQSxDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQSxLQUFLO0FBQ0w7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7O0FBRUE7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0EsNEZBQTRGLGFBQWE7QUFDekc7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLDJFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzdsQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsRzs7Ozs7Ozs7Ozs7OztBQ2RBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEc7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDZEE7QUFDQTtBQUNBO0FBQ0E7QUFDOEI7QUFDUjtBQUN0QjtBQUNBO0FBQ0E7QUFDQTtBQUNzRDs7QUFFdEQ7QUFDQTs7QUFFQTtBQUNBOztBQUVBOztBQUVBLG1FQUFtRSxhQUFhO0FBQ2hGO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLEtBQUs7QUFDTDs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0Esc0ZBQXdDO0FBQ3hDO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsbUJBQW1CO0FBQ25DO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBR0EsMEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3JMQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBLENBQUM7O0FBRUQ7QUFDQSx5RTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNsQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBLENBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1RTs7Ozs7Ozs7Ozs7Ozs7OztBQ3RCQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdMQUF3TCwwQ0FBMEM7QUFDbE87QUFDQSxHQUFHO0FBQ0g7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzdEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDdUQ7QUFDdkQ7QUFDQTs7QUFFdVc7QUFDdlc7QUFDMEI7O0FBRTFCOztBQUVBO0FBQ0EsZ0VBQWdFLGFBQWE7QUFDN0U7QUFDQTs7QUFFQTtBQUNBLHNFQUFzRSxlQUFlO0FBQ3JGO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLG1CQUFtQixnQkFBZ0I7QUFDbkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7OztBQUdBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0NBQWdDO0FBQ2hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLENBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CO0FBQ25CLHVCQUF1QjtBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVMsMkJBQTJCO0FBQ3BDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVCxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1gsU0FBUztBQUNUO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0EsOElBQXVHLG9DQUFvQztBQUMzSSxvSEFBNkU7QUFDN0U7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPLHNEQUFzRDtBQUM3RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYSx5QkFBeUI7QUFDdEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSzs7QUFFTDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQSxhQUFhLHVEQUF1RDtBQUNwRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBLGVBQWUsdURBQXVEO0FBQ3RFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPLDBHQUEyRDtBQUNsRTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOzs7QUFHQSw4Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2x6Q0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNnQzs7QUFFaEM7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBOztBQUVBLG1FQUFtRSxhQUFhO0FBQ2hGO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0Esd0JBQXdCLHVCQUF1QjtBQUMvQztBQUNBLEtBQUs7QUFDTDtBQUNBLEtBQUs7QUFDTDtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQSxLQUFLO0FBQ0w7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSw4Q0FBOEM7QUFDOUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsNEZBQWdDO0FBQ2hDO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSw2RUFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFHQSw0Qzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNsTEE7QUFDQTtBQUMwQjtBQUMxQjtBQUNBO0FBQ0E7QUFDUTtBQUNSLGdIOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNQQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxpQkFBaUIsa0JBQWtCO0FBQ25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQixrQkFBa0I7QUFDbkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxpQkFBaUIscUJBQXFCO0FBQ3RDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsaUJBQWlCLHVCQUF1QjtBQUN4QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3BLQTtBQUM2QztBQUM3QztBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1AsS0FBSztBQUNMO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EscUZBQThDO0FBQzlDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQSxHOzs7Ozs7Ozs7Ozs7O0FDdkpBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHOzs7Ozs7Ozs7Ozs7O0FDakJBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEc7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNSQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7O0FBRUQsb0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDakJBO0FBQ0E7QUFDNkM7QUFDN0M7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNENBQTRDO0FBQzVDO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxzQkFBc0I7QUFDdEIsS0FBSztBQUNMO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsR0FBRztBQUNIO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzRkFBK0M7QUFDL0M7QUFDQSxPQUFPO0FBQ1AsMEVBQW1DLDBDQUEwQztBQUM3RTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUZBQWdEO0FBQ2hELE9BQU87QUFDUCwwRUFBbUMsMENBQTBDO0FBQzdFOztBQUVBO0FBQ0EseUZBQWtEOztBQUVsRDtBQUNBO0FBQ0E7QUFDQSx1RkFBZ0Q7QUFDaEQ7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVMsbUVBQW1FO0FBQzVFO0FBQ0E7QUFDQSxXQUFXLHVDQUF1QztBQUNsRDtBQUNBO0FBQ0EsYUFBYSxrREFBa0Q7QUFDL0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsRzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0U0E7QUFDQTtBQUNBO0FBQzhCO0FBQzlCO0FBQ0E7QUFDc0I7O0FBRXRCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxrQkFBa0I7QUFDbEIsU0FBUztBQUNUO0FBQ0E7QUFDQSxLQUFLOztBQUVMO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxrS0FBK0Q7QUFDL0Q7QUFDQSxpREFBaUQsaUJBQWlCO0FBQ2xFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzRkFBMEI7QUFDMUIsT0FBTyx5RUFBMkIsaUJBQWlCO0FBQ25EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0EsRzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNwR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ3FGOztBQUVyRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQLEtBQUs7O0FBRUw7QUFDQSxHQUFHO0FBQ0g7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLHFGQUE4QztBQUM5QztBQUNBO0FBQ0E7QUFDQTtBQUNBLHVGQUEyQjtBQUMzQixPQUFPO0FBQ1AsdUZBQTJCO0FBQzNCO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBLENBQUM7O0FBRUQsMkU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNoRkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDc0I7O0FBRXRCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBLFlBQVk7QUFDWixHQUFHO0FBQ0g7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsaUZBQTBDO0FBQzFDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7QUFFRCx3RTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDckRBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNzQjs7QUFFdEI7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBLEtBQUs7QUFDTDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsb0ZBQTRDOztBQUU1QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQSxHQUFHOztBQUVIO0FBQ0EsQ0FBQzs7QUFFRDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTs7K0RBRUE7OztBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLGlFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2xOQTtBQUNBO0FBQ0E7O0FBRUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNKQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLGlCQUFpQixjQUFjO0FBQy9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSx1RkFBMkI7QUFDM0I7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUcsSUFBSTtBQUNQLEM7Ozs7Ozs7Ozs7Ozs7Ozs7QUNsRkE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQSxDIiwiZmlsZSI6InNjcmlwdHMvN184NDBjZjRhYTUwYzg2NzdmYjAyMy5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxudmFyIGNvbnRlbnQgPSByZXF1aXJlKFwiISEuLi8uLi8uLi8uLi9jc3MtbG9hZGVyL2luZGV4LmpzIS4vaW5kZXguY3NzXCIpO1xuXG5pZih0eXBlb2YgY29udGVudCA9PT0gJ3N0cmluZycpIGNvbnRlbnQgPSBbW21vZHVsZS5pZCwgY29udGVudCwgJyddXTtcblxudmFyIHRyYW5zZm9ybTtcbnZhciBpbnNlcnRJbnRvO1xuXG5cblxudmFyIG9wdGlvbnMgPSB7XCJobXJcIjp0cnVlfVxuXG5vcHRpb25zLnRyYW5zZm9ybSA9IHRyYW5zZm9ybVxub3B0aW9ucy5pbnNlcnRJbnRvID0gdW5kZWZpbmVkO1xuXG52YXIgdXBkYXRlID0gcmVxdWlyZShcIiEuLi8uLi8uLi8uLi9zdHlsZS1sb2FkZXIvbGliL2FkZFN0eWxlcy5qc1wiKShjb250ZW50LCBvcHRpb25zKTtcblxuaWYoY29udGVudC5sb2NhbHMpIG1vZHVsZS5leHBvcnRzID0gY29udGVudC5sb2NhbHM7XG5cbmlmKG1vZHVsZS5ob3QpIHtcblx0bW9kdWxlLmhvdC5hY2NlcHQoXCIhIS4uLy4uLy4uLy4uL2Nzcy1sb2FkZXIvaW5kZXguanMhLi9pbmRleC5jc3NcIiwgZnVuY3Rpb24oKSB7XG5cdFx0dmFyIG5ld0NvbnRlbnQgPSByZXF1aXJlKFwiISEuLi8uLi8uLi8uLi9jc3MtbG9hZGVyL2luZGV4LmpzIS4vaW5kZXguY3NzXCIpO1xuXG5cdFx0aWYodHlwZW9mIG5ld0NvbnRlbnQgPT09ICdzdHJpbmcnKSBuZXdDb250ZW50ID0gW1ttb2R1bGUuaWQsIG5ld0NvbnRlbnQsICcnXV07XG5cblx0XHR2YXIgbG9jYWxzID0gKGZ1bmN0aW9uKGEsIGIpIHtcblx0XHRcdHZhciBrZXksIGlkeCA9IDA7XG5cblx0XHRcdGZvcihrZXkgaW4gYSkge1xuXHRcdFx0XHRpZighYiB8fCBhW2tleV0gIT09IGJba2V5XSkgcmV0dXJuIGZhbHNlO1xuXHRcdFx0XHRpZHgrKztcblx0XHRcdH1cblxuXHRcdFx0Zm9yKGtleSBpbiBiKSBpZHgtLTtcblxuXHRcdFx0cmV0dXJuIGlkeCA9PT0gMDtcblx0XHR9KGNvbnRlbnQubG9jYWxzLCBuZXdDb250ZW50LmxvY2FscykpO1xuXG5cdFx0aWYoIWxvY2FscykgdGhyb3cgbmV3IEVycm9yKCdBYm9ydGluZyBDU1MgSE1SIGR1ZSB0byBjaGFuZ2VkIGNzcy1tb2R1bGVzIGxvY2Fscy4nKTtcblxuXHRcdHVwZGF0ZShuZXdDb250ZW50KTtcblx0fSk7XG5cblx0bW9kdWxlLmhvdC5kaXNwb3NlKGZ1bmN0aW9uKCkgeyB1cGRhdGUoKTsgfSk7XG59IiwiXG52YXIgY29udGVudCA9IHJlcXVpcmUoXCIhIS4uLy4uLy4uLy4uL2Nzcy1sb2FkZXIvaW5kZXguanMhLi9pbmRleC5jc3NcIik7XG5cbmlmKHR5cGVvZiBjb250ZW50ID09PSAnc3RyaW5nJykgY29udGVudCA9IFtbbW9kdWxlLmlkLCBjb250ZW50LCAnJ11dO1xuXG52YXIgdHJhbnNmb3JtO1xudmFyIGluc2VydEludG87XG5cblxuXG52YXIgb3B0aW9ucyA9IHtcImhtclwiOnRydWV9XG5cbm9wdGlvbnMudHJhbnNmb3JtID0gdHJhbnNmb3JtXG5vcHRpb25zLmluc2VydEludG8gPSB1bmRlZmluZWQ7XG5cbnZhciB1cGRhdGUgPSByZXF1aXJlKFwiIS4uLy4uLy4uLy4uL3N0eWxlLWxvYWRlci9saWIvYWRkU3R5bGVzLmpzXCIpKGNvbnRlbnQsIG9wdGlvbnMpO1xuXG5pZihjb250ZW50LmxvY2FscykgbW9kdWxlLmV4cG9ydHMgPSBjb250ZW50LmxvY2FscztcblxuaWYobW9kdWxlLmhvdCkge1xuXHRtb2R1bGUuaG90LmFjY2VwdChcIiEhLi4vLi4vLi4vLi4vY3NzLWxvYWRlci9pbmRleC5qcyEuL2luZGV4LmNzc1wiLCBmdW5jdGlvbigpIHtcblx0XHR2YXIgbmV3Q29udGVudCA9IHJlcXVpcmUoXCIhIS4uLy4uLy4uLy4uL2Nzcy1sb2FkZXIvaW5kZXguanMhLi9pbmRleC5jc3NcIik7XG5cblx0XHRpZih0eXBlb2YgbmV3Q29udGVudCA9PT0gJ3N0cmluZycpIG5ld0NvbnRlbnQgPSBbW21vZHVsZS5pZCwgbmV3Q29udGVudCwgJyddXTtcblxuXHRcdHZhciBsb2NhbHMgPSAoZnVuY3Rpb24oYSwgYikge1xuXHRcdFx0dmFyIGtleSwgaWR4ID0gMDtcblxuXHRcdFx0Zm9yKGtleSBpbiBhKSB7XG5cdFx0XHRcdGlmKCFiIHx8IGFba2V5XSAhPT0gYltrZXldKSByZXR1cm4gZmFsc2U7XG5cdFx0XHRcdGlkeCsrO1xuXHRcdFx0fVxuXG5cdFx0XHRmb3Ioa2V5IGluIGIpIGlkeC0tO1xuXG5cdFx0XHRyZXR1cm4gaWR4ID09PSAwO1xuXHRcdH0oY29udGVudC5sb2NhbHMsIG5ld0NvbnRlbnQubG9jYWxzKSk7XG5cblx0XHRpZighbG9jYWxzKSB0aHJvdyBuZXcgRXJyb3IoJ0Fib3J0aW5nIENTUyBITVIgZHVlIHRvIGNoYW5nZWQgY3NzLW1vZHVsZXMgbG9jYWxzLicpO1xuXG5cdFx0dXBkYXRlKG5ld0NvbnRlbnQpO1xuXHR9KTtcblxuXHRtb2R1bGUuaG90LmRpc3Bvc2UoZnVuY3Rpb24oKSB7IHVwZGF0ZSgpOyB9KTtcbn0iLCJcbnZhciBjb250ZW50ID0gcmVxdWlyZShcIiEhLi4vLi4vLi4vLi4vY3NzLWxvYWRlci9pbmRleC5qcyEuL2luZGV4LmNzc1wiKTtcblxuaWYodHlwZW9mIGNvbnRlbnQgPT09ICdzdHJpbmcnKSBjb250ZW50ID0gW1ttb2R1bGUuaWQsIGNvbnRlbnQsICcnXV07XG5cbnZhciB0cmFuc2Zvcm07XG52YXIgaW5zZXJ0SW50bztcblxuXG5cbnZhciBvcHRpb25zID0ge1wiaG1yXCI6dHJ1ZX1cblxub3B0aW9ucy50cmFuc2Zvcm0gPSB0cmFuc2Zvcm1cbm9wdGlvbnMuaW5zZXJ0SW50byA9IHVuZGVmaW5lZDtcblxudmFyIHVwZGF0ZSA9IHJlcXVpcmUoXCIhLi4vLi4vLi4vLi4vc3R5bGUtbG9hZGVyL2xpYi9hZGRTdHlsZXMuanNcIikoY29udGVudCwgb3B0aW9ucyk7XG5cbmlmKGNvbnRlbnQubG9jYWxzKSBtb2R1bGUuZXhwb3J0cyA9IGNvbnRlbnQubG9jYWxzO1xuXG5pZihtb2R1bGUuaG90KSB7XG5cdG1vZHVsZS5ob3QuYWNjZXB0KFwiISEuLi8uLi8uLi8uLi9jc3MtbG9hZGVyL2luZGV4LmpzIS4vaW5kZXguY3NzXCIsIGZ1bmN0aW9uKCkge1xuXHRcdHZhciBuZXdDb250ZW50ID0gcmVxdWlyZShcIiEhLi4vLi4vLi4vLi4vY3NzLWxvYWRlci9pbmRleC5qcyEuL2luZGV4LmNzc1wiKTtcblxuXHRcdGlmKHR5cGVvZiBuZXdDb250ZW50ID09PSAnc3RyaW5nJykgbmV3Q29udGVudCA9IFtbbW9kdWxlLmlkLCBuZXdDb250ZW50LCAnJ11dO1xuXG5cdFx0dmFyIGxvY2FscyA9IChmdW5jdGlvbihhLCBiKSB7XG5cdFx0XHR2YXIga2V5LCBpZHggPSAwO1xuXG5cdFx0XHRmb3Ioa2V5IGluIGEpIHtcblx0XHRcdFx0aWYoIWIgfHwgYVtrZXldICE9PSBiW2tleV0pIHJldHVybiBmYWxzZTtcblx0XHRcdFx0aWR4Kys7XG5cdFx0XHR9XG5cblx0XHRcdGZvcihrZXkgaW4gYikgaWR4LS07XG5cblx0XHRcdHJldHVybiBpZHggPT09IDA7XG5cdFx0fShjb250ZW50LmxvY2FscywgbmV3Q29udGVudC5sb2NhbHMpKTtcblxuXHRcdGlmKCFsb2NhbHMpIHRocm93IG5ldyBFcnJvcignQWJvcnRpbmcgQ1NTIEhNUiBkdWUgdG8gY2hhbmdlZCBjc3MtbW9kdWxlcyBsb2NhbHMuJyk7XG5cblx0XHR1cGRhdGUobmV3Q29udGVudCk7XG5cdH0pO1xuXG5cdG1vZHVsZS5ob3QuZGlzcG9zZShmdW5jdGlvbigpIHsgdXBkYXRlKCk7IH0pO1xufSIsIlxudmFyIGNvbnRlbnQgPSByZXF1aXJlKFwiISEuLi8uLi8uLi8uLi9jc3MtbG9hZGVyL2luZGV4LmpzIS4vaW5kZXguY3NzXCIpO1xuXG5pZih0eXBlb2YgY29udGVudCA9PT0gJ3N0cmluZycpIGNvbnRlbnQgPSBbW21vZHVsZS5pZCwgY29udGVudCwgJyddXTtcblxudmFyIHRyYW5zZm9ybTtcbnZhciBpbnNlcnRJbnRvO1xuXG5cblxudmFyIG9wdGlvbnMgPSB7XCJobXJcIjp0cnVlfVxuXG5vcHRpb25zLnRyYW5zZm9ybSA9IHRyYW5zZm9ybVxub3B0aW9ucy5pbnNlcnRJbnRvID0gdW5kZWZpbmVkO1xuXG52YXIgdXBkYXRlID0gcmVxdWlyZShcIiEuLi8uLi8uLi8uLi9zdHlsZS1sb2FkZXIvbGliL2FkZFN0eWxlcy5qc1wiKShjb250ZW50LCBvcHRpb25zKTtcblxuaWYoY29udGVudC5sb2NhbHMpIG1vZHVsZS5leHBvcnRzID0gY29udGVudC5sb2NhbHM7XG5cbmlmKG1vZHVsZS5ob3QpIHtcblx0bW9kdWxlLmhvdC5hY2NlcHQoXCIhIS4uLy4uLy4uLy4uL2Nzcy1sb2FkZXIvaW5kZXguanMhLi9pbmRleC5jc3NcIiwgZnVuY3Rpb24oKSB7XG5cdFx0dmFyIG5ld0NvbnRlbnQgPSByZXF1aXJlKFwiISEuLi8uLi8uLi8uLi9jc3MtbG9hZGVyL2luZGV4LmpzIS4vaW5kZXguY3NzXCIpO1xuXG5cdFx0aWYodHlwZW9mIG5ld0NvbnRlbnQgPT09ICdzdHJpbmcnKSBuZXdDb250ZW50ID0gW1ttb2R1bGUuaWQsIG5ld0NvbnRlbnQsICcnXV07XG5cblx0XHR2YXIgbG9jYWxzID0gKGZ1bmN0aW9uKGEsIGIpIHtcblx0XHRcdHZhciBrZXksIGlkeCA9IDA7XG5cblx0XHRcdGZvcihrZXkgaW4gYSkge1xuXHRcdFx0XHRpZighYiB8fCBhW2tleV0gIT09IGJba2V5XSkgcmV0dXJuIGZhbHNlO1xuXHRcdFx0XHRpZHgrKztcblx0XHRcdH1cblxuXHRcdFx0Zm9yKGtleSBpbiBiKSBpZHgtLTtcblxuXHRcdFx0cmV0dXJuIGlkeCA9PT0gMDtcblx0XHR9KGNvbnRlbnQubG9jYWxzLCBuZXdDb250ZW50LmxvY2FscykpO1xuXG5cdFx0aWYoIWxvY2FscykgdGhyb3cgbmV3IEVycm9yKCdBYm9ydGluZyBDU1MgSE1SIGR1ZSB0byBjaGFuZ2VkIGNzcy1tb2R1bGVzIGxvY2Fscy4nKTtcblxuXHRcdHVwZGF0ZShuZXdDb250ZW50KTtcblx0fSk7XG5cblx0bW9kdWxlLmhvdC5kaXNwb3NlKGZ1bmN0aW9uKCkgeyB1cGRhdGUoKTsgfSk7XG59IiwiXG52YXIgY29udGVudCA9IHJlcXVpcmUoXCIhIS4uLy4uLy4uLy4uL2Nzcy1sb2FkZXIvaW5kZXguanMhLi9pbmRleC5jc3NcIik7XG5cbmlmKHR5cGVvZiBjb250ZW50ID09PSAnc3RyaW5nJykgY29udGVudCA9IFtbbW9kdWxlLmlkLCBjb250ZW50LCAnJ11dO1xuXG52YXIgdHJhbnNmb3JtO1xudmFyIGluc2VydEludG87XG5cblxuXG52YXIgb3B0aW9ucyA9IHtcImhtclwiOnRydWV9XG5cbm9wdGlvbnMudHJhbnNmb3JtID0gdHJhbnNmb3JtXG5vcHRpb25zLmluc2VydEludG8gPSB1bmRlZmluZWQ7XG5cbnZhciB1cGRhdGUgPSByZXF1aXJlKFwiIS4uLy4uLy4uLy4uL3N0eWxlLWxvYWRlci9saWIvYWRkU3R5bGVzLmpzXCIpKGNvbnRlbnQsIG9wdGlvbnMpO1xuXG5pZihjb250ZW50LmxvY2FscykgbW9kdWxlLmV4cG9ydHMgPSBjb250ZW50LmxvY2FscztcblxuaWYobW9kdWxlLmhvdCkge1xuXHRtb2R1bGUuaG90LmFjY2VwdChcIiEhLi4vLi4vLi4vLi4vY3NzLWxvYWRlci9pbmRleC5qcyEuL2luZGV4LmNzc1wiLCBmdW5jdGlvbigpIHtcblx0XHR2YXIgbmV3Q29udGVudCA9IHJlcXVpcmUoXCIhIS4uLy4uLy4uLy4uL2Nzcy1sb2FkZXIvaW5kZXguanMhLi9pbmRleC5jc3NcIik7XG5cblx0XHRpZih0eXBlb2YgbmV3Q29udGVudCA9PT0gJ3N0cmluZycpIG5ld0NvbnRlbnQgPSBbW21vZHVsZS5pZCwgbmV3Q29udGVudCwgJyddXTtcblxuXHRcdHZhciBsb2NhbHMgPSAoZnVuY3Rpb24oYSwgYikge1xuXHRcdFx0dmFyIGtleSwgaWR4ID0gMDtcblxuXHRcdFx0Zm9yKGtleSBpbiBhKSB7XG5cdFx0XHRcdGlmKCFiIHx8IGFba2V5XSAhPT0gYltrZXldKSByZXR1cm4gZmFsc2U7XG5cdFx0XHRcdGlkeCsrO1xuXHRcdFx0fVxuXG5cdFx0XHRmb3Ioa2V5IGluIGIpIGlkeC0tO1xuXG5cdFx0XHRyZXR1cm4gaWR4ID09PSAwO1xuXHRcdH0oY29udGVudC5sb2NhbHMsIG5ld0NvbnRlbnQubG9jYWxzKSk7XG5cblx0XHRpZighbG9jYWxzKSB0aHJvdyBuZXcgRXJyb3IoJ0Fib3J0aW5nIENTUyBITVIgZHVlIHRvIGNoYW5nZWQgY3NzLW1vZHVsZXMgbG9jYWxzLicpO1xuXG5cdFx0dXBkYXRlKG5ld0NvbnRlbnQpO1xuXHR9KTtcblxuXHRtb2R1bGUuaG90LmRpc3Bvc2UoZnVuY3Rpb24oKSB7IHVwZGF0ZSgpOyB9KTtcbn0iLCJleHBvcnRzID0gbW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiLi4vLi4vLi4vLi4vY3NzLWxvYWRlci9saWIvY3NzLWJhc2UuanNcIikoZmFsc2UpO1xuLy8gaW1wb3J0c1xuXG5cbi8vIG1vZHVsZVxuZXhwb3J0cy5wdXNoKFttb2R1bGUuaWQsIFwiLyogc3R5bGVsaW50LWRpc2FibGUgYXQtcnVsZS1lbXB0eS1saW5lLWJlZm9yZSxhdC1ydWxlLW5hbWUtc3BhY2UtYWZ0ZXIsYXQtcnVsZS1uby11bmtub3duICovXFxuLyogc3R5bGVsaW50LWRpc2FibGUgbm8tZHVwbGljYXRlLXNlbGVjdG9ycyAqL1xcbi8qIHN0eWxlbGludC1kaXNhYmxlIGRlY2xhcmF0aW9uLWJhbmctc3BhY2UtYmVmb3JlLG5vLWR1cGxpY2F0ZS1zZWxlY3RvcnMgKi9cXG4vKiBzdHlsZWxpbnQtZGlzYWJsZSBkZWNsYXJhdGlvbi1iYW5nLXNwYWNlLWJlZm9yZSxuby1kdXBsaWNhdGUtc2VsZWN0b3JzLHN0cmluZy1uby1uZXdsaW5lICovXFxuLmFudC1jYXJkIHtcXG4gIGZvbnQtZmFtaWx5OiBcXFwiTW9ub3NwYWNlZCBOdW1iZXJcXFwiLCBcXFwiQ2hpbmVzZSBRdW90ZVxcXCIsIC1hcHBsZS1zeXN0ZW0sIEJsaW5rTWFjU3lzdGVtRm9udCwgXFxcIlNlZ29lIFVJXFxcIiwgUm9ib3RvLCBcXFwiUGluZ0ZhbmcgU0NcXFwiLCBcXFwiSGlyYWdpbm8gU2FucyBHQlxcXCIsIFxcXCJNaWNyb3NvZnQgWWFIZWlcXFwiLCBcXFwiSGVsdmV0aWNhIE5ldWVcXFwiLCBIZWx2ZXRpY2EsIEFyaWFsLCBzYW5zLXNlcmlmO1xcbiAgZm9udC1zaXplOiAxNHB4O1xcbiAgbGluZS1oZWlnaHQ6IDEuNTtcXG4gIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuNjUpO1xcbiAgLXdlYmtpdC1ib3gtc2l6aW5nOiBib3JkZXItYm94O1xcbiAgICAgICAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xcbiAgbWFyZ2luOiAwO1xcbiAgcGFkZGluZzogMDtcXG4gIGxpc3Qtc3R5bGU6IG5vbmU7XFxuICBiYWNrZ3JvdW5kOiAjZmZmO1xcbiAgYm9yZGVyLXJhZGl1czogMnB4O1xcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xcbiAgLXdlYmtpdC10cmFuc2l0aW9uOiBhbGwgLjNzO1xcbiAgdHJhbnNpdGlvbjogYWxsIC4zcztcXG59XFxuLmFudC1jYXJkLWhvdmVyYWJsZSB7XFxuICBjdXJzb3I6IHBvaW50ZXI7XFxufVxcbi5hbnQtY2FyZC1ob3ZlcmFibGU6aG92ZXIge1xcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiAwIDJweCA4cHggcmdiYSgwLCAwLCAwLCAwLjA5KTtcXG4gICAgICAgICAgYm94LXNoYWRvdzogMCAycHggOHB4IHJnYmEoMCwgMCwgMCwgMC4wOSk7XFxuICBib3JkZXItY29sb3I6IHJnYmEoMCwgMCwgMCwgMC4wOSk7XFxufVxcbi5hbnQtY2FyZC1ib3JkZXJlZCB7XFxuICBib3JkZXI6IDFweCBzb2xpZCAjZThlOGU4O1xcbn1cXG4uYW50LWNhcmQtaGVhZCB7XFxuICBiYWNrZ3JvdW5kOiAjZmZmO1xcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlOGU4ZTg7XFxuICBwYWRkaW5nOiAwIDI0cHg7XFxuICBib3JkZXItcmFkaXVzOiAycHggMnB4IDAgMDtcXG4gIHpvb206IDE7XFxuICBtYXJnaW4tYm90dG9tOiAtMXB4O1xcbiAgbWluLWhlaWdodDogNDhweDtcXG59XFxuLmFudC1jYXJkLWhlYWQ6YmVmb3JlLFxcbi5hbnQtY2FyZC1oZWFkOmFmdGVyIHtcXG4gIGNvbnRlbnQ6IFxcXCIgXFxcIjtcXG4gIGRpc3BsYXk6IHRhYmxlO1xcbn1cXG4uYW50LWNhcmQtaGVhZDphZnRlciB7XFxuICBjbGVhcjogYm90aDtcXG4gIHZpc2liaWxpdHk6IGhpZGRlbjtcXG4gIGZvbnQtc2l6ZTogMDtcXG4gIGhlaWdodDogMDtcXG59XFxuLmFudC1jYXJkLWhlYWQtd3JhcHBlciB7XFxuICBkaXNwbGF5OiAtd2Via2l0LWJveDtcXG4gIGRpc3BsYXk6IC13ZWJraXQtZmxleDtcXG4gIGRpc3BsYXk6IC1tcy1mbGV4Ym94O1xcbiAgZGlzcGxheTogZmxleDtcXG59XFxuLmFudC1jYXJkLWhlYWQtdGl0bGUge1xcbiAgZm9udC1zaXplOiAxNnB4O1xcbiAgcGFkZGluZzogMTZweCAwO1xcbiAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XFxuICBvdmVyZmxvdzogaGlkZGVuO1xcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcXG4gIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuODUpO1xcbiAgZm9udC13ZWlnaHQ6IDUwMDtcXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcXG4gIC13ZWJraXQtYm94LWZsZXg6IDE7XFxuICAtd2Via2l0LWZsZXg6IDE7XFxuICAgICAgLW1zLWZsZXg6IDE7XFxuICAgICAgICAgIGZsZXg6IDE7XFxufVxcbi5hbnQtY2FyZC1oZWFkIC5hbnQtdGFicyB7XFxuICBtYXJnaW4tYm90dG9tOiAtMTdweDtcXG4gIGNsZWFyOiBib3RoO1xcbn1cXG4uYW50LWNhcmQtaGVhZCAuYW50LXRhYnMtYmFyIHtcXG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZThlOGU4O1xcbn1cXG4uYW50LWNhcmQtZXh0cmEge1xcbiAgZmxvYXQ6IHJpZ2h0O1xcbiAgcGFkZGluZzogMTcuNXB4IDA7XFxuICB0ZXh0LWFsaWduOiByaWdodDtcXG4gIG1hcmdpbi1sZWZ0OiBhdXRvO1xcbn1cXG4uYW50LWNhcmQtYm9keSB7XFxuICBwYWRkaW5nOiAyNHB4O1xcbiAgem9vbTogMTtcXG59XFxuLmFudC1jYXJkLWJvZHk6YmVmb3JlLFxcbi5hbnQtY2FyZC1ib2R5OmFmdGVyIHtcXG4gIGNvbnRlbnQ6IFxcXCIgXFxcIjtcXG4gIGRpc3BsYXk6IHRhYmxlO1xcbn1cXG4uYW50LWNhcmQtYm9keTphZnRlciB7XFxuICBjbGVhcjogYm90aDtcXG4gIHZpc2liaWxpdHk6IGhpZGRlbjtcXG4gIGZvbnQtc2l6ZTogMDtcXG4gIGhlaWdodDogMDtcXG59XFxuLmFudC1jYXJkLWNvbnRhaW4tZ3JpZDpub3QoLmFudC1jYXJkLWxvYWRpbmcpIHtcXG4gIG1hcmdpbjogLTFweCAwIDAgLTFweDtcXG4gIHBhZGRpbmc6IDA7XFxufVxcbi5hbnQtY2FyZC1ncmlkIHtcXG4gIGJvcmRlci1yYWRpdXM6IDA7XFxuICBib3JkZXI6IDA7XFxuICAtd2Via2l0LWJveC1zaGFkb3c6IDFweCAwIDAgMCAjZThlOGU4LCAwIDFweCAwIDAgI2U4ZThlOCwgMXB4IDFweCAwIDAgI2U4ZThlOCwgMXB4IDAgMCAwICNlOGU4ZTggaW5zZXQsIDAgMXB4IDAgMCAjZThlOGU4IGluc2V0O1xcbiAgICAgICAgICBib3gtc2hhZG93OiAxcHggMCAwIDAgI2U4ZThlOCwgMCAxcHggMCAwICNlOGU4ZTgsIDFweCAxcHggMCAwICNlOGU4ZTgsIDFweCAwIDAgMCAjZThlOGU4IGluc2V0LCAwIDFweCAwIDAgI2U4ZThlOCBpbnNldDtcXG4gIHdpZHRoOiAzMy4zMyU7XFxuICBmbG9hdDogbGVmdDtcXG4gIHBhZGRpbmc6IDI0cHg7XFxuICAtd2Via2l0LXRyYW5zaXRpb246IGFsbCAuM3M7XFxuICB0cmFuc2l0aW9uOiBhbGwgLjNzO1xcbn1cXG4uYW50LWNhcmQtZ3JpZDpob3ZlciB7XFxuICBwb3NpdGlvbjogcmVsYXRpdmU7XFxuICB6LWluZGV4OiAxO1xcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiAwIDJweCA4cHggcmdiYSgwLCAwLCAwLCAwLjE1KTtcXG4gICAgICAgICAgYm94LXNoYWRvdzogMCAycHggOHB4IHJnYmEoMCwgMCwgMCwgMC4xNSk7XFxufVxcbi5hbnQtY2FyZC1jb250YWluLXRhYnMgLmFudC1jYXJkLWhlYWQtdGl0bGUge1xcbiAgcGFkZGluZy1ib3R0b206IDA7XFxuICBtaW4taGVpZ2h0OiAzMnB4O1xcbn1cXG4uYW50LWNhcmQtY29udGFpbi10YWJzIC5hbnQtY2FyZC1leHRyYSB7XFxuICBwYWRkaW5nLWJvdHRvbTogMDtcXG59XFxuLmFudC1jYXJkLWNvdmVyID4gKiB7XFxuICB3aWR0aDogMTAwJTtcXG4gIGRpc3BsYXk6IGJsb2NrO1xcbn1cXG4uYW50LWNhcmQtYWN0aW9ucyB7XFxuICBib3JkZXItdG9wOiAxcHggc29saWQgI2U4ZThlODtcXG4gIGJhY2tncm91bmQ6ICNmYWZhZmE7XFxuICB6b29tOiAxO1xcbiAgbGlzdC1zdHlsZTogbm9uZTtcXG4gIG1hcmdpbjogMDtcXG4gIHBhZGRpbmc6IDA7XFxufVxcbi5hbnQtY2FyZC1hY3Rpb25zOmJlZm9yZSxcXG4uYW50LWNhcmQtYWN0aW9uczphZnRlciB7XFxuICBjb250ZW50OiBcXFwiIFxcXCI7XFxuICBkaXNwbGF5OiB0YWJsZTtcXG59XFxuLmFudC1jYXJkLWFjdGlvbnM6YWZ0ZXIge1xcbiAgY2xlYXI6IGJvdGg7XFxuICB2aXNpYmlsaXR5OiBoaWRkZW47XFxuICBmb250LXNpemU6IDA7XFxuICBoZWlnaHQ6IDA7XFxufVxcbi5hbnQtY2FyZC1hY3Rpb25zID4gbGkge1xcbiAgZmxvYXQ6IGxlZnQ7XFxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XFxuICBtYXJnaW46IDEycHggMDtcXG4gIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuNDUpO1xcbn1cXG4uYW50LWNhcmQtYWN0aW9ucyA+IGxpID4gc3BhbiB7XFxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XFxuICBmb250LXNpemU6IDE0cHg7XFxuICBjdXJzb3I6IHBvaW50ZXI7XFxuICBsaW5lLWhlaWdodDogMjJweDtcXG4gIG1pbi13aWR0aDogMzJweDtcXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcXG59XFxuLmFudC1jYXJkLWFjdGlvbnMgPiBsaSA+IHNwYW46aG92ZXIge1xcbiAgY29sb3I6ICMxODkwZmY7XFxuICAtd2Via2l0LXRyYW5zaXRpb246IGNvbG9yIC4zcztcXG4gIHRyYW5zaXRpb246IGNvbG9yIC4zcztcXG59XFxuLmFudC1jYXJkLWFjdGlvbnMgPiBsaSA+IHNwYW4gPiAuYW50aWNvbiB7XFxuICBmb250LXNpemU6IDE2cHg7XFxuICBsaW5lLWhlaWdodDogMjJweDtcXG4gIGRpc3BsYXk6IGJsb2NrO1xcbiAgd2lkdGg6IDEwMCU7XFxufVxcbi5hbnQtY2FyZC1hY3Rpb25zID4gbGkgPiBzcGFuIGEge1xcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC40NSk7XFxuICBsaW5lLWhlaWdodDogMjJweDtcXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcXG4gIHdpZHRoOiAxMDAlO1xcbn1cXG4uYW50LWNhcmQtYWN0aW9ucyA+IGxpID4gc3BhbiBhOmhvdmVyIHtcXG4gIGNvbG9yOiAjMTg5MGZmO1xcbn1cXG4uYW50LWNhcmQtYWN0aW9ucyA+IGxpOm5vdCg6bGFzdC1jaGlsZCkge1xcbiAgYm9yZGVyLXJpZ2h0OiAxcHggc29saWQgI2U4ZThlODtcXG59XFxuLmFudC1jYXJkLXdpZGVyLXBhZGRpbmcgLmFudC1jYXJkLWhlYWQge1xcbiAgcGFkZGluZzogMCAzMnB4O1xcbn1cXG4uYW50LWNhcmQtd2lkZXItcGFkZGluZyAuYW50LWNhcmQtYm9keSB7XFxuICBwYWRkaW5nOiAyNHB4IDMycHg7XFxufVxcbi5hbnQtY2FyZC1wYWRkaW5nLXRyYW5zaXRpb24gLmFudC1jYXJkLWhlYWQsXFxuLmFudC1jYXJkLXBhZGRpbmctdHJhbnNpdGlvbiAuYW50LWNhcmQtYm9keSB7XFxuICAtd2Via2l0LXRyYW5zaXRpb246IHBhZGRpbmcgLjNzO1xcbiAgdHJhbnNpdGlvbjogcGFkZGluZyAuM3M7XFxufVxcbi5hbnQtY2FyZC10eXBlLWlubmVyIC5hbnQtY2FyZC1oZWFkIHtcXG4gIHBhZGRpbmc6IDAgMjRweDtcXG4gIGJhY2tncm91bmQ6ICNmYWZhZmE7XFxufVxcbi5hbnQtY2FyZC10eXBlLWlubmVyIC5hbnQtY2FyZC1oZWFkLXRpdGxlIHtcXG4gIHBhZGRpbmc6IDEycHggMDtcXG4gIGZvbnQtc2l6ZTogMTRweDtcXG59XFxuLmFudC1jYXJkLXR5cGUtaW5uZXIgLmFudC1jYXJkLWJvZHkge1xcbiAgcGFkZGluZzogMTZweCAyNHB4O1xcbn1cXG4uYW50LWNhcmQtdHlwZS1pbm5lciAuYW50LWNhcmQtZXh0cmEge1xcbiAgcGFkZGluZzogMTMuNXB4IDA7XFxufVxcbi5hbnQtY2FyZC1tZXRhIHtcXG4gIG1hcmdpbjogLTRweCAwO1xcbiAgem9vbTogMTtcXG59XFxuLmFudC1jYXJkLW1ldGE6YmVmb3JlLFxcbi5hbnQtY2FyZC1tZXRhOmFmdGVyIHtcXG4gIGNvbnRlbnQ6IFxcXCIgXFxcIjtcXG4gIGRpc3BsYXk6IHRhYmxlO1xcbn1cXG4uYW50LWNhcmQtbWV0YTphZnRlciB7XFxuICBjbGVhcjogYm90aDtcXG4gIHZpc2liaWxpdHk6IGhpZGRlbjtcXG4gIGZvbnQtc2l6ZTogMDtcXG4gIGhlaWdodDogMDtcXG59XFxuLmFudC1jYXJkLW1ldGEtYXZhdGFyIHtcXG4gIHBhZGRpbmctcmlnaHQ6IDE2cHg7XFxuICBmbG9hdDogbGVmdDtcXG59XFxuLmFudC1jYXJkLW1ldGEtZGV0YWlsIHtcXG4gIG92ZXJmbG93OiBoaWRkZW47XFxufVxcbi5hbnQtY2FyZC1tZXRhLWRldGFpbCA+IGRpdjpub3QoOmxhc3QtY2hpbGQpIHtcXG4gIG1hcmdpbi1ib3R0b206IDhweDtcXG59XFxuLmFudC1jYXJkLW1ldGEtdGl0bGUge1xcbiAgZm9udC1zaXplOiAxNnB4O1xcbiAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XFxuICBvdmVyZmxvdzogaGlkZGVuO1xcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcXG4gIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuODUpO1xcbiAgZm9udC13ZWlnaHQ6IDUwMDtcXG59XFxuLmFudC1jYXJkLW1ldGEtZGVzY3JpcHRpb24ge1xcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC40NSk7XFxufVxcbi5hbnQtY2FyZC1sb2FkaW5nIC5hbnQtY2FyZC1ib2R5IHtcXG4gIC13ZWJraXQtdXNlci1zZWxlY3Q6IG5vbmU7XFxuICAgICAtbW96LXVzZXItc2VsZWN0OiBub25lO1xcbiAgICAgIC1tcy11c2VyLXNlbGVjdDogbm9uZTtcXG4gICAgICAgICAgdXNlci1zZWxlY3Q6IG5vbmU7XFxufVxcbi5hbnQtY2FyZC1sb2FkaW5nLWNvbnRlbnQgcCB7XFxuICBtYXJnaW46IDA7XFxufVxcbi5hbnQtY2FyZC1sb2FkaW5nLWJsb2NrIHtcXG4gIGhlaWdodDogMTRweDtcXG4gIG1hcmdpbjogNHB4IDA7XFxuICBib3JkZXItcmFkaXVzOiAycHg7XFxuICBiYWNrZ3JvdW5kOiAtd2Via2l0LWdyYWRpZW50KGxpbmVhciwgbGVmdCB0b3AsIHJpZ2h0IHRvcCwgZnJvbShyZ2JhKDIwNywgMjE2LCAyMjAsIDAuMikpLCBjb2xvci1zdG9wKHJnYmEoMjA3LCAyMTYsIDIyMCwgMC40KSksIHRvKHJnYmEoMjA3LCAyMTYsIDIyMCwgMC4yKSkpO1xcbiAgYmFja2dyb3VuZDogLXdlYmtpdC1saW5lYXItZ3JhZGllbnQobGVmdCwgcmdiYSgyMDcsIDIxNiwgMjIwLCAwLjIpLCByZ2JhKDIwNywgMjE2LCAyMjAsIDAuNCksIHJnYmEoMjA3LCAyMTYsIDIyMCwgMC4yKSk7XFxuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMjA3LCAyMTYsIDIyMCwgMC4yKSwgcmdiYSgyMDcsIDIxNiwgMjIwLCAwLjQpLCByZ2JhKDIwNywgMjE2LCAyMjAsIDAuMikpO1xcbiAgLXdlYmtpdC1hbmltYXRpb246IGNhcmQtbG9hZGluZyAxLjRzIGVhc2UgaW5maW5pdGU7XFxuICAgICAgICAgIGFuaW1hdGlvbjogY2FyZC1sb2FkaW5nIDEuNHMgZWFzZSBpbmZpbml0ZTtcXG4gIGJhY2tncm91bmQtc2l6ZTogNjAwJSA2MDAlO1xcbn1cXG5ALXdlYmtpdC1rZXlmcmFtZXMgY2FyZC1sb2FkaW5nIHtcXG4gIDAlLFxcbiAgMTAwJSB7XFxuICAgIGJhY2tncm91bmQtcG9zaXRpb246IDAgNTAlO1xcbiAgfVxcbiAgNTAlIHtcXG4gICAgYmFja2dyb3VuZC1wb3NpdGlvbjogMTAwJSA1MCU7XFxuICB9XFxufVxcbkBrZXlmcmFtZXMgY2FyZC1sb2FkaW5nIHtcXG4gIDAlLFxcbiAgMTAwJSB7XFxuICAgIGJhY2tncm91bmQtcG9zaXRpb246IDAgNTAlO1xcbiAgfVxcbiAgNTAlIHtcXG4gICAgYmFja2dyb3VuZC1wb3NpdGlvbjogMTAwJSA1MCU7XFxuICB9XFxufVxcblwiLCBcIlwiXSk7XG5cbi8vIGV4cG9ydHNcbiIsImV4cG9ydHMgPSBtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCIuLi8uLi8uLi8uLi9jc3MtbG9hZGVyL2xpYi9jc3MtYmFzZS5qc1wiKShmYWxzZSk7XG4vLyBpbXBvcnRzXG5cblxuLy8gbW9kdWxlXG5leHBvcnRzLnB1c2goW21vZHVsZS5pZCwgXCIvKiBzdHlsZWxpbnQtZGlzYWJsZSBhdC1ydWxlLWVtcHR5LWxpbmUtYmVmb3JlLGF0LXJ1bGUtbmFtZS1zcGFjZS1hZnRlcixhdC1ydWxlLW5vLXVua25vd24gKi9cXG4vKiBzdHlsZWxpbnQtZGlzYWJsZSBuby1kdXBsaWNhdGUtc2VsZWN0b3JzICovXFxuLyogc3R5bGVsaW50LWRpc2FibGUgZGVjbGFyYXRpb24tYmFuZy1zcGFjZS1iZWZvcmUsbm8tZHVwbGljYXRlLXNlbGVjdG9ycyAqL1xcbi8qIHN0eWxlbGludC1kaXNhYmxlIGRlY2xhcmF0aW9uLWJhbmctc3BhY2UtYmVmb3JlLG5vLWR1cGxpY2F0ZS1zZWxlY3RvcnMsc3RyaW5nLW5vLW5ld2xpbmUgKi9cXG4uYW50LXBhZ2luYXRpb24ge1xcbiAgZm9udC1mYW1pbHk6IFxcXCJNb25vc3BhY2VkIE51bWJlclxcXCIsIFxcXCJDaGluZXNlIFF1b3RlXFxcIiwgLWFwcGxlLXN5c3RlbSwgQmxpbmtNYWNTeXN0ZW1Gb250LCBcXFwiU2Vnb2UgVUlcXFwiLCBSb2JvdG8sIFxcXCJQaW5nRmFuZyBTQ1xcXCIsIFxcXCJIaXJhZ2lubyBTYW5zIEdCXFxcIiwgXFxcIk1pY3Jvc29mdCBZYUhlaVxcXCIsIFxcXCJIZWx2ZXRpY2EgTmV1ZVxcXCIsIEhlbHZldGljYSwgQXJpYWwsIHNhbnMtc2VyaWY7XFxuICBmb250LXNpemU6IDE0cHg7XFxuICBsaW5lLWhlaWdodDogMS41O1xcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC42NSk7XFxuICAtd2Via2l0LWJveC1zaXppbmc6IGJvcmRlci1ib3g7XFxuICAgICAgICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XFxuICBtYXJnaW46IDA7XFxuICBwYWRkaW5nOiAwO1xcbiAgbGlzdC1zdHlsZTogbm9uZTtcXG59XFxuLmFudC1wYWdpbmF0aW9uIHVsLFxcbi5hbnQtcGFnaW5hdGlvbiBvbCB7XFxuICBtYXJnaW46IDA7XFxuICBwYWRkaW5nOiAwO1xcbiAgbGlzdC1zdHlsZTogbm9uZTtcXG59XFxuLmFudC1wYWdpbmF0aW9uOmFmdGVyIHtcXG4gIGNvbnRlbnQ6IFxcXCIgXFxcIjtcXG4gIGRpc3BsYXk6IGJsb2NrO1xcbiAgaGVpZ2h0OiAwO1xcbiAgY2xlYXI6IGJvdGg7XFxuICBvdmVyZmxvdzogaGlkZGVuO1xcbiAgdmlzaWJpbGl0eTogaGlkZGVuO1xcbn1cXG4uYW50LXBhZ2luYXRpb24tdG90YWwtdGV4dCB7XFxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XFxuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xcbiAgaGVpZ2h0OiAzMnB4O1xcbiAgbGluZS1oZWlnaHQ6IDMwcHg7XFxuICBtYXJnaW4tcmlnaHQ6IDhweDtcXG59XFxuLmFudC1wYWdpbmF0aW9uLWl0ZW0ge1xcbiAgY3Vyc29yOiBwb2ludGVyO1xcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xcbiAgLXdlYmtpdC11c2VyLXNlbGVjdDogbm9uZTtcXG4gICAgIC1tb3otdXNlci1zZWxlY3Q6IG5vbmU7XFxuICAgICAgLW1zLXVzZXItc2VsZWN0OiBub25lO1xcbiAgICAgICAgICB1c2VyLXNlbGVjdDogbm9uZTtcXG4gIG1pbi13aWR0aDogMzJweDtcXG4gIGhlaWdodDogMzJweDtcXG4gIGxpbmUtaGVpZ2h0OiAzMHB4O1xcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xcbiAgbGlzdC1zdHlsZTogbm9uZTtcXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcXG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XFxuICBib3JkZXI6IDFweCBzb2xpZCAjZDlkOWQ5O1xcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcXG4gIG1hcmdpbi1yaWdodDogOHB4O1xcbiAgZm9udC1mYW1pbHk6IEFyaWFsO1xcbiAgb3V0bGluZTogMDtcXG59XFxuLmFudC1wYWdpbmF0aW9uLWl0ZW0gYSB7XFxuICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XFxuICBjb2xvcjogcmdiYSgwLCAwLCAwLCAwLjY1KTtcXG4gIC13ZWJraXQtdHJhbnNpdGlvbjogbm9uZTtcXG4gIHRyYW5zaXRpb246IG5vbmU7XFxuICBtYXJnaW46IDAgNnB4O1xcbn1cXG4uYW50LXBhZ2luYXRpb24taXRlbTpmb2N1cyxcXG4uYW50LXBhZ2luYXRpb24taXRlbTpob3ZlciB7XFxuICAtd2Via2l0LXRyYW5zaXRpb246IGFsbCAuM3M7XFxuICB0cmFuc2l0aW9uOiBhbGwgLjNzO1xcbiAgYm9yZGVyLWNvbG9yOiAjMTg5MGZmO1xcbn1cXG4uYW50LXBhZ2luYXRpb24taXRlbTpmb2N1cyBhLFxcbi5hbnQtcGFnaW5hdGlvbi1pdGVtOmhvdmVyIGEge1xcbiAgY29sb3I6ICMxODkwZmY7XFxufVxcbi5hbnQtcGFnaW5hdGlvbi1pdGVtLWFjdGl2ZSB7XFxuICBib3JkZXItY29sb3I6ICMxODkwZmY7XFxuICBmb250LXdlaWdodDogNTAwO1xcbn1cXG4uYW50LXBhZ2luYXRpb24taXRlbS1hY3RpdmUgYSB7XFxuICBjb2xvcjogIzE4OTBmZjtcXG59XFxuLmFudC1wYWdpbmF0aW9uLWl0ZW0tYWN0aXZlOmZvY3VzLFxcbi5hbnQtcGFnaW5hdGlvbi1pdGVtLWFjdGl2ZTpob3ZlciB7XFxuICBib3JkZXItY29sb3I6ICM0MGE5ZmY7XFxufVxcbi5hbnQtcGFnaW5hdGlvbi1pdGVtLWFjdGl2ZTpmb2N1cyBhLFxcbi5hbnQtcGFnaW5hdGlvbi1pdGVtLWFjdGl2ZTpob3ZlciBhIHtcXG4gIGNvbG9yOiAjNDBhOWZmO1xcbn1cXG4uYW50LXBhZ2luYXRpb24tanVtcC1wcmV2LFxcbi5hbnQtcGFnaW5hdGlvbi1qdW1wLW5leHQge1xcbiAgb3V0bGluZTogMDtcXG59XFxuLmFudC1wYWdpbmF0aW9uLWp1bXAtcHJldjphZnRlcixcXG4uYW50LXBhZ2luYXRpb24tanVtcC1uZXh0OmFmdGVyIHtcXG4gIGNvbnRlbnQ6IFxcXCJcXFxcMjAyMlxcXFwyMDIyXFxcXDIwMjJcXFwiO1xcbiAgZGlzcGxheTogYmxvY2s7XFxuICBsZXR0ZXItc3BhY2luZzogMnB4O1xcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC4yNSk7XFxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XFxufVxcbi5hbnQtcGFnaW5hdGlvbi1qdW1wLXByZXY6Zm9jdXM6YWZ0ZXIsXFxuLmFudC1wYWdpbmF0aW9uLWp1bXAtbmV4dDpmb2N1czphZnRlcixcXG4uYW50LXBhZ2luYXRpb24tanVtcC1wcmV2OmhvdmVyOmFmdGVyLFxcbi5hbnQtcGFnaW5hdGlvbi1qdW1wLW5leHQ6aG92ZXI6YWZ0ZXIge1xcbiAgY29sb3I6ICMxODkwZmY7XFxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XFxuICBmb250LXNpemU6IDEycHg7XFxuICBmb250LXNpemU6IDhweCBcXFxcOTtcXG4gIC13ZWJraXQtdHJhbnNmb3JtOiBzY2FsZSgwLjY2NjY2NjY3KSByb3RhdGUoMGRlZyk7XFxuICAgICAgLW1zLXRyYW5zZm9ybTogc2NhbGUoMC42NjY2NjY2Nykgcm90YXRlKDBkZWcpO1xcbiAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDAuNjY2NjY2NjcpIHJvdGF0ZSgwZGVnKTtcXG4gIGxldHRlci1zcGFjaW5nOiAtMXB4O1xcbiAgZm9udC1mYW1pbHk6IFxcXCJhbnRpY29uXFxcIjtcXG59XFxuOnJvb3QgLmFudC1wYWdpbmF0aW9uLWp1bXAtcHJldjpmb2N1czphZnRlcixcXG46cm9vdCAuYW50LXBhZ2luYXRpb24tanVtcC1uZXh0OmZvY3VzOmFmdGVyLFxcbjpyb290IC5hbnQtcGFnaW5hdGlvbi1qdW1wLXByZXY6aG92ZXI6YWZ0ZXIsXFxuOnJvb3QgLmFudC1wYWdpbmF0aW9uLWp1bXAtbmV4dDpob3ZlcjphZnRlciB7XFxuICBmb250LXNpemU6IDEycHg7XFxufVxcbi5hbnQtcGFnaW5hdGlvbi1qdW1wLXByZXY6Zm9jdXM6YWZ0ZXIsXFxuLmFudC1wYWdpbmF0aW9uLWp1bXAtcHJldjpob3ZlcjphZnRlciB7XFxuICBjb250ZW50OiBcXFwiXFxcXEU2MjBcXFxcRTYyMFxcXCI7XFxufVxcbi5hbnQtcGFnaW5hdGlvbi1qdW1wLW5leHQ6Zm9jdXM6YWZ0ZXIsXFxuLmFudC1wYWdpbmF0aW9uLWp1bXAtbmV4dDpob3ZlcjphZnRlciB7XFxuICBjb250ZW50OiBcXFwiXFxcXEU2MUZcXFxcRTYxRlxcXCI7XFxufVxcbi5hbnQtcGFnaW5hdGlvbi1wcmV2LFxcbi5hbnQtcGFnaW5hdGlvbi1qdW1wLXByZXYsXFxuLmFudC1wYWdpbmF0aW9uLWp1bXAtbmV4dCB7XFxuICBtYXJnaW4tcmlnaHQ6IDhweDtcXG59XFxuLmFudC1wYWdpbmF0aW9uLXByZXYsXFxuLmFudC1wYWdpbmF0aW9uLW5leHQsXFxuLmFudC1wYWdpbmF0aW9uLWp1bXAtcHJldixcXG4uYW50LXBhZ2luYXRpb24tanVtcC1uZXh0IHtcXG4gIGZvbnQtZmFtaWx5OiBBcmlhbDtcXG4gIGN1cnNvcjogcG9pbnRlcjtcXG4gIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuNjUpO1xcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xcbiAgbGlzdC1zdHlsZTogbm9uZTtcXG4gIG1pbi13aWR0aDogMzJweDtcXG4gIGhlaWdodDogMzJweDtcXG4gIGxpbmUtaGVpZ2h0OiAzMnB4O1xcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xcbiAgLXdlYmtpdC10cmFuc2l0aW9uOiBhbGwgLjNzO1xcbiAgdHJhbnNpdGlvbjogYWxsIC4zcztcXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcXG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XFxufVxcbi5hbnQtcGFnaW5hdGlvbi1wcmV2LFxcbi5hbnQtcGFnaW5hdGlvbi1uZXh0IHtcXG4gIG91dGxpbmU6IDA7XFxufVxcbi5hbnQtcGFnaW5hdGlvbi1wcmV2IGEsXFxuLmFudC1wYWdpbmF0aW9uLW5leHQgYSB7XFxuICBjb2xvcjogcmdiYSgwLCAwLCAwLCAwLjY1KTtcXG4gIC13ZWJraXQtdXNlci1zZWxlY3Q6IG5vbmU7XFxuICAgICAtbW96LXVzZXItc2VsZWN0OiBub25lO1xcbiAgICAgIC1tcy11c2VyLXNlbGVjdDogbm9uZTtcXG4gICAgICAgICAgdXNlci1zZWxlY3Q6IG5vbmU7XFxufVxcbi5hbnQtcGFnaW5hdGlvbi1wcmV2OmhvdmVyIGEsXFxuLmFudC1wYWdpbmF0aW9uLW5leHQ6aG92ZXIgYSB7XFxuICBib3JkZXItY29sb3I6ICM0MGE5ZmY7XFxufVxcbi5hbnQtcGFnaW5hdGlvbi1wcmV2IC5hbnQtcGFnaW5hdGlvbi1pdGVtLWxpbmssXFxuLmFudC1wYWdpbmF0aW9uLW5leHQgLmFudC1wYWdpbmF0aW9uLWl0ZW0tbGluayB7XFxuICBib3JkZXI6IDFweCBzb2xpZCAjZDlkOWQ5O1xcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcXG4gIGJvcmRlci1yYWRpdXM6IDRweDtcXG4gIG91dGxpbmU6IG5vbmU7XFxuICBkaXNwbGF5OiBibG9jaztcXG4gIC13ZWJraXQtdHJhbnNpdGlvbjogYWxsIC4zcztcXG4gIHRyYW5zaXRpb246IGFsbCAuM3M7XFxufVxcbi5hbnQtcGFnaW5hdGlvbi1wcmV2IC5hbnQtcGFnaW5hdGlvbi1pdGVtLWxpbms6YWZ0ZXIsXFxuLmFudC1wYWdpbmF0aW9uLW5leHQgLmFudC1wYWdpbmF0aW9uLWl0ZW0tbGluazphZnRlciB7XFxuICBmb250LXNpemU6IDEycHg7XFxuICBkaXNwbGF5OiBibG9jaztcXG4gIGhlaWdodDogMzBweDtcXG4gIGZvbnQtZmFtaWx5OiBcXFwiYW50aWNvblxcXCI7XFxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XFxuICBmb250LXdlaWdodDogNTAwO1xcbn1cXG4uYW50LXBhZ2luYXRpb24tcHJldjpmb2N1cyAuYW50LXBhZ2luYXRpb24taXRlbS1saW5rLFxcbi5hbnQtcGFnaW5hdGlvbi1uZXh0OmZvY3VzIC5hbnQtcGFnaW5hdGlvbi1pdGVtLWxpbmssXFxuLmFudC1wYWdpbmF0aW9uLXByZXY6aG92ZXIgLmFudC1wYWdpbmF0aW9uLWl0ZW0tbGluayxcXG4uYW50LXBhZ2luYXRpb24tbmV4dDpob3ZlciAuYW50LXBhZ2luYXRpb24taXRlbS1saW5rIHtcXG4gIGJvcmRlci1jb2xvcjogIzE4OTBmZjtcXG4gIGNvbG9yOiAjMTg5MGZmO1xcbn1cXG4uYW50LXBhZ2luYXRpb24tcHJldiAuYW50LXBhZ2luYXRpb24taXRlbS1saW5rOmFmdGVyIHtcXG4gIGNvbnRlbnQ6IFxcXCJcXFxcRTYyMFxcXCI7XFxuICBkaXNwbGF5OiBibG9jaztcXG59XFxuLmFudC1wYWdpbmF0aW9uLW5leHQgLmFudC1wYWdpbmF0aW9uLWl0ZW0tbGluazphZnRlciB7XFxuICBjb250ZW50OiBcXFwiXFxcXEU2MUZcXFwiO1xcbiAgZGlzcGxheTogYmxvY2s7XFxufVxcbi5hbnQtcGFnaW5hdGlvbi1kaXNhYmxlZCxcXG4uYW50LXBhZ2luYXRpb24tZGlzYWJsZWQ6aG92ZXIsXFxuLmFudC1wYWdpbmF0aW9uLWRpc2FibGVkOmZvY3VzIHtcXG4gIGN1cnNvcjogbm90LWFsbG93ZWQ7XFxufVxcbi5hbnQtcGFnaW5hdGlvbi1kaXNhYmxlZCBhLFxcbi5hbnQtcGFnaW5hdGlvbi1kaXNhYmxlZDpob3ZlciBhLFxcbi5hbnQtcGFnaW5hdGlvbi1kaXNhYmxlZDpmb2N1cyBhLFxcbi5hbnQtcGFnaW5hdGlvbi1kaXNhYmxlZCAuYW50LXBhZ2luYXRpb24taXRlbS1saW5rLFxcbi5hbnQtcGFnaW5hdGlvbi1kaXNhYmxlZDpob3ZlciAuYW50LXBhZ2luYXRpb24taXRlbS1saW5rLFxcbi5hbnQtcGFnaW5hdGlvbi1kaXNhYmxlZDpmb2N1cyAuYW50LXBhZ2luYXRpb24taXRlbS1saW5rIHtcXG4gIGJvcmRlci1jb2xvcjogI2Q5ZDlkOTtcXG4gIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuMjUpO1xcbiAgY3Vyc29yOiBub3QtYWxsb3dlZDtcXG59XFxuLmFudC1wYWdpbmF0aW9uLXNsYXNoIHtcXG4gIG1hcmdpbjogMCAxMHB4IDAgNXB4O1xcbn1cXG4uYW50LXBhZ2luYXRpb24tb3B0aW9ucyB7XFxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XFxuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xcbiAgbWFyZ2luLWxlZnQ6IDE2cHg7XFxufVxcbi5hbnQtcGFnaW5hdGlvbi1vcHRpb25zLXNpemUtY2hhbmdlci5hbnQtc2VsZWN0IHtcXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcXG4gIG1hcmdpbi1yaWdodDogOHB4O1xcbn1cXG4uYW50LXBhZ2luYXRpb24tb3B0aW9ucy1xdWljay1qdW1wZXIge1xcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xcbiAgdmVydGljYWwtYWxpZ246IHRvcDtcXG4gIGhlaWdodDogMzJweDtcXG4gIGxpbmUtaGVpZ2h0OiAzMnB4O1xcbn1cXG4uYW50LXBhZ2luYXRpb24tb3B0aW9ucy1xdWljay1qdW1wZXIgaW5wdXQge1xcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xcbiAgcGFkZGluZzogNHB4IDExcHg7XFxuICB3aWR0aDogMTAwJTtcXG4gIGhlaWdodDogMzJweDtcXG4gIGZvbnQtc2l6ZTogMTRweDtcXG4gIGxpbmUtaGVpZ2h0OiAxLjU7XFxuICBjb2xvcjogcmdiYSgwLCAwLCAwLCAwLjY1KTtcXG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XFxuICBiYWNrZ3JvdW5kLWltYWdlOiBub25lO1xcbiAgYm9yZGVyOiAxcHggc29saWQgI2Q5ZDlkOTtcXG4gIGJvcmRlci1yYWRpdXM6IDRweDtcXG4gIC13ZWJraXQtdHJhbnNpdGlvbjogYWxsIC4zcztcXG4gIHRyYW5zaXRpb246IGFsbCAuM3M7XFxuICBtYXJnaW46IDAgOHB4O1xcbiAgd2lkdGg6IDUwcHg7XFxufVxcbi5hbnQtcGFnaW5hdGlvbi1vcHRpb25zLXF1aWNrLWp1bXBlciBpbnB1dDo6LW1vei1wbGFjZWhvbGRlciB7XFxuICBjb2xvcjogI2JmYmZiZjtcXG4gIG9wYWNpdHk6IDE7XFxufVxcbi5hbnQtcGFnaW5hdGlvbi1vcHRpb25zLXF1aWNrLWp1bXBlciBpbnB1dDotbXMtaW5wdXQtcGxhY2Vob2xkZXIge1xcbiAgY29sb3I6ICNiZmJmYmY7XFxufVxcbi5hbnQtcGFnaW5hdGlvbi1vcHRpb25zLXF1aWNrLWp1bXBlciBpbnB1dDo6LXdlYmtpdC1pbnB1dC1wbGFjZWhvbGRlciB7XFxuICBjb2xvcjogI2JmYmZiZjtcXG59XFxuLmFudC1wYWdpbmF0aW9uLW9wdGlvbnMtcXVpY2stanVtcGVyIGlucHV0OmhvdmVyIHtcXG4gIGJvcmRlci1jb2xvcjogIzQwYTlmZjtcXG59XFxuLmFudC1wYWdpbmF0aW9uLW9wdGlvbnMtcXVpY2stanVtcGVyIGlucHV0OmZvY3VzIHtcXG4gIGJvcmRlci1jb2xvcjogIzQwYTlmZjtcXG4gIG91dGxpbmU6IDA7XFxuICAtd2Via2l0LWJveC1zaGFkb3c6IDAgMCAwIDJweCByZ2JhKDI0LCAxNDQsIDI1NSwgMC4yKTtcXG4gICAgICAgICAgYm94LXNoYWRvdzogMCAwIDAgMnB4IHJnYmEoMjQsIDE0NCwgMjU1LCAwLjIpO1xcbn1cXG4uYW50LXBhZ2luYXRpb24tb3B0aW9ucy1xdWljay1qdW1wZXIgaW5wdXQtZGlzYWJsZWQge1xcbiAgYmFja2dyb3VuZC1jb2xvcjogI2Y1ZjVmNTtcXG4gIG9wYWNpdHk6IDE7XFxuICBjdXJzb3I6IG5vdC1hbGxvd2VkO1xcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC4yNSk7XFxufVxcbi5hbnQtcGFnaW5hdGlvbi1vcHRpb25zLXF1aWNrLWp1bXBlciBpbnB1dC1kaXNhYmxlZDpob3ZlciB7XFxuICBib3JkZXItY29sb3I6ICNlNmQ4ZDg7XFxufVxcbnRleHRhcmVhLmFudC1wYWdpbmF0aW9uLW9wdGlvbnMtcXVpY2stanVtcGVyIGlucHV0IHtcXG4gIG1heC13aWR0aDogMTAwJTtcXG4gIGhlaWdodDogYXV0bztcXG4gIHZlcnRpY2FsLWFsaWduOiBib3R0b207XFxuICAtd2Via2l0LXRyYW5zaXRpb246IGFsbCAuM3MsIGhlaWdodCAwcztcXG4gIHRyYW5zaXRpb246IGFsbCAuM3MsIGhlaWdodCAwcztcXG4gIG1pbi1oZWlnaHQ6IDMycHg7XFxufVxcbi5hbnQtcGFnaW5hdGlvbi1vcHRpb25zLXF1aWNrLWp1bXBlciBpbnB1dC1sZyB7XFxuICBwYWRkaW5nOiA2cHggMTFweDtcXG4gIGhlaWdodDogNDBweDtcXG4gIGZvbnQtc2l6ZTogMTZweDtcXG59XFxuLmFudC1wYWdpbmF0aW9uLW9wdGlvbnMtcXVpY2stanVtcGVyIGlucHV0LXNtIHtcXG4gIHBhZGRpbmc6IDFweCA3cHg7XFxuICBoZWlnaHQ6IDI0cHg7XFxufVxcbi5hbnQtcGFnaW5hdGlvbi1zaW1wbGUgLmFudC1wYWdpbmF0aW9uLXByZXYsXFxuLmFudC1wYWdpbmF0aW9uLXNpbXBsZSAuYW50LXBhZ2luYXRpb24tbmV4dCB7XFxuICBoZWlnaHQ6IDI0cHg7XFxuICBsaW5lLWhlaWdodDogMjRweDtcXG4gIHZlcnRpY2FsLWFsaWduOiB0b3A7XFxufVxcbi5hbnQtcGFnaW5hdGlvbi1zaW1wbGUgLmFudC1wYWdpbmF0aW9uLXByZXYgLmFudC1wYWdpbmF0aW9uLWl0ZW0tbGluayxcXG4uYW50LXBhZ2luYXRpb24tc2ltcGxlIC5hbnQtcGFnaW5hdGlvbi1uZXh0IC5hbnQtcGFnaW5hdGlvbi1pdGVtLWxpbmsge1xcbiAgYm9yZGVyOiAwO1xcbiAgaGVpZ2h0OiAyNHB4O1xcbn1cXG4uYW50LXBhZ2luYXRpb24tc2ltcGxlIC5hbnQtcGFnaW5hdGlvbi1wcmV2IC5hbnQtcGFnaW5hdGlvbi1pdGVtLWxpbms6YWZ0ZXIsXFxuLmFudC1wYWdpbmF0aW9uLXNpbXBsZSAuYW50LXBhZ2luYXRpb24tbmV4dCAuYW50LXBhZ2luYXRpb24taXRlbS1saW5rOmFmdGVyIHtcXG4gIGhlaWdodDogMjRweDtcXG4gIGxpbmUtaGVpZ2h0OiAyNHB4O1xcbn1cXG4uYW50LXBhZ2luYXRpb24tc2ltcGxlIC5hbnQtcGFnaW5hdGlvbi1zaW1wbGUtcGFnZXIge1xcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xcbiAgbWFyZ2luLXJpZ2h0OiA4cHg7XFxuICBoZWlnaHQ6IDI0cHg7XFxufVxcbi5hbnQtcGFnaW5hdGlvbi1zaW1wbGUgLmFudC1wYWdpbmF0aW9uLXNpbXBsZS1wYWdlciBpbnB1dCB7XFxuICBtYXJnaW4tcmlnaHQ6IDhweDtcXG4gIC13ZWJraXQtYm94LXNpemluZzogYm9yZGVyLWJveDtcXG4gICAgICAgICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcXG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XFxuICBib3JkZXItcmFkaXVzOiA0cHg7XFxuICBib3JkZXI6IDFweCBzb2xpZCAjZDlkOWQ5O1xcbiAgb3V0bGluZTogbm9uZTtcXG4gIHBhZGRpbmc6IDAgNnB4O1xcbiAgaGVpZ2h0OiAxMDAlO1xcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xcbiAgLXdlYmtpdC10cmFuc2l0aW9uOiBib3JkZXItY29sb3IgMC4zcztcXG4gIHRyYW5zaXRpb246IGJvcmRlci1jb2xvciAwLjNzO1xcbn1cXG4uYW50LXBhZ2luYXRpb24tc2ltcGxlIC5hbnQtcGFnaW5hdGlvbi1zaW1wbGUtcGFnZXIgaW5wdXQ6aG92ZXIge1xcbiAgYm9yZGVyLWNvbG9yOiAjMTg5MGZmO1xcbn1cXG4uYW50LXBhZ2luYXRpb24ubWluaSAuYW50LXBhZ2luYXRpb24tdG90YWwtdGV4dCxcXG4uYW50LXBhZ2luYXRpb24ubWluaSAuYW50LXBhZ2luYXRpb24tc2ltcGxlLXBhZ2VyIHtcXG4gIGhlaWdodDogMjRweDtcXG4gIGxpbmUtaGVpZ2h0OiAyNHB4O1xcbn1cXG4uYW50LXBhZ2luYXRpb24ubWluaSAuYW50LXBhZ2luYXRpb24taXRlbSB7XFxuICBtYXJnaW46IDA7XFxuICBtaW4td2lkdGg6IDI0cHg7XFxuICBoZWlnaHQ6IDI0cHg7XFxuICBsaW5lLWhlaWdodDogMjJweDtcXG59XFxuLmFudC1wYWdpbmF0aW9uLm1pbmkgLmFudC1wYWdpbmF0aW9uLWl0ZW06bm90KC5hbnQtcGFnaW5hdGlvbi1pdGVtLWFjdGl2ZSkge1xcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XFxuICBib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xcbn1cXG4uYW50LXBhZ2luYXRpb24ubWluaSAuYW50LXBhZ2luYXRpb24tcHJldixcXG4uYW50LXBhZ2luYXRpb24ubWluaSAuYW50LXBhZ2luYXRpb24tbmV4dCB7XFxuICBtYXJnaW46IDA7XFxuICBtaW4td2lkdGg6IDI0cHg7XFxuICBoZWlnaHQ6IDI0cHg7XFxuICBsaW5lLWhlaWdodDogMjRweDtcXG59XFxuLmFudC1wYWdpbmF0aW9uLm1pbmkgLmFudC1wYWdpbmF0aW9uLXByZXYgLmFudC1wYWdpbmF0aW9uLWl0ZW0tbGluayxcXG4uYW50LXBhZ2luYXRpb24ubWluaSAuYW50LXBhZ2luYXRpb24tbmV4dCAuYW50LXBhZ2luYXRpb24taXRlbS1saW5rIHtcXG4gIGJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XFxuICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcXG59XFxuLmFudC1wYWdpbmF0aW9uLm1pbmkgLmFudC1wYWdpbmF0aW9uLXByZXYgLmFudC1wYWdpbmF0aW9uLWl0ZW0tbGluazphZnRlcixcXG4uYW50LXBhZ2luYXRpb24ubWluaSAuYW50LXBhZ2luYXRpb24tbmV4dCAuYW50LXBhZ2luYXRpb24taXRlbS1saW5rOmFmdGVyIHtcXG4gIGhlaWdodDogMjRweDtcXG4gIGxpbmUtaGVpZ2h0OiAyNHB4O1xcbn1cXG4uYW50LXBhZ2luYXRpb24ubWluaSAuYW50LXBhZ2luYXRpb24tanVtcC1wcmV2LFxcbi5hbnQtcGFnaW5hdGlvbi5taW5pIC5hbnQtcGFnaW5hdGlvbi1qdW1wLW5leHQge1xcbiAgaGVpZ2h0OiAyNHB4O1xcbiAgbGluZS1oZWlnaHQ6IDI0cHg7XFxuICBtYXJnaW4tcmlnaHQ6IDA7XFxufVxcbi5hbnQtcGFnaW5hdGlvbi5taW5pIC5hbnQtcGFnaW5hdGlvbi1vcHRpb25zIHtcXG4gIG1hcmdpbi1sZWZ0OiAycHg7XFxufVxcbi5hbnQtcGFnaW5hdGlvbi5taW5pIC5hbnQtcGFnaW5hdGlvbi1vcHRpb25zLXF1aWNrLWp1bXBlciB7XFxuICBoZWlnaHQ6IDI0cHg7XFxuICBsaW5lLWhlaWdodDogMjRweDtcXG59XFxuLmFudC1wYWdpbmF0aW9uLm1pbmkgLmFudC1wYWdpbmF0aW9uLW9wdGlvbnMtcXVpY2stanVtcGVyIGlucHV0IHtcXG4gIHBhZGRpbmc6IDFweCA3cHg7XFxuICBoZWlnaHQ6IDI0cHg7XFxuICB3aWR0aDogNDRweDtcXG59XFxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA5OTJweCkge1xcbiAgLmFudC1wYWdpbmF0aW9uLWl0ZW0tYWZ0ZXItanVtcC1wcmV2LFxcbiAgLmFudC1wYWdpbmF0aW9uLWl0ZW0tYmVmb3JlLWp1bXAtbmV4dCB7XFxuICAgIGRpc3BsYXk6IG5vbmU7XFxuICB9XFxufVxcbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1heC13aWR0aDogNTc2cHgpIHtcXG4gIC5hbnQtcGFnaW5hdGlvbi1vcHRpb25zIHtcXG4gICAgZGlzcGxheTogbm9uZTtcXG4gIH1cXG59XFxuXCIsIFwiXCJdKTtcblxuLy8gZXhwb3J0c1xuIiwiZXhwb3J0cyA9IG1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIi4uLy4uLy4uLy4uL2Nzcy1sb2FkZXIvbGliL2Nzcy1iYXNlLmpzXCIpKGZhbHNlKTtcbi8vIGltcG9ydHNcblxuXG4vLyBtb2R1bGVcbmV4cG9ydHMucHVzaChbbW9kdWxlLmlkLCBcIi8qIHN0eWxlbGludC1kaXNhYmxlIGF0LXJ1bGUtZW1wdHktbGluZS1iZWZvcmUsYXQtcnVsZS1uYW1lLXNwYWNlLWFmdGVyLGF0LXJ1bGUtbm8tdW5rbm93biAqL1xcbi8qIHN0eWxlbGludC1kaXNhYmxlIG5vLWR1cGxpY2F0ZS1zZWxlY3RvcnMgKi9cXG4vKiBzdHlsZWxpbnQtZGlzYWJsZSBkZWNsYXJhdGlvbi1iYW5nLXNwYWNlLWJlZm9yZSxuby1kdXBsaWNhdGUtc2VsZWN0b3JzICovXFxuLyogc3R5bGVsaW50LWRpc2FibGUgZGVjbGFyYXRpb24tYmFuZy1zcGFjZS1iZWZvcmUsbm8tZHVwbGljYXRlLXNlbGVjdG9ycyxzdHJpbmctbm8tbmV3bGluZSAqL1xcbi5hbnQtc2VsZWN0IHtcXG4gIGZvbnQtZmFtaWx5OiBcXFwiTW9ub3NwYWNlZCBOdW1iZXJcXFwiLCBcXFwiQ2hpbmVzZSBRdW90ZVxcXCIsIC1hcHBsZS1zeXN0ZW0sIEJsaW5rTWFjU3lzdGVtRm9udCwgXFxcIlNlZ29lIFVJXFxcIiwgUm9ib3RvLCBcXFwiUGluZ0ZhbmcgU0NcXFwiLCBcXFwiSGlyYWdpbm8gU2FucyBHQlxcXCIsIFxcXCJNaWNyb3NvZnQgWWFIZWlcXFwiLCBcXFwiSGVsdmV0aWNhIE5ldWVcXFwiLCBIZWx2ZXRpY2EsIEFyaWFsLCBzYW5zLXNlcmlmO1xcbiAgZm9udC1zaXplOiAxNHB4O1xcbiAgbGluZS1oZWlnaHQ6IDEuNTtcXG4gIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuNjUpO1xcbiAgLXdlYmtpdC1ib3gtc2l6aW5nOiBib3JkZXItYm94O1xcbiAgICAgICAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xcbiAgbWFyZ2luOiAwO1xcbiAgcGFkZGluZzogMDtcXG4gIGxpc3Qtc3R5bGU6IG5vbmU7XFxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XFxuICBwb3NpdGlvbjogcmVsYXRpdmU7XFxufVxcbi5hbnQtc2VsZWN0IHVsLFxcbi5hbnQtc2VsZWN0IG9sIHtcXG4gIG1hcmdpbjogMDtcXG4gIHBhZGRpbmc6IDA7XFxuICBsaXN0LXN0eWxlOiBub25lO1xcbn1cXG4uYW50LXNlbGVjdCA+IHVsID4gbGkgPiBhIHtcXG4gIHBhZGRpbmc6IDA7XFxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xcbn1cXG4uYW50LXNlbGVjdC1hcnJvdyB7XFxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XFxuICBmb250LXN0eWxlOiBub3JtYWw7XFxuICB2ZXJ0aWNhbC1hbGlnbjogYmFzZWxpbmU7XFxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XFxuICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcXG4gIHRleHQtcmVuZGVyaW5nOiBvcHRpbWl6ZUxlZ2liaWxpdHk7XFxuICAtd2Via2l0LWZvbnQtc21vb3RoaW5nOiBhbnRpYWxpYXNlZDtcXG4gIC1tb3otb3N4LWZvbnQtc21vb3RoaW5nOiBncmF5c2NhbGU7XFxuICBwb3NpdGlvbjogYWJzb2x1dGU7XFxuICB0b3A6IDUwJTtcXG4gIHJpZ2h0OiAxMXB4O1xcbiAgbGluZS1oZWlnaHQ6IDE7XFxuICBtYXJnaW4tdG9wOiAtNnB4O1xcbiAgLXdlYmtpdC10cmFuc2Zvcm0tb3JpZ2luOiA1MCUgNTAlO1xcbiAgICAgIC1tcy10cmFuc2Zvcm0tb3JpZ2luOiA1MCUgNTAlO1xcbiAgICAgICAgICB0cmFuc2Zvcm0tb3JpZ2luOiA1MCUgNTAlO1xcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC4yNSk7XFxuICBmb250LXNpemU6IDEycHg7XFxufVxcbi5hbnQtc2VsZWN0LWFycm93OmJlZm9yZSB7XFxuICBkaXNwbGF5OiBibG9jaztcXG4gIGZvbnQtZmFtaWx5OiBcXFwiYW50aWNvblxcXCIgIWltcG9ydGFudDtcXG59XFxuLmFudC1zZWxlY3QtYXJyb3cgKiB7XFxuICBkaXNwbGF5OiBub25lO1xcbn1cXG4uYW50LXNlbGVjdC1hcnJvdzpiZWZvcmUge1xcbiAgY29udGVudDogJ1xcXFxFNjFEJztcXG4gIC13ZWJraXQtdHJhbnNpdGlvbjogLXdlYmtpdC10cmFuc2Zvcm0gLjNzO1xcbiAgdHJhbnNpdGlvbjogLXdlYmtpdC10cmFuc2Zvcm0gLjNzO1xcbiAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIC4zcztcXG4gIHRyYW5zaXRpb246IHRyYW5zZm9ybSAuM3MsIC13ZWJraXQtdHJhbnNmb3JtIC4zcztcXG59XFxuLmFudC1zZWxlY3Qtc2VsZWN0aW9uIHtcXG4gIG91dGxpbmU6IG5vbmU7XFxuICAtd2Via2l0LXVzZXItc2VsZWN0OiBub25lO1xcbiAgICAgLW1vei11c2VyLXNlbGVjdDogbm9uZTtcXG4gICAgICAtbXMtdXNlci1zZWxlY3Q6IG5vbmU7XFxuICAgICAgICAgIHVzZXItc2VsZWN0OiBub25lO1xcbiAgLXdlYmtpdC1ib3gtc2l6aW5nOiBib3JkZXItYm94O1xcbiAgICAgICAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xcbiAgZGlzcGxheTogYmxvY2s7XFxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xcbiAgYm9yZGVyOiAxcHggc29saWQgI2Q5ZDlkOTtcXG4gIGJvcmRlci10b3Atd2lkdGg6IDEuMDJweDtcXG4gIC13ZWJraXQtdHJhbnNpdGlvbjogYWxsIDAuM3MgY3ViaWMtYmV6aWVyKDAuNjQ1LCAwLjA0NSwgMC4zNTUsIDEpO1xcbiAgdHJhbnNpdGlvbjogYWxsIDAuM3MgY3ViaWMtYmV6aWVyKDAuNjQ1LCAwLjA0NSwgMC4zNTUsIDEpO1xcbn1cXG4uYW50LXNlbGVjdC1zZWxlY3Rpb246aG92ZXIge1xcbiAgYm9yZGVyLWNvbG9yOiAjNDBhOWZmO1xcbn1cXG4uYW50LXNlbGVjdC1mb2N1c2VkIC5hbnQtc2VsZWN0LXNlbGVjdGlvbixcXG4uYW50LXNlbGVjdC1zZWxlY3Rpb246Zm9jdXMsXFxuLmFudC1zZWxlY3Qtc2VsZWN0aW9uOmFjdGl2ZSB7XFxuICBib3JkZXItY29sb3I6ICM0MGE5ZmY7XFxuICBvdXRsaW5lOiAwO1xcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiAwIDAgMCAycHggcmdiYSgyNCwgMTQ0LCAyNTUsIDAuMik7XFxuICAgICAgICAgIGJveC1zaGFkb3c6IDAgMCAwIDJweCByZ2JhKDI0LCAxNDQsIDI1NSwgMC4yKTtcXG59XFxuLmFudC1zZWxlY3Qtc2VsZWN0aW9uX19jbGVhciB7XFxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XFxuICBmb250LXN0eWxlOiBub3JtYWw7XFxuICB2ZXJ0aWNhbC1hbGlnbjogYmFzZWxpbmU7XFxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XFxuICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcXG4gIHRleHQtcmVuZGVyaW5nOiBhdXRvO1xcbiAgb3BhY2l0eTogMDtcXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcXG4gIHJpZ2h0OiAxMXB4O1xcbiAgei1pbmRleDogMTtcXG4gIGJhY2tncm91bmQ6ICNmZmY7XFxuICB0b3A6IDUwJTtcXG4gIGZvbnQtc2l6ZTogMTJweDtcXG4gIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuMjUpO1xcbiAgd2lkdGg6IDEycHg7XFxuICBoZWlnaHQ6IDEycHg7XFxuICBtYXJnaW4tdG9wOiAtNnB4O1xcbiAgbGluZS1oZWlnaHQ6IDEycHg7XFxuICBjdXJzb3I6IHBvaW50ZXI7XFxuICAtd2Via2l0LXRyYW5zaXRpb246IGNvbG9yIDAuM3MgZWFzZSwgb3BhY2l0eSAwLjE1cyBlYXNlO1xcbiAgdHJhbnNpdGlvbjogY29sb3IgMC4zcyBlYXNlLCBvcGFjaXR5IDAuMTVzIGVhc2U7XFxufVxcbi5hbnQtc2VsZWN0LXNlbGVjdGlvbl9fY2xlYXI6YmVmb3JlIHtcXG4gIGRpc3BsYXk6IGJsb2NrO1xcbiAgZm9udC1mYW1pbHk6ICdhbnRpY29uJztcXG4gIHRleHQtcmVuZGVyaW5nOiBvcHRpbWl6ZUxlZ2liaWxpdHk7XFxuICAtd2Via2l0LWZvbnQtc21vb3RoaW5nOiBhbnRpYWxpYXNlZDtcXG4gIC1tb3otb3N4LWZvbnQtc21vb3RoaW5nOiBncmF5c2NhbGU7XFxuICBjb250ZW50OiBcXFwiXFxcXEU2MkVcXFwiO1xcbn1cXG4uYW50LXNlbGVjdC1zZWxlY3Rpb25fX2NsZWFyOmhvdmVyIHtcXG4gIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuNDUpO1xcbn1cXG4uYW50LXNlbGVjdC1zZWxlY3Rpb246aG92ZXIgLmFudC1zZWxlY3Qtc2VsZWN0aW9uX19jbGVhciB7XFxuICBvcGFjaXR5OiAxO1xcbn1cXG4uYW50LXNlbGVjdC1zZWxlY3Rpb24tc2VsZWN0ZWQtdmFsdWUge1xcbiAgZmxvYXQ6IGxlZnQ7XFxuICBvdmVyZmxvdzogaGlkZGVuO1xcbiAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XFxuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xcbiAgbWF4LXdpZHRoOiAxMDAlO1xcbiAgcGFkZGluZy1yaWdodDogMjBweDtcXG59XFxuLmFudC1zZWxlY3QtZGlzYWJsZWQge1xcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC4yNSk7XFxufVxcbi5hbnQtc2VsZWN0LWRpc2FibGVkIC5hbnQtc2VsZWN0LXNlbGVjdGlvbiB7XFxuICBiYWNrZ3JvdW5kOiAjZjVmNWY1O1xcbiAgY3Vyc29yOiBub3QtYWxsb3dlZDtcXG59XFxuLmFudC1zZWxlY3QtZGlzYWJsZWQgLmFudC1zZWxlY3Qtc2VsZWN0aW9uOmhvdmVyLFxcbi5hbnQtc2VsZWN0LWRpc2FibGVkIC5hbnQtc2VsZWN0LXNlbGVjdGlvbjpmb2N1cyxcXG4uYW50LXNlbGVjdC1kaXNhYmxlZCAuYW50LXNlbGVjdC1zZWxlY3Rpb246YWN0aXZlIHtcXG4gIGJvcmRlci1jb2xvcjogI2Q5ZDlkOTtcXG4gIC13ZWJraXQtYm94LXNoYWRvdzogbm9uZTtcXG4gICAgICAgICAgYm94LXNoYWRvdzogbm9uZTtcXG59XFxuLmFudC1zZWxlY3QtZGlzYWJsZWQgLmFudC1zZWxlY3Qtc2VsZWN0aW9uX19jbGVhciB7XFxuICBkaXNwbGF5OiBub25lO1xcbiAgdmlzaWJpbGl0eTogaGlkZGVuO1xcbiAgcG9pbnRlci1ldmVudHM6IG5vbmU7XFxufVxcbi5hbnQtc2VsZWN0LWRpc2FibGVkIC5hbnQtc2VsZWN0LXNlbGVjdGlvbi0tbXVsdGlwbGUgLmFudC1zZWxlY3Qtc2VsZWN0aW9uX19jaG9pY2Uge1xcbiAgYmFja2dyb3VuZDogI2Y1ZjVmNTtcXG4gIGNvbG9yOiAjYWFhO1xcbiAgcGFkZGluZy1yaWdodDogMTBweDtcXG59XFxuLmFudC1zZWxlY3QtZGlzYWJsZWQgLmFudC1zZWxlY3Qtc2VsZWN0aW9uLS1tdWx0aXBsZSAuYW50LXNlbGVjdC1zZWxlY3Rpb25fX2Nob2ljZV9fcmVtb3ZlIHtcXG4gIGRpc3BsYXk6IG5vbmU7XFxufVxcbi5hbnQtc2VsZWN0LXNlbGVjdGlvbi0tc2luZ2xlIHtcXG4gIGhlaWdodDogMzJweDtcXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcXG4gIGN1cnNvcjogcG9pbnRlcjtcXG59XFxuLmFudC1zZWxlY3Qtc2VsZWN0aW9uX19yZW5kZXJlZCB7XFxuICBkaXNwbGF5OiBibG9jaztcXG4gIG1hcmdpbi1sZWZ0OiAxMXB4O1xcbiAgbWFyZ2luLXJpZ2h0OiAxMXB4O1xcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xcbiAgbGluZS1oZWlnaHQ6IDMwcHg7XFxufVxcbi5hbnQtc2VsZWN0LXNlbGVjdGlvbl9fcmVuZGVyZWQ6YWZ0ZXIge1xcbiAgY29udGVudDogJy4nO1xcbiAgdmlzaWJpbGl0eTogaGlkZGVuO1xcbiAgcG9pbnRlci1ldmVudHM6IG5vbmU7XFxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XFxuICB3aWR0aDogMDtcXG59XFxuLmFudC1zZWxlY3QtbGcge1xcbiAgZm9udC1zaXplOiAxNnB4O1xcbn1cXG4uYW50LXNlbGVjdC1sZyAuYW50LXNlbGVjdC1zZWxlY3Rpb24tLXNpbmdsZSB7XFxuICBoZWlnaHQ6IDQwcHg7XFxufVxcbi5hbnQtc2VsZWN0LWxnIC5hbnQtc2VsZWN0LXNlbGVjdGlvbl9fcmVuZGVyZWQge1xcbiAgbGluZS1oZWlnaHQ6IDM4cHg7XFxufVxcbi5hbnQtc2VsZWN0LWxnIC5hbnQtc2VsZWN0LXNlbGVjdGlvbi0tbXVsdGlwbGUge1xcbiAgbWluLWhlaWdodDogNDBweDtcXG59XFxuLmFudC1zZWxlY3QtbGcgLmFudC1zZWxlY3Qtc2VsZWN0aW9uLS1tdWx0aXBsZSAuYW50LXNlbGVjdC1zZWxlY3Rpb25fX3JlbmRlcmVkIGxpIHtcXG4gIGhlaWdodDogMzJweDtcXG4gIGxpbmUtaGVpZ2h0OiAzMnB4O1xcbn1cXG4uYW50LXNlbGVjdC1sZyAuYW50LXNlbGVjdC1zZWxlY3Rpb24tLW11bHRpcGxlIC5hbnQtc2VsZWN0LXNlbGVjdGlvbl9fY2xlYXIge1xcbiAgdG9wOiAyMHB4O1xcbn1cXG4uYW50LXNlbGVjdC1zbSAuYW50LXNlbGVjdC1zZWxlY3Rpb24tLXNpbmdsZSB7XFxuICBoZWlnaHQ6IDI0cHg7XFxufVxcbi5hbnQtc2VsZWN0LXNtIC5hbnQtc2VsZWN0LXNlbGVjdGlvbl9fcmVuZGVyZWQge1xcbiAgbGluZS1oZWlnaHQ6IDIycHg7XFxuICBtYXJnaW46IDAgN3B4O1xcbn1cXG4uYW50LXNlbGVjdC1zbSAuYW50LXNlbGVjdC1zZWxlY3Rpb24tLW11bHRpcGxlIHtcXG4gIG1pbi1oZWlnaHQ6IDI0cHg7XFxufVxcbi5hbnQtc2VsZWN0LXNtIC5hbnQtc2VsZWN0LXNlbGVjdGlvbi0tbXVsdGlwbGUgLmFudC1zZWxlY3Qtc2VsZWN0aW9uX19yZW5kZXJlZCBsaSB7XFxuICBoZWlnaHQ6IDE2cHg7XFxuICBsaW5lLWhlaWdodDogMTRweDtcXG59XFxuLmFudC1zZWxlY3Qtc20gLmFudC1zZWxlY3Qtc2VsZWN0aW9uLS1tdWx0aXBsZSAuYW50LXNlbGVjdC1zZWxlY3Rpb25fX2NsZWFyIHtcXG4gIHRvcDogMTJweDtcXG59XFxuLmFudC1zZWxlY3Qtc20gLmFudC1zZWxlY3Qtc2VsZWN0aW9uX19jbGVhcixcXG4uYW50LXNlbGVjdC1zbSAuYW50LXNlbGVjdC1hcnJvdyB7XFxuICByaWdodDogOHB4O1xcbn1cXG4uYW50LXNlbGVjdC1kaXNhYmxlZCAuYW50LXNlbGVjdC1zZWxlY3Rpb25fX2Nob2ljZV9fcmVtb3ZlIHtcXG4gIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuMjUpO1xcbiAgY3Vyc29yOiBkZWZhdWx0O1xcbn1cXG4uYW50LXNlbGVjdC1kaXNhYmxlZCAuYW50LXNlbGVjdC1zZWxlY3Rpb25fX2Nob2ljZV9fcmVtb3ZlOmhvdmVyIHtcXG4gIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuMjUpO1xcbn1cXG4uYW50LXNlbGVjdC1zZWFyY2hfX2ZpZWxkX193cmFwIHtcXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcXG59XFxuLmFudC1zZWxlY3Qtc2VsZWN0aW9uX19wbGFjZWhvbGRlcixcXG4uYW50LXNlbGVjdC1zZWFyY2hfX2ZpZWxkX19wbGFjZWhvbGRlciB7XFxuICBwb3NpdGlvbjogYWJzb2x1dGU7XFxuICB0b3A6IDUwJTtcXG4gIGxlZnQ6IDA7XFxuICByaWdodDogOXB4O1xcbiAgY29sb3I6ICNiZmJmYmY7XFxuICBsaW5lLWhlaWdodDogMjBweDtcXG4gIGhlaWdodDogMjBweDtcXG4gIG1heC13aWR0aDogMTAwJTtcXG4gIG1hcmdpbi10b3A6IC0xMHB4O1xcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcXG4gIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcXG4gIHRleHQtYWxpZ246IGxlZnQ7XFxufVxcbi5hbnQtc2VsZWN0LXNlYXJjaF9fZmllbGRfX3BsYWNlaG9sZGVyIHtcXG4gIGxlZnQ6IDEycHg7XFxufVxcbi5hbnQtc2VsZWN0LXNlYXJjaF9fZmllbGRfX21pcnJvciB7XFxuICBwb3NpdGlvbjogYWJzb2x1dGU7XFxuICB0b3A6IDA7XFxuICBsZWZ0OiAtOTk5OXB4O1xcbiAgd2hpdGUtc3BhY2U6IHByZTtcXG4gIHBvaW50ZXItZXZlbnRzOiBub25lO1xcbn1cXG4uYW50LXNlbGVjdC1zZWFyY2gtLWlubGluZSB7XFxuICBwb3NpdGlvbjogYWJzb2x1dGU7XFxuICBoZWlnaHQ6IDEwMCU7XFxuICB3aWR0aDogMTAwJTtcXG59XFxuLmFudC1zZWxlY3Qtc2VhcmNoLS1pbmxpbmUgLmFudC1zZWxlY3Qtc2VhcmNoX19maWVsZF9fd3JhcCB7XFxuICB3aWR0aDogMTAwJTtcXG4gIGhlaWdodDogMTAwJTtcXG59XFxuLmFudC1zZWxlY3Qtc2VhcmNoLS1pbmxpbmUgLmFudC1zZWxlY3Qtc2VhcmNoX19maWVsZCB7XFxuICBib3JkZXItd2lkdGg6IDA7XFxuICBmb250LXNpemU6IDEwMCU7XFxuICBoZWlnaHQ6IDEwMCU7XFxuICB3aWR0aDogMTAwJTtcXG4gIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xcbiAgb3V0bGluZTogMDtcXG4gIGJvcmRlci1yYWRpdXM6IDRweDtcXG4gIGxpbmUtaGVpZ2h0OiAxO1xcbn1cXG4uYW50LXNlbGVjdC1zZWFyY2gtLWlubGluZSA+IGkge1xcbiAgZmxvYXQ6IHJpZ2h0O1xcbn1cXG4uYW50LXNlbGVjdC1zZWxlY3Rpb24tLW11bHRpcGxlIHtcXG4gIG1pbi1oZWlnaHQ6IDMycHg7XFxuICBjdXJzb3I6IHRleHQ7XFxuICBwYWRkaW5nLWJvdHRvbTogM3B4O1xcbiAgem9vbTogMTtcXG59XFxuLmFudC1zZWxlY3Qtc2VsZWN0aW9uLS1tdWx0aXBsZTpiZWZvcmUsXFxuLmFudC1zZWxlY3Qtc2VsZWN0aW9uLS1tdWx0aXBsZTphZnRlciB7XFxuICBjb250ZW50OiBcXFwiIFxcXCI7XFxuICBkaXNwbGF5OiB0YWJsZTtcXG59XFxuLmFudC1zZWxlY3Qtc2VsZWN0aW9uLS1tdWx0aXBsZTphZnRlciB7XFxuICBjbGVhcjogYm90aDtcXG4gIHZpc2liaWxpdHk6IGhpZGRlbjtcXG4gIGZvbnQtc2l6ZTogMDtcXG4gIGhlaWdodDogMDtcXG59XFxuLmFudC1zZWxlY3Qtc2VsZWN0aW9uLS1tdWx0aXBsZSAuYW50LXNlbGVjdC1zZWFyY2gtLWlubGluZSB7XFxuICBmbG9hdDogbGVmdDtcXG4gIHBvc2l0aW9uOiBzdGF0aWM7XFxuICB3aWR0aDogYXV0bztcXG4gIHBhZGRpbmc6IDA7XFxuICBtYXgtd2lkdGg6IDEwMCU7XFxufVxcbi5hbnQtc2VsZWN0LXNlbGVjdGlvbi0tbXVsdGlwbGUgLmFudC1zZWxlY3Qtc2VhcmNoLS1pbmxpbmUgLmFudC1zZWxlY3Qtc2VhcmNoX19maWVsZCB7XFxuICBtYXgtd2lkdGg6IDEwMCU7XFxuICB3aWR0aDogMC43NWVtO1xcbn1cXG4uYW50LXNlbGVjdC1zZWxlY3Rpb24tLW11bHRpcGxlIC5hbnQtc2VsZWN0LXNlbGVjdGlvbl9fcmVuZGVyZWQge1xcbiAgbWFyZ2luLWxlZnQ6IDVweDtcXG4gIG1hcmdpbi1ib3R0b206IC0zcHg7XFxuICBoZWlnaHQ6IGF1dG87XFxufVxcbi5hbnQtc2VsZWN0LXNlbGVjdGlvbi0tbXVsdGlwbGUgLmFudC1zZWxlY3Qtc2VsZWN0aW9uX19wbGFjZWhvbGRlciB7XFxuICBtYXJnaW4tbGVmdDogNnB4O1xcbn1cXG4uYW50LXNlbGVjdC1zZWxlY3Rpb24tLW11bHRpcGxlID4gdWwgPiBsaSxcXG4uYW50LXNlbGVjdC1zZWxlY3Rpb24tLW11bHRpcGxlIC5hbnQtc2VsZWN0LXNlbGVjdGlvbl9fcmVuZGVyZWQgPiB1bCA+IGxpIHtcXG4gIG1hcmdpbi10b3A6IDNweDtcXG4gIGhlaWdodDogMjRweDtcXG4gIGxpbmUtaGVpZ2h0OiAyMnB4O1xcbn1cXG4uYW50LXNlbGVjdC1zZWxlY3Rpb24tLW11bHRpcGxlIC5hbnQtc2VsZWN0LXNlbGVjdGlvbl9fY2hvaWNlIHtcXG4gIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuNjUpO1xcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZhZmFmYTtcXG4gIGJvcmRlcjogMXB4IHNvbGlkICNlOGU4ZTg7XFxuICBib3JkZXItcmFkaXVzOiAycHg7XFxuICBjdXJzb3I6IGRlZmF1bHQ7XFxuICBmbG9hdDogbGVmdDtcXG4gIG1hcmdpbi1yaWdodDogNHB4O1xcbiAgbWF4LXdpZHRoOiA5OSU7XFxuICBwb3NpdGlvbjogcmVsYXRpdmU7XFxuICBvdmVyZmxvdzogaGlkZGVuO1xcbiAgLXdlYmtpdC10cmFuc2l0aW9uOiBwYWRkaW5nIDAuM3MgY3ViaWMtYmV6aWVyKDAuNjQ1LCAwLjA0NSwgMC4zNTUsIDEpO1xcbiAgdHJhbnNpdGlvbjogcGFkZGluZyAwLjNzIGN1YmljLWJlemllcigwLjY0NSwgMC4wNDUsIDAuMzU1LCAxKTtcXG4gIHBhZGRpbmc6IDAgMjBweCAwIDEwcHg7XFxufVxcbi5hbnQtc2VsZWN0LXNlbGVjdGlvbi0tbXVsdGlwbGUgLmFudC1zZWxlY3Qtc2VsZWN0aW9uX19jaG9pY2VfX2Rpc2FibGVkIHtcXG4gIHBhZGRpbmc6IDAgMTBweDtcXG59XFxuLmFudC1zZWxlY3Qtc2VsZWN0aW9uLS1tdWx0aXBsZSAuYW50LXNlbGVjdC1zZWxlY3Rpb25fX2Nob2ljZV9fY29udGVudCB7XFxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XFxuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcXG4gIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xcbiAgbWF4LXdpZHRoOiAxMDAlO1xcbiAgLXdlYmtpdC10cmFuc2l0aW9uOiBtYXJnaW4gMC4zcyBjdWJpYy1iZXppZXIoMC42NDUsIDAuMDQ1LCAwLjM1NSwgMSk7XFxuICB0cmFuc2l0aW9uOiBtYXJnaW4gMC4zcyBjdWJpYy1iZXppZXIoMC42NDUsIDAuMDQ1LCAwLjM1NSwgMSk7XFxufVxcbi5hbnQtc2VsZWN0LXNlbGVjdGlvbi0tbXVsdGlwbGUgLmFudC1zZWxlY3Qtc2VsZWN0aW9uX19jaG9pY2VfX3JlbW92ZSB7XFxuICBmb250LXN0eWxlOiBub3JtYWw7XFxuICB2ZXJ0aWNhbC1hbGlnbjogYmFzZWxpbmU7XFxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XFxuICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcXG4gIGxpbmUtaGVpZ2h0OiAxO1xcbiAgdGV4dC1yZW5kZXJpbmc6IG9wdGltaXplTGVnaWJpbGl0eTtcXG4gIC13ZWJraXQtZm9udC1zbW9vdGhpbmc6IGFudGlhbGlhc2VkO1xcbiAgLW1vei1vc3gtZm9udC1zbW9vdGhpbmc6IGdyYXlzY2FsZTtcXG4gIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuNDUpO1xcbiAgbGluZS1oZWlnaHQ6IGluaGVyaXQ7XFxuICBjdXJzb3I6IHBvaW50ZXI7XFxuICBmb250LXdlaWdodDogYm9sZDtcXG4gIC13ZWJraXQtdHJhbnNpdGlvbjogYWxsIC4zcztcXG4gIHRyYW5zaXRpb246IGFsbCAuM3M7XFxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XFxuICBmb250LXNpemU6IDEycHg7XFxuICBmb250LXNpemU6IDEwcHggXFxcXDk7XFxuICAtd2Via2l0LXRyYW5zZm9ybTogc2NhbGUoMC44MzMzMzMzMykgcm90YXRlKDBkZWcpO1xcbiAgICAgIC1tcy10cmFuc2Zvcm06IHNjYWxlKDAuODMzMzMzMzMpIHJvdGF0ZSgwZGVnKTtcXG4gICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgwLjgzMzMzMzMzKSByb3RhdGUoMGRlZyk7XFxuICBwb3NpdGlvbjogYWJzb2x1dGU7XFxuICByaWdodDogNHB4O1xcbn1cXG4uYW50LXNlbGVjdC1zZWxlY3Rpb24tLW11bHRpcGxlIC5hbnQtc2VsZWN0LXNlbGVjdGlvbl9fY2hvaWNlX19yZW1vdmU6YmVmb3JlIHtcXG4gIGRpc3BsYXk6IGJsb2NrO1xcbiAgZm9udC1mYW1pbHk6IFxcXCJhbnRpY29uXFxcIiAhaW1wb3J0YW50O1xcbn1cXG46cm9vdCAuYW50LXNlbGVjdC1zZWxlY3Rpb24tLW11bHRpcGxlIC5hbnQtc2VsZWN0LXNlbGVjdGlvbl9fY2hvaWNlX19yZW1vdmUge1xcbiAgZm9udC1zaXplOiAxMnB4O1xcbn1cXG4uYW50LXNlbGVjdC1zZWxlY3Rpb24tLW11bHRpcGxlIC5hbnQtc2VsZWN0LXNlbGVjdGlvbl9fY2hvaWNlX19yZW1vdmU6aG92ZXIge1xcbiAgY29sb3I6ICM0MDQwNDA7XFxufVxcbi5hbnQtc2VsZWN0LXNlbGVjdGlvbi0tbXVsdGlwbGUgLmFudC1zZWxlY3Qtc2VsZWN0aW9uX19jaG9pY2VfX3JlbW92ZTpiZWZvcmUge1xcbiAgY29udGVudDogXFxcIlxcXFxFNjMzXFxcIjtcXG59XFxuLmFudC1zZWxlY3Qtc2VsZWN0aW9uLS1tdWx0aXBsZSAuYW50LXNlbGVjdC1zZWxlY3Rpb25fX2NsZWFyIHtcXG4gIHRvcDogMTZweDtcXG59XFxuLmFudC1zZWxlY3QtYWxsb3ctY2xlYXIgLmFudC1zZWxlY3Qtc2VsZWN0aW9uLS1tdWx0aXBsZSAuYW50LXNlbGVjdC1zZWxlY3Rpb25fX3JlbmRlcmVkIHtcXG4gIG1hcmdpbi1yaWdodDogMjBweDtcXG59XFxuLmFudC1zZWxlY3Qtb3BlbiAuYW50LXNlbGVjdC1hcnJvdzpiZWZvcmUge1xcbiAgLXdlYmtpdC10cmFuc2Zvcm06IHJvdGF0ZSgxODBkZWcpO1xcbiAgICAgIC1tcy10cmFuc2Zvcm06IHJvdGF0ZSgxODBkZWcpO1xcbiAgICAgICAgICB0cmFuc2Zvcm06IHJvdGF0ZSgxODBkZWcpO1xcbn1cXG4uYW50LXNlbGVjdC1vcGVuIC5hbnQtc2VsZWN0LXNlbGVjdGlvbiB7XFxuICBib3JkZXItY29sb3I6ICM0MGE5ZmY7XFxuICBvdXRsaW5lOiAwO1xcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiAwIDAgMCAycHggcmdiYSgyNCwgMTQ0LCAyNTUsIDAuMik7XFxuICAgICAgICAgIGJveC1zaGFkb3c6IDAgMCAwIDJweCByZ2JhKDI0LCAxNDQsIDI1NSwgMC4yKTtcXG59XFxuLmFudC1zZWxlY3QtY29tYm9ib3ggLmFudC1zZWxlY3QtYXJyb3cge1xcbiAgZGlzcGxheTogbm9uZTtcXG59XFxuLmFudC1zZWxlY3QtY29tYm9ib3ggLmFudC1zZWxlY3Qtc2VhcmNoLS1pbmxpbmUge1xcbiAgaGVpZ2h0OiAxMDAlO1xcbiAgd2lkdGg6IDEwMCU7XFxuICBmbG9hdDogbm9uZTtcXG59XFxuLmFudC1zZWxlY3QtY29tYm9ib3ggLmFudC1zZWxlY3Qtc2VhcmNoX19maWVsZF9fd3JhcCB7XFxuICB3aWR0aDogMTAwJTtcXG4gIGhlaWdodDogMTAwJTtcXG59XFxuLmFudC1zZWxlY3QtY29tYm9ib3ggLmFudC1zZWxlY3Qtc2VhcmNoX19maWVsZCB7XFxuICB3aWR0aDogMTAwJTtcXG4gIGhlaWdodDogMTAwJTtcXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcXG4gIHotaW5kZXg6IDE7XFxuICAtd2Via2l0LXRyYW5zaXRpb246IGFsbCAwLjNzIGN1YmljLWJlemllcigwLjY0NSwgMC4wNDUsIDAuMzU1LCAxKTtcXG4gIHRyYW5zaXRpb246IGFsbCAwLjNzIGN1YmljLWJlemllcigwLjY0NSwgMC4wNDUsIDAuMzU1LCAxKTtcXG4gIC13ZWJraXQtYm94LXNoYWRvdzogbm9uZTtcXG4gICAgICAgICAgYm94LXNoYWRvdzogbm9uZTtcXG59XFxuLmFudC1zZWxlY3QtY29tYm9ib3guYW50LXNlbGVjdC1hbGxvdy1jbGVhciAuYW50LXNlbGVjdC1zZWxlY3Rpb246aG92ZXIgLmFudC1zZWxlY3Qtc2VsZWN0aW9uX19yZW5kZXJlZCB7XFxuICBtYXJnaW4tcmlnaHQ6IDIwcHg7XFxufVxcbi5hbnQtc2VsZWN0LWRyb3Bkb3duIHtcXG4gIGZvbnQtZmFtaWx5OiBcXFwiTW9ub3NwYWNlZCBOdW1iZXJcXFwiLCBcXFwiQ2hpbmVzZSBRdW90ZVxcXCIsIC1hcHBsZS1zeXN0ZW0sIEJsaW5rTWFjU3lzdGVtRm9udCwgXFxcIlNlZ29lIFVJXFxcIiwgUm9ib3RvLCBcXFwiUGluZ0ZhbmcgU0NcXFwiLCBcXFwiSGlyYWdpbm8gU2FucyBHQlxcXCIsIFxcXCJNaWNyb3NvZnQgWWFIZWlcXFwiLCBcXFwiSGVsdmV0aWNhIE5ldWVcXFwiLCBIZWx2ZXRpY2EsIEFyaWFsLCBzYW5zLXNlcmlmO1xcbiAgbGluZS1oZWlnaHQ6IDEuNTtcXG4gIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuNjUpO1xcbiAgbWFyZ2luOiAwO1xcbiAgcGFkZGluZzogMDtcXG4gIGxpc3Qtc3R5bGU6IG5vbmU7XFxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiAwIDJweCA4cHggcmdiYSgwLCAwLCAwLCAwLjE1KTtcXG4gICAgICAgICAgYm94LXNoYWRvdzogMCAycHggOHB4IHJnYmEoMCwgMCwgMCwgMC4xNSk7XFxuICBib3JkZXItcmFkaXVzOiA0cHg7XFxuICAtd2Via2l0LWJveC1zaXppbmc6IGJvcmRlci1ib3g7XFxuICAgICAgICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XFxuICB6LWluZGV4OiAxMDUwO1xcbiAgbGVmdDogLTk5OTlweDtcXG4gIHRvcDogLTk5OTlweDtcXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcXG4gIG91dGxpbmU6IG5vbmU7XFxuICBmb250LXNpemU6IDE0cHg7XFxufVxcbi5hbnQtc2VsZWN0LWRyb3Bkb3duLnNsaWRlLXVwLWVudGVyLnNsaWRlLXVwLWVudGVyLWFjdGl2ZS5hbnQtc2VsZWN0LWRyb3Bkb3duLXBsYWNlbWVudC1ib3R0b21MZWZ0LFxcbi5hbnQtc2VsZWN0LWRyb3Bkb3duLnNsaWRlLXVwLWFwcGVhci5zbGlkZS11cC1hcHBlYXItYWN0aXZlLmFudC1zZWxlY3QtZHJvcGRvd24tcGxhY2VtZW50LWJvdHRvbUxlZnQge1xcbiAgLXdlYmtpdC1hbmltYXRpb24tbmFtZTogYW50U2xpZGVVcEluO1xcbiAgICAgICAgICBhbmltYXRpb24tbmFtZTogYW50U2xpZGVVcEluO1xcbn1cXG4uYW50LXNlbGVjdC1kcm9wZG93bi5zbGlkZS11cC1lbnRlci5zbGlkZS11cC1lbnRlci1hY3RpdmUuYW50LXNlbGVjdC1kcm9wZG93bi1wbGFjZW1lbnQtdG9wTGVmdCxcXG4uYW50LXNlbGVjdC1kcm9wZG93bi5zbGlkZS11cC1hcHBlYXIuc2xpZGUtdXAtYXBwZWFyLWFjdGl2ZS5hbnQtc2VsZWN0LWRyb3Bkb3duLXBsYWNlbWVudC10b3BMZWZ0IHtcXG4gIC13ZWJraXQtYW5pbWF0aW9uLW5hbWU6IGFudFNsaWRlRG93bkluO1xcbiAgICAgICAgICBhbmltYXRpb24tbmFtZTogYW50U2xpZGVEb3duSW47XFxufVxcbi5hbnQtc2VsZWN0LWRyb3Bkb3duLnNsaWRlLXVwLWxlYXZlLnNsaWRlLXVwLWxlYXZlLWFjdGl2ZS5hbnQtc2VsZWN0LWRyb3Bkb3duLXBsYWNlbWVudC1ib3R0b21MZWZ0IHtcXG4gIC13ZWJraXQtYW5pbWF0aW9uLW5hbWU6IGFudFNsaWRlVXBPdXQ7XFxuICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBhbnRTbGlkZVVwT3V0O1xcbn1cXG4uYW50LXNlbGVjdC1kcm9wZG93bi5zbGlkZS11cC1sZWF2ZS5zbGlkZS11cC1sZWF2ZS1hY3RpdmUuYW50LXNlbGVjdC1kcm9wZG93bi1wbGFjZW1lbnQtdG9wTGVmdCB7XFxuICAtd2Via2l0LWFuaW1hdGlvbi1uYW1lOiBhbnRTbGlkZURvd25PdXQ7XFxuICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBhbnRTbGlkZURvd25PdXQ7XFxufVxcbi5hbnQtc2VsZWN0LWRyb3Bkb3duLWhpZGRlbiB7XFxuICBkaXNwbGF5OiBub25lO1xcbn1cXG4uYW50LXNlbGVjdC1kcm9wZG93bi1tZW51IHtcXG4gIG91dGxpbmU6IG5vbmU7XFxuICBtYXJnaW4tYm90dG9tOiAwO1xcbiAgcGFkZGluZy1sZWZ0OiAwO1xcbiAgbGlzdC1zdHlsZTogbm9uZTtcXG4gIG1heC1oZWlnaHQ6IDI1MHB4O1xcbiAgb3ZlcmZsb3c6IGF1dG87XFxufVxcbi5hbnQtc2VsZWN0LWRyb3Bkb3duLW1lbnUtaXRlbS1ncm91cC1saXN0IHtcXG4gIG1hcmdpbjogMDtcXG4gIHBhZGRpbmc6IDA7XFxufVxcbi5hbnQtc2VsZWN0LWRyb3Bkb3duLW1lbnUtaXRlbS1ncm91cC1saXN0ID4gLmFudC1zZWxlY3QtZHJvcGRvd24tbWVudS1pdGVtIHtcXG4gIHBhZGRpbmctbGVmdDogMjBweDtcXG59XFxuLmFudC1zZWxlY3QtZHJvcGRvd24tbWVudS1pdGVtLWdyb3VwLXRpdGxlIHtcXG4gIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuNDUpO1xcbiAgcGFkZGluZzogMCAxMnB4O1xcbiAgaGVpZ2h0OiAzMnB4O1xcbiAgbGluZS1oZWlnaHQ6IDMycHg7XFxuICBmb250LXNpemU6IDEycHg7XFxufVxcbi5hbnQtc2VsZWN0LWRyb3Bkb3duLW1lbnUtaXRlbSB7XFxuICBwb3NpdGlvbjogcmVsYXRpdmU7XFxuICBkaXNwbGF5OiBibG9jaztcXG4gIHBhZGRpbmc6IDVweCAxMnB4O1xcbiAgbGluZS1oZWlnaHQ6IDIycHg7XFxuICBmb250LXdlaWdodDogbm9ybWFsO1xcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC42NSk7XFxuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xcbiAgY3Vyc29yOiBwb2ludGVyO1xcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcXG4gIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xcbiAgLXdlYmtpdC10cmFuc2l0aW9uOiBiYWNrZ3JvdW5kIDAuM3MgZWFzZTtcXG4gIHRyYW5zaXRpb246IGJhY2tncm91bmQgMC4zcyBlYXNlO1xcbn1cXG4uYW50LXNlbGVjdC1kcm9wZG93bi1tZW51LWl0ZW06aG92ZXIge1xcbiAgYmFja2dyb3VuZC1jb2xvcjogI2U2ZjdmZjtcXG59XFxuLmFudC1zZWxlY3QtZHJvcGRvd24tbWVudS1pdGVtOmZpcnN0LWNoaWxkIHtcXG4gIGJvcmRlci1yYWRpdXM6IDRweCA0cHggMCAwO1xcbn1cXG4uYW50LXNlbGVjdC1kcm9wZG93bi1tZW51LWl0ZW06bGFzdC1jaGlsZCB7XFxuICBib3JkZXItcmFkaXVzOiAwIDAgNHB4IDRweDtcXG59XFxuLmFudC1zZWxlY3QtZHJvcGRvd24tbWVudS1pdGVtLWRpc2FibGVkIHtcXG4gIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuMjUpO1xcbiAgY3Vyc29yOiBub3QtYWxsb3dlZDtcXG59XFxuLmFudC1zZWxlY3QtZHJvcGRvd24tbWVudS1pdGVtLWRpc2FibGVkOmhvdmVyIHtcXG4gIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuMjUpO1xcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcXG4gIGN1cnNvcjogbm90LWFsbG93ZWQ7XFxufVxcbi5hbnQtc2VsZWN0LWRyb3Bkb3duLW1lbnUtaXRlbS1zZWxlY3RlZCxcXG4uYW50LXNlbGVjdC1kcm9wZG93bi1tZW51LWl0ZW0tc2VsZWN0ZWQ6aG92ZXIge1xcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZhZmFmYTtcXG4gIGZvbnQtd2VpZ2h0OiA2MDA7XFxuICBjb2xvcjogcmdiYSgwLCAwLCAwLCAwLjY1KTtcXG59XFxuLmFudC1zZWxlY3QtZHJvcGRvd24tbWVudS1pdGVtLWFjdGl2ZSB7XFxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTZmN2ZmO1xcbn1cXG4uYW50LXNlbGVjdC1kcm9wZG93bi1tZW51LWl0ZW0tZGl2aWRlciB7XFxuICBoZWlnaHQ6IDFweDtcXG4gIG1hcmdpbjogMXB4IDA7XFxuICBvdmVyZmxvdzogaGlkZGVuO1xcbiAgYmFja2dyb3VuZC1jb2xvcjogI2U4ZThlODtcXG4gIGxpbmUtaGVpZ2h0OiAwO1xcbn1cXG4uYW50LXNlbGVjdC1kcm9wZG93bi5hbnQtc2VsZWN0LWRyb3Bkb3duLS1tdWx0aXBsZSAuYW50LXNlbGVjdC1kcm9wZG93bi1tZW51LWl0ZW06YWZ0ZXIge1xcbiAgZm9udC1mYW1pbHk6ICdhbnRpY29uJztcXG4gIHRleHQtcmVuZGVyaW5nOiBvcHRpbWl6ZUxlZ2liaWxpdHk7XFxuICAtd2Via2l0LWZvbnQtc21vb3RoaW5nOiBhbnRpYWxpYXNlZDtcXG4gIC1tb3otb3N4LWZvbnQtc21vb3RoaW5nOiBncmF5c2NhbGU7XFxuICBjb250ZW50OiBcXFwiXFxcXEU2MzJcXFwiO1xcbiAgY29sb3I6IHRyYW5zcGFyZW50O1xcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xcbiAgZm9udC1zaXplOiAxMnB4O1xcbiAgZm9udC1zaXplOiAxMHB4IFxcXFw5O1xcbiAgLXdlYmtpdC10cmFuc2Zvcm06IHNjYWxlKDAuODMzMzMzMzMpIHJvdGF0ZSgwZGVnKTtcXG4gICAgICAtbXMtdHJhbnNmb3JtOiBzY2FsZSgwLjgzMzMzMzMzKSByb3RhdGUoMGRlZyk7XFxuICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC44MzMzMzMzMykgcm90YXRlKDBkZWcpO1xcbiAgLXdlYmtpdC10cmFuc2l0aW9uOiBhbGwgMC4ycyBlYXNlO1xcbiAgdHJhbnNpdGlvbjogYWxsIDAuMnMgZWFzZTtcXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcXG4gIHRvcDogNTAlO1xcbiAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTUwJSk7XFxuICAgICAgLW1zLXRyYW5zZm9ybTogdHJhbnNsYXRlWSgtNTAlKTtcXG4gICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC01MCUpO1xcbiAgcmlnaHQ6IDEycHg7XFxuICBmb250LXdlaWdodDogYm9sZDtcXG4gIHRleHQtc2hhZG93OiAwIDAuMXB4IDAsIDAuMXB4IDAgMCwgMCAtMC4xcHggMCwgLTAuMXB4IDA7XFxufVxcbjpyb290IC5hbnQtc2VsZWN0LWRyb3Bkb3duLmFudC1zZWxlY3QtZHJvcGRvd24tLW11bHRpcGxlIC5hbnQtc2VsZWN0LWRyb3Bkb3duLW1lbnUtaXRlbTphZnRlciB7XFxuICBmb250LXNpemU6IDEycHg7XFxufVxcbi5hbnQtc2VsZWN0LWRyb3Bkb3duLmFudC1zZWxlY3QtZHJvcGRvd24tLW11bHRpcGxlIC5hbnQtc2VsZWN0LWRyb3Bkb3duLW1lbnUtaXRlbTpob3ZlcjphZnRlciB7XFxuICBjb2xvcjogI2RkZDtcXG59XFxuLmFudC1zZWxlY3QtZHJvcGRvd24uYW50LXNlbGVjdC1kcm9wZG93bi0tbXVsdGlwbGUgLmFudC1zZWxlY3QtZHJvcGRvd24tbWVudS1pdGVtLWRpc2FibGVkOmFmdGVyIHtcXG4gIGRpc3BsYXk6IG5vbmU7XFxufVxcbi5hbnQtc2VsZWN0LWRyb3Bkb3duLmFudC1zZWxlY3QtZHJvcGRvd24tLW11bHRpcGxlIC5hbnQtc2VsZWN0LWRyb3Bkb3duLW1lbnUtaXRlbS1zZWxlY3RlZDphZnRlcixcXG4uYW50LXNlbGVjdC1kcm9wZG93bi5hbnQtc2VsZWN0LWRyb3Bkb3duLS1tdWx0aXBsZSAuYW50LXNlbGVjdC1kcm9wZG93bi1tZW51LWl0ZW0tc2VsZWN0ZWQ6aG92ZXI6YWZ0ZXIge1xcbiAgY29sb3I6ICMxODkwZmY7XFxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XFxufVxcbi5hbnQtc2VsZWN0LWRyb3Bkb3duLWNvbnRhaW5lci1vcGVuIC5hbnQtc2VsZWN0LWRyb3Bkb3duLFxcbi5hbnQtc2VsZWN0LWRyb3Bkb3duLW9wZW4gLmFudC1zZWxlY3QtZHJvcGRvd24ge1xcbiAgZGlzcGxheTogYmxvY2s7XFxufVxcblwiLCBcIlwiXSk7XG5cbi8vIGV4cG9ydHNcbiIsImV4cG9ydHMgPSBtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCIuLi8uLi8uLi8uLi9jc3MtbG9hZGVyL2xpYi9jc3MtYmFzZS5qc1wiKShmYWxzZSk7XG4vLyBpbXBvcnRzXG5cblxuLy8gbW9kdWxlXG5leHBvcnRzLnB1c2goW21vZHVsZS5pZCwgXCIvKiBzdHlsZWxpbnQtZGlzYWJsZSBhdC1ydWxlLWVtcHR5LWxpbmUtYmVmb3JlLGF0LXJ1bGUtbmFtZS1zcGFjZS1hZnRlcixhdC1ydWxlLW5vLXVua25vd24gKi9cXG4vKiBzdHlsZWxpbnQtZGlzYWJsZSBuby1kdXBsaWNhdGUtc2VsZWN0b3JzICovXFxuLyogc3R5bGVsaW50LWRpc2FibGUgZGVjbGFyYXRpb24tYmFuZy1zcGFjZS1iZWZvcmUsbm8tZHVwbGljYXRlLXNlbGVjdG9ycyAqL1xcbi8qIHN0eWxlbGludC1kaXNhYmxlIGRlY2xhcmF0aW9uLWJhbmctc3BhY2UtYmVmb3JlLG5vLWR1cGxpY2F0ZS1zZWxlY3RvcnMsc3RyaW5nLW5vLW5ld2xpbmUgKi9cXG4uYW50LXNwaW4ge1xcbiAgZm9udC1mYW1pbHk6IFxcXCJNb25vc3BhY2VkIE51bWJlclxcXCIsIFxcXCJDaGluZXNlIFF1b3RlXFxcIiwgLWFwcGxlLXN5c3RlbSwgQmxpbmtNYWNTeXN0ZW1Gb250LCBcXFwiU2Vnb2UgVUlcXFwiLCBSb2JvdG8sIFxcXCJQaW5nRmFuZyBTQ1xcXCIsIFxcXCJIaXJhZ2lubyBTYW5zIEdCXFxcIiwgXFxcIk1pY3Jvc29mdCBZYUhlaVxcXCIsIFxcXCJIZWx2ZXRpY2EgTmV1ZVxcXCIsIEhlbHZldGljYSwgQXJpYWwsIHNhbnMtc2VyaWY7XFxuICBmb250LXNpemU6IDE0cHg7XFxuICBsaW5lLWhlaWdodDogMS41O1xcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC42NSk7XFxuICAtd2Via2l0LWJveC1zaXppbmc6IGJvcmRlci1ib3g7XFxuICAgICAgICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XFxuICBtYXJnaW46IDA7XFxuICBwYWRkaW5nOiAwO1xcbiAgbGlzdC1zdHlsZTogbm9uZTtcXG4gIGNvbG9yOiAjMTg5MGZmO1xcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcXG4gIG9wYWNpdHk6IDA7XFxuICBwb3NpdGlvbjogYWJzb2x1dGU7XFxuICAtd2Via2l0LXRyYW5zaXRpb246IC13ZWJraXQtdHJhbnNmb3JtIDAuM3MgY3ViaWMtYmV6aWVyKDAuNzgsIDAuMTQsIDAuMTUsIDAuODYpO1xcbiAgdHJhbnNpdGlvbjogLXdlYmtpdC10cmFuc2Zvcm0gMC4zcyBjdWJpYy1iZXppZXIoMC43OCwgMC4xNCwgMC4xNSwgMC44Nik7XFxuICB0cmFuc2l0aW9uOiB0cmFuc2Zvcm0gMC4zcyBjdWJpYy1iZXppZXIoMC43OCwgMC4xNCwgMC4xNSwgMC44Nik7XFxuICB0cmFuc2l0aW9uOiB0cmFuc2Zvcm0gMC4zcyBjdWJpYy1iZXppZXIoMC43OCwgMC4xNCwgMC4xNSwgMC44NiksIC13ZWJraXQtdHJhbnNmb3JtIDAuM3MgY3ViaWMtYmV6aWVyKDAuNzgsIDAuMTQsIDAuMTUsIDAuODYpO1xcbiAgZGlzcGxheTogbm9uZTtcXG59XFxuLmFudC1zcGluLXNwaW5uaW5nIHtcXG4gIG9wYWNpdHk6IDE7XFxuICBwb3NpdGlvbjogc3RhdGljO1xcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xcbn1cXG4uYW50LXNwaW4tbmVzdGVkLWxvYWRpbmcge1xcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xcbn1cXG4uYW50LXNwaW4tbmVzdGVkLWxvYWRpbmcgPiBkaXYgPiAuYW50LXNwaW4ge1xcbiAgcG9zaXRpb246IGFic29sdXRlO1xcbiAgaGVpZ2h0OiAxMDAlO1xcbiAgbWF4LWhlaWdodDogMzIwcHg7XFxuICB3aWR0aDogMTAwJTtcXG4gIHotaW5kZXg6IDQ7XFxufVxcbi5hbnQtc3Bpbi1uZXN0ZWQtbG9hZGluZyA+IGRpdiA+IC5hbnQtc3BpbiAuYW50LXNwaW4tZG90IHtcXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcXG4gIHRvcDogNTAlO1xcbiAgbGVmdDogNTAlO1xcbiAgbWFyZ2luOiAtMTBweDtcXG59XFxuLmFudC1zcGluLW5lc3RlZC1sb2FkaW5nID4gZGl2ID4gLmFudC1zcGluIC5hbnQtc3Bpbi10ZXh0IHtcXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcXG4gIHRvcDogNTAlO1xcbiAgd2lkdGg6IDEwMCU7XFxuICBwYWRkaW5nLXRvcDogNXB4O1xcbiAgdGV4dC1zaGFkb3c6IDAgMXB4IDJweCAjZmZmO1xcbn1cXG4uYW50LXNwaW4tbmVzdGVkLWxvYWRpbmcgPiBkaXYgPiAuYW50LXNwaW4uYW50LXNwaW4tc2hvdy10ZXh0IC5hbnQtc3Bpbi1kb3Qge1xcbiAgbWFyZ2luLXRvcDogLTIwcHg7XFxufVxcbi5hbnQtc3Bpbi1uZXN0ZWQtbG9hZGluZyA+IGRpdiA+IC5hbnQtc3Bpbi1zbSAuYW50LXNwaW4tZG90IHtcXG4gIG1hcmdpbjogLTdweDtcXG59XFxuLmFudC1zcGluLW5lc3RlZC1sb2FkaW5nID4gZGl2ID4gLmFudC1zcGluLXNtIC5hbnQtc3Bpbi10ZXh0IHtcXG4gIHBhZGRpbmctdG9wOiAycHg7XFxufVxcbi5hbnQtc3Bpbi1uZXN0ZWQtbG9hZGluZyA+IGRpdiA+IC5hbnQtc3Bpbi1zbS5hbnQtc3Bpbi1zaG93LXRleHQgLmFudC1zcGluLWRvdCB7XFxuICBtYXJnaW4tdG9wOiAtMTdweDtcXG59XFxuLmFudC1zcGluLW5lc3RlZC1sb2FkaW5nID4gZGl2ID4gLmFudC1zcGluLWxnIC5hbnQtc3Bpbi1kb3Qge1xcbiAgbWFyZ2luOiAtMTZweDtcXG59XFxuLmFudC1zcGluLW5lc3RlZC1sb2FkaW5nID4gZGl2ID4gLmFudC1zcGluLWxnIC5hbnQtc3Bpbi10ZXh0IHtcXG4gIHBhZGRpbmctdG9wOiAxMXB4O1xcbn1cXG4uYW50LXNwaW4tbmVzdGVkLWxvYWRpbmcgPiBkaXYgPiAuYW50LXNwaW4tbGcuYW50LXNwaW4tc2hvdy10ZXh0IC5hbnQtc3Bpbi1kb3Qge1xcbiAgbWFyZ2luLXRvcDogLTI2cHg7XFxufVxcbi5hbnQtc3Bpbi1jb250YWluZXIge1xcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xcbiAgem9vbTogMTtcXG59XFxuLmFudC1zcGluLWNvbnRhaW5lcjpiZWZvcmUsXFxuLmFudC1zcGluLWNvbnRhaW5lcjphZnRlciB7XFxuICBjb250ZW50OiBcXFwiIFxcXCI7XFxuICBkaXNwbGF5OiB0YWJsZTtcXG59XFxuLmFudC1zcGluLWNvbnRhaW5lcjphZnRlciB7XFxuICBjbGVhcjogYm90aDtcXG4gIHZpc2liaWxpdHk6IGhpZGRlbjtcXG4gIGZvbnQtc2l6ZTogMDtcXG4gIGhlaWdodDogMDtcXG59XFxuLmFudC1zcGluLWJsdXIge1xcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcXG4gIG9wYWNpdHk6IDAuNztcXG4gIC13ZWJraXQtZmlsdGVyOiBibHVyKDAuNXB4KTtcXG4gIGZpbHRlcjogYmx1cigwLjVweCk7XFxuICAvKiBhdXRvcHJlZml4ZXI6IG9mZiAqL1xcbiAgZmlsdGVyOiBwcm9naWRcXFxcOkRYSW1hZ2VUcmFuc2Zvcm1cXFxcLk1pY3Jvc29mdFxcXFwuQmx1cihQaXhlbFJhZGl1c1xcXFw9MSwgTWFrZVNoYWRvd1xcXFw9ZmFsc2UpO1xcbiAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZVooMCk7XFxufVxcbi5hbnQtc3Bpbi1ibHVyOmFmdGVyIHtcXG4gIGNvbnRlbnQ6ICcnO1xcbiAgcG9zaXRpb246IGFic29sdXRlO1xcbiAgbGVmdDogMDtcXG4gIHJpZ2h0OiAwO1xcbiAgdG9wOiAwO1xcbiAgYm90dG9tOiAwO1xcbiAgYmFja2dyb3VuZDogI2ZmZjtcXG4gIG9wYWNpdHk6IDAuMztcXG4gIC13ZWJraXQtdHJhbnNpdGlvbjogYWxsIC4zcztcXG4gIHRyYW5zaXRpb246IGFsbCAuM3M7XFxuICB6LWluZGV4OiAxMDtcXG59XFxuLmFudC1zcGluLXRpcCB7XFxuICBjb2xvcjogcmdiYSgwLCAwLCAwLCAwLjQ1KTtcXG59XFxuLmFudC1zcGluLWRvdCB7XFxuICBwb3NpdGlvbjogcmVsYXRpdmU7XFxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XFxuICB3aWR0aDogMjBweDtcXG4gIGhlaWdodDogMjBweDtcXG59XFxuLmFudC1zcGluLWRvdCBpIHtcXG4gIHdpZHRoOiA5cHg7XFxuICBoZWlnaHQ6IDlweDtcXG4gIGJvcmRlci1yYWRpdXM6IDEwMCU7XFxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMTg5MGZmO1xcbiAgLXdlYmtpdC10cmFuc2Zvcm06IHNjYWxlKDAuNzUpO1xcbiAgICAgIC1tcy10cmFuc2Zvcm06IHNjYWxlKDAuNzUpO1xcbiAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDAuNzUpO1xcbiAgZGlzcGxheTogYmxvY2s7XFxuICBwb3NpdGlvbjogYWJzb2x1dGU7XFxuICBvcGFjaXR5OiAwLjM7XFxuICAtd2Via2l0LWFuaW1hdGlvbjogYW50U3Bpbk1vdmUgMXMgaW5maW5pdGUgbGluZWFyIGFsdGVybmF0ZTtcXG4gICAgICAgICAgYW5pbWF0aW9uOiBhbnRTcGluTW92ZSAxcyBpbmZpbml0ZSBsaW5lYXIgYWx0ZXJuYXRlO1xcbiAgLXdlYmtpdC10cmFuc2Zvcm0tb3JpZ2luOiA1MCUgNTAlO1xcbiAgICAgIC1tcy10cmFuc2Zvcm0tb3JpZ2luOiA1MCUgNTAlO1xcbiAgICAgICAgICB0cmFuc2Zvcm0tb3JpZ2luOiA1MCUgNTAlO1xcbn1cXG4uYW50LXNwaW4tZG90IGk6bnRoLWNoaWxkKDEpIHtcXG4gIGxlZnQ6IDA7XFxuICB0b3A6IDA7XFxufVxcbi5hbnQtc3Bpbi1kb3QgaTpudGgtY2hpbGQoMikge1xcbiAgcmlnaHQ6IDA7XFxuICB0b3A6IDA7XFxuICAtd2Via2l0LWFuaW1hdGlvbi1kZWxheTogMC40cztcXG4gICAgICAgICAgYW5pbWF0aW9uLWRlbGF5OiAwLjRzO1xcbn1cXG4uYW50LXNwaW4tZG90IGk6bnRoLWNoaWxkKDMpIHtcXG4gIHJpZ2h0OiAwO1xcbiAgYm90dG9tOiAwO1xcbiAgLXdlYmtpdC1hbmltYXRpb24tZGVsYXk6IDAuOHM7XFxuICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC44cztcXG59XFxuLmFudC1zcGluLWRvdCBpOm50aC1jaGlsZCg0KSB7XFxuICBsZWZ0OiAwO1xcbiAgYm90dG9tOiAwO1xcbiAgLXdlYmtpdC1hbmltYXRpb24tZGVsYXk6IDEuMnM7XFxuICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMS4ycztcXG59XFxuLmFudC1zcGluLWRvdC1zcGluIHtcXG4gIC13ZWJraXQtdHJhbnNmb3JtOiByb3RhdGUoNDVkZWcpO1xcbiAgICAgIC1tcy10cmFuc2Zvcm06IHJvdGF0ZSg0NWRlZyk7XFxuICAgICAgICAgIHRyYW5zZm9ybTogcm90YXRlKDQ1ZGVnKTtcXG4gIC13ZWJraXQtYW5pbWF0aW9uOiBhbnRSb3RhdGUgMS4ycyBpbmZpbml0ZSBsaW5lYXI7XFxuICAgICAgICAgIGFuaW1hdGlvbjogYW50Um90YXRlIDEuMnMgaW5maW5pdGUgbGluZWFyO1xcbn1cXG4uYW50LXNwaW4tc20gLmFudC1zcGluLWRvdCB7XFxuICB3aWR0aDogMTRweDtcXG4gIGhlaWdodDogMTRweDtcXG59XFxuLmFudC1zcGluLXNtIC5hbnQtc3Bpbi1kb3QgaSB7XFxuICB3aWR0aDogNnB4O1xcbiAgaGVpZ2h0OiA2cHg7XFxufVxcbi5hbnQtc3Bpbi1sZyAuYW50LXNwaW4tZG90IHtcXG4gIHdpZHRoOiAzMnB4O1xcbiAgaGVpZ2h0OiAzMnB4O1xcbn1cXG4uYW50LXNwaW4tbGcgLmFudC1zcGluLWRvdCBpIHtcXG4gIHdpZHRoOiAxNHB4O1xcbiAgaGVpZ2h0OiAxNHB4O1xcbn1cXG4uYW50LXNwaW4uYW50LXNwaW4tc2hvdy10ZXh0IC5hbnQtc3Bpbi10ZXh0IHtcXG4gIGRpc3BsYXk6IGJsb2NrO1xcbn1cXG5AbWVkaWEgYWxsIGFuZCAoLW1zLWhpZ2gtY29udHJhc3Q6IG5vbmUpLCAoLW1zLWhpZ2gtY29udHJhc3Q6IGFjdGl2ZSkge1xcbiAgLyogSUUxMCsgKi9cXG4gIC5hbnQtc3Bpbi1ibHVyIHtcXG4gICAgYmFja2dyb3VuZDogI2ZmZjtcXG4gICAgb3BhY2l0eTogMC41O1xcbiAgfVxcbn1cXG5ALXdlYmtpdC1rZXlmcmFtZXMgYW50U3Bpbk1vdmUge1xcbiAgdG8ge1xcbiAgICBvcGFjaXR5OiAxO1xcbiAgfVxcbn1cXG5Aa2V5ZnJhbWVzIGFudFNwaW5Nb3ZlIHtcXG4gIHRvIHtcXG4gICAgb3BhY2l0eTogMTtcXG4gIH1cXG59XFxuQC13ZWJraXQta2V5ZnJhbWVzIGFudFJvdGF0ZSB7XFxuICB0byB7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiByb3RhdGUoNDA1ZGVnKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHJvdGF0ZSg0MDVkZWcpO1xcbiAgfVxcbn1cXG5Aa2V5ZnJhbWVzIGFudFJvdGF0ZSB7XFxuICB0byB7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiByb3RhdGUoNDA1ZGVnKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHJvdGF0ZSg0MDVkZWcpO1xcbiAgfVxcbn1cXG5cIiwgXCJcIl0pO1xuXG4vLyBleHBvcnRzXG4iLCJleHBvcnRzID0gbW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiLi4vLi4vLi4vLi4vY3NzLWxvYWRlci9saWIvY3NzLWJhc2UuanNcIikoZmFsc2UpO1xuLy8gaW1wb3J0c1xuXG5cbi8vIG1vZHVsZVxuZXhwb3J0cy5wdXNoKFttb2R1bGUuaWQsIFwiLyogc3R5bGVsaW50LWRpc2FibGUgYXQtcnVsZS1lbXB0eS1saW5lLWJlZm9yZSxhdC1ydWxlLW5hbWUtc3BhY2UtYWZ0ZXIsYXQtcnVsZS1uby11bmtub3duICovXFxuLyogc3R5bGVsaW50LWRpc2FibGUgbm8tZHVwbGljYXRlLXNlbGVjdG9ycyAqL1xcbi8qIHN0eWxlbGludC1kaXNhYmxlIGRlY2xhcmF0aW9uLWJhbmctc3BhY2UtYmVmb3JlLG5vLWR1cGxpY2F0ZS1zZWxlY3RvcnMgKi9cXG4vKiBzdHlsZWxpbnQtZGlzYWJsZSBkZWNsYXJhdGlvbi1iYW5nLXNwYWNlLWJlZm9yZSxuby1kdXBsaWNhdGUtc2VsZWN0b3JzLHN0cmluZy1uby1uZXdsaW5lICovXFxuLmFudC10YWJzLmFudC10YWJzLWNhcmQgPiAuYW50LXRhYnMtYmFyIC5hbnQtdGFicy1uYXYtY29udGFpbmVyIHtcXG4gIGhlaWdodDogNDBweDtcXG59XFxuLmFudC10YWJzLmFudC10YWJzLWNhcmQgPiAuYW50LXRhYnMtYmFyIC5hbnQtdGFicy1pbmstYmFyIHtcXG4gIHZpc2liaWxpdHk6IGhpZGRlbjtcXG59XFxuLmFudC10YWJzLmFudC10YWJzLWNhcmQgPiAuYW50LXRhYnMtYmFyIC5hbnQtdGFicy10YWIge1xcbiAgbWFyZ2luOiAwO1xcbiAgYm9yZGVyOiAxcHggc29saWQgI2U4ZThlODtcXG4gIGJvcmRlci1ib3R0b206IDA7XFxuICBib3JkZXItcmFkaXVzOiA0cHggNHB4IDAgMDtcXG4gIGJhY2tncm91bmQ6ICNmYWZhZmE7XFxuICBtYXJnaW4tcmlnaHQ6IDJweDtcXG4gIHBhZGRpbmc6IDAgMTZweDtcXG4gIC13ZWJraXQtdHJhbnNpdGlvbjogYWxsIDAuM3MgY3ViaWMtYmV6aWVyKDAuNjQ1LCAwLjA0NSwgMC4zNTUsIDEpO1xcbiAgdHJhbnNpdGlvbjogYWxsIDAuM3MgY3ViaWMtYmV6aWVyKDAuNjQ1LCAwLjA0NSwgMC4zNTUsIDEpO1xcbiAgbGluZS1oZWlnaHQ6IDM4cHg7XFxufVxcbi5hbnQtdGFicy5hbnQtdGFicy1jYXJkID4gLmFudC10YWJzLWJhciAuYW50LXRhYnMtdGFiLWFjdGl2ZSB7XFxuICBiYWNrZ3JvdW5kOiAjZmZmO1xcbiAgYm9yZGVyLWNvbG9yOiAjZThlOGU4O1xcbiAgY29sb3I6ICMxODkwZmY7XFxuICBwYWRkaW5nLWJvdHRvbTogMXB4O1xcbn1cXG4uYW50LXRhYnMuYW50LXRhYnMtY2FyZCA+IC5hbnQtdGFicy1iYXIgLmFudC10YWJzLXRhYi1pbmFjdGl2ZSB7XFxuICBwYWRkaW5nOiAwO1xcbn1cXG4uYW50LXRhYnMuYW50LXRhYnMtY2FyZCA+IC5hbnQtdGFicy1iYXIgLmFudC10YWJzLW5hdi13cmFwIHtcXG4gIG1hcmdpbi1ib3R0b206IDA7XFxufVxcbi5hbnQtdGFicy5hbnQtdGFicy1jYXJkID4gLmFudC10YWJzLWJhciAuYW50LXRhYnMtdGFiIC5hbnRpY29uLWNsb3NlIHtcXG4gIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuNDUpO1xcbiAgLXdlYmtpdC10cmFuc2l0aW9uOiBhbGwgLjNzO1xcbiAgdHJhbnNpdGlvbjogYWxsIC4zcztcXG4gIGZvbnQtc2l6ZTogMTJweDtcXG4gIG1hcmdpbi1sZWZ0OiAzcHg7XFxuICBtYXJnaW4tcmlnaHQ6IC01cHg7XFxuICBvdmVyZmxvdzogaGlkZGVuO1xcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcXG4gIHdpZHRoOiAxNnB4O1xcbiAgaGVpZ2h0OiAxNnB4O1xcbiAgaGVpZ2h0OiAxNHB4O1xcbn1cXG4uYW50LXRhYnMuYW50LXRhYnMtY2FyZCA+IC5hbnQtdGFicy1iYXIgLmFudC10YWJzLXRhYiAuYW50aWNvbi1jbG9zZTpob3ZlciB7XFxuICBjb2xvcjogcmdiYSgwLCAwLCAwLCAwLjg1KTtcXG59XFxuLmFudC10YWJzLmFudC10YWJzLWNhcmQgLmFudC10YWJzLWNvbnRlbnQgPiAuYW50LXRhYnMtdGFicGFuZSxcXG4uYW50LXRhYnMuYW50LXRhYnMtZWRpdGFibGUtY2FyZCAuYW50LXRhYnMtY29udGVudCA+IC5hbnQtdGFicy10YWJwYW5lIHtcXG4gIC13ZWJraXQtdHJhbnNpdGlvbjogbm9uZSAhaW1wb3J0YW50O1xcbiAgdHJhbnNpdGlvbjogbm9uZSAhaW1wb3J0YW50O1xcbn1cXG4uYW50LXRhYnMuYW50LXRhYnMtY2FyZCAuYW50LXRhYnMtY29udGVudCA+IC5hbnQtdGFicy10YWJwYW5lLWluYWN0aXZlLFxcbi5hbnQtdGFicy5hbnQtdGFicy1lZGl0YWJsZS1jYXJkIC5hbnQtdGFicy1jb250ZW50ID4gLmFudC10YWJzLXRhYnBhbmUtaW5hY3RpdmUge1xcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcXG59XFxuLmFudC10YWJzLmFudC10YWJzLWNhcmQgPiAuYW50LXRhYnMtYmFyIC5hbnQtdGFicy10YWI6aG92ZXIgLmFudGljb24tY2xvc2Uge1xcbiAgb3BhY2l0eTogMTtcXG59XFxuLmFudC10YWJzLWV4dHJhLWNvbnRlbnQge1xcbiAgbGluZS1oZWlnaHQ6IDQwcHg7XFxufVxcbi5hbnQtdGFicy1leHRyYS1jb250ZW50IC5hbnQtdGFicy1uZXctdGFiIHtcXG4gIHdpZHRoOiAyMHB4O1xcbiAgaGVpZ2h0OiAyMHB4O1xcbiAgbGluZS1oZWlnaHQ6IDIwcHg7XFxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XFxuICBjdXJzb3I6IHBvaW50ZXI7XFxuICBib3JkZXItcmFkaXVzOiAycHg7XFxuICBib3JkZXI6IDFweCBzb2xpZCAjZThlOGU4O1xcbiAgZm9udC1zaXplOiAxMnB4O1xcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC42NSk7XFxuICAtd2Via2l0LXRyYW5zaXRpb246IGFsbCAuM3M7XFxuICB0cmFuc2l0aW9uOiBhbGwgLjNzO1xcbn1cXG4uYW50LXRhYnMtZXh0cmEtY29udGVudCAuYW50LXRhYnMtbmV3LXRhYjpob3ZlciB7XFxuICBjb2xvcjogIzE4OTBmZjtcXG4gIGJvcmRlci1jb2xvcjogIzE4OTBmZjtcXG59XFxuLmFudC10YWJzLXZlcnRpY2FsLmFudC10YWJzLWNhcmQgPiAuYW50LXRhYnMtYmFyIC5hbnQtdGFicy1uYXYtY29udGFpbmVyIHtcXG4gIGhlaWdodDogYXV0bztcXG59XFxuLmFudC10YWJzLXZlcnRpY2FsLmFudC10YWJzLWNhcmQgPiAuYW50LXRhYnMtYmFyIC5hbnQtdGFicy10YWIge1xcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlOGU4ZTg7XFxuICBtYXJnaW4tYm90dG9tOiA4cHg7XFxufVxcbi5hbnQtdGFicy12ZXJ0aWNhbC5hbnQtdGFicy1jYXJkID4gLmFudC10YWJzLWJhciAuYW50LXRhYnMtdGFiLWFjdGl2ZSB7XFxuICBwYWRkaW5nLWJvdHRvbTogNHB4O1xcbn1cXG4uYW50LXRhYnMtdmVydGljYWwuYW50LXRhYnMtY2FyZCA+IC5hbnQtdGFicy1iYXIgLmFudC10YWJzLXRhYjpsYXN0LWNoaWxkIHtcXG4gIG1hcmdpbi1ib3R0b206IDhweDtcXG59XFxuLmFudC10YWJzLXZlcnRpY2FsLmFudC10YWJzLWNhcmQgPiAuYW50LXRhYnMtYmFyIC5hbnQtdGFicy1uZXctdGFiIHtcXG4gIHdpZHRoOiA5MCU7XFxufVxcbi5hbnQtdGFicy12ZXJ0aWNhbC5hbnQtdGFicy1jYXJkLmFudC10YWJzLWxlZnQgPiAuYW50LXRhYnMtYmFyIC5hbnQtdGFicy1uYXYtd3JhcCB7XFxuICBtYXJnaW4tcmlnaHQ6IDA7XFxufVxcbi5hbnQtdGFicy12ZXJ0aWNhbC5hbnQtdGFicy1jYXJkLmFudC10YWJzLWxlZnQgPiAuYW50LXRhYnMtYmFyIC5hbnQtdGFicy10YWIge1xcbiAgYm9yZGVyLXJpZ2h0OiAwO1xcbiAgYm9yZGVyLXJhZGl1czogNHB4IDAgMCA0cHg7XFxuICBtYXJnaW4tcmlnaHQ6IDFweDtcXG59XFxuLmFudC10YWJzLXZlcnRpY2FsLmFudC10YWJzLWNhcmQuYW50LXRhYnMtbGVmdCA+IC5hbnQtdGFicy1iYXIgLmFudC10YWJzLXRhYi1hY3RpdmUge1xcbiAgbWFyZ2luLXJpZ2h0OiAtMXB4O1xcbiAgcGFkZGluZy1yaWdodDogMThweDtcXG59XFxuLmFudC10YWJzLXZlcnRpY2FsLmFudC10YWJzLWNhcmQuYW50LXRhYnMtcmlnaHQgPiAuYW50LXRhYnMtYmFyIC5hbnQtdGFicy1uYXYtd3JhcCB7XFxuICBtYXJnaW4tbGVmdDogMDtcXG59XFxuLmFudC10YWJzLXZlcnRpY2FsLmFudC10YWJzLWNhcmQuYW50LXRhYnMtcmlnaHQgPiAuYW50LXRhYnMtYmFyIC5hbnQtdGFicy10YWIge1xcbiAgYm9yZGVyLWxlZnQ6IDA7XFxuICBib3JkZXItcmFkaXVzOiAwIDRweCA0cHggMDtcXG4gIG1hcmdpbi1sZWZ0OiAxcHg7XFxufVxcbi5hbnQtdGFicy12ZXJ0aWNhbC5hbnQtdGFicy1jYXJkLmFudC10YWJzLXJpZ2h0ID4gLmFudC10YWJzLWJhciAuYW50LXRhYnMtdGFiLWFjdGl2ZSB7XFxuICBtYXJnaW4tbGVmdDogLTFweDtcXG4gIHBhZGRpbmctbGVmdDogMThweDtcXG59XFxuLmFudC10YWJzLmFudC10YWJzLWNhcmQuYW50LXRhYnMtYm90dG9tID4gLmFudC10YWJzLWJhciAuYW50LXRhYnMtdGFiIHtcXG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZThlOGU4O1xcbiAgYm9yZGVyLXRvcDogMDtcXG4gIGJvcmRlci1yYWRpdXM6IDAgMCA0cHggNHB4O1xcbn1cXG4uYW50LXRhYnMuYW50LXRhYnMtY2FyZC5hbnQtdGFicy1ib3R0b20gPiAuYW50LXRhYnMtYmFyIC5hbnQtdGFicy10YWItYWN0aXZlIHtcXG4gIGNvbG9yOiAjMTg5MGZmO1xcbiAgcGFkZGluZy1ib3R0b206IDA7XFxuICBwYWRkaW5nLXRvcDogMXB4O1xcbn1cXG4uYW50LXRhYnMge1xcbiAgZm9udC1mYW1pbHk6IFxcXCJNb25vc3BhY2VkIE51bWJlclxcXCIsIFxcXCJDaGluZXNlIFF1b3RlXFxcIiwgLWFwcGxlLXN5c3RlbSwgQmxpbmtNYWNTeXN0ZW1Gb250LCBcXFwiU2Vnb2UgVUlcXFwiLCBSb2JvdG8sIFxcXCJQaW5nRmFuZyBTQ1xcXCIsIFxcXCJIaXJhZ2lubyBTYW5zIEdCXFxcIiwgXFxcIk1pY3Jvc29mdCBZYUhlaVxcXCIsIFxcXCJIZWx2ZXRpY2EgTmV1ZVxcXCIsIEhlbHZldGljYSwgQXJpYWwsIHNhbnMtc2VyaWY7XFxuICBmb250LXNpemU6IDE0cHg7XFxuICBsaW5lLWhlaWdodDogMS41O1xcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC42NSk7XFxuICAtd2Via2l0LWJveC1zaXppbmc6IGJvcmRlci1ib3g7XFxuICAgICAgICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XFxuICBtYXJnaW46IDA7XFxuICBwYWRkaW5nOiAwO1xcbiAgbGlzdC1zdHlsZTogbm9uZTtcXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcXG4gIG92ZXJmbG93OiBoaWRkZW47XFxuICB6b29tOiAxO1xcbn1cXG4uYW50LXRhYnM6YmVmb3JlLFxcbi5hbnQtdGFiczphZnRlciB7XFxuICBjb250ZW50OiBcXFwiIFxcXCI7XFxuICBkaXNwbGF5OiB0YWJsZTtcXG59XFxuLmFudC10YWJzOmFmdGVyIHtcXG4gIGNsZWFyOiBib3RoO1xcbiAgdmlzaWJpbGl0eTogaGlkZGVuO1xcbiAgZm9udC1zaXplOiAwO1xcbiAgaGVpZ2h0OiAwO1xcbn1cXG4uYW50LXRhYnMtaW5rLWJhciB7XFxuICB6LWluZGV4OiAxO1xcbiAgcG9zaXRpb246IGFic29sdXRlO1xcbiAgbGVmdDogMDtcXG4gIGJvdHRvbTogMXB4O1xcbiAgLXdlYmtpdC1ib3gtc2l6aW5nOiBib3JkZXItYm94O1xcbiAgICAgICAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xcbiAgaGVpZ2h0OiAycHg7XFxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMTg5MGZmO1xcbiAgLXdlYmtpdC10cmFuc2Zvcm0tb3JpZ2luOiAwIDA7XFxuICAgICAgLW1zLXRyYW5zZm9ybS1vcmlnaW46IDAgMDtcXG4gICAgICAgICAgdHJhbnNmb3JtLW9yaWdpbjogMCAwO1xcbn1cXG4uYW50LXRhYnMtYmFyIHtcXG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZThlOGU4O1xcbiAgbWFyZ2luOiAwIDAgMTZweCAwO1xcbiAgb3V0bGluZTogbm9uZTtcXG4gIC13ZWJraXQtdHJhbnNpdGlvbjogcGFkZGluZyAwLjNzIGN1YmljLWJlemllcigwLjY0NSwgMC4wNDUsIDAuMzU1LCAxKTtcXG4gIHRyYW5zaXRpb246IHBhZGRpbmcgMC4zcyBjdWJpYy1iZXppZXIoMC42NDUsIDAuMDQ1LCAwLjM1NSwgMSk7XFxufVxcbi5hbnQtdGFicy1uYXYtY29udGFpbmVyIHtcXG4gIG92ZXJmbG93OiBoaWRkZW47XFxuICBmb250LXNpemU6IDE0cHg7XFxuICBsaW5lLWhlaWdodDogMS41O1xcbiAgLXdlYmtpdC1ib3gtc2l6aW5nOiBib3JkZXItYm94O1xcbiAgICAgICAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcXG4gIG1hcmdpbi1ib3R0b206IC0xcHg7XFxuICAtd2Via2l0LXRyYW5zaXRpb246IHBhZGRpbmcgMC4zcyBjdWJpYy1iZXppZXIoMC42NDUsIDAuMDQ1LCAwLjM1NSwgMSk7XFxuICB0cmFuc2l0aW9uOiBwYWRkaW5nIDAuM3MgY3ViaWMtYmV6aWVyKDAuNjQ1LCAwLjA0NSwgMC4zNTUsIDEpO1xcbiAgem9vbTogMTtcXG59XFxuLmFudC10YWJzLW5hdi1jb250YWluZXI6YmVmb3JlLFxcbi5hbnQtdGFicy1uYXYtY29udGFpbmVyOmFmdGVyIHtcXG4gIGNvbnRlbnQ6IFxcXCIgXFxcIjtcXG4gIGRpc3BsYXk6IHRhYmxlO1xcbn1cXG4uYW50LXRhYnMtbmF2LWNvbnRhaW5lcjphZnRlciB7XFxuICBjbGVhcjogYm90aDtcXG4gIHZpc2liaWxpdHk6IGhpZGRlbjtcXG4gIGZvbnQtc2l6ZTogMDtcXG4gIGhlaWdodDogMDtcXG59XFxuLmFudC10YWJzLW5hdi1jb250YWluZXItc2Nyb2xsaW5nIHtcXG4gIHBhZGRpbmctbGVmdDogMzJweDtcXG4gIHBhZGRpbmctcmlnaHQ6IDMycHg7XFxufVxcbi5hbnQtdGFicy1ib3R0b20gLmFudC10YWJzLWJhciB7XFxuICBib3JkZXItYm90dG9tOiBub25lO1xcbiAgYm9yZGVyLXRvcDogMXB4IHNvbGlkICNlOGU4ZTg7XFxufVxcbi5hbnQtdGFicy1ib3R0b20gLmFudC10YWJzLWluay1iYXIge1xcbiAgYm90dG9tOiBhdXRvO1xcbiAgdG9wOiAxcHg7XFxufVxcbi5hbnQtdGFicy1ib3R0b20gLmFudC10YWJzLW5hdi1jb250YWluZXIge1xcbiAgbWFyZ2luLWJvdHRvbTogMDtcXG4gIG1hcmdpbi10b3A6IC0xcHg7XFxufVxcbi5hbnQtdGFicy10YWItcHJldixcXG4uYW50LXRhYnMtdGFiLW5leHQge1xcbiAgLXdlYmtpdC11c2VyLXNlbGVjdDogbm9uZTtcXG4gICAgIC1tb3otdXNlci1zZWxlY3Q6IG5vbmU7XFxuICAgICAgLW1zLXVzZXItc2VsZWN0OiBub25lO1xcbiAgICAgICAgICB1c2VyLXNlbGVjdDogbm9uZTtcXG4gIHotaW5kZXg6IDI7XFxuICB3aWR0aDogMDtcXG4gIGhlaWdodDogMTAwJTtcXG4gIGN1cnNvcjogcG9pbnRlcjtcXG4gIGJvcmRlcjogMDtcXG4gIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xcbiAgcG9zaXRpb246IGFic29sdXRlO1xcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC40NSk7XFxuICAtd2Via2l0LXRyYW5zaXRpb246IHdpZHRoIDAuM3MgY3ViaWMtYmV6aWVyKDAuNjQ1LCAwLjA0NSwgMC4zNTUsIDEpLCBvcGFjaXR5IDAuM3MgY3ViaWMtYmV6aWVyKDAuNjQ1LCAwLjA0NSwgMC4zNTUsIDEpLCBjb2xvciAwLjNzIGN1YmljLWJlemllcigwLjY0NSwgMC4wNDUsIDAuMzU1LCAxKTtcXG4gIHRyYW5zaXRpb246IHdpZHRoIDAuM3MgY3ViaWMtYmV6aWVyKDAuNjQ1LCAwLjA0NSwgMC4zNTUsIDEpLCBvcGFjaXR5IDAuM3MgY3ViaWMtYmV6aWVyKDAuNjQ1LCAwLjA0NSwgMC4zNTUsIDEpLCBjb2xvciAwLjNzIGN1YmljLWJlemllcigwLjY0NSwgMC4wNDUsIDAuMzU1LCAxKTtcXG4gIG9wYWNpdHk6IDA7XFxuICBwb2ludGVyLWV2ZW50czogbm9uZTtcXG59XFxuLmFudC10YWJzLXRhYi1wcmV2LmFudC10YWJzLXRhYi1hcnJvdy1zaG93LFxcbi5hbnQtdGFicy10YWItbmV4dC5hbnQtdGFicy10YWItYXJyb3ctc2hvdyB7XFxuICBvcGFjaXR5OiAxO1xcbiAgd2lkdGg6IDMycHg7XFxuICBoZWlnaHQ6IDEwMCU7XFxuICBwb2ludGVyLWV2ZW50czogYXV0bztcXG59XFxuLmFudC10YWJzLXRhYi1wcmV2OmhvdmVyLFxcbi5hbnQtdGFicy10YWItbmV4dDpob3ZlciB7XFxuICBjb2xvcjogcmdiYSgwLCAwLCAwLCAwLjY1KTtcXG59XFxuLmFudC10YWJzLXRhYi1wcmV2LWljb24sXFxuLmFudC10YWJzLXRhYi1uZXh0LWljb24ge1xcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XFxuICBmb250LXZhcmlhbnQ6IG5vcm1hbDtcXG4gIGxpbmUtaGVpZ2h0OiBpbmhlcml0O1xcbiAgdmVydGljYWwtYWxpZ246IGJhc2VsaW5lO1xcbiAgcG9zaXRpb246IGFic29sdXRlO1xcbiAgdG9wOiA1MCU7XFxuICBsZWZ0OiA1MCU7XFxuICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xcbiAgICAgIC1tcy10cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKTtcXG4gICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XFxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XFxuICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcXG59XFxuLmFudC10YWJzLXRhYi1wcmV2LWljb246YmVmb3JlLFxcbi5hbnQtdGFicy10YWItbmV4dC1pY29uOmJlZm9yZSB7XFxuICBkaXNwbGF5OiBibG9jaztcXG4gIGZvbnQtZmFtaWx5OiBcXFwiYW50aWNvblxcXCIgIWltcG9ydGFudDtcXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcXG4gIGZvbnQtc2l6ZTogMTJweDtcXG4gIGZvbnQtc2l6ZTogMTBweCBcXFxcOTtcXG4gIC13ZWJraXQtdHJhbnNmb3JtOiBzY2FsZSgwLjgzMzMzMzMzKSByb3RhdGUoMGRlZyk7XFxuICAgICAgLW1zLXRyYW5zZm9ybTogc2NhbGUoMC44MzMzMzMzMykgcm90YXRlKDBkZWcpO1xcbiAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDAuODMzMzMzMzMpIHJvdGF0ZSgwZGVnKTtcXG59XFxuOnJvb3QgLmFudC10YWJzLXRhYi1wcmV2LWljb246YmVmb3JlLFxcbjpyb290IC5hbnQtdGFicy10YWItbmV4dC1pY29uOmJlZm9yZSB7XFxuICBmb250LXNpemU6IDEycHg7XFxufVxcbi5hbnQtdGFicy10YWItYnRuLWRpc2FibGVkIHtcXG4gIGN1cnNvcjogbm90LWFsbG93ZWQ7XFxufVxcbi5hbnQtdGFicy10YWItYnRuLWRpc2FibGVkLFxcbi5hbnQtdGFicy10YWItYnRuLWRpc2FibGVkOmhvdmVyIHtcXG4gIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuMjUpO1xcbn1cXG4uYW50LXRhYnMtdGFiLW5leHQge1xcbiAgcmlnaHQ6IDJweDtcXG59XFxuLmFudC10YWJzLXRhYi1uZXh0LWljb246YmVmb3JlIHtcXG4gIGNvbnRlbnQ6IFxcXCJcXFxcRTYxRlxcXCI7XFxufVxcbi5hbnQtdGFicy10YWItcHJldiB7XFxuICBsZWZ0OiAwO1xcbn1cXG4uYW50LXRhYnMtdGFiLXByZXYtaWNvbjpiZWZvcmUge1xcbiAgY29udGVudDogXFxcIlxcXFxFNjIwXFxcIjtcXG59XFxuOnJvb3QgLmFudC10YWJzLXRhYi1wcmV2IHtcXG4gIC13ZWJraXQtZmlsdGVyOiBub25lO1xcbiAgICAgICAgICBmaWx0ZXI6IG5vbmU7XFxufVxcbi5hbnQtdGFicy1uYXYtd3JhcCB7XFxuICBvdmVyZmxvdzogaGlkZGVuO1xcbiAgbWFyZ2luLWJvdHRvbTogLTFweDtcXG59XFxuLmFudC10YWJzLW5hdi1zY3JvbGwge1xcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcXG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XFxufVxcbi5hbnQtdGFicy1uYXYge1xcbiAgLXdlYmtpdC1ib3gtc2l6aW5nOiBib3JkZXItYm94O1xcbiAgICAgICAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xcbiAgcGFkZGluZy1sZWZ0OiAwO1xcbiAgLXdlYmtpdC10cmFuc2l0aW9uOiAtd2Via2l0LXRyYW5zZm9ybSAwLjNzIGN1YmljLWJlemllcigwLjY0NSwgMC4wNDUsIDAuMzU1LCAxKTtcXG4gIHRyYW5zaXRpb246IC13ZWJraXQtdHJhbnNmb3JtIDAuM3MgY3ViaWMtYmV6aWVyKDAuNjQ1LCAwLjA0NSwgMC4zNTUsIDEpO1xcbiAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDAuM3MgY3ViaWMtYmV6aWVyKDAuNjQ1LCAwLjA0NSwgMC4zNTUsIDEpO1xcbiAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDAuM3MgY3ViaWMtYmV6aWVyKDAuNjQ1LCAwLjA0NSwgMC4zNTUsIDEpLCAtd2Via2l0LXRyYW5zZm9ybSAwLjNzIGN1YmljLWJlemllcigwLjY0NSwgMC4wNDUsIDAuMzU1LCAxKTtcXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcXG4gIG1hcmdpbjogMDtcXG4gIGxpc3Qtc3R5bGU6IG5vbmU7XFxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XFxufVxcbi5hbnQtdGFicy1uYXY6YmVmb3JlLFxcbi5hbnQtdGFicy1uYXY6YWZ0ZXIge1xcbiAgZGlzcGxheTogdGFibGU7XFxuICBjb250ZW50OiBcXFwiIFxcXCI7XFxufVxcbi5hbnQtdGFicy1uYXY6YWZ0ZXIge1xcbiAgY2xlYXI6IGJvdGg7XFxufVxcbi5hbnQtdGFicy1uYXYgLmFudC10YWJzLXRhYi1kaXNhYmxlZCB7XFxuICBwb2ludGVyLWV2ZW50czogbm9uZTtcXG4gIGN1cnNvcjogZGVmYXVsdDtcXG4gIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuMjUpO1xcbn1cXG4uYW50LXRhYnMtbmF2IC5hbnQtdGFicy10YWIge1xcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xcbiAgaGVpZ2h0OiAxMDAlO1xcbiAgbWFyZ2luOiAwIDMycHggMCAwO1xcbiAgcGFkZGluZzogMTJweCAxNnB4O1xcbiAgLXdlYmtpdC1ib3gtc2l6aW5nOiBib3JkZXItYm94O1xcbiAgICAgICAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xcbiAgLXdlYmtpdC10cmFuc2l0aW9uOiBjb2xvciAwLjNzIGN1YmljLWJlemllcigwLjY0NSwgMC4wNDUsIDAuMzU1LCAxKTtcXG4gIHRyYW5zaXRpb246IGNvbG9yIDAuM3MgY3ViaWMtYmV6aWVyKDAuNjQ1LCAwLjA0NSwgMC4zNTUsIDEpO1xcbiAgY3Vyc29yOiBwb2ludGVyO1xcbiAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xcbn1cXG4uYW50LXRhYnMtbmF2IC5hbnQtdGFicy10YWI6bGFzdC1jaGlsZCB7XFxuICBtYXJnaW4tcmlnaHQ6IDA7XFxufVxcbi5hbnQtdGFicy1uYXYgLmFudC10YWJzLXRhYjpob3ZlciB7XFxuICBjb2xvcjogIzQwYTlmZjtcXG59XFxuLmFudC10YWJzLW5hdiAuYW50LXRhYnMtdGFiOmFjdGl2ZSB7XFxuICBjb2xvcjogIzA5NmRkOTtcXG59XFxuLmFudC10YWJzLW5hdiAuYW50LXRhYnMtdGFiIC5hbnRpY29uIHtcXG4gIG1hcmdpbi1yaWdodDogOHB4O1xcbn1cXG4uYW50LXRhYnMtbmF2IC5hbnQtdGFicy10YWItYWN0aXZlIHtcXG4gIGNvbG9yOiAjMTg5MGZmO1xcbiAgZm9udC13ZWlnaHQ6IDUwMDtcXG59XFxuLmFudC10YWJzLWxhcmdlIC5hbnQtdGFicy1uYXYtY29udGFpbmVyIHtcXG4gIGZvbnQtc2l6ZTogMTZweDtcXG59XFxuLmFudC10YWJzLWxhcmdlIC5hbnQtdGFicy10YWIge1xcbiAgcGFkZGluZzogMTZweDtcXG59XFxuLmFudC10YWJzLXNtYWxsIC5hbnQtdGFicy1uYXYtY29udGFpbmVyIHtcXG4gIGZvbnQtc2l6ZTogMTRweDtcXG59XFxuLmFudC10YWJzLXNtYWxsIC5hbnQtdGFicy10YWIge1xcbiAgcGFkZGluZzogOHB4IDE2cHg7XFxufVxcbi5hbnQtdGFiczpub3QoLmFudC10YWJzLXZlcnRpY2FsKSA+IC5hbnQtdGFicy1jb250ZW50IHtcXG4gIHdpZHRoOiAxMDAlO1xcbn1cXG4uYW50LXRhYnM6bm90KC5hbnQtdGFicy12ZXJ0aWNhbCkgPiAuYW50LXRhYnMtY29udGVudCA+IC5hbnQtdGFicy10YWJwYW5lIHtcXG4gIC13ZWJraXQtZmxleC1zaHJpbms6IDA7XFxuICAgICAgLW1zLWZsZXgtbmVnYXRpdmU6IDA7XFxuICAgICAgICAgIGZsZXgtc2hyaW5rOiAwO1xcbiAgd2lkdGg6IDEwMCU7XFxuICAtd2Via2l0LXRyYW5zaXRpb246IG9wYWNpdHkgLjQ1cztcXG4gIHRyYW5zaXRpb246IG9wYWNpdHkgLjQ1cztcXG4gIG9wYWNpdHk6IDE7XFxufVxcbi5hbnQtdGFiczpub3QoLmFudC10YWJzLXZlcnRpY2FsKSA+IC5hbnQtdGFicy1jb250ZW50ID4gLmFudC10YWJzLXRhYnBhbmUtaW5hY3RpdmUge1xcbiAgb3BhY2l0eTogMDtcXG4gIGhlaWdodDogMDtcXG4gIHBhZGRpbmc6IDAgIWltcG9ydGFudDtcXG4gIHBvaW50ZXItZXZlbnRzOiBub25lO1xcbn1cXG4uYW50LXRhYnM6bm90KC5hbnQtdGFicy12ZXJ0aWNhbCkgPiAuYW50LXRhYnMtY29udGVudC1hbmltYXRlZCB7XFxuICBkaXNwbGF5OiAtd2Via2l0LWJveDtcXG4gIGRpc3BsYXk6IC13ZWJraXQtZmxleDtcXG4gIGRpc3BsYXk6IC1tcy1mbGV4Ym94O1xcbiAgZGlzcGxheTogZmxleDtcXG4gIC13ZWJraXQtYm94LW9yaWVudDogaG9yaXpvbnRhbDtcXG4gIC13ZWJraXQtYm94LWRpcmVjdGlvbjogbm9ybWFsO1xcbiAgLXdlYmtpdC1mbGV4LWRpcmVjdGlvbjogcm93O1xcbiAgICAgIC1tcy1mbGV4LWRpcmVjdGlvbjogcm93O1xcbiAgICAgICAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xcbiAgd2lsbC1jaGFuZ2U6IG1hcmdpbi1sZWZ0O1xcbiAgLXdlYmtpdC10cmFuc2l0aW9uOiBtYXJnaW4tbGVmdCAwLjNzIGN1YmljLWJlemllcigwLjY0NSwgMC4wNDUsIDAuMzU1LCAxKTtcXG4gIHRyYW5zaXRpb246IG1hcmdpbi1sZWZ0IDAuM3MgY3ViaWMtYmV6aWVyKDAuNjQ1LCAwLjA0NSwgMC4zNTUsIDEpO1xcbn1cXG4uYW50LXRhYnMtdmVydGljYWwgPiAuYW50LXRhYnMtYmFyIHtcXG4gIGJvcmRlci1ib3R0b206IDA7XFxuICBoZWlnaHQ6IDEwMCU7XFxufVxcbi5hbnQtdGFicy12ZXJ0aWNhbCA+IC5hbnQtdGFicy1iYXItdGFiLXByZXYsXFxuLmFudC10YWJzLXZlcnRpY2FsID4gLmFudC10YWJzLWJhci10YWItbmV4dCB7XFxuICB3aWR0aDogMzJweDtcXG4gIGhlaWdodDogMDtcXG4gIC13ZWJraXQtdHJhbnNpdGlvbjogaGVpZ2h0IDAuM3MgY3ViaWMtYmV6aWVyKDAuNjQ1LCAwLjA0NSwgMC4zNTUsIDEpLCBvcGFjaXR5IDAuM3MgY3ViaWMtYmV6aWVyKDAuNjQ1LCAwLjA0NSwgMC4zNTUsIDEpLCBjb2xvciAwLjNzIGN1YmljLWJlemllcigwLjY0NSwgMC4wNDUsIDAuMzU1LCAxKTtcXG4gIHRyYW5zaXRpb246IGhlaWdodCAwLjNzIGN1YmljLWJlemllcigwLjY0NSwgMC4wNDUsIDAuMzU1LCAxKSwgb3BhY2l0eSAwLjNzIGN1YmljLWJlemllcigwLjY0NSwgMC4wNDUsIDAuMzU1LCAxKSwgY29sb3IgMC4zcyBjdWJpYy1iZXppZXIoMC42NDUsIDAuMDQ1LCAwLjM1NSwgMSk7XFxufVxcbi5hbnQtdGFicy12ZXJ0aWNhbCA+IC5hbnQtdGFicy1iYXItdGFiLXByZXYuYW50LXRhYnMtdGFiLWFycm93LXNob3csXFxuLmFudC10YWJzLXZlcnRpY2FsID4gLmFudC10YWJzLWJhci10YWItbmV4dC5hbnQtdGFicy10YWItYXJyb3ctc2hvdyB7XFxuICB3aWR0aDogMTAwJTtcXG4gIGhlaWdodDogMzJweDtcXG59XFxuLmFudC10YWJzLXZlcnRpY2FsID4gLmFudC10YWJzLWJhciAuYW50LXRhYnMtdGFiIHtcXG4gIGZsb2F0OiBub25lO1xcbiAgbWFyZ2luOiAwIDAgMTZweCAwO1xcbiAgcGFkZGluZzogOHB4IDI0cHg7XFxuICBkaXNwbGF5OiBibG9jaztcXG59XFxuLmFudC10YWJzLXZlcnRpY2FsID4gLmFudC10YWJzLWJhciAuYW50LXRhYnMtdGFiOmxhc3QtY2hpbGQge1xcbiAgbWFyZ2luLWJvdHRvbTogMDtcXG59XFxuLmFudC10YWJzLXZlcnRpY2FsID4gLmFudC10YWJzLWJhciAuYW50LXRhYnMtZXh0cmEtY29udGVudCB7XFxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XFxufVxcbi5hbnQtdGFicy12ZXJ0aWNhbCA+IC5hbnQtdGFicy1iYXIgLmFudC10YWJzLW5hdi1zY3JvbGwge1xcbiAgd2lkdGg6IGF1dG87XFxufVxcbi5hbnQtdGFicy12ZXJ0aWNhbCA+IC5hbnQtdGFicy1iYXIgLmFudC10YWJzLW5hdi1jb250YWluZXIsXFxuLmFudC10YWJzLXZlcnRpY2FsID4gLmFudC10YWJzLWJhciAuYW50LXRhYnMtbmF2LXdyYXAge1xcbiAgaGVpZ2h0OiAxMDAlO1xcbn1cXG4uYW50LXRhYnMtdmVydGljYWwgPiAuYW50LXRhYnMtYmFyIC5hbnQtdGFicy1uYXYtY29udGFpbmVyIHtcXG4gIG1hcmdpbi1ib3R0b206IDA7XFxufVxcbi5hbnQtdGFicy12ZXJ0aWNhbCA+IC5hbnQtdGFicy1iYXIgLmFudC10YWJzLW5hdi1jb250YWluZXIuYW50LXRhYnMtbmF2LWNvbnRhaW5lci1zY3JvbGxpbmcge1xcbiAgcGFkZGluZzogMzJweCAwO1xcbn1cXG4uYW50LXRhYnMtdmVydGljYWwgPiAuYW50LXRhYnMtYmFyIC5hbnQtdGFicy1uYXYtd3JhcCB7XFxuICBtYXJnaW4tYm90dG9tOiAwO1xcbn1cXG4uYW50LXRhYnMtdmVydGljYWwgPiAuYW50LXRhYnMtYmFyIC5hbnQtdGFicy1uYXYge1xcbiAgd2lkdGg6IDEwMCU7XFxufVxcbi5hbnQtdGFicy12ZXJ0aWNhbCA+IC5hbnQtdGFicy1iYXIgLmFudC10YWJzLWluay1iYXIge1xcbiAgd2lkdGg6IDJweDtcXG4gIGxlZnQ6IGF1dG87XFxuICBoZWlnaHQ6IGF1dG87XFxuICB0b3A6IDA7XFxufVxcbi5hbnQtdGFicy12ZXJ0aWNhbCA+IC5hbnQtdGFicy1iYXIgLmFudC10YWJzLXRhYi1uZXh0IHtcXG4gIHdpZHRoOiAxMDAlO1xcbiAgYm90dG9tOiAwO1xcbiAgaGVpZ2h0OiAzMnB4O1xcbn1cXG4uYW50LXRhYnMtdmVydGljYWwgPiAuYW50LXRhYnMtYmFyIC5hbnQtdGFicy10YWItbmV4dC1pY29uOmJlZm9yZSB7XFxuICBjb250ZW50OiBcXFwiXFxcXEU2MURcXFwiO1xcbn1cXG4uYW50LXRhYnMtdmVydGljYWwgPiAuYW50LXRhYnMtYmFyIC5hbnQtdGFicy10YWItcHJldiB7XFxuICB0b3A6IDA7XFxuICB3aWR0aDogMTAwJTtcXG4gIGhlaWdodDogMzJweDtcXG59XFxuLmFudC10YWJzLXZlcnRpY2FsID4gLmFudC10YWJzLWJhciAuYW50LXRhYnMtdGFiLXByZXYtaWNvbjpiZWZvcmUge1xcbiAgY29udGVudDogXFxcIlxcXFxFNjFFXFxcIjtcXG59XFxuLmFudC10YWJzLXZlcnRpY2FsID4gLmFudC10YWJzLWNvbnRlbnQge1xcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcXG4gIHdpZHRoOiBhdXRvO1xcbiAgbWFyZ2luLXRvcDogMCAhaW1wb3J0YW50O1xcbn1cXG4uYW50LXRhYnMtdmVydGljYWwuYW50LXRhYnMtbGVmdCA+IC5hbnQtdGFicy1iYXIge1xcbiAgZmxvYXQ6IGxlZnQ7XFxuICBib3JkZXItcmlnaHQ6IDFweCBzb2xpZCAjZThlOGU4O1xcbiAgbWFyZ2luLXJpZ2h0OiAtMXB4O1xcbiAgbWFyZ2luLWJvdHRvbTogMDtcXG59XFxuLmFudC10YWJzLXZlcnRpY2FsLmFudC10YWJzLWxlZnQgPiAuYW50LXRhYnMtYmFyIC5hbnQtdGFicy10YWIge1xcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XFxufVxcbi5hbnQtdGFicy12ZXJ0aWNhbC5hbnQtdGFicy1sZWZ0ID4gLmFudC10YWJzLWJhciAuYW50LXRhYnMtbmF2LWNvbnRhaW5lciB7XFxuICBtYXJnaW4tcmlnaHQ6IC0xcHg7XFxufVxcbi5hbnQtdGFicy12ZXJ0aWNhbC5hbnQtdGFicy1sZWZ0ID4gLmFudC10YWJzLWJhciAuYW50LXRhYnMtbmF2LXdyYXAge1xcbiAgbWFyZ2luLXJpZ2h0OiAtMXB4O1xcbn1cXG4uYW50LXRhYnMtdmVydGljYWwuYW50LXRhYnMtbGVmdCA+IC5hbnQtdGFicy1iYXIgLmFudC10YWJzLWluay1iYXIge1xcbiAgcmlnaHQ6IDFweDtcXG59XFxuLmFudC10YWJzLXZlcnRpY2FsLmFudC10YWJzLWxlZnQgPiAuYW50LXRhYnMtY29udGVudCB7XFxuICBwYWRkaW5nLWxlZnQ6IDI0cHg7XFxuICBib3JkZXItbGVmdDogMXB4IHNvbGlkICNlOGU4ZTg7XFxufVxcbi5hbnQtdGFicy12ZXJ0aWNhbC5hbnQtdGFicy1yaWdodCA+IC5hbnQtdGFicy1iYXIge1xcbiAgZmxvYXQ6IHJpZ2h0O1xcbiAgYm9yZGVyLWxlZnQ6IDFweCBzb2xpZCAjZThlOGU4O1xcbiAgbWFyZ2luLWxlZnQ6IC0xcHg7XFxuICBtYXJnaW4tYm90dG9tOiAwO1xcbn1cXG4uYW50LXRhYnMtdmVydGljYWwuYW50LXRhYnMtcmlnaHQgPiAuYW50LXRhYnMtYmFyIC5hbnQtdGFicy1uYXYtY29udGFpbmVyIHtcXG4gIG1hcmdpbi1sZWZ0OiAtMXB4O1xcbn1cXG4uYW50LXRhYnMtdmVydGljYWwuYW50LXRhYnMtcmlnaHQgPiAuYW50LXRhYnMtYmFyIC5hbnQtdGFicy1uYXYtd3JhcCB7XFxuICBtYXJnaW4tbGVmdDogLTFweDtcXG59XFxuLmFudC10YWJzLXZlcnRpY2FsLmFudC10YWJzLXJpZ2h0ID4gLmFudC10YWJzLWJhciAuYW50LXRhYnMtaW5rLWJhciB7XFxuICBsZWZ0OiAxcHg7XFxufVxcbi5hbnQtdGFicy12ZXJ0aWNhbC5hbnQtdGFicy1yaWdodCA+IC5hbnQtdGFicy1jb250ZW50IHtcXG4gIHBhZGRpbmctcmlnaHQ6IDI0cHg7XFxuICBib3JkZXItcmlnaHQ6IDFweCBzb2xpZCAjZThlOGU4O1xcbn1cXG4uYW50LXRhYnMtYm90dG9tID4gLmFudC10YWJzLWJhciB7XFxuICBtYXJnaW4tYm90dG9tOiAwO1xcbiAgbWFyZ2luLXRvcDogMTZweDtcXG59XFxuLmFudC10YWJzLXRvcCAuYW50LXRhYnMtaW5rLWJhci1hbmltYXRlZCxcXG4uYW50LXRhYnMtYm90dG9tIC5hbnQtdGFicy1pbmstYmFyLWFuaW1hdGVkIHtcXG4gIC13ZWJraXQtdHJhbnNpdGlvbjogd2lkdGggMC4zcyBjdWJpYy1iZXppZXIoMC42NDUsIDAuMDQ1LCAwLjM1NSwgMSksIC13ZWJraXQtdHJhbnNmb3JtIDAuM3MgY3ViaWMtYmV6aWVyKDAuNjQ1LCAwLjA0NSwgMC4zNTUsIDEpO1xcbiAgdHJhbnNpdGlvbjogd2lkdGggMC4zcyBjdWJpYy1iZXppZXIoMC42NDUsIDAuMDQ1LCAwLjM1NSwgMSksIC13ZWJraXQtdHJhbnNmb3JtIDAuM3MgY3ViaWMtYmV6aWVyKDAuNjQ1LCAwLjA0NSwgMC4zNTUsIDEpO1xcbiAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDAuM3MgY3ViaWMtYmV6aWVyKDAuNjQ1LCAwLjA0NSwgMC4zNTUsIDEpLCB3aWR0aCAwLjNzIGN1YmljLWJlemllcigwLjY0NSwgMC4wNDUsIDAuMzU1LCAxKTtcXG4gIHRyYW5zaXRpb246IHRyYW5zZm9ybSAwLjNzIGN1YmljLWJlemllcigwLjY0NSwgMC4wNDUsIDAuMzU1LCAxKSwgd2lkdGggMC4zcyBjdWJpYy1iZXppZXIoMC42NDUsIDAuMDQ1LCAwLjM1NSwgMSksIC13ZWJraXQtdHJhbnNmb3JtIDAuM3MgY3ViaWMtYmV6aWVyKDAuNjQ1LCAwLjA0NSwgMC4zNTUsIDEpO1xcbn1cXG4uYW50LXRhYnMtbGVmdCAuYW50LXRhYnMtaW5rLWJhci1hbmltYXRlZCxcXG4uYW50LXRhYnMtcmlnaHQgLmFudC10YWJzLWluay1iYXItYW5pbWF0ZWQge1xcbiAgLXdlYmtpdC10cmFuc2l0aW9uOiBoZWlnaHQgMC4zcyBjdWJpYy1iZXppZXIoMC42NDUsIDAuMDQ1LCAwLjM1NSwgMSksIC13ZWJraXQtdHJhbnNmb3JtIDAuM3MgY3ViaWMtYmV6aWVyKDAuNjQ1LCAwLjA0NSwgMC4zNTUsIDEpO1xcbiAgdHJhbnNpdGlvbjogaGVpZ2h0IDAuM3MgY3ViaWMtYmV6aWVyKDAuNjQ1LCAwLjA0NSwgMC4zNTUsIDEpLCAtd2Via2l0LXRyYW5zZm9ybSAwLjNzIGN1YmljLWJlemllcigwLjY0NSwgMC4wNDUsIDAuMzU1LCAxKTtcXG4gIHRyYW5zaXRpb246IHRyYW5zZm9ybSAwLjNzIGN1YmljLWJlemllcigwLjY0NSwgMC4wNDUsIDAuMzU1LCAxKSwgaGVpZ2h0IDAuM3MgY3ViaWMtYmV6aWVyKDAuNjQ1LCAwLjA0NSwgMC4zNTUsIDEpO1xcbiAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDAuM3MgY3ViaWMtYmV6aWVyKDAuNjQ1LCAwLjA0NSwgMC4zNTUsIDEpLCBoZWlnaHQgMC4zcyBjdWJpYy1iZXppZXIoMC42NDUsIDAuMDQ1LCAwLjM1NSwgMSksIC13ZWJraXQtdHJhbnNmb3JtIDAuM3MgY3ViaWMtYmV6aWVyKDAuNjQ1LCAwLjA0NSwgMC4zNTUsIDEpO1xcbn1cXG4ubm8tZmxleCA+IC5hbnQtdGFicy1jb250ZW50LWFuaW1hdGVkLFxcbi5hbnQtdGFicy1uby1hbmltYXRpb24gPiAuYW50LXRhYnMtY29udGVudC1hbmltYXRlZCxcXG4uYW50LXRhYnMtdmVydGljYWwgPiAuYW50LXRhYnMtY29udGVudC1hbmltYXRlZCB7XFxuICAtd2Via2l0LXRyYW5zZm9ybTogbm9uZSAhaW1wb3J0YW50O1xcbiAgICAgIC1tcy10cmFuc2Zvcm06IG5vbmUgIWltcG9ydGFudDtcXG4gICAgICAgICAgdHJhbnNmb3JtOiBub25lICFpbXBvcnRhbnQ7XFxuICBtYXJnaW4tbGVmdDogMCAhaW1wb3J0YW50O1xcbn1cXG4ubm8tZmxleCA+IC5hbnQtdGFicy1jb250ZW50ID4gLmFudC10YWJzLXRhYnBhbmUtaW5hY3RpdmUsXFxuLmFudC10YWJzLW5vLWFuaW1hdGlvbiA+IC5hbnQtdGFicy1jb250ZW50ID4gLmFudC10YWJzLXRhYnBhbmUtaW5hY3RpdmUsXFxuLmFudC10YWJzLXZlcnRpY2FsID4gLmFudC10YWJzLWNvbnRlbnQgPiAuYW50LXRhYnMtdGFicGFuZS1pbmFjdGl2ZSB7XFxuICBkaXNwbGF5OiBub25lO1xcbn1cXG5cIiwgXCJcIl0pO1xuXG4vLyBleHBvcnRzXG4iLCJ2YXIgaXNPYmplY3QgPSByZXF1aXJlKCcuL2lzT2JqZWN0JyksXG4gICAgbm93ID0gcmVxdWlyZSgnLi9ub3cnKSxcbiAgICB0b051bWJlciA9IHJlcXVpcmUoJy4vdG9OdW1iZXInKTtcblxuLyoqIEVycm9yIG1lc3NhZ2UgY29uc3RhbnRzLiAqL1xudmFyIEZVTkNfRVJST1JfVEVYVCA9ICdFeHBlY3RlZCBhIGZ1bmN0aW9uJztcblxuLyogQnVpbHQtaW4gbWV0aG9kIHJlZmVyZW5jZXMgZm9yIHRob3NlIHdpdGggdGhlIHNhbWUgbmFtZSBhcyBvdGhlciBgbG9kYXNoYCBtZXRob2RzLiAqL1xudmFyIG5hdGl2ZU1heCA9IE1hdGgubWF4LFxuICAgIG5hdGl2ZU1pbiA9IE1hdGgubWluO1xuXG4vKipcbiAqIENyZWF0ZXMgYSBkZWJvdW5jZWQgZnVuY3Rpb24gdGhhdCBkZWxheXMgaW52b2tpbmcgYGZ1bmNgIHVudGlsIGFmdGVyIGB3YWl0YFxuICogbWlsbGlzZWNvbmRzIGhhdmUgZWxhcHNlZCBzaW5jZSB0aGUgbGFzdCB0aW1lIHRoZSBkZWJvdW5jZWQgZnVuY3Rpb24gd2FzXG4gKiBpbnZva2VkLiBUaGUgZGVib3VuY2VkIGZ1bmN0aW9uIGNvbWVzIHdpdGggYSBgY2FuY2VsYCBtZXRob2QgdG8gY2FuY2VsXG4gKiBkZWxheWVkIGBmdW5jYCBpbnZvY2F0aW9ucyBhbmQgYSBgZmx1c2hgIG1ldGhvZCB0byBpbW1lZGlhdGVseSBpbnZva2UgdGhlbS5cbiAqIFByb3ZpZGUgYG9wdGlvbnNgIHRvIGluZGljYXRlIHdoZXRoZXIgYGZ1bmNgIHNob3VsZCBiZSBpbnZva2VkIG9uIHRoZVxuICogbGVhZGluZyBhbmQvb3IgdHJhaWxpbmcgZWRnZSBvZiB0aGUgYHdhaXRgIHRpbWVvdXQuIFRoZSBgZnVuY2AgaXMgaW52b2tlZFxuICogd2l0aCB0aGUgbGFzdCBhcmd1bWVudHMgcHJvdmlkZWQgdG8gdGhlIGRlYm91bmNlZCBmdW5jdGlvbi4gU3Vic2VxdWVudFxuICogY2FsbHMgdG8gdGhlIGRlYm91bmNlZCBmdW5jdGlvbiByZXR1cm4gdGhlIHJlc3VsdCBvZiB0aGUgbGFzdCBgZnVuY2BcbiAqIGludm9jYXRpb24uXG4gKlxuICogKipOb3RlOioqIElmIGBsZWFkaW5nYCBhbmQgYHRyYWlsaW5nYCBvcHRpb25zIGFyZSBgdHJ1ZWAsIGBmdW5jYCBpc1xuICogaW52b2tlZCBvbiB0aGUgdHJhaWxpbmcgZWRnZSBvZiB0aGUgdGltZW91dCBvbmx5IGlmIHRoZSBkZWJvdW5jZWQgZnVuY3Rpb25cbiAqIGlzIGludm9rZWQgbW9yZSB0aGFuIG9uY2UgZHVyaW5nIHRoZSBgd2FpdGAgdGltZW91dC5cbiAqXG4gKiBJZiBgd2FpdGAgaXMgYDBgIGFuZCBgbGVhZGluZ2AgaXMgYGZhbHNlYCwgYGZ1bmNgIGludm9jYXRpb24gaXMgZGVmZXJyZWRcbiAqIHVudGlsIHRvIHRoZSBuZXh0IHRpY2ssIHNpbWlsYXIgdG8gYHNldFRpbWVvdXRgIHdpdGggYSB0aW1lb3V0IG9mIGAwYC5cbiAqXG4gKiBTZWUgW0RhdmlkIENvcmJhY2hvJ3MgYXJ0aWNsZV0oaHR0cHM6Ly9jc3MtdHJpY2tzLmNvbS9kZWJvdW5jaW5nLXRocm90dGxpbmctZXhwbGFpbmVkLWV4YW1wbGVzLylcbiAqIGZvciBkZXRhaWxzIG92ZXIgdGhlIGRpZmZlcmVuY2VzIGJldHdlZW4gYF8uZGVib3VuY2VgIGFuZCBgXy50aHJvdHRsZWAuXG4gKlxuICogQHN0YXRpY1xuICogQG1lbWJlck9mIF9cbiAqIEBzaW5jZSAwLjEuMFxuICogQGNhdGVnb3J5IEZ1bmN0aW9uXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBmdW5jIFRoZSBmdW5jdGlvbiB0byBkZWJvdW5jZS5cbiAqIEBwYXJhbSB7bnVtYmVyfSBbd2FpdD0wXSBUaGUgbnVtYmVyIG9mIG1pbGxpc2Vjb25kcyB0byBkZWxheS5cbiAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9ucz17fV0gVGhlIG9wdGlvbnMgb2JqZWN0LlxuICogQHBhcmFtIHtib29sZWFufSBbb3B0aW9ucy5sZWFkaW5nPWZhbHNlXVxuICogIFNwZWNpZnkgaW52b2tpbmcgb24gdGhlIGxlYWRpbmcgZWRnZSBvZiB0aGUgdGltZW91dC5cbiAqIEBwYXJhbSB7bnVtYmVyfSBbb3B0aW9ucy5tYXhXYWl0XVxuICogIFRoZSBtYXhpbXVtIHRpbWUgYGZ1bmNgIGlzIGFsbG93ZWQgdG8gYmUgZGVsYXllZCBiZWZvcmUgaXQncyBpbnZva2VkLlxuICogQHBhcmFtIHtib29sZWFufSBbb3B0aW9ucy50cmFpbGluZz10cnVlXVxuICogIFNwZWNpZnkgaW52b2tpbmcgb24gdGhlIHRyYWlsaW5nIGVkZ2Ugb2YgdGhlIHRpbWVvdXQuXG4gKiBAcmV0dXJucyB7RnVuY3Rpb259IFJldHVybnMgdGhlIG5ldyBkZWJvdW5jZWQgZnVuY3Rpb24uXG4gKiBAZXhhbXBsZVxuICpcbiAqIC8vIEF2b2lkIGNvc3RseSBjYWxjdWxhdGlvbnMgd2hpbGUgdGhlIHdpbmRvdyBzaXplIGlzIGluIGZsdXguXG4gKiBqUXVlcnkod2luZG93KS5vbigncmVzaXplJywgXy5kZWJvdW5jZShjYWxjdWxhdGVMYXlvdXQsIDE1MCkpO1xuICpcbiAqIC8vIEludm9rZSBgc2VuZE1haWxgIHdoZW4gY2xpY2tlZCwgZGVib3VuY2luZyBzdWJzZXF1ZW50IGNhbGxzLlxuICogalF1ZXJ5KGVsZW1lbnQpLm9uKCdjbGljaycsIF8uZGVib3VuY2Uoc2VuZE1haWwsIDMwMCwge1xuICogICAnbGVhZGluZyc6IHRydWUsXG4gKiAgICd0cmFpbGluZyc6IGZhbHNlXG4gKiB9KSk7XG4gKlxuICogLy8gRW5zdXJlIGBiYXRjaExvZ2AgaXMgaW52b2tlZCBvbmNlIGFmdGVyIDEgc2Vjb25kIG9mIGRlYm91bmNlZCBjYWxscy5cbiAqIHZhciBkZWJvdW5jZWQgPSBfLmRlYm91bmNlKGJhdGNoTG9nLCAyNTAsIHsgJ21heFdhaXQnOiAxMDAwIH0pO1xuICogdmFyIHNvdXJjZSA9IG5ldyBFdmVudFNvdXJjZSgnL3N0cmVhbScpO1xuICogalF1ZXJ5KHNvdXJjZSkub24oJ21lc3NhZ2UnLCBkZWJvdW5jZWQpO1xuICpcbiAqIC8vIENhbmNlbCB0aGUgdHJhaWxpbmcgZGVib3VuY2VkIGludm9jYXRpb24uXG4gKiBqUXVlcnkod2luZG93KS5vbigncG9wc3RhdGUnLCBkZWJvdW5jZWQuY2FuY2VsKTtcbiAqL1xuZnVuY3Rpb24gZGVib3VuY2UoZnVuYywgd2FpdCwgb3B0aW9ucykge1xuICB2YXIgbGFzdEFyZ3MsXG4gICAgICBsYXN0VGhpcyxcbiAgICAgIG1heFdhaXQsXG4gICAgICByZXN1bHQsXG4gICAgICB0aW1lcklkLFxuICAgICAgbGFzdENhbGxUaW1lLFxuICAgICAgbGFzdEludm9rZVRpbWUgPSAwLFxuICAgICAgbGVhZGluZyA9IGZhbHNlLFxuICAgICAgbWF4aW5nID0gZmFsc2UsXG4gICAgICB0cmFpbGluZyA9IHRydWU7XG5cbiAgaWYgKHR5cGVvZiBmdW5jICE9ICdmdW5jdGlvbicpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKEZVTkNfRVJST1JfVEVYVCk7XG4gIH1cbiAgd2FpdCA9IHRvTnVtYmVyKHdhaXQpIHx8IDA7XG4gIGlmIChpc09iamVjdChvcHRpb25zKSkge1xuICAgIGxlYWRpbmcgPSAhIW9wdGlvbnMubGVhZGluZztcbiAgICBtYXhpbmcgPSAnbWF4V2FpdCcgaW4gb3B0aW9ucztcbiAgICBtYXhXYWl0ID0gbWF4aW5nID8gbmF0aXZlTWF4KHRvTnVtYmVyKG9wdGlvbnMubWF4V2FpdCkgfHwgMCwgd2FpdCkgOiBtYXhXYWl0O1xuICAgIHRyYWlsaW5nID0gJ3RyYWlsaW5nJyBpbiBvcHRpb25zID8gISFvcHRpb25zLnRyYWlsaW5nIDogdHJhaWxpbmc7XG4gIH1cblxuICBmdW5jdGlvbiBpbnZva2VGdW5jKHRpbWUpIHtcbiAgICB2YXIgYXJncyA9IGxhc3RBcmdzLFxuICAgICAgICB0aGlzQXJnID0gbGFzdFRoaXM7XG5cbiAgICBsYXN0QXJncyA9IGxhc3RUaGlzID0gdW5kZWZpbmVkO1xuICAgIGxhc3RJbnZva2VUaW1lID0gdGltZTtcbiAgICByZXN1bHQgPSBmdW5jLmFwcGx5KHRoaXNBcmcsIGFyZ3MpO1xuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cblxuICBmdW5jdGlvbiBsZWFkaW5nRWRnZSh0aW1lKSB7XG4gICAgLy8gUmVzZXQgYW55IGBtYXhXYWl0YCB0aW1lci5cbiAgICBsYXN0SW52b2tlVGltZSA9IHRpbWU7XG4gICAgLy8gU3RhcnQgdGhlIHRpbWVyIGZvciB0aGUgdHJhaWxpbmcgZWRnZS5cbiAgICB0aW1lcklkID0gc2V0VGltZW91dCh0aW1lckV4cGlyZWQsIHdhaXQpO1xuICAgIC8vIEludm9rZSB0aGUgbGVhZGluZyBlZGdlLlxuICAgIHJldHVybiBsZWFkaW5nID8gaW52b2tlRnVuYyh0aW1lKSA6IHJlc3VsdDtcbiAgfVxuXG4gIGZ1bmN0aW9uIHJlbWFpbmluZ1dhaXQodGltZSkge1xuICAgIHZhciB0aW1lU2luY2VMYXN0Q2FsbCA9IHRpbWUgLSBsYXN0Q2FsbFRpbWUsXG4gICAgICAgIHRpbWVTaW5jZUxhc3RJbnZva2UgPSB0aW1lIC0gbGFzdEludm9rZVRpbWUsXG4gICAgICAgIHRpbWVXYWl0aW5nID0gd2FpdCAtIHRpbWVTaW5jZUxhc3RDYWxsO1xuXG4gICAgcmV0dXJuIG1heGluZ1xuICAgICAgPyBuYXRpdmVNaW4odGltZVdhaXRpbmcsIG1heFdhaXQgLSB0aW1lU2luY2VMYXN0SW52b2tlKVxuICAgICAgOiB0aW1lV2FpdGluZztcbiAgfVxuXG4gIGZ1bmN0aW9uIHNob3VsZEludm9rZSh0aW1lKSB7XG4gICAgdmFyIHRpbWVTaW5jZUxhc3RDYWxsID0gdGltZSAtIGxhc3RDYWxsVGltZSxcbiAgICAgICAgdGltZVNpbmNlTGFzdEludm9rZSA9IHRpbWUgLSBsYXN0SW52b2tlVGltZTtcblxuICAgIC8vIEVpdGhlciB0aGlzIGlzIHRoZSBmaXJzdCBjYWxsLCBhY3Rpdml0eSBoYXMgc3RvcHBlZCBhbmQgd2UncmUgYXQgdGhlXG4gICAgLy8gdHJhaWxpbmcgZWRnZSwgdGhlIHN5c3RlbSB0aW1lIGhhcyBnb25lIGJhY2t3YXJkcyBhbmQgd2UncmUgdHJlYXRpbmdcbiAgICAvLyBpdCBhcyB0aGUgdHJhaWxpbmcgZWRnZSwgb3Igd2UndmUgaGl0IHRoZSBgbWF4V2FpdGAgbGltaXQuXG4gICAgcmV0dXJuIChsYXN0Q2FsbFRpbWUgPT09IHVuZGVmaW5lZCB8fCAodGltZVNpbmNlTGFzdENhbGwgPj0gd2FpdCkgfHxcbiAgICAgICh0aW1lU2luY2VMYXN0Q2FsbCA8IDApIHx8IChtYXhpbmcgJiYgdGltZVNpbmNlTGFzdEludm9rZSA+PSBtYXhXYWl0KSk7XG4gIH1cblxuICBmdW5jdGlvbiB0aW1lckV4cGlyZWQoKSB7XG4gICAgdmFyIHRpbWUgPSBub3coKTtcbiAgICBpZiAoc2hvdWxkSW52b2tlKHRpbWUpKSB7XG4gICAgICByZXR1cm4gdHJhaWxpbmdFZGdlKHRpbWUpO1xuICAgIH1cbiAgICAvLyBSZXN0YXJ0IHRoZSB0aW1lci5cbiAgICB0aW1lcklkID0gc2V0VGltZW91dCh0aW1lckV4cGlyZWQsIHJlbWFpbmluZ1dhaXQodGltZSkpO1xuICB9XG5cbiAgZnVuY3Rpb24gdHJhaWxpbmdFZGdlKHRpbWUpIHtcbiAgICB0aW1lcklkID0gdW5kZWZpbmVkO1xuXG4gICAgLy8gT25seSBpbnZva2UgaWYgd2UgaGF2ZSBgbGFzdEFyZ3NgIHdoaWNoIG1lYW5zIGBmdW5jYCBoYXMgYmVlblxuICAgIC8vIGRlYm91bmNlZCBhdCBsZWFzdCBvbmNlLlxuICAgIGlmICh0cmFpbGluZyAmJiBsYXN0QXJncykge1xuICAgICAgcmV0dXJuIGludm9rZUZ1bmModGltZSk7XG4gICAgfVxuICAgIGxhc3RBcmdzID0gbGFzdFRoaXMgPSB1bmRlZmluZWQ7XG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfVxuXG4gIGZ1bmN0aW9uIGNhbmNlbCgpIHtcbiAgICBpZiAodGltZXJJZCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICBjbGVhclRpbWVvdXQodGltZXJJZCk7XG4gICAgfVxuICAgIGxhc3RJbnZva2VUaW1lID0gMDtcbiAgICBsYXN0QXJncyA9IGxhc3RDYWxsVGltZSA9IGxhc3RUaGlzID0gdGltZXJJZCA9IHVuZGVmaW5lZDtcbiAgfVxuXG4gIGZ1bmN0aW9uIGZsdXNoKCkge1xuICAgIHJldHVybiB0aW1lcklkID09PSB1bmRlZmluZWQgPyByZXN1bHQgOiB0cmFpbGluZ0VkZ2Uobm93KCkpO1xuICB9XG5cbiAgZnVuY3Rpb24gZGVib3VuY2VkKCkge1xuICAgIHZhciB0aW1lID0gbm93KCksXG4gICAgICAgIGlzSW52b2tpbmcgPSBzaG91bGRJbnZva2UodGltZSk7XG5cbiAgICBsYXN0QXJncyA9IGFyZ3VtZW50cztcbiAgICBsYXN0VGhpcyA9IHRoaXM7XG4gICAgbGFzdENhbGxUaW1lID0gdGltZTtcblxuICAgIGlmIChpc0ludm9raW5nKSB7XG4gICAgICBpZiAodGltZXJJZCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHJldHVybiBsZWFkaW5nRWRnZShsYXN0Q2FsbFRpbWUpO1xuICAgICAgfVxuICAgICAgaWYgKG1heGluZykge1xuICAgICAgICAvLyBIYW5kbGUgaW52b2NhdGlvbnMgaW4gYSB0aWdodCBsb29wLlxuICAgICAgICB0aW1lcklkID0gc2V0VGltZW91dCh0aW1lckV4cGlyZWQsIHdhaXQpO1xuICAgICAgICByZXR1cm4gaW52b2tlRnVuYyhsYXN0Q2FsbFRpbWUpO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAodGltZXJJZCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICB0aW1lcklkID0gc2V0VGltZW91dCh0aW1lckV4cGlyZWQsIHdhaXQpO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xuICB9XG4gIGRlYm91bmNlZC5jYW5jZWwgPSBjYW5jZWw7XG4gIGRlYm91bmNlZC5mbHVzaCA9IGZsdXNoO1xuICByZXR1cm4gZGVib3VuY2VkO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IGRlYm91bmNlO1xuIiwidmFyIHJvb3QgPSByZXF1aXJlKCcuL19yb290Jyk7XG5cbi8qKlxuICogR2V0cyB0aGUgdGltZXN0YW1wIG9mIHRoZSBudW1iZXIgb2YgbWlsbGlzZWNvbmRzIHRoYXQgaGF2ZSBlbGFwc2VkIHNpbmNlXG4gKiB0aGUgVW5peCBlcG9jaCAoMSBKYW51YXJ5IDE5NzAgMDA6MDA6MDAgVVRDKS5cbiAqXG4gKiBAc3RhdGljXG4gKiBAbWVtYmVyT2YgX1xuICogQHNpbmNlIDIuNC4wXG4gKiBAY2F0ZWdvcnkgRGF0ZVxuICogQHJldHVybnMge251bWJlcn0gUmV0dXJucyB0aGUgdGltZXN0YW1wLlxuICogQGV4YW1wbGVcbiAqXG4gKiBfLmRlZmVyKGZ1bmN0aW9uKHN0YW1wKSB7XG4gKiAgIGNvbnNvbGUubG9nKF8ubm93KCkgLSBzdGFtcCk7XG4gKiB9LCBfLm5vdygpKTtcbiAqIC8vID0+IExvZ3MgdGhlIG51bWJlciBvZiBtaWxsaXNlY29uZHMgaXQgdG9vayBmb3IgdGhlIGRlZmVycmVkIGludm9jYXRpb24uXG4gKi9cbnZhciBub3cgPSBmdW5jdGlvbigpIHtcbiAgcmV0dXJuIHJvb3QuRGF0ZS5ub3coKTtcbn07XG5cbm1vZHVsZS5leHBvcnRzID0gbm93O1xuIiwidmFyIGlzT2JqZWN0ID0gcmVxdWlyZSgnLi9pc09iamVjdCcpLFxuICAgIGlzU3ltYm9sID0gcmVxdWlyZSgnLi9pc1N5bWJvbCcpO1xuXG4vKiogVXNlZCBhcyByZWZlcmVuY2VzIGZvciB2YXJpb3VzIGBOdW1iZXJgIGNvbnN0YW50cy4gKi9cbnZhciBOQU4gPSAwIC8gMDtcblxuLyoqIFVzZWQgdG8gbWF0Y2ggbGVhZGluZyBhbmQgdHJhaWxpbmcgd2hpdGVzcGFjZS4gKi9cbnZhciByZVRyaW0gPSAvXlxccyt8XFxzKyQvZztcblxuLyoqIFVzZWQgdG8gZGV0ZWN0IGJhZCBzaWduZWQgaGV4YWRlY2ltYWwgc3RyaW5nIHZhbHVlcy4gKi9cbnZhciByZUlzQmFkSGV4ID0gL15bLStdMHhbMC05YS1mXSskL2k7XG5cbi8qKiBVc2VkIHRvIGRldGVjdCBiaW5hcnkgc3RyaW5nIHZhbHVlcy4gKi9cbnZhciByZUlzQmluYXJ5ID0gL14wYlswMV0rJC9pO1xuXG4vKiogVXNlZCB0byBkZXRlY3Qgb2N0YWwgc3RyaW5nIHZhbHVlcy4gKi9cbnZhciByZUlzT2N0YWwgPSAvXjBvWzAtN10rJC9pO1xuXG4vKiogQnVpbHQtaW4gbWV0aG9kIHJlZmVyZW5jZXMgd2l0aG91dCBhIGRlcGVuZGVuY3kgb24gYHJvb3RgLiAqL1xudmFyIGZyZWVQYXJzZUludCA9IHBhcnNlSW50O1xuXG4vKipcbiAqIENvbnZlcnRzIGB2YWx1ZWAgdG8gYSBudW1iZXIuXG4gKlxuICogQHN0YXRpY1xuICogQG1lbWJlck9mIF9cbiAqIEBzaW5jZSA0LjAuMFxuICogQGNhdGVnb3J5IExhbmdcbiAqIEBwYXJhbSB7Kn0gdmFsdWUgVGhlIHZhbHVlIHRvIHByb2Nlc3MuXG4gKiBAcmV0dXJucyB7bnVtYmVyfSBSZXR1cm5zIHRoZSBudW1iZXIuXG4gKiBAZXhhbXBsZVxuICpcbiAqIF8udG9OdW1iZXIoMy4yKTtcbiAqIC8vID0+IDMuMlxuICpcbiAqIF8udG9OdW1iZXIoTnVtYmVyLk1JTl9WQUxVRSk7XG4gKiAvLyA9PiA1ZS0zMjRcbiAqXG4gKiBfLnRvTnVtYmVyKEluZmluaXR5KTtcbiAqIC8vID0+IEluZmluaXR5XG4gKlxuICogXy50b051bWJlcignMy4yJyk7XG4gKiAvLyA9PiAzLjJcbiAqL1xuZnVuY3Rpb24gdG9OdW1iZXIodmFsdWUpIHtcbiAgaWYgKHR5cGVvZiB2YWx1ZSA9PSAnbnVtYmVyJykge1xuICAgIHJldHVybiB2YWx1ZTtcbiAgfVxuICBpZiAoaXNTeW1ib2wodmFsdWUpKSB7XG4gICAgcmV0dXJuIE5BTjtcbiAgfVxuICBpZiAoaXNPYmplY3QodmFsdWUpKSB7XG4gICAgdmFyIG90aGVyID0gdHlwZW9mIHZhbHVlLnZhbHVlT2YgPT0gJ2Z1bmN0aW9uJyA/IHZhbHVlLnZhbHVlT2YoKSA6IHZhbHVlO1xuICAgIHZhbHVlID0gaXNPYmplY3Qob3RoZXIpID8gKG90aGVyICsgJycpIDogb3RoZXI7XG4gIH1cbiAgaWYgKHR5cGVvZiB2YWx1ZSAhPSAnc3RyaW5nJykge1xuICAgIHJldHVybiB2YWx1ZSA9PT0gMCA/IHZhbHVlIDogK3ZhbHVlO1xuICB9XG4gIHZhbHVlID0gdmFsdWUucmVwbGFjZShyZVRyaW0sICcnKTtcbiAgdmFyIGlzQmluYXJ5ID0gcmVJc0JpbmFyeS50ZXN0KHZhbHVlKTtcbiAgcmV0dXJuIChpc0JpbmFyeSB8fCByZUlzT2N0YWwudGVzdCh2YWx1ZSkpXG4gICAgPyBmcmVlUGFyc2VJbnQodmFsdWUuc2xpY2UoMiksIGlzQmluYXJ5ID8gMiA6IDgpXG4gICAgOiAocmVJc0JhZEhleC50ZXN0KHZhbHVlKSA/IE5BTiA6ICt2YWx1ZSk7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gdG9OdW1iZXI7XG4iLCJleHBvcnQgZGVmYXVsdCB7XG4gIHRvZGF5OiAnVG9kYXknLFxuICBub3c6ICdOb3cnLFxuICBiYWNrVG9Ub2RheTogJ0JhY2sgdG8gdG9kYXknLFxuICBvazogJ09rJyxcbiAgY2xlYXI6ICdDbGVhcicsXG4gIG1vbnRoOiAnTW9udGgnLFxuICB5ZWFyOiAnWWVhcicsXG4gIHRpbWVTZWxlY3Q6ICdTZWxlY3QgdGltZScsXG4gIGRhdGVTZWxlY3Q6ICdTZWxlY3QgZGF0ZScsXG4gIG1vbnRoU2VsZWN0OiAnQ2hvb3NlIGEgbW9udGgnLFxuICB5ZWFyU2VsZWN0OiAnQ2hvb3NlIGEgeWVhcicsXG4gIGRlY2FkZVNlbGVjdDogJ0Nob29zZSBhIGRlY2FkZScsXG4gIHllYXJGb3JtYXQ6ICdZWVlZJyxcbiAgZGF0ZUZvcm1hdDogJ00vRC9ZWVlZJyxcbiAgZGF5Rm9ybWF0OiAnRCcsXG4gIGRhdGVUaW1lRm9ybWF0OiAnTS9EL1lZWVkgSEg6bW06c3MnLFxuICBtb250aEJlZm9yZVllYXI6IHRydWUsXG4gIHByZXZpb3VzTW9udGg6ICdQcmV2aW91cyBtb250aCAoUGFnZVVwKScsXG4gIG5leHRNb250aDogJ05leHQgbW9udGggKFBhZ2VEb3duKScsXG4gIHByZXZpb3VzWWVhcjogJ0xhc3QgeWVhciAoQ29udHJvbCArIGxlZnQpJyxcbiAgbmV4dFllYXI6ICdOZXh0IHllYXIgKENvbnRyb2wgKyByaWdodCknLFxuICBwcmV2aW91c0RlY2FkZTogJ0xhc3QgZGVjYWRlJyxcbiAgbmV4dERlY2FkZTogJ05leHQgZGVjYWRlJyxcbiAgcHJldmlvdXNDZW50dXJ5OiAnTGFzdCBjZW50dXJ5JyxcbiAgbmV4dENlbnR1cnk6ICdOZXh0IGNlbnR1cnknXG59OyIsImV4cG9ydCBkZWZhdWx0IHtcbiAgWkVSTzogNDgsXG4gIE5JTkU6IDU3LFxuXG4gIE5VTVBBRF9aRVJPOiA5NixcbiAgTlVNUEFEX05JTkU6IDEwNSxcblxuICBCQUNLU1BBQ0U6IDgsXG4gIERFTEVURTogNDYsXG4gIEVOVEVSOiAxMyxcblxuICBBUlJPV19VUDogMzgsXG4gIEFSUk9XX0RPV046IDQwXG59OyIsImltcG9ydCBfY2xhc3NDYWxsQ2hlY2sgZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL2NsYXNzQ2FsbENoZWNrJztcbmltcG9ydCBfY3JlYXRlQ2xhc3MgZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL2NyZWF0ZUNsYXNzJztcbmltcG9ydCBfcG9zc2libGVDb25zdHJ1Y3RvclJldHVybiBmcm9tICdiYWJlbC1ydW50aW1lL2hlbHBlcnMvcG9zc2libGVDb25zdHJ1Y3RvclJldHVybic7XG5pbXBvcnQgX2luaGVyaXRzIGZyb20gJ2JhYmVsLXJ1bnRpbWUvaGVscGVycy9pbmhlcml0cyc7XG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcbmltcG9ydCBLRVlDT0RFIGZyb20gJy4vS2V5Q29kZSc7XG5cbnZhciBPcHRpb25zID0gZnVuY3Rpb24gKF9SZWFjdCRDb21wb25lbnQpIHtcbiAgX2luaGVyaXRzKE9wdGlvbnMsIF9SZWFjdCRDb21wb25lbnQpO1xuXG4gIGZ1bmN0aW9uIE9wdGlvbnMocHJvcHMpIHtcbiAgICBfY2xhc3NDYWxsQ2hlY2sodGhpcywgT3B0aW9ucyk7XG5cbiAgICB2YXIgX3RoaXMgPSBfcG9zc2libGVDb25zdHJ1Y3RvclJldHVybih0aGlzLCAoT3B0aW9ucy5fX3Byb3RvX18gfHwgT2JqZWN0LmdldFByb3RvdHlwZU9mKE9wdGlvbnMpKS5jYWxsKHRoaXMsIHByb3BzKSk7XG5cbiAgICBfdGhpcy5idWlsZE9wdGlvblRleHQgPSBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgIHJldHVybiB2YWx1ZSArICcgJyArIF90aGlzLnByb3BzLmxvY2FsZS5pdGVtc19wZXJfcGFnZTtcbiAgICB9O1xuXG4gICAgX3RoaXMuY2hhbmdlU2l6ZSA9IGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgX3RoaXMucHJvcHMuY2hhbmdlU2l6ZShOdW1iZXIodmFsdWUpKTtcbiAgICB9O1xuXG4gICAgX3RoaXMuaGFuZGxlQ2hhbmdlID0gZnVuY3Rpb24gKGUpIHtcbiAgICAgIF90aGlzLnNldFN0YXRlKHtcbiAgICAgICAgZ29JbnB1dFRleHQ6IGUudGFyZ2V0LnZhbHVlXG4gICAgICB9KTtcbiAgICB9O1xuXG4gICAgX3RoaXMuZ28gPSBmdW5jdGlvbiAoZSkge1xuICAgICAgdmFyIHZhbCA9IF90aGlzLnN0YXRlLmdvSW5wdXRUZXh0O1xuICAgICAgaWYgKHZhbCA9PT0gJycpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgdmFsID0gaXNOYU4odmFsKSA/IF90aGlzLnByb3BzLmN1cnJlbnQgOiBOdW1iZXIodmFsKTtcbiAgICAgIGlmIChlLmtleUNvZGUgPT09IEtFWUNPREUuRU5URVIgfHwgZS50eXBlID09PSAnY2xpY2snKSB7XG4gICAgICAgIF90aGlzLnNldFN0YXRlKHtcbiAgICAgICAgICBnb0lucHV0VGV4dDogJydcbiAgICAgICAgfSk7XG4gICAgICAgIF90aGlzLnByb3BzLnF1aWNrR28odmFsKTtcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgX3RoaXMuc3RhdGUgPSB7XG4gICAgICBnb0lucHV0VGV4dDogJydcbiAgICB9O1xuICAgIHJldHVybiBfdGhpcztcbiAgfVxuXG4gIF9jcmVhdGVDbGFzcyhPcHRpb25zLCBbe1xuICAgIGtleTogJ3JlbmRlcicsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHJlbmRlcigpIHtcbiAgICAgIHZhciBwcm9wcyA9IHRoaXMucHJvcHM7XG4gICAgICB2YXIgc3RhdGUgPSB0aGlzLnN0YXRlO1xuICAgICAgdmFyIGxvY2FsZSA9IHByb3BzLmxvY2FsZTtcbiAgICAgIHZhciBwcmVmaXhDbHMgPSBwcm9wcy5yb290UHJlZml4Q2xzICsgJy1vcHRpb25zJztcbiAgICAgIHZhciBjaGFuZ2VTaXplID0gcHJvcHMuY2hhbmdlU2l6ZTtcbiAgICAgIHZhciBxdWlja0dvID0gcHJvcHMucXVpY2tHbztcbiAgICAgIHZhciBnb0J1dHRvbiA9IHByb3BzLmdvQnV0dG9uO1xuICAgICAgdmFyIGJ1aWxkT3B0aW9uVGV4dCA9IHByb3BzLmJ1aWxkT3B0aW9uVGV4dCB8fCB0aGlzLmJ1aWxkT3B0aW9uVGV4dDtcbiAgICAgIHZhciBTZWxlY3QgPSBwcm9wcy5zZWxlY3RDb21wb25lbnRDbGFzcztcbiAgICAgIHZhciBjaGFuZ2VTZWxlY3QgPSBudWxsO1xuICAgICAgdmFyIGdvSW5wdXQgPSBudWxsO1xuICAgICAgdmFyIGdvdG9CdXR0b24gPSBudWxsO1xuXG4gICAgICBpZiAoIShjaGFuZ2VTaXplIHx8IHF1aWNrR28pKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgICAgfVxuXG4gICAgICBpZiAoY2hhbmdlU2l6ZSAmJiBTZWxlY3QpIHtcbiAgICAgICAgdmFyIE9wdGlvbiA9IFNlbGVjdC5PcHRpb247XG4gICAgICAgIHZhciBwYWdlU2l6ZSA9IHByb3BzLnBhZ2VTaXplIHx8IHByb3BzLnBhZ2VTaXplT3B0aW9uc1swXTtcbiAgICAgICAgdmFyIG9wdGlvbnMgPSBwcm9wcy5wYWdlU2l6ZU9wdGlvbnMubWFwKGZ1bmN0aW9uIChvcHQsIGkpIHtcbiAgICAgICAgICByZXR1cm4gUmVhY3QuY3JlYXRlRWxlbWVudChcbiAgICAgICAgICAgIE9wdGlvbixcbiAgICAgICAgICAgIHsga2V5OiBpLCB2YWx1ZTogb3B0IH0sXG4gICAgICAgICAgICBidWlsZE9wdGlvblRleHQob3B0KVxuICAgICAgICAgICk7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIGNoYW5nZVNlbGVjdCA9IFJlYWN0LmNyZWF0ZUVsZW1lbnQoXG4gICAgICAgICAgU2VsZWN0LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIHByZWZpeENsczogcHJvcHMuc2VsZWN0UHJlZml4Q2xzLFxuICAgICAgICAgICAgc2hvd1NlYXJjaDogZmFsc2UsXG4gICAgICAgICAgICBjbGFzc05hbWU6IHByZWZpeENscyArICctc2l6ZS1jaGFuZ2VyJyxcbiAgICAgICAgICAgIG9wdGlvbkxhYmVsUHJvcDogJ2NoaWxkcmVuJyxcbiAgICAgICAgICAgIGRyb3Bkb3duTWF0Y2hTZWxlY3RXaWR0aDogZmFsc2UsXG4gICAgICAgICAgICB2YWx1ZTogcGFnZVNpemUudG9TdHJpbmcoKSxcbiAgICAgICAgICAgIG9uQ2hhbmdlOiB0aGlzLmNoYW5nZVNpemUsXG4gICAgICAgICAgICBnZXRQb3B1cENvbnRhaW5lcjogZnVuY3Rpb24gZ2V0UG9wdXBDb250YWluZXIodHJpZ2dlck5vZGUpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIHRyaWdnZXJOb2RlLnBhcmVudE5vZGU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSxcbiAgICAgICAgICBvcHRpb25zXG4gICAgICAgICk7XG4gICAgICB9XG5cbiAgICAgIGlmIChxdWlja0dvKSB7XG4gICAgICAgIGlmIChnb0J1dHRvbikge1xuICAgICAgICAgIGlmICh0eXBlb2YgZ29CdXR0b24gPT09ICdib29sZWFuJykge1xuICAgICAgICAgICAgZ290b0J1dHRvbiA9IFJlYWN0LmNyZWF0ZUVsZW1lbnQoXG4gICAgICAgICAgICAgICdidXR0b24nLFxuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgdHlwZTogJ2J1dHRvbicsXG4gICAgICAgICAgICAgICAgb25DbGljazogdGhpcy5nbyxcbiAgICAgICAgICAgICAgICBvbktleVVwOiB0aGlzLmdvXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIGxvY2FsZS5qdW1wX3RvX2NvbmZpcm1cbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGdvdG9CdXR0b24gPSBSZWFjdC5jcmVhdGVFbGVtZW50KFxuICAgICAgICAgICAgICAnc3BhbicsXG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBvbkNsaWNrOiB0aGlzLmdvLFxuICAgICAgICAgICAgICAgIG9uS2V5VXA6IHRoaXMuZ29cbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgZ29CdXR0b25cbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGdvSW5wdXQgPSBSZWFjdC5jcmVhdGVFbGVtZW50KFxuICAgICAgICAgICdkaXYnLFxuICAgICAgICAgIHsgY2xhc3NOYW1lOiBwcmVmaXhDbHMgKyAnLXF1aWNrLWp1bXBlcicgfSxcbiAgICAgICAgICBsb2NhbGUuanVtcF90byxcbiAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KCdpbnB1dCcsIHtcbiAgICAgICAgICAgIHR5cGU6ICd0ZXh0JyxcbiAgICAgICAgICAgIHZhbHVlOiBzdGF0ZS5nb0lucHV0VGV4dCxcbiAgICAgICAgICAgIG9uQ2hhbmdlOiB0aGlzLmhhbmRsZUNoYW5nZSxcbiAgICAgICAgICAgIG9uS2V5VXA6IHRoaXMuZ29cbiAgICAgICAgICB9KSxcbiAgICAgICAgICBsb2NhbGUucGFnZSxcbiAgICAgICAgICBnb3RvQnV0dG9uXG4gICAgICAgICk7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiBSZWFjdC5jcmVhdGVFbGVtZW50KFxuICAgICAgICAnbGknLFxuICAgICAgICB7IGNsYXNzTmFtZTogJycgKyBwcmVmaXhDbHMgfSxcbiAgICAgICAgY2hhbmdlU2VsZWN0LFxuICAgICAgICBnb0lucHV0XG4gICAgICApO1xuICAgIH1cbiAgfV0pO1xuXG4gIHJldHVybiBPcHRpb25zO1xufShSZWFjdC5Db21wb25lbnQpO1xuXG5PcHRpb25zLnByb3BUeXBlcyA9IHtcbiAgY2hhbmdlU2l6ZTogUHJvcFR5cGVzLmZ1bmMsXG4gIHF1aWNrR286IFByb3BUeXBlcy5mdW5jLFxuICBzZWxlY3RDb21wb25lbnRDbGFzczogUHJvcFR5cGVzLmZ1bmMsXG4gIGN1cnJlbnQ6IFByb3BUeXBlcy5udW1iZXIsXG4gIHBhZ2VTaXplT3B0aW9uczogUHJvcFR5cGVzLmFycmF5T2YoUHJvcFR5cGVzLnN0cmluZyksXG4gIHBhZ2VTaXplOiBQcm9wVHlwZXMubnVtYmVyLFxuICBidWlsZE9wdGlvblRleHQ6IFByb3BUeXBlcy5mdW5jLFxuICBsb2NhbGU6IFByb3BUeXBlcy5vYmplY3Rcbn07XG5PcHRpb25zLmRlZmF1bHRQcm9wcyA9IHtcbiAgcGFnZVNpemVPcHRpb25zOiBbJzEwJywgJzIwJywgJzMwJywgJzQwJ11cbn07XG5cblxuZXhwb3J0IGRlZmF1bHQgT3B0aW9uczsiLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcblxudmFyIFBhZ2VyID0gZnVuY3Rpb24gUGFnZXIocHJvcHMpIHtcbiAgdmFyIHByZWZpeENscyA9IHByb3BzLnJvb3RQcmVmaXhDbHMgKyAnLWl0ZW0nO1xuICB2YXIgY2xzID0gcHJlZml4Q2xzICsgJyAnICsgcHJlZml4Q2xzICsgJy0nICsgcHJvcHMucGFnZTtcblxuICBpZiAocHJvcHMuYWN0aXZlKSB7XG4gICAgY2xzID0gY2xzICsgJyAnICsgcHJlZml4Q2xzICsgJy1hY3RpdmUnO1xuICB9XG5cbiAgaWYgKHByb3BzLmNsYXNzTmFtZSkge1xuICAgIGNscyA9IGNscyArICcgJyArIHByb3BzLmNsYXNzTmFtZTtcbiAgfVxuXG4gIHZhciBoYW5kbGVDbGljayA9IGZ1bmN0aW9uIGhhbmRsZUNsaWNrKCkge1xuICAgIHByb3BzLm9uQ2xpY2socHJvcHMucGFnZSk7XG4gIH07XG5cbiAgdmFyIGhhbmRsZUtleVByZXNzID0gZnVuY3Rpb24gaGFuZGxlS2V5UHJlc3MoZSkge1xuICAgIHByb3BzLm9uS2V5UHJlc3MoZSwgcHJvcHMub25DbGljaywgcHJvcHMucGFnZSk7XG4gIH07XG5cbiAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXG4gICAgJ2xpJyxcbiAgICB7XG4gICAgICB0aXRsZTogcHJvcHMuc2hvd1RpdGxlID8gcHJvcHMucGFnZSA6IG51bGwsXG4gICAgICBjbGFzc05hbWU6IGNscyxcbiAgICAgIG9uQ2xpY2s6IGhhbmRsZUNsaWNrLFxuICAgICAgb25LZXlQcmVzczogaGFuZGxlS2V5UHJlc3MsXG4gICAgICB0YWJJbmRleDogJzAnXG4gICAgfSxcbiAgICBwcm9wcy5pdGVtUmVuZGVyKHByb3BzLnBhZ2UsICdwYWdlJywgUmVhY3QuY3JlYXRlRWxlbWVudChcbiAgICAgICdhJyxcbiAgICAgIG51bGwsXG4gICAgICBwcm9wcy5wYWdlXG4gICAgKSlcbiAgKTtcbn07XG5cblBhZ2VyLnByb3BUeXBlcyA9IHtcbiAgcGFnZTogUHJvcFR5cGVzLm51bWJlcixcbiAgYWN0aXZlOiBQcm9wVHlwZXMuYm9vbCxcbiAgbGFzdDogUHJvcFR5cGVzLmJvb2wsXG4gIGxvY2FsZTogUHJvcFR5cGVzLm9iamVjdCxcbiAgY2xhc3NOYW1lOiBQcm9wVHlwZXMuc3RyaW5nLFxuICBzaG93VGl0bGU6IFByb3BUeXBlcy5ib29sLFxuICByb290UHJlZml4Q2xzOiBQcm9wVHlwZXMuc3RyaW5nLFxuICBvbkNsaWNrOiBQcm9wVHlwZXMuZnVuYyxcbiAgb25LZXlQcmVzczogUHJvcFR5cGVzLmZ1bmMsXG4gIGl0ZW1SZW5kZXI6IFByb3BUeXBlcy5mdW5jXG59O1xuXG5leHBvcnQgZGVmYXVsdCBQYWdlcjsiLCJpbXBvcnQgX2NsYXNzQ2FsbENoZWNrIGZyb20gJ2JhYmVsLXJ1bnRpbWUvaGVscGVycy9jbGFzc0NhbGxDaGVjayc7XG5pbXBvcnQgX2NyZWF0ZUNsYXNzIGZyb20gJ2JhYmVsLXJ1bnRpbWUvaGVscGVycy9jcmVhdGVDbGFzcyc7XG5pbXBvcnQgX3Bvc3NpYmxlQ29uc3RydWN0b3JSZXR1cm4gZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL3Bvc3NpYmxlQ29uc3RydWN0b3JSZXR1cm4nO1xuaW1wb3J0IF9pbmhlcml0cyBmcm9tICdiYWJlbC1ydW50aW1lL2hlbHBlcnMvaW5oZXJpdHMnO1xuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcyc7XG5pbXBvcnQgUGFnZXIgZnJvbSAnLi9QYWdlcic7XG5pbXBvcnQgT3B0aW9ucyBmcm9tICcuL09wdGlvbnMnO1xuaW1wb3J0IEtFWUNPREUgZnJvbSAnLi9LZXlDb2RlJztcbmltcG9ydCBMT0NBTEUgZnJvbSAnLi9sb2NhbGUvemhfQ04nO1xuXG5mdW5jdGlvbiBub29wKCkge31cblxuZnVuY3Rpb24gaXNJbnRlZ2VyKHZhbHVlKSB7XG4gIHJldHVybiB0eXBlb2YgdmFsdWUgPT09ICdudW1iZXInICYmIGlzRmluaXRlKHZhbHVlKSAmJiBNYXRoLmZsb29yKHZhbHVlKSA9PT0gdmFsdWU7XG59XG5cbmZ1bmN0aW9uIGRlZmF1bHRJdGVtUmVuZGVyKHBhZ2UsIHR5cGUsIGVsZW1lbnQpIHtcbiAgcmV0dXJuIGVsZW1lbnQ7XG59XG5cbnZhciBQYWdpbmF0aW9uID0gZnVuY3Rpb24gKF9SZWFjdCRDb21wb25lbnQpIHtcbiAgX2luaGVyaXRzKFBhZ2luYXRpb24sIF9SZWFjdCRDb21wb25lbnQpO1xuXG4gIGZ1bmN0aW9uIFBhZ2luYXRpb24ocHJvcHMpIHtcbiAgICBfY2xhc3NDYWxsQ2hlY2sodGhpcywgUGFnaW5hdGlvbik7XG5cbiAgICB2YXIgX3RoaXMgPSBfcG9zc2libGVDb25zdHJ1Y3RvclJldHVybih0aGlzLCAoUGFnaW5hdGlvbi5fX3Byb3RvX18gfHwgT2JqZWN0LmdldFByb3RvdHlwZU9mKFBhZ2luYXRpb24pKS5jYWxsKHRoaXMsIHByb3BzKSk7XG5cbiAgICBfaW5pdGlhbGlzZVByb3BzLmNhbGwoX3RoaXMpO1xuXG4gICAgdmFyIGhhc09uQ2hhbmdlID0gcHJvcHMub25DaGFuZ2UgIT09IG5vb3A7XG4gICAgdmFyIGhhc0N1cnJlbnQgPSAnY3VycmVudCcgaW4gcHJvcHM7XG4gICAgaWYgKGhhc0N1cnJlbnQgJiYgIWhhc09uQ2hhbmdlKSB7XG4gICAgICBjb25zb2xlLndhcm4oJ1dhcm5pbmc6IFlvdSBwcm92aWRlZCBhIGBjdXJyZW50YCBwcm9wIHRvIGEgUGFnaW5hdGlvbiBjb21wb25lbnQgd2l0aG91dCBhbiBgb25DaGFuZ2VgIGhhbmRsZXIuIFRoaXMgd2lsbCByZW5kZXIgYSByZWFkLW9ubHkgY29tcG9uZW50LicpOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lXG4gICAgfVxuXG4gICAgdmFyIGN1cnJlbnQgPSBwcm9wcy5kZWZhdWx0Q3VycmVudDtcbiAgICBpZiAoJ2N1cnJlbnQnIGluIHByb3BzKSB7XG4gICAgICBjdXJyZW50ID0gcHJvcHMuY3VycmVudDtcbiAgICB9XG5cbiAgICB2YXIgcGFnZVNpemUgPSBwcm9wcy5kZWZhdWx0UGFnZVNpemU7XG4gICAgaWYgKCdwYWdlU2l6ZScgaW4gcHJvcHMpIHtcbiAgICAgIHBhZ2VTaXplID0gcHJvcHMucGFnZVNpemU7XG4gICAgfVxuXG4gICAgX3RoaXMuc3RhdGUgPSB7XG4gICAgICBjdXJyZW50OiBjdXJyZW50LFxuICAgICAgY3VycmVudElucHV0VmFsdWU6IGN1cnJlbnQsXG4gICAgICBwYWdlU2l6ZTogcGFnZVNpemVcbiAgICB9O1xuICAgIHJldHVybiBfdGhpcztcbiAgfVxuXG4gIF9jcmVhdGVDbGFzcyhQYWdpbmF0aW9uLCBbe1xuICAgIGtleTogJ2NvbXBvbmVudFdpbGxSZWNlaXZlUHJvcHMnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBjb21wb25lbnRXaWxsUmVjZWl2ZVByb3BzKG5leHRQcm9wcykge1xuICAgICAgaWYgKCdjdXJyZW50JyBpbiBuZXh0UHJvcHMpIHtcbiAgICAgICAgdGhpcy5zZXRTdGF0ZSh7XG4gICAgICAgICAgY3VycmVudDogbmV4dFByb3BzLmN1cnJlbnQsXG4gICAgICAgICAgY3VycmVudElucHV0VmFsdWU6IG5leHRQcm9wcy5jdXJyZW50XG4gICAgICAgIH0pO1xuICAgICAgfVxuXG4gICAgICBpZiAoJ3BhZ2VTaXplJyBpbiBuZXh0UHJvcHMpIHtcbiAgICAgICAgdmFyIG5ld1N0YXRlID0ge307XG4gICAgICAgIHZhciBjdXJyZW50ID0gdGhpcy5zdGF0ZS5jdXJyZW50O1xuICAgICAgICB2YXIgbmV3Q3VycmVudCA9IHRoaXMuY2FsY3VsYXRlUGFnZShuZXh0UHJvcHMucGFnZVNpemUpO1xuICAgICAgICBjdXJyZW50ID0gY3VycmVudCA+IG5ld0N1cnJlbnQgPyBuZXdDdXJyZW50IDogY3VycmVudDtcbiAgICAgICAgaWYgKCEoJ2N1cnJlbnQnIGluIG5leHRQcm9wcykpIHtcbiAgICAgICAgICBuZXdTdGF0ZS5jdXJyZW50ID0gY3VycmVudDtcbiAgICAgICAgICBuZXdTdGF0ZS5jdXJyZW50SW5wdXRWYWx1ZSA9IGN1cnJlbnQ7XG4gICAgICAgIH1cbiAgICAgICAgbmV3U3RhdGUucGFnZVNpemUgPSBuZXh0UHJvcHMucGFnZVNpemU7XG4gICAgICAgIHRoaXMuc2V0U3RhdGUobmV3U3RhdGUpO1xuICAgICAgfVxuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ2NvbXBvbmVudERpZFVwZGF0ZScsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGNvbXBvbmVudERpZFVwZGF0ZShwcmV2UHJvcHMsIHByZXZTdGF0ZSkge1xuICAgICAgLy8gV2hlbiBjdXJyZW50IHBhZ2UgY2hhbmdlLCBmaXggZm9jdXNlZCBzdHlsZSBvZiBwcmV2IGl0ZW1cbiAgICAgIC8vIEEgaGFja3kgc29sdXRpb24gb2YgaHR0cHM6Ly9naXRodWIuY29tL2FudC1kZXNpZ24vYW50LWRlc2lnbi9pc3N1ZXMvODk0OFxuICAgICAgdmFyIHByZWZpeENscyA9IHRoaXMucHJvcHMucHJlZml4Q2xzO1xuXG4gICAgICBpZiAocHJldlN0YXRlLmN1cnJlbnQgIT09IHRoaXMuc3RhdGUuY3VycmVudCAmJiB0aGlzLnBhZ2luYXRpb25Ob2RlKSB7XG4gICAgICAgIHZhciBsYXN0Q3VycmVudE5vZGUgPSB0aGlzLnBhZ2luYXRpb25Ob2RlLnF1ZXJ5U2VsZWN0b3IoJy4nICsgcHJlZml4Q2xzICsgJy1pdGVtLScgKyBwcmV2U3RhdGUuY3VycmVudCk7XG4gICAgICAgIGlmIChsYXN0Q3VycmVudE5vZGUgJiYgZG9jdW1lbnQuYWN0aXZlRWxlbWVudCA9PT0gbGFzdEN1cnJlbnROb2RlKSB7XG4gICAgICAgICAgbGFzdEN1cnJlbnROb2RlLmJsdXIoKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ2dldEp1bXBQcmV2UGFnZScsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGdldEp1bXBQcmV2UGFnZSgpIHtcbiAgICAgIHJldHVybiBNYXRoLm1heCgxLCB0aGlzLnN0YXRlLmN1cnJlbnQgLSAodGhpcy5wcm9wcy5zaG93TGVzc0l0ZW1zID8gMyA6IDUpKTtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdnZXRKdW1wTmV4dFBhZ2UnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBnZXRKdW1wTmV4dFBhZ2UoKSB7XG4gICAgICByZXR1cm4gTWF0aC5taW4odGhpcy5jYWxjdWxhdGVQYWdlKCksIHRoaXMuc3RhdGUuY3VycmVudCArICh0aGlzLnByb3BzLnNob3dMZXNzSXRlbXMgPyAzIDogNSkpO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ2dldEp1bXBQcmV2UGFnZScsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIGdldEp1bXBQcmV2UGFnZSgpIHtcbiAgICAgIHJldHVybiBNYXRoLm1heCgxLCB0aGlzLnN0YXRlLmN1cnJlbnQgLSAodGhpcy5wcm9wcy5zaG93TGVzc0l0ZW1zID8gMyA6IDUpKTtcbiAgICB9XG4gIH0sIHtcbiAgICBrZXk6ICdnZXRKdW1wTmV4dFBhZ2UnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBnZXRKdW1wTmV4dFBhZ2UoKSB7XG4gICAgICByZXR1cm4gTWF0aC5taW4odGhpcy5jYWxjdWxhdGVQYWdlKCksIHRoaXMuc3RhdGUuY3VycmVudCArICh0aGlzLnByb3BzLnNob3dMZXNzSXRlbXMgPyAzIDogNSkpO1xuICAgIH1cbiAgfSwge1xuICAgIGtleTogJ3JlbmRlcicsXG4gICAgdmFsdWU6IGZ1bmN0aW9uIHJlbmRlcigpIHtcbiAgICAgIC8vIFdoZW4gaGlkZU9uU2luZ2xlUGFnZSBpcyB0cnVlIGFuZCB0aGVyZSBpcyBvbmx5IDEgcGFnZSwgaGlkZSB0aGUgcGFnZXJcbiAgICAgIGlmICh0aGlzLnByb3BzLmhpZGVPblNpbmdsZVBhZ2UgPT09IHRydWUgJiYgdGhpcy5wcm9wcy50b3RhbCA8PSB0aGlzLnN0YXRlLnBhZ2VTaXplKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgICAgfVxuXG4gICAgICB2YXIgcHJvcHMgPSB0aGlzLnByb3BzO1xuICAgICAgdmFyIGxvY2FsZSA9IHByb3BzLmxvY2FsZTtcblxuICAgICAgdmFyIHByZWZpeENscyA9IHByb3BzLnByZWZpeENscztcbiAgICAgIHZhciBhbGxQYWdlcyA9IHRoaXMuY2FsY3VsYXRlUGFnZSgpO1xuICAgICAgdmFyIHBhZ2VyTGlzdCA9IFtdO1xuICAgICAgdmFyIGp1bXBQcmV2ID0gbnVsbDtcbiAgICAgIHZhciBqdW1wTmV4dCA9IG51bGw7XG4gICAgICB2YXIgZmlyc3RQYWdlciA9IG51bGw7XG4gICAgICB2YXIgbGFzdFBhZ2VyID0gbnVsbDtcbiAgICAgIHZhciBnb3RvQnV0dG9uID0gbnVsbDtcblxuICAgICAgdmFyIGdvQnV0dG9uID0gcHJvcHMuc2hvd1F1aWNrSnVtcGVyICYmIHByb3BzLnNob3dRdWlja0p1bXBlci5nb0J1dHRvbjtcbiAgICAgIHZhciBwYWdlQnVmZmVyU2l6ZSA9IHByb3BzLnNob3dMZXNzSXRlbXMgPyAxIDogMjtcbiAgICAgIHZhciBfc3RhdGUgPSB0aGlzLnN0YXRlLFxuICAgICAgICAgIGN1cnJlbnQgPSBfc3RhdGUuY3VycmVudCxcbiAgICAgICAgICBwYWdlU2l6ZSA9IF9zdGF0ZS5wYWdlU2l6ZTtcblxuXG4gICAgICB2YXIgcHJldlBhZ2UgPSBjdXJyZW50IC0gMSA+IDAgPyBjdXJyZW50IC0gMSA6IDA7XG4gICAgICB2YXIgbmV4dFBhZ2UgPSBjdXJyZW50ICsgMSA8IGFsbFBhZ2VzID8gY3VycmVudCArIDEgOiBhbGxQYWdlcztcblxuICAgICAgaWYgKHByb3BzLnNpbXBsZSkge1xuICAgICAgICBpZiAoZ29CdXR0b24pIHtcbiAgICAgICAgICBpZiAodHlwZW9mIGdvQnV0dG9uID09PSAnYm9vbGVhbicpIHtcbiAgICAgICAgICAgIGdvdG9CdXR0b24gPSBSZWFjdC5jcmVhdGVFbGVtZW50KFxuICAgICAgICAgICAgICAnYnV0dG9uJyxcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHR5cGU6ICdidXR0b24nLFxuICAgICAgICAgICAgICAgIG9uQ2xpY2s6IHRoaXMuaGFuZGxlR29UTyxcbiAgICAgICAgICAgICAgICBvbktleVVwOiB0aGlzLmhhbmRsZUdvVE9cbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgbG9jYWxlLmp1bXBfdG9fY29uZmlybVxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgZ290b0J1dHRvbiA9IFJlYWN0LmNyZWF0ZUVsZW1lbnQoXG4gICAgICAgICAgICAgICdzcGFuJyxcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIG9uQ2xpY2s6IHRoaXMuaGFuZGxlR29UTyxcbiAgICAgICAgICAgICAgICBvbktleVVwOiB0aGlzLmhhbmRsZUdvVE9cbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgZ29CdXR0b25cbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGdvdG9CdXR0b24gPSBSZWFjdC5jcmVhdGVFbGVtZW50KFxuICAgICAgICAgICAgJ2xpJyxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgdGl0bGU6IHByb3BzLnNob3dUaXRsZSA/ICcnICsgbG9jYWxlLmp1bXBfdG8gKyB0aGlzLnN0YXRlLmN1cnJlbnQgKyAnLycgKyBhbGxQYWdlcyA6IG51bGwsXG4gICAgICAgICAgICAgIGNsYXNzTmFtZTogcHJlZml4Q2xzICsgJy1zaW1wbGUtcGFnZXInXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZ290b0J1dHRvblxuICAgICAgICAgICk7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gUmVhY3QuY3JlYXRlRWxlbWVudChcbiAgICAgICAgICAndWwnLFxuICAgICAgICAgIHsgY2xhc3NOYW1lOiBwcmVmaXhDbHMgKyAnICcgKyBwcmVmaXhDbHMgKyAnLXNpbXBsZSAnICsgcHJvcHMuY2xhc3NOYW1lLCBzdHlsZTogcHJvcHMuc3R5bGUgfSxcbiAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFxuICAgICAgICAgICAgJ2xpJyxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgdGl0bGU6IHByb3BzLnNob3dUaXRsZSA/IGxvY2FsZS5wcmV2X3BhZ2UgOiBudWxsLFxuICAgICAgICAgICAgICBvbkNsaWNrOiB0aGlzLnByZXYsXG4gICAgICAgICAgICAgIHRhYkluZGV4OiB0aGlzLmhhc1ByZXYoKSA/IDAgOiBudWxsLFxuICAgICAgICAgICAgICBvbktleVByZXNzOiB0aGlzLnJ1bklmRW50ZXJQcmV2LFxuICAgICAgICAgICAgICBjbGFzc05hbWU6ICh0aGlzLmhhc1ByZXYoKSA/ICcnIDogcHJlZml4Q2xzICsgJy1kaXNhYmxlZCcpICsgJyAnICsgcHJlZml4Q2xzICsgJy1wcmV2JyxcbiAgICAgICAgICAgICAgJ2FyaWEtZGlzYWJsZWQnOiAhdGhpcy5oYXNQcmV2KClcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBwcm9wcy5pdGVtUmVuZGVyKHByZXZQYWdlLCAncHJldicsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoJ2EnLCB7IGNsYXNzTmFtZTogcHJlZml4Q2xzICsgJy1pdGVtLWxpbmsnIH0pKVxuICAgICAgICAgICksXG4gICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcbiAgICAgICAgICAgICdsaScsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIHRpdGxlOiBwcm9wcy5zaG93VGl0bGUgPyB0aGlzLnN0YXRlLmN1cnJlbnQgKyAnLycgKyBhbGxQYWdlcyA6IG51bGwsXG4gICAgICAgICAgICAgIGNsYXNzTmFtZTogcHJlZml4Q2xzICsgJy1zaW1wbGUtcGFnZXInXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudCgnaW5wdXQnLCB7XG4gICAgICAgICAgICAgIHR5cGU6ICd0ZXh0JyxcbiAgICAgICAgICAgICAgdmFsdWU6IHRoaXMuc3RhdGUuY3VycmVudElucHV0VmFsdWUsXG4gICAgICAgICAgICAgIG9uS2V5RG93bjogdGhpcy5oYW5kbGVLZXlEb3duLFxuICAgICAgICAgICAgICBvbktleVVwOiB0aGlzLmhhbmRsZUtleVVwLFxuICAgICAgICAgICAgICBvbkNoYW5nZTogdGhpcy5oYW5kbGVLZXlVcCxcbiAgICAgICAgICAgICAgc2l6ZTogJzMnXG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXG4gICAgICAgICAgICAgICdzcGFuJyxcbiAgICAgICAgICAgICAgeyBjbGFzc05hbWU6IHByZWZpeENscyArICctc2xhc2gnIH0sXG4gICAgICAgICAgICAgICdcXHVGRjBGJ1xuICAgICAgICAgICAgKSxcbiAgICAgICAgICAgIGFsbFBhZ2VzXG4gICAgICAgICAgKSxcbiAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFxuICAgICAgICAgICAgJ2xpJyxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgdGl0bGU6IHByb3BzLnNob3dUaXRsZSA/IGxvY2FsZS5uZXh0X3BhZ2UgOiBudWxsLFxuICAgICAgICAgICAgICBvbkNsaWNrOiB0aGlzLm5leHQsXG4gICAgICAgICAgICAgIHRhYkluZGV4OiB0aGlzLmhhc1ByZXYoKSA/IDAgOiBudWxsLFxuICAgICAgICAgICAgICBvbktleVByZXNzOiB0aGlzLnJ1bklmRW50ZXJOZXh0LFxuICAgICAgICAgICAgICBjbGFzc05hbWU6ICh0aGlzLmhhc05leHQoKSA/ICcnIDogcHJlZml4Q2xzICsgJy1kaXNhYmxlZCcpICsgJyAnICsgcHJlZml4Q2xzICsgJy1uZXh0JyxcbiAgICAgICAgICAgICAgJ2FyaWEtZGlzYWJsZWQnOiAhdGhpcy5oYXNOZXh0KClcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBwcm9wcy5pdGVtUmVuZGVyKG5leHRQYWdlLCAnbmV4dCcsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoJ2EnLCB7IGNsYXNzTmFtZTogcHJlZml4Q2xzICsgJy1pdGVtLWxpbmsnIH0pKVxuICAgICAgICAgICksXG4gICAgICAgICAgZ290b0J1dHRvblxuICAgICAgICApO1xuICAgICAgfVxuXG4gICAgICBpZiAoYWxsUGFnZXMgPD0gNSArIHBhZ2VCdWZmZXJTaXplICogMikge1xuICAgICAgICBmb3IgKHZhciBpID0gMTsgaSA8PSBhbGxQYWdlczsgaSsrKSB7XG4gICAgICAgICAgdmFyIGFjdGl2ZSA9IHRoaXMuc3RhdGUuY3VycmVudCA9PT0gaTtcbiAgICAgICAgICBwYWdlckxpc3QucHVzaChSZWFjdC5jcmVhdGVFbGVtZW50KFBhZ2VyLCB7XG4gICAgICAgICAgICBsb2NhbGU6IGxvY2FsZSxcbiAgICAgICAgICAgIHJvb3RQcmVmaXhDbHM6IHByZWZpeENscyxcbiAgICAgICAgICAgIG9uQ2xpY2s6IHRoaXMuaGFuZGxlQ2hhbmdlLFxuICAgICAgICAgICAgb25LZXlQcmVzczogdGhpcy5ydW5JZkVudGVyLFxuICAgICAgICAgICAga2V5OiBpLFxuICAgICAgICAgICAgcGFnZTogaSxcbiAgICAgICAgICAgIGFjdGl2ZTogYWN0aXZlLFxuICAgICAgICAgICAgc2hvd1RpdGxlOiBwcm9wcy5zaG93VGl0bGUsXG4gICAgICAgICAgICBpdGVtUmVuZGVyOiBwcm9wcy5pdGVtUmVuZGVyXG4gICAgICAgICAgfSkpO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB2YXIgcHJldkl0ZW1UaXRsZSA9IHByb3BzLnNob3dMZXNzSXRlbXMgPyBsb2NhbGUucHJldl8zIDogbG9jYWxlLnByZXZfNTtcbiAgICAgICAgdmFyIG5leHRJdGVtVGl0bGUgPSBwcm9wcy5zaG93TGVzc0l0ZW1zID8gbG9jYWxlLm5leHRfMyA6IGxvY2FsZS5uZXh0XzU7XG4gICAgICAgIGlmIChwcm9wcy5zaG93UHJldk5leHRKdW1wZXJzKSB7XG4gICAgICAgICAganVtcFByZXYgPSBSZWFjdC5jcmVhdGVFbGVtZW50KFxuICAgICAgICAgICAgJ2xpJyxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgdGl0bGU6IHByb3BzLnNob3dUaXRsZSA/IHByZXZJdGVtVGl0bGUgOiBudWxsLFxuICAgICAgICAgICAgICBrZXk6ICdwcmV2JyxcbiAgICAgICAgICAgICAgb25DbGljazogdGhpcy5qdW1wUHJldixcbiAgICAgICAgICAgICAgdGFiSW5kZXg6ICcwJyxcbiAgICAgICAgICAgICAgb25LZXlQcmVzczogdGhpcy5ydW5JZkVudGVySnVtcFByZXYsXG4gICAgICAgICAgICAgIGNsYXNzTmFtZTogcHJlZml4Q2xzICsgJy1qdW1wLXByZXYnXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcHJvcHMuaXRlbVJlbmRlcih0aGlzLmdldEp1bXBQcmV2UGFnZSgpLCAnanVtcC1wcmV2JywgUmVhY3QuY3JlYXRlRWxlbWVudCgnYScsIHsgY2xhc3NOYW1lOiBwcmVmaXhDbHMgKyAnLWl0ZW0tbGluaycgfSkpXG4gICAgICAgICAgKTtcbiAgICAgICAgICBqdW1wTmV4dCA9IFJlYWN0LmNyZWF0ZUVsZW1lbnQoXG4gICAgICAgICAgICAnbGknLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICB0aXRsZTogcHJvcHMuc2hvd1RpdGxlID8gbmV4dEl0ZW1UaXRsZSA6IG51bGwsXG4gICAgICAgICAgICAgIGtleTogJ25leHQnLFxuICAgICAgICAgICAgICB0YWJJbmRleDogJzAnLFxuICAgICAgICAgICAgICBvbkNsaWNrOiB0aGlzLmp1bXBOZXh0LFxuICAgICAgICAgICAgICBvbktleVByZXNzOiB0aGlzLnJ1bklmRW50ZXJKdW1wTmV4dCxcbiAgICAgICAgICAgICAgY2xhc3NOYW1lOiBwcmVmaXhDbHMgKyAnLWp1bXAtbmV4dCdcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBwcm9wcy5pdGVtUmVuZGVyKHRoaXMuZ2V0SnVtcE5leHRQYWdlKCksICdqdW1wLW5leHQnLCBSZWFjdC5jcmVhdGVFbGVtZW50KCdhJywgeyBjbGFzc05hbWU6IHByZWZpeENscyArICctaXRlbS1saW5rJyB9KSlcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICAgIGxhc3RQYWdlciA9IFJlYWN0LmNyZWF0ZUVsZW1lbnQoUGFnZXIsIHtcbiAgICAgICAgICBsb2NhbGU6IHByb3BzLmxvY2FsZSxcbiAgICAgICAgICBsYXN0OiB0cnVlLFxuICAgICAgICAgIHJvb3RQcmVmaXhDbHM6IHByZWZpeENscyxcbiAgICAgICAgICBvbkNsaWNrOiB0aGlzLmhhbmRsZUNoYW5nZSxcbiAgICAgICAgICBvbktleVByZXNzOiB0aGlzLnJ1bklmRW50ZXIsXG4gICAgICAgICAga2V5OiBhbGxQYWdlcyxcbiAgICAgICAgICBwYWdlOiBhbGxQYWdlcyxcbiAgICAgICAgICBhY3RpdmU6IGZhbHNlLFxuICAgICAgICAgIHNob3dUaXRsZTogcHJvcHMuc2hvd1RpdGxlLFxuICAgICAgICAgIGl0ZW1SZW5kZXI6IHByb3BzLml0ZW1SZW5kZXJcbiAgICAgICAgfSk7XG4gICAgICAgIGZpcnN0UGFnZXIgPSBSZWFjdC5jcmVhdGVFbGVtZW50KFBhZ2VyLCB7XG4gICAgICAgICAgbG9jYWxlOiBwcm9wcy5sb2NhbGUsXG4gICAgICAgICAgcm9vdFByZWZpeENsczogcHJlZml4Q2xzLFxuICAgICAgICAgIG9uQ2xpY2s6IHRoaXMuaGFuZGxlQ2hhbmdlLFxuICAgICAgICAgIG9uS2V5UHJlc3M6IHRoaXMucnVuSWZFbnRlcixcbiAgICAgICAgICBrZXk6IDEsXG4gICAgICAgICAgcGFnZTogMSxcbiAgICAgICAgICBhY3RpdmU6IGZhbHNlLFxuICAgICAgICAgIHNob3dUaXRsZTogcHJvcHMuc2hvd1RpdGxlLFxuICAgICAgICAgIGl0ZW1SZW5kZXI6IHByb3BzLml0ZW1SZW5kZXJcbiAgICAgICAgfSk7XG5cbiAgICAgICAgdmFyIGxlZnQgPSBNYXRoLm1heCgxLCBjdXJyZW50IC0gcGFnZUJ1ZmZlclNpemUpO1xuICAgICAgICB2YXIgcmlnaHQgPSBNYXRoLm1pbihjdXJyZW50ICsgcGFnZUJ1ZmZlclNpemUsIGFsbFBhZ2VzKTtcblxuICAgICAgICBpZiAoY3VycmVudCAtIDEgPD0gcGFnZUJ1ZmZlclNpemUpIHtcbiAgICAgICAgICByaWdodCA9IDEgKyBwYWdlQnVmZmVyU2l6ZSAqIDI7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoYWxsUGFnZXMgLSBjdXJyZW50IDw9IHBhZ2VCdWZmZXJTaXplKSB7XG4gICAgICAgICAgbGVmdCA9IGFsbFBhZ2VzIC0gcGFnZUJ1ZmZlclNpemUgKiAyO1xuICAgICAgICB9XG5cbiAgICAgICAgZm9yICh2YXIgX2kgPSBsZWZ0OyBfaSA8PSByaWdodDsgX2krKykge1xuICAgICAgICAgIHZhciBfYWN0aXZlID0gY3VycmVudCA9PT0gX2k7XG4gICAgICAgICAgcGFnZXJMaXN0LnB1c2goUmVhY3QuY3JlYXRlRWxlbWVudChQYWdlciwge1xuICAgICAgICAgICAgbG9jYWxlOiBwcm9wcy5sb2NhbGUsXG4gICAgICAgICAgICByb290UHJlZml4Q2xzOiBwcmVmaXhDbHMsXG4gICAgICAgICAgICBvbkNsaWNrOiB0aGlzLmhhbmRsZUNoYW5nZSxcbiAgICAgICAgICAgIG9uS2V5UHJlc3M6IHRoaXMucnVuSWZFbnRlcixcbiAgICAgICAgICAgIGtleTogX2ksXG4gICAgICAgICAgICBwYWdlOiBfaSxcbiAgICAgICAgICAgIGFjdGl2ZTogX2FjdGl2ZSxcbiAgICAgICAgICAgIHNob3dUaXRsZTogcHJvcHMuc2hvd1RpdGxlLFxuICAgICAgICAgICAgaXRlbVJlbmRlcjogcHJvcHMuaXRlbVJlbmRlclxuICAgICAgICAgIH0pKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChjdXJyZW50IC0gMSA+PSBwYWdlQnVmZmVyU2l6ZSAqIDIgJiYgY3VycmVudCAhPT0gMSArIDIpIHtcbiAgICAgICAgICBwYWdlckxpc3RbMF0gPSBSZWFjdC5jbG9uZUVsZW1lbnQocGFnZXJMaXN0WzBdLCB7XG4gICAgICAgICAgICBjbGFzc05hbWU6IHByZWZpeENscyArICctaXRlbS1hZnRlci1qdW1wLXByZXYnXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgcGFnZXJMaXN0LnVuc2hpZnQoanVtcFByZXYpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChhbGxQYWdlcyAtIGN1cnJlbnQgPj0gcGFnZUJ1ZmZlclNpemUgKiAyICYmIGN1cnJlbnQgIT09IGFsbFBhZ2VzIC0gMikge1xuICAgICAgICAgIHBhZ2VyTGlzdFtwYWdlckxpc3QubGVuZ3RoIC0gMV0gPSBSZWFjdC5jbG9uZUVsZW1lbnQocGFnZXJMaXN0W3BhZ2VyTGlzdC5sZW5ndGggLSAxXSwge1xuICAgICAgICAgICAgY2xhc3NOYW1lOiBwcmVmaXhDbHMgKyAnLWl0ZW0tYmVmb3JlLWp1bXAtbmV4dCdcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBwYWdlckxpc3QucHVzaChqdW1wTmV4dCk7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAobGVmdCAhPT0gMSkge1xuICAgICAgICAgIHBhZ2VyTGlzdC51bnNoaWZ0KGZpcnN0UGFnZXIpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChyaWdodCAhPT0gYWxsUGFnZXMpIHtcbiAgICAgICAgICBwYWdlckxpc3QucHVzaChsYXN0UGFnZXIpO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIHZhciB0b3RhbFRleHQgPSBudWxsO1xuXG4gICAgICBpZiAocHJvcHMuc2hvd1RvdGFsKSB7XG4gICAgICAgIHRvdGFsVGV4dCA9IFJlYWN0LmNyZWF0ZUVsZW1lbnQoXG4gICAgICAgICAgJ2xpJyxcbiAgICAgICAgICB7IGNsYXNzTmFtZTogcHJlZml4Q2xzICsgJy10b3RhbC10ZXh0JyB9LFxuICAgICAgICAgIHByb3BzLnNob3dUb3RhbChwcm9wcy50b3RhbCwgWyhjdXJyZW50IC0gMSkgKiBwYWdlU2l6ZSArIDEsIGN1cnJlbnQgKiBwYWdlU2l6ZSA+IHByb3BzLnRvdGFsID8gcHJvcHMudG90YWwgOiBjdXJyZW50ICogcGFnZVNpemVdKVxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgdmFyIHByZXZEaXNhYmxlZCA9ICF0aGlzLmhhc1ByZXYoKTtcbiAgICAgIHZhciBuZXh0RGlzYWJsZWQgPSAhdGhpcy5oYXNOZXh0KCk7XG4gICAgICByZXR1cm4gUmVhY3QuY3JlYXRlRWxlbWVudChcbiAgICAgICAgJ3VsJyxcbiAgICAgICAge1xuICAgICAgICAgIGNsYXNzTmFtZTogcHJlZml4Q2xzICsgJyAnICsgcHJvcHMuY2xhc3NOYW1lLFxuICAgICAgICAgIHN0eWxlOiBwcm9wcy5zdHlsZSxcbiAgICAgICAgICB1bnNlbGVjdGFibGU6ICd1bnNlbGVjdGFibGUnLFxuICAgICAgICAgIHJlZjogdGhpcy5zYXZlUGFnaW5hdGlvbk5vZGVcbiAgICAgICAgfSxcbiAgICAgICAgdG90YWxUZXh0LFxuICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFxuICAgICAgICAgICdsaScsXG4gICAgICAgICAge1xuICAgICAgICAgICAgdGl0bGU6IHByb3BzLnNob3dUaXRsZSA/IGxvY2FsZS5wcmV2X3BhZ2UgOiBudWxsLFxuICAgICAgICAgICAgb25DbGljazogdGhpcy5wcmV2LFxuICAgICAgICAgICAgdGFiSW5kZXg6IHByZXZEaXNhYmxlZCA/IG51bGwgOiAwLFxuICAgICAgICAgICAgb25LZXlQcmVzczogdGhpcy5ydW5JZkVudGVyUHJldixcbiAgICAgICAgICAgIGNsYXNzTmFtZTogKCFwcmV2RGlzYWJsZWQgPyAnJyA6IHByZWZpeENscyArICctZGlzYWJsZWQnKSArICcgJyArIHByZWZpeENscyArICctcHJldicsXG4gICAgICAgICAgICAnYXJpYS1kaXNhYmxlZCc6IHByZXZEaXNhYmxlZFxuICAgICAgICAgIH0sXG4gICAgICAgICAgcHJvcHMuaXRlbVJlbmRlcihwcmV2UGFnZSwgJ3ByZXYnLCBSZWFjdC5jcmVhdGVFbGVtZW50KCdhJywgeyBjbGFzc05hbWU6IHByZWZpeENscyArICctaXRlbS1saW5rJyB9KSlcbiAgICAgICAgKSxcbiAgICAgICAgcGFnZXJMaXN0LFxuICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFxuICAgICAgICAgICdsaScsXG4gICAgICAgICAge1xuICAgICAgICAgICAgdGl0bGU6IHByb3BzLnNob3dUaXRsZSA/IGxvY2FsZS5uZXh0X3BhZ2UgOiBudWxsLFxuICAgICAgICAgICAgb25DbGljazogdGhpcy5uZXh0LFxuICAgICAgICAgICAgdGFiSW5kZXg6IG5leHREaXNhYmxlZCA/IG51bGwgOiAwLFxuICAgICAgICAgICAgb25LZXlQcmVzczogdGhpcy5ydW5JZkVudGVyTmV4dCxcbiAgICAgICAgICAgIGNsYXNzTmFtZTogKCFuZXh0RGlzYWJsZWQgPyAnJyA6IHByZWZpeENscyArICctZGlzYWJsZWQnKSArICcgJyArIHByZWZpeENscyArICctbmV4dCcsXG4gICAgICAgICAgICAnYXJpYS1kaXNhYmxlZCc6IG5leHREaXNhYmxlZFxuICAgICAgICAgIH0sXG4gICAgICAgICAgcHJvcHMuaXRlbVJlbmRlcihuZXh0UGFnZSwgJ25leHQnLCBSZWFjdC5jcmVhdGVFbGVtZW50KCdhJywgeyBjbGFzc05hbWU6IHByZWZpeENscyArICctaXRlbS1saW5rJyB9KSlcbiAgICAgICAgKSxcbiAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChPcHRpb25zLCB7XG4gICAgICAgICAgbG9jYWxlOiBwcm9wcy5sb2NhbGUsXG4gICAgICAgICAgcm9vdFByZWZpeENsczogcHJlZml4Q2xzLFxuICAgICAgICAgIHNlbGVjdENvbXBvbmVudENsYXNzOiBwcm9wcy5zZWxlY3RDb21wb25lbnRDbGFzcyxcbiAgICAgICAgICBzZWxlY3RQcmVmaXhDbHM6IHByb3BzLnNlbGVjdFByZWZpeENscyxcbiAgICAgICAgICBjaGFuZ2VTaXplOiB0aGlzLnByb3BzLnNob3dTaXplQ2hhbmdlciA/IHRoaXMuY2hhbmdlUGFnZVNpemUgOiBudWxsLFxuICAgICAgICAgIGN1cnJlbnQ6IHRoaXMuc3RhdGUuY3VycmVudCxcbiAgICAgICAgICBwYWdlU2l6ZTogdGhpcy5zdGF0ZS5wYWdlU2l6ZSxcbiAgICAgICAgICBwYWdlU2l6ZU9wdGlvbnM6IHRoaXMucHJvcHMucGFnZVNpemVPcHRpb25zLFxuICAgICAgICAgIHF1aWNrR286IHRoaXMucHJvcHMuc2hvd1F1aWNrSnVtcGVyID8gdGhpcy5oYW5kbGVDaGFuZ2UgOiBudWxsLFxuICAgICAgICAgIGdvQnV0dG9uOiBnb0J1dHRvblxuICAgICAgICB9KVxuICAgICAgKTtcbiAgICB9XG4gIH1dKTtcblxuICByZXR1cm4gUGFnaW5hdGlvbjtcbn0oUmVhY3QuQ29tcG9uZW50KTtcblxuUGFnaW5hdGlvbi5wcm9wVHlwZXMgPSB7XG4gIHByZWZpeENsczogUHJvcFR5cGVzLnN0cmluZyxcbiAgY3VycmVudDogUHJvcFR5cGVzLm51bWJlcixcbiAgZGVmYXVsdEN1cnJlbnQ6IFByb3BUeXBlcy5udW1iZXIsXG4gIHRvdGFsOiBQcm9wVHlwZXMubnVtYmVyLFxuICBwYWdlU2l6ZTogUHJvcFR5cGVzLm51bWJlcixcbiAgZGVmYXVsdFBhZ2VTaXplOiBQcm9wVHlwZXMubnVtYmVyLFxuICBvbkNoYW5nZTogUHJvcFR5cGVzLmZ1bmMsXG4gIGhpZGVPblNpbmdsZVBhZ2U6IFByb3BUeXBlcy5ib29sLFxuICBzaG93U2l6ZUNoYW5nZXI6IFByb3BUeXBlcy5ib29sLFxuICBzaG93TGVzc0l0ZW1zOiBQcm9wVHlwZXMuYm9vbCxcbiAgb25TaG93U2l6ZUNoYW5nZTogUHJvcFR5cGVzLmZ1bmMsXG4gIHNlbGVjdENvbXBvbmVudENsYXNzOiBQcm9wVHlwZXMuZnVuYyxcbiAgc2hvd1ByZXZOZXh0SnVtcGVyczogUHJvcFR5cGVzLmJvb2wsXG4gIHNob3dRdWlja0p1bXBlcjogUHJvcFR5cGVzLm9uZU9mVHlwZShbUHJvcFR5cGVzLmJvb2wsIFByb3BUeXBlcy5vYmplY3RdKSxcbiAgc2hvd1RpdGxlOiBQcm9wVHlwZXMuYm9vbCxcbiAgcGFnZVNpemVPcHRpb25zOiBQcm9wVHlwZXMuYXJyYXlPZihQcm9wVHlwZXMuc3RyaW5nKSxcbiAgc2hvd1RvdGFsOiBQcm9wVHlwZXMuZnVuYyxcbiAgbG9jYWxlOiBQcm9wVHlwZXMub2JqZWN0LFxuICBzdHlsZTogUHJvcFR5cGVzLm9iamVjdCxcbiAgaXRlbVJlbmRlcjogUHJvcFR5cGVzLmZ1bmNcbn07XG5QYWdpbmF0aW9uLmRlZmF1bHRQcm9wcyA9IHtcbiAgZGVmYXVsdEN1cnJlbnQ6IDEsXG4gIHRvdGFsOiAwLFxuICBkZWZhdWx0UGFnZVNpemU6IDEwLFxuICBvbkNoYW5nZTogbm9vcCxcbiAgY2xhc3NOYW1lOiAnJyxcbiAgc2VsZWN0UHJlZml4Q2xzOiAncmMtc2VsZWN0JyxcbiAgcHJlZml4Q2xzOiAncmMtcGFnaW5hdGlvbicsXG4gIHNlbGVjdENvbXBvbmVudENsYXNzOiBudWxsLFxuICBoaWRlT25TaW5nbGVQYWdlOiBmYWxzZSxcbiAgc2hvd1ByZXZOZXh0SnVtcGVyczogdHJ1ZSxcbiAgc2hvd1F1aWNrSnVtcGVyOiBmYWxzZSxcbiAgc2hvd1NpemVDaGFuZ2VyOiBmYWxzZSxcbiAgc2hvd0xlc3NJdGVtczogZmFsc2UsXG4gIHNob3dUaXRsZTogdHJ1ZSxcbiAgb25TaG93U2l6ZUNoYW5nZTogbm9vcCxcbiAgbG9jYWxlOiBMT0NBTEUsXG4gIHN0eWxlOiB7fSxcbiAgaXRlbVJlbmRlcjogZGVmYXVsdEl0ZW1SZW5kZXJcbn07XG5cbnZhciBfaW5pdGlhbGlzZVByb3BzID0gZnVuY3Rpb24gX2luaXRpYWxpc2VQcm9wcygpIHtcbiAgdmFyIF90aGlzMiA9IHRoaXM7XG5cbiAgdGhpcy5zYXZlUGFnaW5hdGlvbk5vZGUgPSBmdW5jdGlvbiAobm9kZSkge1xuICAgIF90aGlzMi5wYWdpbmF0aW9uTm9kZSA9IG5vZGU7XG4gIH07XG5cbiAgdGhpcy5jYWxjdWxhdGVQYWdlID0gZnVuY3Rpb24gKHApIHtcbiAgICB2YXIgcGFnZVNpemUgPSBwO1xuICAgIGlmICh0eXBlb2YgcGFnZVNpemUgPT09ICd1bmRlZmluZWQnKSB7XG4gICAgICBwYWdlU2l6ZSA9IF90aGlzMi5zdGF0ZS5wYWdlU2l6ZTtcbiAgICB9XG4gICAgcmV0dXJuIE1hdGguZmxvb3IoKF90aGlzMi5wcm9wcy50b3RhbCAtIDEpIC8gcGFnZVNpemUpICsgMTtcbiAgfTtcblxuICB0aGlzLmlzVmFsaWQgPSBmdW5jdGlvbiAocGFnZSkge1xuICAgIHJldHVybiBpc0ludGVnZXIocGFnZSkgJiYgcGFnZSA+PSAxICYmIHBhZ2UgIT09IF90aGlzMi5zdGF0ZS5jdXJyZW50O1xuICB9O1xuXG4gIHRoaXMuaGFuZGxlS2V5RG93biA9IGZ1bmN0aW9uIChlKSB7XG4gICAgaWYgKGUua2V5Q29kZSA9PT0gS0VZQ09ERS5BUlJPV19VUCB8fCBlLmtleUNvZGUgPT09IEtFWUNPREUuQVJST1dfRE9XTikge1xuICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIH1cbiAgfTtcblxuICB0aGlzLmhhbmRsZUtleVVwID0gZnVuY3Rpb24gKGUpIHtcbiAgICB2YXIgaW5wdXRWYWx1ZSA9IGUudGFyZ2V0LnZhbHVlO1xuICAgIHZhciBjdXJyZW50SW5wdXRWYWx1ZSA9IF90aGlzMi5zdGF0ZS5jdXJyZW50SW5wdXRWYWx1ZTtcbiAgICB2YXIgdmFsdWUgPSB2b2lkIDA7XG5cbiAgICBpZiAoaW5wdXRWYWx1ZSA9PT0gJycpIHtcbiAgICAgIHZhbHVlID0gaW5wdXRWYWx1ZTtcbiAgICB9IGVsc2UgaWYgKGlzTmFOKE51bWJlcihpbnB1dFZhbHVlKSkpIHtcbiAgICAgIHZhbHVlID0gY3VycmVudElucHV0VmFsdWU7XG4gICAgfSBlbHNlIHtcbiAgICAgIHZhbHVlID0gTnVtYmVyKGlucHV0VmFsdWUpO1xuICAgIH1cblxuICAgIGlmICh2YWx1ZSAhPT0gY3VycmVudElucHV0VmFsdWUpIHtcbiAgICAgIF90aGlzMi5zZXRTdGF0ZSh7XG4gICAgICAgIGN1cnJlbnRJbnB1dFZhbHVlOiB2YWx1ZVxuICAgICAgfSk7XG4gICAgfVxuXG4gICAgaWYgKGUua2V5Q29kZSA9PT0gS0VZQ09ERS5FTlRFUikge1xuICAgICAgX3RoaXMyLmhhbmRsZUNoYW5nZSh2YWx1ZSk7XG4gICAgfSBlbHNlIGlmIChlLmtleUNvZGUgPT09IEtFWUNPREUuQVJST1dfVVApIHtcbiAgICAgIF90aGlzMi5oYW5kbGVDaGFuZ2UodmFsdWUgLSAxKTtcbiAgICB9IGVsc2UgaWYgKGUua2V5Q29kZSA9PT0gS0VZQ09ERS5BUlJPV19ET1dOKSB7XG4gICAgICBfdGhpczIuaGFuZGxlQ2hhbmdlKHZhbHVlICsgMSk7XG4gICAgfVxuICB9O1xuXG4gIHRoaXMuY2hhbmdlUGFnZVNpemUgPSBmdW5jdGlvbiAoc2l6ZSkge1xuICAgIHZhciBjdXJyZW50ID0gX3RoaXMyLnN0YXRlLmN1cnJlbnQ7XG4gICAgdmFyIG5ld0N1cnJlbnQgPSBfdGhpczIuY2FsY3VsYXRlUGFnZShzaXplKTtcbiAgICBjdXJyZW50ID0gY3VycmVudCA+IG5ld0N1cnJlbnQgPyBuZXdDdXJyZW50IDogY3VycmVudDtcbiAgICBpZiAodHlwZW9mIHNpemUgPT09ICdudW1iZXInKSB7XG4gICAgICBpZiAoISgncGFnZVNpemUnIGluIF90aGlzMi5wcm9wcykpIHtcbiAgICAgICAgX3RoaXMyLnNldFN0YXRlKHtcbiAgICAgICAgICBwYWdlU2l6ZTogc2l6ZVxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIGlmICghKCdjdXJyZW50JyBpbiBfdGhpczIucHJvcHMpKSB7XG4gICAgICAgIF90aGlzMi5zZXRTdGF0ZSh7XG4gICAgICAgICAgY3VycmVudDogY3VycmVudCxcbiAgICAgICAgICBjdXJyZW50SW5wdXRWYWx1ZTogY3VycmVudFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gICAgX3RoaXMyLnByb3BzLm9uU2hvd1NpemVDaGFuZ2UoY3VycmVudCwgc2l6ZSk7XG4gIH07XG5cbiAgdGhpcy5oYW5kbGVDaGFuZ2UgPSBmdW5jdGlvbiAocCkge1xuICAgIHZhciBwYWdlID0gcDtcbiAgICBpZiAoX3RoaXMyLmlzVmFsaWQocGFnZSkpIHtcbiAgICAgIGlmIChwYWdlID4gX3RoaXMyLmNhbGN1bGF0ZVBhZ2UoKSkge1xuICAgICAgICBwYWdlID0gX3RoaXMyLmNhbGN1bGF0ZVBhZ2UoKTtcbiAgICAgIH1cblxuICAgICAgaWYgKCEoJ2N1cnJlbnQnIGluIF90aGlzMi5wcm9wcykpIHtcbiAgICAgICAgX3RoaXMyLnNldFN0YXRlKHtcbiAgICAgICAgICBjdXJyZW50OiBwYWdlLFxuICAgICAgICAgIGN1cnJlbnRJbnB1dFZhbHVlOiBwYWdlXG4gICAgICAgIH0pO1xuICAgICAgfVxuXG4gICAgICB2YXIgcGFnZVNpemUgPSBfdGhpczIuc3RhdGUucGFnZVNpemU7XG4gICAgICBfdGhpczIucHJvcHMub25DaGFuZ2UocGFnZSwgcGFnZVNpemUpO1xuXG4gICAgICByZXR1cm4gcGFnZTtcbiAgICB9XG5cbiAgICByZXR1cm4gX3RoaXMyLnN0YXRlLmN1cnJlbnQ7XG4gIH07XG5cbiAgdGhpcy5wcmV2ID0gZnVuY3Rpb24gKCkge1xuICAgIGlmIChfdGhpczIuaGFzUHJldigpKSB7XG4gICAgICBfdGhpczIuaGFuZGxlQ2hhbmdlKF90aGlzMi5zdGF0ZS5jdXJyZW50IC0gMSk7XG4gICAgfVxuICB9O1xuXG4gIHRoaXMubmV4dCA9IGZ1bmN0aW9uICgpIHtcbiAgICBpZiAoX3RoaXMyLmhhc05leHQoKSkge1xuICAgICAgX3RoaXMyLmhhbmRsZUNoYW5nZShfdGhpczIuc3RhdGUuY3VycmVudCArIDEpO1xuICAgIH1cbiAgfTtcblxuICB0aGlzLmp1bXBQcmV2ID0gZnVuY3Rpb24gKCkge1xuICAgIF90aGlzMi5oYW5kbGVDaGFuZ2UoX3RoaXMyLmdldEp1bXBQcmV2UGFnZSgpKTtcbiAgfTtcblxuICB0aGlzLmp1bXBOZXh0ID0gZnVuY3Rpb24gKCkge1xuICAgIF90aGlzMi5oYW5kbGVDaGFuZ2UoX3RoaXMyLmdldEp1bXBOZXh0UGFnZSgpKTtcbiAgfTtcblxuICB0aGlzLmhhc1ByZXYgPSBmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIF90aGlzMi5zdGF0ZS5jdXJyZW50ID4gMTtcbiAgfTtcblxuICB0aGlzLmhhc05leHQgPSBmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIF90aGlzMi5zdGF0ZS5jdXJyZW50IDwgX3RoaXMyLmNhbGN1bGF0ZVBhZ2UoKTtcbiAgfTtcblxuICB0aGlzLnJ1bklmRW50ZXIgPSBmdW5jdGlvbiAoZXZlbnQsIGNhbGxiYWNrKSB7XG4gICAgZm9yICh2YXIgX2xlbiA9IGFyZ3VtZW50cy5sZW5ndGgsIHJlc3RQYXJhbXMgPSBBcnJheShfbGVuID4gMiA/IF9sZW4gLSAyIDogMCksIF9rZXkgPSAyOyBfa2V5IDwgX2xlbjsgX2tleSsrKSB7XG4gICAgICByZXN0UGFyYW1zW19rZXkgLSAyXSA9IGFyZ3VtZW50c1tfa2V5XTtcbiAgICB9XG5cbiAgICBpZiAoZXZlbnQua2V5ID09PSAnRW50ZXInIHx8IGV2ZW50LmNoYXJDb2RlID09PSAxMykge1xuICAgICAgY2FsbGJhY2suYXBwbHkodW5kZWZpbmVkLCByZXN0UGFyYW1zKTtcbiAgICB9XG4gIH07XG5cbiAgdGhpcy5ydW5JZkVudGVyUHJldiA9IGZ1bmN0aW9uIChlKSB7XG4gICAgX3RoaXMyLnJ1bklmRW50ZXIoZSwgX3RoaXMyLnByZXYpO1xuICB9O1xuXG4gIHRoaXMucnVuSWZFbnRlck5leHQgPSBmdW5jdGlvbiAoZSkge1xuICAgIF90aGlzMi5ydW5JZkVudGVyKGUsIF90aGlzMi5uZXh0KTtcbiAgfTtcblxuICB0aGlzLnJ1bklmRW50ZXJKdW1wUHJldiA9IGZ1bmN0aW9uIChlKSB7XG4gICAgX3RoaXMyLnJ1bklmRW50ZXIoZSwgX3RoaXMyLmp1bXBQcmV2KTtcbiAgfTtcblxuICB0aGlzLnJ1bklmRW50ZXJKdW1wTmV4dCA9IGZ1bmN0aW9uIChlKSB7XG4gICAgX3RoaXMyLnJ1bklmRW50ZXIoZSwgX3RoaXMyLmp1bXBOZXh0KTtcbiAgfTtcblxuICB0aGlzLmhhbmRsZUdvVE8gPSBmdW5jdGlvbiAoZSkge1xuICAgIGlmIChlLmtleUNvZGUgPT09IEtFWUNPREUuRU5URVIgfHwgZS50eXBlID09PSAnY2xpY2snKSB7XG4gICAgICBfdGhpczIuaGFuZGxlQ2hhbmdlKF90aGlzMi5zdGF0ZS5jdXJyZW50SW5wdXRWYWx1ZSk7XG4gICAgfVxuICB9O1xufTtcblxuZXhwb3J0IGRlZmF1bHQgUGFnaW5hdGlvbjsiLCJleHBvcnQgZGVmYXVsdCB7XG4gIC8vIE9wdGlvbnMuanN4XG4gIGl0ZW1zX3Blcl9wYWdlOiAnLyBwYWdlJyxcbiAganVtcF90bzogJ0dvdG8nLFxuICBqdW1wX3RvX2NvbmZpcm06ICdjb25maXJtJyxcbiAgcGFnZTogJycsXG5cbiAgLy8gUGFnaW5hdGlvbi5qc3hcbiAgcHJldl9wYWdlOiAnUHJldmlvdXMgUGFnZScsXG4gIG5leHRfcGFnZTogJ05leHQgUGFnZScsXG4gIHByZXZfNTogJ1ByZXZpb3VzIDUgUGFnZXMnLFxuICBuZXh0XzU6ICdOZXh0IDUgUGFnZXMnLFxuICBwcmV2XzM6ICdQcmV2aW91cyAzIFBhZ2VzJyxcbiAgbmV4dF8zOiAnTmV4dCAzIFBhZ2VzJ1xufTsiLCJleHBvcnQgZGVmYXVsdCB7XG4gIC8vIE9wdGlvbnMuanN4XG4gIGl0ZW1zX3Blcl9wYWdlOiAn5p2hL+mhtScsXG4gIGp1bXBfdG86ICfot7Poh7MnLFxuICBqdW1wX3RvX2NvbmZpcm06ICfnoa7lrponLFxuICBwYWdlOiAn6aG1JyxcblxuICAvLyBQYWdpbmF0aW9uLmpzeFxuICBwcmV2X3BhZ2U6ICfkuIrkuIDpobUnLFxuICBuZXh0X3BhZ2U6ICfkuIvkuIDpobUnLFxuICBwcmV2XzU6ICflkJHliY0gNSDpobUnLFxuICBuZXh0XzU6ICflkJHlkI4gNSDpobUnLFxuICBwcmV2XzM6ICflkJHliY0gMyDpobUnLFxuICBuZXh0XzM6ICflkJHlkI4gMyDpobUnXG59OyIsImltcG9ydCBfZXh0ZW5kcyBmcm9tICdiYWJlbC1ydW50aW1lL2hlbHBlcnMvZXh0ZW5kcyc7XG5pbXBvcnQgX2NsYXNzQ2FsbENoZWNrIGZyb20gJ2JhYmVsLXJ1bnRpbWUvaGVscGVycy9jbGFzc0NhbGxDaGVjayc7XG5pbXBvcnQgX3Bvc3NpYmxlQ29uc3RydWN0b3JSZXR1cm4gZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL3Bvc3NpYmxlQ29uc3RydWN0b3JSZXR1cm4nO1xuaW1wb3J0IF9pbmhlcml0cyBmcm9tICdiYWJlbC1ydW50aW1lL2hlbHBlcnMvaW5oZXJpdHMnO1xuaW1wb3J0IFJlYWN0LCB7IGNsb25lRWxlbWVudCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGZpbmRET01Ob2RlIH0gZnJvbSAncmVhY3QtZG9tJztcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcyc7XG5pbXBvcnQgdG9BcnJheSBmcm9tICdyYy11dGlsL2VzL0NoaWxkcmVuL3RvQXJyYXknO1xuaW1wb3J0IE1lbnUgZnJvbSAncmMtbWVudSc7XG5pbXBvcnQgc2Nyb2xsSW50b1ZpZXcgZnJvbSAnZG9tLXNjcm9sbC1pbnRvLXZpZXcnO1xuaW1wb3J0IHsgZ2V0U2VsZWN0S2V5cywgcHJldmVudERlZmF1bHRFdmVudCwgc2F2ZVJlZiB9IGZyb20gJy4vdXRpbCc7XG5cbnZhciBEcm9wZG93bk1lbnUgPSBmdW5jdGlvbiAoX1JlYWN0JENvbXBvbmVudCkge1xuICBfaW5oZXJpdHMoRHJvcGRvd25NZW51LCBfUmVhY3QkQ29tcG9uZW50KTtcblxuICBmdW5jdGlvbiBEcm9wZG93bk1lbnUoKSB7XG4gICAgdmFyIF90ZW1wLCBfdGhpcywgX3JldDtcblxuICAgIF9jbGFzc0NhbGxDaGVjayh0aGlzLCBEcm9wZG93bk1lbnUpO1xuXG4gICAgZm9yICh2YXIgX2xlbiA9IGFyZ3VtZW50cy5sZW5ndGgsIGFyZ3MgPSBBcnJheShfbGVuKSwgX2tleSA9IDA7IF9rZXkgPCBfbGVuOyBfa2V5KyspIHtcbiAgICAgIGFyZ3NbX2tleV0gPSBhcmd1bWVudHNbX2tleV07XG4gICAgfVxuXG4gICAgcmV0dXJuIF9yZXQgPSAoX3RlbXAgPSAoX3RoaXMgPSBfcG9zc2libGVDb25zdHJ1Y3RvclJldHVybih0aGlzLCBfUmVhY3QkQ29tcG9uZW50LmNhbGwuYXBwbHkoX1JlYWN0JENvbXBvbmVudCwgW3RoaXNdLmNvbmNhdChhcmdzKSkpLCBfdGhpcyksIF90aGlzLnNjcm9sbEFjdGl2ZUl0ZW1Ub1ZpZXcgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAvLyBzY3JvbGwgaW50byB2aWV3XG4gICAgICB2YXIgaXRlbUNvbXBvbmVudCA9IGZpbmRET01Ob2RlKF90aGlzLmZpcnN0QWN0aXZlSXRlbSk7XG4gICAgICB2YXIgcHJvcHMgPSBfdGhpcy5wcm9wcztcblxuICAgICAgaWYgKGl0ZW1Db21wb25lbnQpIHtcbiAgICAgICAgdmFyIHNjcm9sbEludG9WaWV3T3B0cyA9IHtcbiAgICAgICAgICBvbmx5U2Nyb2xsSWZOZWVkZWQ6IHRydWVcbiAgICAgICAgfTtcbiAgICAgICAgaWYgKCghcHJvcHMudmFsdWUgfHwgcHJvcHMudmFsdWUubGVuZ3RoID09PSAwKSAmJiBwcm9wcy5maXJzdEFjdGl2ZVZhbHVlKSB7XG4gICAgICAgICAgc2Nyb2xsSW50b1ZpZXdPcHRzLmFsaWduV2l0aFRvcCA9IHRydWU7XG4gICAgICAgIH1cblxuICAgICAgICBzY3JvbGxJbnRvVmlldyhpdGVtQ29tcG9uZW50LCBmaW5kRE9NTm9kZShfdGhpcy5tZW51UmVmKSwgc2Nyb2xsSW50b1ZpZXdPcHRzKTtcbiAgICAgIH1cbiAgICB9LCBfdGVtcCksIF9wb3NzaWJsZUNvbnN0cnVjdG9yUmV0dXJuKF90aGlzLCBfcmV0KTtcbiAgfVxuXG4gIERyb3Bkb3duTWVudS5wcm90b3R5cGUuY29tcG9uZW50V2lsbE1vdW50ID0gZnVuY3Rpb24gY29tcG9uZW50V2lsbE1vdW50KCkge1xuICAgIHRoaXMubGFzdElucHV0VmFsdWUgPSB0aGlzLnByb3BzLmlucHV0VmFsdWU7XG4gIH07XG5cbiAgRHJvcGRvd25NZW51LnByb3RvdHlwZS5jb21wb25lbnREaWRNb3VudCA9IGZ1bmN0aW9uIGNvbXBvbmVudERpZE1vdW50KCkge1xuICAgIHRoaXMuc2Nyb2xsQWN0aXZlSXRlbVRvVmlldygpO1xuICAgIHRoaXMubGFzdFZpc2libGUgPSB0aGlzLnByb3BzLnZpc2libGU7XG4gIH07XG5cbiAgRHJvcGRvd25NZW51LnByb3RvdHlwZS5zaG91bGRDb21wb25lbnRVcGRhdGUgPSBmdW5jdGlvbiBzaG91bGRDb21wb25lbnRVcGRhdGUobmV4dFByb3BzKSB7XG4gICAgaWYgKCFuZXh0UHJvcHMudmlzaWJsZSkge1xuICAgICAgdGhpcy5sYXN0VmlzaWJsZSA9IGZhbHNlO1xuICAgIH1cbiAgICAvLyBmcmVlemUgd2hlbiBoaWRlXG4gICAgcmV0dXJuIG5leHRQcm9wcy52aXNpYmxlO1xuICB9O1xuXG4gIERyb3Bkb3duTWVudS5wcm90b3R5cGUuY29tcG9uZW50RGlkVXBkYXRlID0gZnVuY3Rpb24gY29tcG9uZW50RGlkVXBkYXRlKHByZXZQcm9wcykge1xuICAgIHZhciBwcm9wcyA9IHRoaXMucHJvcHM7XG4gICAgaWYgKCFwcmV2UHJvcHMudmlzaWJsZSAmJiBwcm9wcy52aXNpYmxlKSB7XG4gICAgICB0aGlzLnNjcm9sbEFjdGl2ZUl0ZW1Ub1ZpZXcoKTtcbiAgICB9XG4gICAgdGhpcy5sYXN0VmlzaWJsZSA9IHByb3BzLnZpc2libGU7XG4gICAgdGhpcy5sYXN0SW5wdXRWYWx1ZSA9IHByb3BzLmlucHV0VmFsdWU7XG4gIH07XG5cbiAgRHJvcGRvd25NZW51LnByb3RvdHlwZS5yZW5kZXJNZW51ID0gZnVuY3Rpb24gcmVuZGVyTWVudSgpIHtcbiAgICB2YXIgX3RoaXMyID0gdGhpcztcblxuICAgIHZhciBwcm9wcyA9IHRoaXMucHJvcHM7XG4gICAgdmFyIG1lbnVJdGVtcyA9IHByb3BzLm1lbnVJdGVtcyxcbiAgICAgICAgZGVmYXVsdEFjdGl2ZUZpcnN0T3B0aW9uID0gcHJvcHMuZGVmYXVsdEFjdGl2ZUZpcnN0T3B0aW9uLFxuICAgICAgICB2YWx1ZSA9IHByb3BzLnZhbHVlLFxuICAgICAgICBwcmVmaXhDbHMgPSBwcm9wcy5wcmVmaXhDbHMsXG4gICAgICAgIG11bHRpcGxlID0gcHJvcHMubXVsdGlwbGUsXG4gICAgICAgIG9uTWVudVNlbGVjdCA9IHByb3BzLm9uTWVudVNlbGVjdCxcbiAgICAgICAgaW5wdXRWYWx1ZSA9IHByb3BzLmlucHV0VmFsdWUsXG4gICAgICAgIGZpcnN0QWN0aXZlVmFsdWUgPSBwcm9wcy5maXJzdEFjdGl2ZVZhbHVlLFxuICAgICAgICBiYWNrZmlsbFZhbHVlID0gcHJvcHMuYmFja2ZpbGxWYWx1ZTtcblxuICAgIGlmIChtZW51SXRlbXMgJiYgbWVudUl0ZW1zLmxlbmd0aCkge1xuICAgICAgdmFyIG1lbnVQcm9wcyA9IHt9O1xuICAgICAgaWYgKG11bHRpcGxlKSB7XG4gICAgICAgIG1lbnVQcm9wcy5vbkRlc2VsZWN0ID0gcHJvcHMub25NZW51RGVzZWxlY3Q7XG4gICAgICAgIG1lbnVQcm9wcy5vblNlbGVjdCA9IG9uTWVudVNlbGVjdDtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIG1lbnVQcm9wcy5vbkNsaWNrID0gb25NZW51U2VsZWN0O1xuICAgICAgfVxuXG4gICAgICB2YXIgc2VsZWN0ZWRLZXlzID0gZ2V0U2VsZWN0S2V5cyhtZW51SXRlbXMsIHZhbHVlKTtcbiAgICAgIHZhciBhY3RpdmVLZXlQcm9wcyA9IHt9O1xuXG4gICAgICB2YXIgY2xvbmVkTWVudUl0ZW1zID0gbWVudUl0ZW1zO1xuICAgICAgaWYgKHNlbGVjdGVkS2V5cy5sZW5ndGggfHwgZmlyc3RBY3RpdmVWYWx1ZSkge1xuICAgICAgICBpZiAocHJvcHMudmlzaWJsZSAmJiAhdGhpcy5sYXN0VmlzaWJsZSkge1xuICAgICAgICAgIGFjdGl2ZUtleVByb3BzLmFjdGl2ZUtleSA9IHNlbGVjdGVkS2V5c1swXSB8fCBmaXJzdEFjdGl2ZVZhbHVlO1xuICAgICAgICB9XG4gICAgICAgIHZhciBmb3VuZEZpcnN0ID0gZmFsc2U7XG4gICAgICAgIC8vIHNldCBmaXJzdEFjdGl2ZUl0ZW0gdmlhIGNsb25pbmcgbWVudXNcbiAgICAgICAgLy8gZm9yIHNjcm9sbCBpbnRvIHZpZXdcbiAgICAgICAgdmFyIGNsb25lID0gZnVuY3Rpb24gY2xvbmUoaXRlbSkge1xuICAgICAgICAgIGlmICghZm91bmRGaXJzdCAmJiBzZWxlY3RlZEtleXMuaW5kZXhPZihpdGVtLmtleSkgIT09IC0xIHx8ICFmb3VuZEZpcnN0ICYmICFzZWxlY3RlZEtleXMubGVuZ3RoICYmIGZpcnN0QWN0aXZlVmFsdWUuaW5kZXhPZihpdGVtLmtleSkgIT09IC0xKSB7XG4gICAgICAgICAgICBmb3VuZEZpcnN0ID0gdHJ1ZTtcbiAgICAgICAgICAgIHJldHVybiBjbG9uZUVsZW1lbnQoaXRlbSwge1xuICAgICAgICAgICAgICByZWY6IGZ1bmN0aW9uIHJlZihfcmVmKSB7XG4gICAgICAgICAgICAgICAgX3RoaXMyLmZpcnN0QWN0aXZlSXRlbSA9IF9yZWY7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gaXRlbTtcbiAgICAgICAgfTtcblxuICAgICAgICBjbG9uZWRNZW51SXRlbXMgPSBtZW51SXRlbXMubWFwKGZ1bmN0aW9uIChpdGVtKSB7XG4gICAgICAgICAgaWYgKGl0ZW0udHlwZS5pc01lbnVJdGVtR3JvdXApIHtcbiAgICAgICAgICAgIHZhciBjaGlsZHJlbiA9IHRvQXJyYXkoaXRlbS5wcm9wcy5jaGlsZHJlbikubWFwKGNsb25lKTtcbiAgICAgICAgICAgIHJldHVybiBjbG9uZUVsZW1lbnQoaXRlbSwge30sIGNoaWxkcmVuKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIGNsb25lKGl0ZW0pO1xuICAgICAgICB9KTtcbiAgICAgIH1cblxuICAgICAgLy8gY2xlYXIgYWN0aXZlS2V5IHdoZW4gaW5wdXRWYWx1ZSBjaGFuZ2VcbiAgICAgIHZhciBsYXN0VmFsdWUgPSB2YWx1ZSAmJiB2YWx1ZVt2YWx1ZS5sZW5ndGggLSAxXTtcbiAgICAgIGlmIChpbnB1dFZhbHVlICE9PSB0aGlzLmxhc3RJbnB1dFZhbHVlICYmICghbGFzdFZhbHVlIHx8IGxhc3RWYWx1ZSAhPT0gYmFja2ZpbGxWYWx1ZSkpIHtcbiAgICAgICAgYWN0aXZlS2V5UHJvcHMuYWN0aXZlS2V5ID0gJyc7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiBSZWFjdC5jcmVhdGVFbGVtZW50KFxuICAgICAgICBNZW51LFxuICAgICAgICBfZXh0ZW5kcyh7XG4gICAgICAgICAgcmVmOiBzYXZlUmVmKHRoaXMsICdtZW51UmVmJyksXG4gICAgICAgICAgc3R5bGU6IHRoaXMucHJvcHMuZHJvcGRvd25NZW51U3R5bGUsXG4gICAgICAgICAgZGVmYXVsdEFjdGl2ZUZpcnN0OiBkZWZhdWx0QWN0aXZlRmlyc3RPcHRpb25cbiAgICAgICAgfSwgYWN0aXZlS2V5UHJvcHMsIHtcbiAgICAgICAgICBtdWx0aXBsZTogbXVsdGlwbGVcbiAgICAgICAgfSwgbWVudVByb3BzLCB7XG4gICAgICAgICAgc2VsZWN0ZWRLZXlzOiBzZWxlY3RlZEtleXMsXG4gICAgICAgICAgcHJlZml4Q2xzOiBwcmVmaXhDbHMgKyAnLW1lbnUnXG4gICAgICAgIH0pLFxuICAgICAgICBjbG9uZWRNZW51SXRlbXNcbiAgICAgICk7XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xuICB9O1xuXG4gIERyb3Bkb3duTWVudS5wcm90b3R5cGUucmVuZGVyID0gZnVuY3Rpb24gcmVuZGVyKCkge1xuICAgIHZhciByZW5kZXJNZW51ID0gdGhpcy5yZW5kZXJNZW51KCk7XG4gICAgcmV0dXJuIHJlbmRlck1lbnUgPyBSZWFjdC5jcmVhdGVFbGVtZW50KFxuICAgICAgJ2RpdicsXG4gICAgICB7XG4gICAgICAgIHN0eWxlOiB7IG92ZXJmbG93OiAnYXV0bycgfSxcbiAgICAgICAgb25Gb2N1czogdGhpcy5wcm9wcy5vblBvcHVwRm9jdXMsXG4gICAgICAgIG9uTW91c2VEb3duOiBwcmV2ZW50RGVmYXVsdEV2ZW50LFxuICAgICAgICBvblNjcm9sbDogdGhpcy5wcm9wcy5vblBvcHVwU2Nyb2xsXG4gICAgICB9LFxuICAgICAgcmVuZGVyTWVudVxuICAgICkgOiBudWxsO1xuICB9O1xuXG4gIHJldHVybiBEcm9wZG93bk1lbnU7XG59KFJlYWN0LkNvbXBvbmVudCk7XG5cbkRyb3Bkb3duTWVudS5wcm9wVHlwZXMgPSB7XG4gIGRlZmF1bHRBY3RpdmVGaXJzdE9wdGlvbjogUHJvcFR5cGVzLmJvb2wsXG4gIHZhbHVlOiBQcm9wVHlwZXMuYW55LFxuICBkcm9wZG93bk1lbnVTdHlsZTogUHJvcFR5cGVzLm9iamVjdCxcbiAgbXVsdGlwbGU6IFByb3BUeXBlcy5ib29sLFxuICBvblBvcHVwRm9jdXM6IFByb3BUeXBlcy5mdW5jLFxuICBvblBvcHVwU2Nyb2xsOiBQcm9wVHlwZXMuZnVuYyxcbiAgb25NZW51RGVTZWxlY3Q6IFByb3BUeXBlcy5mdW5jLFxuICBvbk1lbnVTZWxlY3Q6IFByb3BUeXBlcy5mdW5jLFxuICBwcmVmaXhDbHM6IFByb3BUeXBlcy5zdHJpbmcsXG4gIG1lbnVJdGVtczogUHJvcFR5cGVzLmFueSxcbiAgaW5wdXRWYWx1ZTogUHJvcFR5cGVzLnN0cmluZyxcbiAgdmlzaWJsZTogUHJvcFR5cGVzLmJvb2xcbn07XG5leHBvcnQgZGVmYXVsdCBEcm9wZG93bk1lbnU7XG5cblxuRHJvcGRvd25NZW51LmRpc3BsYXlOYW1lID0gJ0Ryb3Bkb3duTWVudSc7IiwiaW1wb3J0IF9jbGFzc0NhbGxDaGVjayBmcm9tICdiYWJlbC1ydW50aW1lL2hlbHBlcnMvY2xhc3NDYWxsQ2hlY2snO1xuaW1wb3J0IF9wb3NzaWJsZUNvbnN0cnVjdG9yUmV0dXJuIGZyb20gJ2JhYmVsLXJ1bnRpbWUvaGVscGVycy9wb3NzaWJsZUNvbnN0cnVjdG9yUmV0dXJuJztcbmltcG9ydCBfaW5oZXJpdHMgZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL2luaGVyaXRzJztcbmltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5cbnZhciBPcHRHcm91cCA9IGZ1bmN0aW9uIChfUmVhY3QkQ29tcG9uZW50KSB7XG4gIF9pbmhlcml0cyhPcHRHcm91cCwgX1JlYWN0JENvbXBvbmVudCk7XG5cbiAgZnVuY3Rpb24gT3B0R3JvdXAoKSB7XG4gICAgX2NsYXNzQ2FsbENoZWNrKHRoaXMsIE9wdEdyb3VwKTtcblxuICAgIHJldHVybiBfcG9zc2libGVDb25zdHJ1Y3RvclJldHVybih0aGlzLCBfUmVhY3QkQ29tcG9uZW50LmFwcGx5KHRoaXMsIGFyZ3VtZW50cykpO1xuICB9XG5cbiAgcmV0dXJuIE9wdEdyb3VwO1xufShSZWFjdC5Db21wb25lbnQpO1xuXG5PcHRHcm91cC5pc1NlbGVjdE9wdEdyb3VwID0gdHJ1ZTtcbmV4cG9ydCBkZWZhdWx0IE9wdEdyb3VwOyIsImltcG9ydCBfY2xhc3NDYWxsQ2hlY2sgZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL2NsYXNzQ2FsbENoZWNrJztcbmltcG9ydCBfcG9zc2libGVDb25zdHJ1Y3RvclJldHVybiBmcm9tICdiYWJlbC1ydW50aW1lL2hlbHBlcnMvcG9zc2libGVDb25zdHJ1Y3RvclJldHVybic7XG5pbXBvcnQgX2luaGVyaXRzIGZyb20gJ2JhYmVsLXJ1bnRpbWUvaGVscGVycy9pbmhlcml0cyc7XG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcblxudmFyIE9wdGlvbiA9IGZ1bmN0aW9uIChfUmVhY3QkQ29tcG9uZW50KSB7XG4gIF9pbmhlcml0cyhPcHRpb24sIF9SZWFjdCRDb21wb25lbnQpO1xuXG4gIGZ1bmN0aW9uIE9wdGlvbigpIHtcbiAgICBfY2xhc3NDYWxsQ2hlY2sodGhpcywgT3B0aW9uKTtcblxuICAgIHJldHVybiBfcG9zc2libGVDb25zdHJ1Y3RvclJldHVybih0aGlzLCBfUmVhY3QkQ29tcG9uZW50LmFwcGx5KHRoaXMsIGFyZ3VtZW50cykpO1xuICB9XG5cbiAgcmV0dXJuIE9wdGlvbjtcbn0oUmVhY3QuQ29tcG9uZW50KTtcblxuT3B0aW9uLnByb3BUeXBlcyA9IHtcbiAgdmFsdWU6IFByb3BUeXBlcy5vbmVPZlR5cGUoW1Byb3BUeXBlcy5zdHJpbmcsIFByb3BUeXBlcy5udW1iZXJdKVxufTtcbk9wdGlvbi5pc1NlbGVjdE9wdGlvbiA9IHRydWU7XG5leHBvcnQgZGVmYXVsdCBPcHRpb247IiwiaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcblxuZnVuY3Rpb24gdmFsdWVUeXBlKHByb3BzLCBwcm9wTmFtZSwgY29tcG9uZW50TmFtZSkge1xuICB2YXIgYmFzaWNUeXBlID0gUHJvcFR5cGVzLm9uZU9mVHlwZShbUHJvcFR5cGVzLnN0cmluZywgUHJvcFR5cGVzLm51bWJlcl0pO1xuXG4gIHZhciBsYWJlbEluVmFsdWVTaGFwZSA9IFByb3BUeXBlcy5zaGFwZSh7XG4gICAga2V5OiBiYXNpY1R5cGUuaXNSZXF1aXJlZCxcbiAgICBsYWJlbDogUHJvcFR5cGVzLm5vZGVcbiAgfSk7XG4gIGlmIChwcm9wcy5sYWJlbEluVmFsdWUpIHtcbiAgICB2YXIgdmFsaWRhdGUgPSBQcm9wVHlwZXMub25lT2ZUeXBlKFtQcm9wVHlwZXMuYXJyYXlPZihsYWJlbEluVmFsdWVTaGFwZSksIGxhYmVsSW5WYWx1ZVNoYXBlXSk7XG4gICAgdmFyIGVycm9yID0gdmFsaWRhdGUuYXBwbHkodW5kZWZpbmVkLCBhcmd1bWVudHMpO1xuICAgIGlmIChlcnJvcikge1xuICAgICAgcmV0dXJuIG5ldyBFcnJvcignSW52YWxpZCBwcm9wIGAnICsgcHJvcE5hbWUgKyAnYCBzdXBwbGllZCB0byBgJyArIGNvbXBvbmVudE5hbWUgKyAnYCwgJyArICgnd2hlbiB5b3Ugc2V0IGBsYWJlbEluVmFsdWVgIHRvIGB0cnVlYCwgYCcgKyBwcm9wTmFtZSArICdgIHNob3VsZCBpbiAnKSArICdzaGFwZSBvZiBgeyBrZXk6IHN0cmluZyB8IG51bWJlciwgbGFiZWw/OiBSZWFjdE5vZGUgfWAuJyk7XG4gICAgfVxuICB9IGVsc2UgaWYgKChwcm9wcy5tb2RlID09PSAnbXVsdGlwbGUnIHx8IHByb3BzLm1vZGUgPT09ICd0YWdzJyB8fCBwcm9wcy5tdWx0aXBsZSB8fCBwcm9wcy50YWdzKSAmJiBwcm9wc1twcm9wTmFtZV0gPT09ICcnKSB7XG4gICAgcmV0dXJuIG5ldyBFcnJvcignSW52YWxpZCBwcm9wIGAnICsgcHJvcE5hbWUgKyAnYCBvZiB0eXBlIGBzdHJpbmdgIHN1cHBsaWVkIHRvIGAnICsgY29tcG9uZW50TmFtZSArICdgLCAnICsgJ2V4cGVjdGVkIGBhcnJheWAgd2hlbiBgbXVsdGlwbGVgIG9yIGB0YWdzYCBpcyBgdHJ1ZWAuJyk7XG4gIH0gZWxzZSB7XG4gICAgdmFyIF92YWxpZGF0ZSA9IFByb3BUeXBlcy5vbmVPZlR5cGUoW1Byb3BUeXBlcy5hcnJheU9mKGJhc2ljVHlwZSksIGJhc2ljVHlwZV0pO1xuICAgIHJldHVybiBfdmFsaWRhdGUuYXBwbHkodW5kZWZpbmVkLCBhcmd1bWVudHMpO1xuICB9XG59XG5cbmV4cG9ydCB2YXIgU2VsZWN0UHJvcFR5cGVzID0ge1xuICBkZWZhdWx0QWN0aXZlRmlyc3RPcHRpb246IFByb3BUeXBlcy5ib29sLFxuICBtdWx0aXBsZTogUHJvcFR5cGVzLmJvb2wsXG4gIGZpbHRlck9wdGlvbjogUHJvcFR5cGVzLmFueSxcbiAgY2hpbGRyZW46IFByb3BUeXBlcy5hbnksXG4gIHNob3dTZWFyY2g6IFByb3BUeXBlcy5ib29sLFxuICBkaXNhYmxlZDogUHJvcFR5cGVzLmJvb2wsXG4gIGFsbG93Q2xlYXI6IFByb3BUeXBlcy5ib29sLFxuICBzaG93QXJyb3c6IFByb3BUeXBlcy5ib29sLFxuICB0YWdzOiBQcm9wVHlwZXMuYm9vbCxcbiAgcHJlZml4Q2xzOiBQcm9wVHlwZXMuc3RyaW5nLFxuICBjbGFzc05hbWU6IFByb3BUeXBlcy5zdHJpbmcsXG4gIHRyYW5zaXRpb25OYW1lOiBQcm9wVHlwZXMuc3RyaW5nLFxuICBvcHRpb25MYWJlbFByb3A6IFByb3BUeXBlcy5zdHJpbmcsXG4gIG9wdGlvbkZpbHRlclByb3A6IFByb3BUeXBlcy5zdHJpbmcsXG4gIGFuaW1hdGlvbjogUHJvcFR5cGVzLnN0cmluZyxcbiAgY2hvaWNlVHJhbnNpdGlvbk5hbWU6IFByb3BUeXBlcy5zdHJpbmcsXG4gIG9uQ2hhbmdlOiBQcm9wVHlwZXMuZnVuYyxcbiAgb25CbHVyOiBQcm9wVHlwZXMuZnVuYyxcbiAgb25Gb2N1czogUHJvcFR5cGVzLmZ1bmMsXG4gIG9uU2VsZWN0OiBQcm9wVHlwZXMuZnVuYyxcbiAgb25TZWFyY2g6IFByb3BUeXBlcy5mdW5jLFxuICBvblBvcHVwU2Nyb2xsOiBQcm9wVHlwZXMuZnVuYyxcbiAgb25Nb3VzZUVudGVyOiBQcm9wVHlwZXMuZnVuYyxcbiAgb25Nb3VzZUxlYXZlOiBQcm9wVHlwZXMuZnVuYyxcbiAgb25JbnB1dEtleURvd246IFByb3BUeXBlcy5mdW5jLFxuICBwbGFjZWhvbGRlcjogUHJvcFR5cGVzLmFueSxcbiAgb25EZXNlbGVjdDogUHJvcFR5cGVzLmZ1bmMsXG4gIGxhYmVsSW5WYWx1ZTogUHJvcFR5cGVzLmJvb2wsXG4gIHZhbHVlOiB2YWx1ZVR5cGUsXG4gIGRlZmF1bHRWYWx1ZTogdmFsdWVUeXBlLFxuICBkcm9wZG93blN0eWxlOiBQcm9wVHlwZXMub2JqZWN0LFxuICBtYXhUYWdUZXh0TGVuZ3RoOiBQcm9wVHlwZXMubnVtYmVyLFxuICBtYXhUYWdDb3VudDogUHJvcFR5cGVzLm51bWJlcixcbiAgbWF4VGFnUGxhY2Vob2xkZXI6IFByb3BUeXBlcy5vbmVPZlR5cGUoW1Byb3BUeXBlcy5ub2RlLCBQcm9wVHlwZXMuZnVuY10pLFxuICB0b2tlblNlcGFyYXRvcnM6IFByb3BUeXBlcy5hcnJheU9mKFByb3BUeXBlcy5zdHJpbmcpLFxuICBnZXRJbnB1dEVsZW1lbnQ6IFByb3BUeXBlcy5mdW5jLFxuICBzaG93QWN0aW9uOiBQcm9wVHlwZXMuYXJyYXlPZihQcm9wVHlwZXMuc3RyaW5nKVxufTsiLCJpbXBvcnQgX2V4dGVuZHMgZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL2V4dGVuZHMnO1xuaW1wb3J0IF9jbGFzc0NhbGxDaGVjayBmcm9tICdiYWJlbC1ydW50aW1lL2hlbHBlcnMvY2xhc3NDYWxsQ2hlY2snO1xuaW1wb3J0IF9wb3NzaWJsZUNvbnN0cnVjdG9yUmV0dXJuIGZyb20gJ2JhYmVsLXJ1bnRpbWUvaGVscGVycy9wb3NzaWJsZUNvbnN0cnVjdG9yUmV0dXJuJztcbmltcG9ydCBfaW5oZXJpdHMgZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL2luaGVyaXRzJztcbi8qIGVzbGludCBmdW5jLW5hbWVzOiAxICovXG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IFJlYWN0RE9NIGZyb20gJ3JlYWN0LWRvbSc7XG5pbXBvcnQgS2V5Q29kZSBmcm9tICdyYy11dGlsL2VzL0tleUNvZGUnO1xuaW1wb3J0IGNoaWxkcmVuVG9BcnJheSBmcm9tICdyYy11dGlsL2VzL0NoaWxkcmVuL3RvQXJyYXknO1xuaW1wb3J0IGNsYXNzbmFtZXMgZnJvbSAnY2xhc3NuYW1lcyc7XG5pbXBvcnQgQW5pbWF0ZSBmcm9tICdyYy1hbmltYXRlJztcbmltcG9ydCBjbGFzc2VzIGZyb20gJ2NvbXBvbmVudC1jbGFzc2VzJztcbmltcG9ydCB7IEl0ZW0gYXMgTWVudUl0ZW0sIEl0ZW1Hcm91cCBhcyBNZW51SXRlbUdyb3VwIH0gZnJvbSAncmMtbWVudSc7XG5pbXBvcnQgd2FybmluZyBmcm9tICd3YXJuaW5nJztcbmltcG9ydCBPcHRpb24gZnJvbSAnLi9PcHRpb24nO1xuXG5pbXBvcnQgeyBnZXRQcm9wVmFsdWUsIGdldFZhbHVlUHJvcFZhbHVlLCBpc0NvbWJvYm94LCBpc011bHRpcGxlT3JUYWdzLCBpc011bHRpcGxlT3JUYWdzT3JDb21ib2JveCwgaXNTaW5nbGVNb2RlLCB0b0FycmF5LCBnZXRNYXBLZXksIGZpbmRJbmRleEluVmFsdWVCeVNpbmdsZVZhbHVlLCBnZXRMYWJlbEZyb21Qcm9wc1ZhbHVlLCBVTlNFTEVDVEFCTEVfQVRUUklCVVRFLCBVTlNFTEVDVEFCTEVfU1RZTEUsIHByZXZlbnREZWZhdWx0RXZlbnQsIGZpbmRGaXJzdE1lbnVJdGVtLCBpbmNsdWRlc1NlcGFyYXRvcnMsIHNwbGl0QnlTZXBhcmF0b3JzLCBkZWZhdWx0RmlsdGVyRm4sIHZhbGlkYXRlT3B0aW9uVmFsdWUsIHNhdmVSZWYgfSBmcm9tICcuL3V0aWwnO1xuaW1wb3J0IFNlbGVjdFRyaWdnZXIgZnJvbSAnLi9TZWxlY3RUcmlnZ2VyJztcbmltcG9ydCB7IFNlbGVjdFByb3BUeXBlcyB9IGZyb20gJy4vUHJvcFR5cGVzJztcblxuZnVuY3Rpb24gbm9vcCgpIHt9XG5cbmZ1bmN0aW9uIGNoYWluaW5nKCkge1xuICBmb3IgKHZhciBfbGVuID0gYXJndW1lbnRzLmxlbmd0aCwgZm5zID0gQXJyYXkoX2xlbiksIF9rZXkgPSAwOyBfa2V5IDwgX2xlbjsgX2tleSsrKSB7XG4gICAgZm5zW19rZXldID0gYXJndW1lbnRzW19rZXldO1xuICB9XG5cbiAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICBmb3IgKHZhciBfbGVuMiA9IGFyZ3VtZW50cy5sZW5ndGgsIGFyZ3MgPSBBcnJheShfbGVuMiksIF9rZXkyID0gMDsgX2tleTIgPCBfbGVuMjsgX2tleTIrKykge1xuICAgICAgYXJnc1tfa2V5Ml0gPSBhcmd1bWVudHNbX2tleTJdO1xuICAgIH1cblxuICAgIC8vIGVzbGludC1kaXNhYmxlLWxpbmVcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1saW5lXG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBmbnMubGVuZ3RoOyBpKyspIHtcbiAgICAgIGlmIChmbnNbaV0gJiYgdHlwZW9mIGZuc1tpXSA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICBmbnNbaV0uYXBwbHkodGhpcywgYXJncyk7XG4gICAgICB9XG4gICAgfVxuICB9O1xufVxuXG52YXIgU2VsZWN0ID0gZnVuY3Rpb24gKF9SZWFjdCRDb21wb25lbnQpIHtcbiAgX2luaGVyaXRzKFNlbGVjdCwgX1JlYWN0JENvbXBvbmVudCk7XG5cbiAgZnVuY3Rpb24gU2VsZWN0KHByb3BzKSB7XG4gICAgX2NsYXNzQ2FsbENoZWNrKHRoaXMsIFNlbGVjdCk7XG5cbiAgICB2YXIgX3RoaXMgPSBfcG9zc2libGVDb25zdHJ1Y3RvclJldHVybih0aGlzLCBfUmVhY3QkQ29tcG9uZW50LmNhbGwodGhpcywgcHJvcHMpKTtcblxuICAgIF9pbml0aWFsaXNlUHJvcHMuY2FsbChfdGhpcyk7XG5cbiAgICB2YXIgdmFsdWUgPSBfdGhpcy5nZXRWYWx1ZUZyb21Qcm9wcyhwcm9wcyk7XG4gICAgdmFyIG9wdGlvbnNJbmZvID0gX3RoaXMuZ2V0T3B0aW9uc0luZm9Gcm9tUHJvcHMocHJvcHMpO1xuICAgIHZhciBpbnB1dFZhbHVlID0gJyc7XG4gICAgaWYgKHByb3BzLmNvbWJvYm94KSB7XG4gICAgICBpbnB1dFZhbHVlID0gdmFsdWUubGVuZ3RoID8gX3RoaXMuZ2V0TGFiZWxCeVNpbmdsZVZhbHVlKHZhbHVlWzBdLCBvcHRpb25zSW5mbykgOiAnJztcbiAgICB9XG4gICAgdmFyIG9wZW4gPSBwcm9wcy5vcGVuO1xuICAgIGlmIChvcGVuID09PSB1bmRlZmluZWQpIHtcbiAgICAgIG9wZW4gPSBwcm9wcy5kZWZhdWx0T3BlbjtcbiAgICB9XG4gICAgX3RoaXMuc3RhdGUgPSB7XG4gICAgICB2YWx1ZTogdmFsdWUsXG4gICAgICBpbnB1dFZhbHVlOiBpbnB1dFZhbHVlLFxuICAgICAgb3Blbjogb3BlbixcbiAgICAgIG9wdGlvbnNJbmZvOiBvcHRpb25zSW5mb1xuICAgIH07XG4gICAgX3RoaXMuYWRqdXN0T3BlblN0YXRlKCk7XG4gICAgcmV0dXJuIF90aGlzO1xuICB9XG5cbiAgU2VsZWN0LnByb3RvdHlwZS5jb21wb25lbnREaWRNb3VudCA9IGZ1bmN0aW9uIGNvbXBvbmVudERpZE1vdW50KCkge1xuICAgIGlmICh0aGlzLnByb3BzLmF1dG9Gb2N1cykge1xuICAgICAgdGhpcy5mb2N1cygpO1xuICAgIH1cbiAgfTtcblxuICBTZWxlY3QucHJvdG90eXBlLmNvbXBvbmVudFdpbGxVcGRhdGUgPSBmdW5jdGlvbiBjb21wb25lbnRXaWxsVXBkYXRlKG5leHRQcm9wcywgbmV4dFN0YXRlKSB7XG4gICAgdGhpcy5wcm9wcyA9IG5leHRQcm9wcztcbiAgICB0aGlzLnN0YXRlID0gbmV4dFN0YXRlO1xuICAgIHRoaXMuYWRqdXN0T3BlblN0YXRlKCk7XG4gIH07XG5cbiAgU2VsZWN0LnByb3RvdHlwZS5jb21wb25lbnREaWRVcGRhdGUgPSBmdW5jdGlvbiBjb21wb25lbnREaWRVcGRhdGUoKSB7XG4gICAgaWYgKGlzTXVsdGlwbGVPclRhZ3ModGhpcy5wcm9wcykpIHtcbiAgICAgIHZhciBpbnB1dE5vZGUgPSB0aGlzLmdldElucHV0RE9NTm9kZSgpO1xuICAgICAgdmFyIG1pcnJvck5vZGUgPSB0aGlzLmdldElucHV0TWlycm9yRE9NTm9kZSgpO1xuICAgICAgaWYgKGlucHV0Tm9kZS52YWx1ZSkge1xuICAgICAgICBpbnB1dE5vZGUuc3R5bGUud2lkdGggPSAnJztcbiAgICAgICAgaW5wdXROb2RlLnN0eWxlLndpZHRoID0gbWlycm9yTm9kZS5jbGllbnRXaWR0aCArICdweCc7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBpbnB1dE5vZGUuc3R5bGUud2lkdGggPSAnJztcbiAgICAgIH1cbiAgICB9XG4gIH07XG5cbiAgU2VsZWN0LnByb3RvdHlwZS5jb21wb25lbnRXaWxsVW5tb3VudCA9IGZ1bmN0aW9uIGNvbXBvbmVudFdpbGxVbm1vdW50KCkge1xuICAgIHRoaXMuY2xlYXJGb2N1c1RpbWUoKTtcbiAgICB0aGlzLmNsZWFyQmx1clRpbWUoKTtcbiAgICB0aGlzLmNsZWFyQWRqdXN0VGltZXIoKTtcbiAgICBpZiAodGhpcy5kcm9wZG93bkNvbnRhaW5lcikge1xuICAgICAgUmVhY3RET00udW5tb3VudENvbXBvbmVudEF0Tm9kZSh0aGlzLmRyb3Bkb3duQ29udGFpbmVyKTtcbiAgICAgIGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQodGhpcy5kcm9wZG93bkNvbnRhaW5lcik7XG4gICAgICB0aGlzLmRyb3Bkb3duQ29udGFpbmVyID0gbnVsbDtcbiAgICB9XG4gIH07XG5cbiAgLy8gY29tYm9ib3ggaWdub3JlXG5cblxuICBTZWxlY3QucHJvdG90eXBlLmZvY3VzID0gZnVuY3Rpb24gZm9jdXMoKSB7XG4gICAgaWYgKGlzU2luZ2xlTW9kZSh0aGlzLnByb3BzKSkge1xuICAgICAgdGhpcy5zZWxlY3Rpb25SZWYuZm9jdXMoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5nZXRJbnB1dERPTU5vZGUoKS5mb2N1cygpO1xuICAgIH1cbiAgfTtcblxuICBTZWxlY3QucHJvdG90eXBlLmJsdXIgPSBmdW5jdGlvbiBibHVyKCkge1xuICAgIGlmIChpc1NpbmdsZU1vZGUodGhpcy5wcm9wcykpIHtcbiAgICAgIHRoaXMuc2VsZWN0aW9uUmVmLmJsdXIoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5nZXRJbnB1dERPTU5vZGUoKS5ibHVyKCk7XG4gICAgfVxuICB9O1xuXG4gIFNlbGVjdC5wcm90b3R5cGUucmVuZGVyQ2xlYXIgPSBmdW5jdGlvbiByZW5kZXJDbGVhcigpIHtcbiAgICB2YXIgX3Byb3BzID0gdGhpcy5wcm9wcyxcbiAgICAgICAgcHJlZml4Q2xzID0gX3Byb3BzLnByZWZpeENscyxcbiAgICAgICAgYWxsb3dDbGVhciA9IF9wcm9wcy5hbGxvd0NsZWFyO1xuICAgIHZhciBfc3RhdGUgPSB0aGlzLnN0YXRlLFxuICAgICAgICB2YWx1ZSA9IF9zdGF0ZS52YWx1ZSxcbiAgICAgICAgaW5wdXRWYWx1ZSA9IF9zdGF0ZS5pbnB1dFZhbHVlO1xuXG4gICAgdmFyIGNsZWFyID0gUmVhY3QuY3JlYXRlRWxlbWVudCgnc3BhbicsIF9leHRlbmRzKHtcbiAgICAgIGtleTogJ2NsZWFyJyxcbiAgICAgIG9uTW91c2VEb3duOiBwcmV2ZW50RGVmYXVsdEV2ZW50LFxuICAgICAgc3R5bGU6IFVOU0VMRUNUQUJMRV9TVFlMRVxuICAgIH0sIFVOU0VMRUNUQUJMRV9BVFRSSUJVVEUsIHtcbiAgICAgIGNsYXNzTmFtZTogcHJlZml4Q2xzICsgJy1zZWxlY3Rpb25fX2NsZWFyJyxcbiAgICAgIG9uQ2xpY2s6IHRoaXMub25DbGVhclNlbGVjdGlvblxuICAgIH0pKTtcbiAgICBpZiAoIWFsbG93Q2xlYXIpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBpZiAoaXNDb21ib2JveCh0aGlzLnByb3BzKSkge1xuICAgICAgaWYgKGlucHV0VmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIGNsZWFyO1xuICAgICAgfVxuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIGlmIChpbnB1dFZhbHVlIHx8IHZhbHVlLmxlbmd0aCkge1xuICAgICAgcmV0dXJuIGNsZWFyO1xuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbiAgfTtcblxuICBTZWxlY3QucHJvdG90eXBlLnJlbmRlciA9IGZ1bmN0aW9uIHJlbmRlcigpIHtcbiAgICB2YXIgX3Jvb3RDbHM7XG5cbiAgICB2YXIgcHJvcHMgPSB0aGlzLnByb3BzO1xuICAgIHZhciBtdWx0aXBsZSA9IGlzTXVsdGlwbGVPclRhZ3MocHJvcHMpO1xuICAgIHZhciBzdGF0ZSA9IHRoaXMuc3RhdGU7XG4gICAgdmFyIGNsYXNzTmFtZSA9IHByb3BzLmNsYXNzTmFtZSxcbiAgICAgICAgZGlzYWJsZWQgPSBwcm9wcy5kaXNhYmxlZCxcbiAgICAgICAgcHJlZml4Q2xzID0gcHJvcHMucHJlZml4Q2xzO1xuXG4gICAgdmFyIGN0cmxOb2RlID0gdGhpcy5yZW5kZXJUb3BDb250cm9sTm9kZSgpO1xuICAgIHZhciBleHRyYVNlbGVjdGlvblByb3BzID0ge307XG4gICAgdmFyIG9wZW4gPSB0aGlzLnN0YXRlLm9wZW47XG5cbiAgICB2YXIgb3B0aW9ucyA9IHRoaXMuX29wdGlvbnM7XG4gICAgaWYgKCFpc011bHRpcGxlT3JUYWdzT3JDb21ib2JveChwcm9wcykpIHtcbiAgICAgIGV4dHJhU2VsZWN0aW9uUHJvcHMgPSB7XG4gICAgICAgIG9uS2V5RG93bjogdGhpcy5vbktleURvd24sXG4gICAgICAgIHRhYkluZGV4OiBwcm9wcy5kaXNhYmxlZCA/IC0xIDogMFxuICAgICAgfTtcbiAgICB9XG4gICAgdmFyIHJvb3RDbHMgPSAoX3Jvb3RDbHMgPSB7fSwgX3Jvb3RDbHNbY2xhc3NOYW1lXSA9ICEhY2xhc3NOYW1lLCBfcm9vdENsc1twcmVmaXhDbHNdID0gMSwgX3Jvb3RDbHNbcHJlZml4Q2xzICsgJy1vcGVuJ10gPSBvcGVuLCBfcm9vdENsc1twcmVmaXhDbHMgKyAnLWZvY3VzZWQnXSA9IG9wZW4gfHwgISF0aGlzLl9mb2N1c2VkLCBfcm9vdENsc1twcmVmaXhDbHMgKyAnLWNvbWJvYm94J10gPSBpc0NvbWJvYm94KHByb3BzKSwgX3Jvb3RDbHNbcHJlZml4Q2xzICsgJy1kaXNhYmxlZCddID0gZGlzYWJsZWQsIF9yb290Q2xzW3ByZWZpeENscyArICctZW5hYmxlZCddID0gIWRpc2FibGVkLCBfcm9vdENsc1twcmVmaXhDbHMgKyAnLWFsbG93LWNsZWFyJ10gPSAhIXByb3BzLmFsbG93Q2xlYXIsIF9yb290Q2xzKTtcbiAgICByZXR1cm4gUmVhY3QuY3JlYXRlRWxlbWVudChcbiAgICAgIFNlbGVjdFRyaWdnZXIsXG4gICAgICB7XG4gICAgICAgIG9uUG9wdXBGb2N1czogdGhpcy5vblBvcHVwRm9jdXMsXG4gICAgICAgIG9uTW91c2VFbnRlcjogdGhpcy5wcm9wcy5vbk1vdXNlRW50ZXIsXG4gICAgICAgIG9uTW91c2VMZWF2ZTogdGhpcy5wcm9wcy5vbk1vdXNlTGVhdmUsXG4gICAgICAgIGRyb3Bkb3duQWxpZ246IHByb3BzLmRyb3Bkb3duQWxpZ24sXG4gICAgICAgIGRyb3Bkb3duQ2xhc3NOYW1lOiBwcm9wcy5kcm9wZG93bkNsYXNzTmFtZSxcbiAgICAgICAgZHJvcGRvd25NYXRjaFNlbGVjdFdpZHRoOiBwcm9wcy5kcm9wZG93bk1hdGNoU2VsZWN0V2lkdGgsXG4gICAgICAgIGRlZmF1bHRBY3RpdmVGaXJzdE9wdGlvbjogcHJvcHMuZGVmYXVsdEFjdGl2ZUZpcnN0T3B0aW9uLFxuICAgICAgICBkcm9wZG93bk1lbnVTdHlsZTogcHJvcHMuZHJvcGRvd25NZW51U3R5bGUsXG4gICAgICAgIHRyYW5zaXRpb25OYW1lOiBwcm9wcy50cmFuc2l0aW9uTmFtZSxcbiAgICAgICAgYW5pbWF0aW9uOiBwcm9wcy5hbmltYXRpb24sXG4gICAgICAgIHByZWZpeENsczogcHJvcHMucHJlZml4Q2xzLFxuICAgICAgICBkcm9wZG93blN0eWxlOiBwcm9wcy5kcm9wZG93blN0eWxlLFxuICAgICAgICBjb21ib2JveDogcHJvcHMuY29tYm9ib3gsXG4gICAgICAgIHNob3dTZWFyY2g6IHByb3BzLnNob3dTZWFyY2gsXG4gICAgICAgIG9wdGlvbnM6IG9wdGlvbnMsXG4gICAgICAgIG11bHRpcGxlOiBtdWx0aXBsZSxcbiAgICAgICAgZGlzYWJsZWQ6IGRpc2FibGVkLFxuICAgICAgICB2aXNpYmxlOiBvcGVuLFxuICAgICAgICBpbnB1dFZhbHVlOiBzdGF0ZS5pbnB1dFZhbHVlLFxuICAgICAgICB2YWx1ZTogc3RhdGUudmFsdWUsXG4gICAgICAgIGJhY2tmaWxsVmFsdWU6IHN0YXRlLmJhY2tmaWxsVmFsdWUsXG4gICAgICAgIGZpcnN0QWN0aXZlVmFsdWU6IHByb3BzLmZpcnN0QWN0aXZlVmFsdWUsXG4gICAgICAgIG9uRHJvcGRvd25WaXNpYmxlQ2hhbmdlOiB0aGlzLm9uRHJvcGRvd25WaXNpYmxlQ2hhbmdlLFxuICAgICAgICBnZXRQb3B1cENvbnRhaW5lcjogcHJvcHMuZ2V0UG9wdXBDb250YWluZXIsXG4gICAgICAgIG9uTWVudVNlbGVjdDogdGhpcy5vbk1lbnVTZWxlY3QsXG4gICAgICAgIG9uTWVudURlc2VsZWN0OiB0aGlzLm9uTWVudURlc2VsZWN0LFxuICAgICAgICBvblBvcHVwU2Nyb2xsOiBwcm9wcy5vblBvcHVwU2Nyb2xsLFxuICAgICAgICBzaG93QWN0aW9uOiBwcm9wcy5zaG93QWN0aW9uLFxuICAgICAgICByZWY6IHNhdmVSZWYodGhpcywgJ3NlbGVjdFRyaWdnZXJSZWYnKVxuICAgICAgfSxcbiAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXG4gICAgICAgICdkaXYnLFxuICAgICAgICB7XG4gICAgICAgICAgc3R5bGU6IHByb3BzLnN0eWxlLFxuICAgICAgICAgIHJlZjogc2F2ZVJlZih0aGlzLCAncm9vdFJlZicpLFxuICAgICAgICAgIG9uQmx1cjogdGhpcy5vbk91dGVyQmx1cixcbiAgICAgICAgICBvbkZvY3VzOiB0aGlzLm9uT3V0ZXJGb2N1cyxcbiAgICAgICAgICBjbGFzc05hbWU6IGNsYXNzbmFtZXMocm9vdENscylcbiAgICAgICAgfSxcbiAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcbiAgICAgICAgICAnZGl2JyxcbiAgICAgICAgICBfZXh0ZW5kcyh7XG4gICAgICAgICAgICByZWY6IHNhdmVSZWYodGhpcywgJ3NlbGVjdGlvblJlZicpLFxuICAgICAgICAgICAga2V5OiAnc2VsZWN0aW9uJyxcbiAgICAgICAgICAgIGNsYXNzTmFtZTogcHJlZml4Q2xzICsgJy1zZWxlY3Rpb25cXG4gICAgICAgICAgICAnICsgcHJlZml4Q2xzICsgJy1zZWxlY3Rpb24tLScgKyAobXVsdGlwbGUgPyAnbXVsdGlwbGUnIDogJ3NpbmdsZScpLFxuICAgICAgICAgICAgcm9sZTogJ2NvbWJvYm94JyxcbiAgICAgICAgICAgICdhcmlhLWF1dG9jb21wbGV0ZSc6ICdsaXN0JyxcbiAgICAgICAgICAgICdhcmlhLWhhc3BvcHVwJzogJ3RydWUnLFxuICAgICAgICAgICAgJ2FyaWEtZXhwYW5kZWQnOiBvcGVuXG4gICAgICAgICAgfSwgZXh0cmFTZWxlY3Rpb25Qcm9wcyksXG4gICAgICAgICAgY3RybE5vZGUsXG4gICAgICAgICAgdGhpcy5yZW5kZXJDbGVhcigpLFxuICAgICAgICAgIG11bHRpcGxlIHx8ICFwcm9wcy5zaG93QXJyb3cgPyBudWxsIDogUmVhY3QuY3JlYXRlRWxlbWVudChcbiAgICAgICAgICAgICdzcGFuJyxcbiAgICAgICAgICAgIF9leHRlbmRzKHtcbiAgICAgICAgICAgICAga2V5OiAnYXJyb3cnLFxuICAgICAgICAgICAgICBjbGFzc05hbWU6IHByZWZpeENscyArICctYXJyb3cnLFxuICAgICAgICAgICAgICBzdHlsZTogVU5TRUxFQ1RBQkxFX1NUWUxFXG4gICAgICAgICAgICB9LCBVTlNFTEVDVEFCTEVfQVRUUklCVVRFLCB7XG4gICAgICAgICAgICAgIG9uQ2xpY2s6IHRoaXMub25BcnJvd0NsaWNrXG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoJ2InLCBudWxsKVxuICAgICAgICAgIClcbiAgICAgICAgKVxuICAgICAgKVxuICAgICk7XG4gIH07XG5cbiAgcmV0dXJuIFNlbGVjdDtcbn0oUmVhY3QuQ29tcG9uZW50KTtcblxuU2VsZWN0LnByb3BUeXBlcyA9IFNlbGVjdFByb3BUeXBlcztcblNlbGVjdC5kZWZhdWx0UHJvcHMgPSB7XG4gIHByZWZpeENsczogJ3JjLXNlbGVjdCcsXG4gIGRlZmF1bHRPcGVuOiBmYWxzZSxcbiAgbGFiZWxJblZhbHVlOiBmYWxzZSxcbiAgZGVmYXVsdEFjdGl2ZUZpcnN0T3B0aW9uOiB0cnVlLFxuICBzaG93U2VhcmNoOiB0cnVlLFxuICBhbGxvd0NsZWFyOiBmYWxzZSxcbiAgcGxhY2Vob2xkZXI6ICcnLFxuICBvbkNoYW5nZTogbm9vcCxcbiAgb25Gb2N1czogbm9vcCxcbiAgb25CbHVyOiBub29wLFxuICBvblNlbGVjdDogbm9vcCxcbiAgb25TZWFyY2g6IG5vb3AsXG4gIG9uRGVzZWxlY3Q6IG5vb3AsXG4gIG9uSW5wdXRLZXlEb3duOiBub29wLFxuICBzaG93QXJyb3c6IHRydWUsXG4gIGRyb3Bkb3duTWF0Y2hTZWxlY3RXaWR0aDogdHJ1ZSxcbiAgZHJvcGRvd25TdHlsZToge30sXG4gIGRyb3Bkb3duTWVudVN0eWxlOiB7fSxcbiAgb3B0aW9uRmlsdGVyUHJvcDogJ3ZhbHVlJyxcbiAgb3B0aW9uTGFiZWxQcm9wOiAndmFsdWUnLFxuICBub3RGb3VuZENvbnRlbnQ6ICdOb3QgRm91bmQnLFxuICBiYWNrZmlsbDogZmFsc2UsXG4gIHNob3dBY3Rpb246IFsnY2xpY2snXSxcbiAgdG9rZW5TZXBhcmF0b3JzOiBbXVxufTtcblxudmFyIF9pbml0aWFsaXNlUHJvcHMgPSBmdW5jdGlvbiBfaW5pdGlhbGlzZVByb3BzKCkge1xuICB2YXIgX3RoaXMyID0gdGhpcztcblxuICB0aGlzLmNvbXBvbmVudFdpbGxSZWNlaXZlUHJvcHMgPSBmdW5jdGlvbiAobmV4dFByb3BzKSB7XG4gICAgdmFyIG9wdGlvbnNJbmZvID0gX3RoaXMyLmdldE9wdGlvbnNJbmZvRnJvbVByb3BzKG5leHRQcm9wcyk7XG4gICAgX3RoaXMyLnNldFN0YXRlKHtcbiAgICAgIG9wdGlvbnNJbmZvOiBvcHRpb25zSW5mb1xuICAgIH0pO1xuICAgIGlmICgndmFsdWUnIGluIG5leHRQcm9wcykge1xuICAgICAgdmFyIHZhbHVlID0gX3RoaXMyLmdldFZhbHVlRnJvbVByb3BzKG5leHRQcm9wcyk7XG4gICAgICBfdGhpczIuc2V0U3RhdGUoe1xuICAgICAgICB2YWx1ZTogdmFsdWVcbiAgICAgIH0sIF90aGlzMi5mb3JjZVBvcHVwQWxpZ24pO1xuICAgICAgaWYgKG5leHRQcm9wcy5jb21ib2JveCkge1xuICAgICAgICBfdGhpczIuc2V0U3RhdGUoe1xuICAgICAgICAgIGlucHV0VmFsdWU6IHZhbHVlLmxlbmd0aCA/IF90aGlzMi5nZXRMYWJlbEJ5U2luZ2xlVmFsdWUodmFsdWVbMF0sIG9wdGlvbnNJbmZvKSA6ICcnXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgfTtcblxuICB0aGlzLm9uSW5wdXRDaGFuZ2UgPSBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICB2YXIgdG9rZW5TZXBhcmF0b3JzID0gX3RoaXMyLnByb3BzLnRva2VuU2VwYXJhdG9ycztcblxuICAgIHZhciB2YWwgPSBldmVudC50YXJnZXQudmFsdWU7XG4gICAgaWYgKGlzTXVsdGlwbGVPclRhZ3MoX3RoaXMyLnByb3BzKSAmJiB0b2tlblNlcGFyYXRvcnMubGVuZ3RoICYmIGluY2x1ZGVzU2VwYXJhdG9ycyh2YWwsIHRva2VuU2VwYXJhdG9ycykpIHtcbiAgICAgIHZhciBuZXh0VmFsdWUgPSBfdGhpczIuZ2V0VmFsdWVCeUlucHV0KHZhbCk7XG4gICAgICBpZiAobmV4dFZhbHVlICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgX3RoaXMyLmZpcmVDaGFuZ2UobmV4dFZhbHVlKTtcbiAgICAgIH1cbiAgICAgIF90aGlzMi5zZXRPcGVuU3RhdGUoZmFsc2UsIHRydWUpO1xuICAgICAgX3RoaXMyLnNldElucHV0VmFsdWUoJycsIGZhbHNlKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgX3RoaXMyLnNldElucHV0VmFsdWUodmFsKTtcbiAgICBfdGhpczIuc2V0U3RhdGUoe1xuICAgICAgb3BlbjogdHJ1ZVxuICAgIH0pO1xuICAgIGlmIChpc0NvbWJvYm94KF90aGlzMi5wcm9wcykpIHtcbiAgICAgIF90aGlzMi5maXJlQ2hhbmdlKFt2YWxdKTtcbiAgICB9XG4gIH07XG5cbiAgdGhpcy5vbkRyb3Bkb3duVmlzaWJsZUNoYW5nZSA9IGZ1bmN0aW9uIChvcGVuKSB7XG4gICAgaWYgKG9wZW4gJiYgIV90aGlzMi5fZm9jdXNlZCkge1xuICAgICAgX3RoaXMyLmNsZWFyQmx1clRpbWUoKTtcbiAgICAgIF90aGlzMi50aW1lb3V0Rm9jdXMoKTtcbiAgICAgIF90aGlzMi5fZm9jdXNlZCA9IHRydWU7XG4gICAgICBfdGhpczIudXBkYXRlRm9jdXNDbGFzc05hbWUoKTtcbiAgICB9XG4gICAgX3RoaXMyLnNldE9wZW5TdGF0ZShvcGVuKTtcbiAgfTtcblxuICB0aGlzLm9uS2V5RG93biA9IGZ1bmN0aW9uIChldmVudCkge1xuICAgIHZhciBwcm9wcyA9IF90aGlzMi5wcm9wcztcbiAgICBpZiAocHJvcHMuZGlzYWJsZWQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdmFyIGtleUNvZGUgPSBldmVudC5rZXlDb2RlO1xuICAgIGlmIChfdGhpczIuc3RhdGUub3BlbiAmJiAhX3RoaXMyLmdldElucHV0RE9NTm9kZSgpKSB7XG4gICAgICBfdGhpczIub25JbnB1dEtleURvd24oZXZlbnQpO1xuICAgIH0gZWxzZSBpZiAoa2V5Q29kZSA9PT0gS2V5Q29kZS5FTlRFUiB8fCBrZXlDb2RlID09PSBLZXlDb2RlLkRPV04pIHtcbiAgICAgIF90aGlzMi5zZXRPcGVuU3RhdGUodHJ1ZSk7XG4gICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIH1cbiAgfTtcblxuICB0aGlzLm9uSW5wdXRLZXlEb3duID0gZnVuY3Rpb24gKGV2ZW50KSB7XG4gICAgdmFyIHByb3BzID0gX3RoaXMyLnByb3BzO1xuICAgIGlmIChwcm9wcy5kaXNhYmxlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB2YXIgc3RhdGUgPSBfdGhpczIuc3RhdGU7XG4gICAgdmFyIGtleUNvZGUgPSBldmVudC5rZXlDb2RlO1xuICAgIGlmIChpc011bHRpcGxlT3JUYWdzKHByb3BzKSAmJiAhZXZlbnQudGFyZ2V0LnZhbHVlICYmIGtleUNvZGUgPT09IEtleUNvZGUuQkFDS1NQQUNFKSB7XG4gICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgdmFyIHZhbHVlID0gc3RhdGUudmFsdWU7XG5cbiAgICAgIGlmICh2YWx1ZS5sZW5ndGgpIHtcbiAgICAgICAgX3RoaXMyLnJlbW92ZVNlbGVjdGVkKHZhbHVlW3ZhbHVlLmxlbmd0aCAtIDFdKTtcbiAgICAgIH1cbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKGtleUNvZGUgPT09IEtleUNvZGUuRE9XTikge1xuICAgICAgaWYgKCFzdGF0ZS5vcGVuKSB7XG4gICAgICAgIF90aGlzMi5vcGVuSWZIYXNDaGlsZHJlbigpO1xuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoa2V5Q29kZSA9PT0gS2V5Q29kZS5FU0MpIHtcbiAgICAgIGlmIChzdGF0ZS5vcGVuKSB7XG4gICAgICAgIF90aGlzMi5zZXRPcGVuU3RhdGUoZmFsc2UpO1xuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgIH1cbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAoc3RhdGUub3Blbikge1xuICAgICAgdmFyIG1lbnUgPSBfdGhpczIuc2VsZWN0VHJpZ2dlclJlZi5nZXRJbm5lck1lbnUoKTtcbiAgICAgIGlmIChtZW51ICYmIG1lbnUub25LZXlEb3duKGV2ZW50LCBfdGhpczIuaGFuZGxlQmFja2ZpbGwpKSB7XG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgfVxuICAgIH1cbiAgfTtcblxuICB0aGlzLm9uTWVudVNlbGVjdCA9IGZ1bmN0aW9uIChfcmVmKSB7XG4gICAgdmFyIGl0ZW0gPSBfcmVmLml0ZW07XG5cbiAgICB2YXIgdmFsdWUgPSBfdGhpczIuc3RhdGUudmFsdWU7XG4gICAgdmFyIHByb3BzID0gX3RoaXMyLnByb3BzO1xuICAgIHZhciBzZWxlY3RlZFZhbHVlID0gZ2V0VmFsdWVQcm9wVmFsdWUoaXRlbSk7XG4gICAgdmFyIGxhc3RWYWx1ZSA9IHZhbHVlW3ZhbHVlLmxlbmd0aCAtIDFdO1xuICAgIF90aGlzMi5maXJlU2VsZWN0KHNlbGVjdGVkVmFsdWUpO1xuICAgIGlmIChpc011bHRpcGxlT3JUYWdzKHByb3BzKSkge1xuICAgICAgaWYgKGZpbmRJbmRleEluVmFsdWVCeVNpbmdsZVZhbHVlKHZhbHVlLCBzZWxlY3RlZFZhbHVlKSAhPT0gLTEpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgdmFsdWUgPSB2YWx1ZS5jb25jYXQoW3NlbGVjdGVkVmFsdWVdKTtcbiAgICB9IGVsc2Uge1xuICAgICAgaWYgKGlzQ29tYm9ib3gocHJvcHMpKSB7XG4gICAgICAgIF90aGlzMi5za2lwQWRqdXN0T3BlbiA9IHRydWU7XG4gICAgICAgIF90aGlzMi5jbGVhckFkanVzdFRpbWVyKCk7XG4gICAgICAgIF90aGlzMi5za2lwQWRqdXN0T3BlblRpbWVyID0gc2V0VGltZW91dChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgX3RoaXMyLnNraXBBZGp1c3RPcGVuID0gZmFsc2U7XG4gICAgICAgIH0sIDApO1xuICAgICAgfVxuICAgICAgaWYgKGxhc3RWYWx1ZSAmJiBsYXN0VmFsdWUgPT09IHNlbGVjdGVkVmFsdWUgJiYgc2VsZWN0ZWRWYWx1ZSAhPT0gX3RoaXMyLnN0YXRlLmJhY2tmaWxsVmFsdWUpIHtcbiAgICAgICAgX3RoaXMyLnNldE9wZW5TdGF0ZShmYWxzZSwgdHJ1ZSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIHZhbHVlID0gW3NlbGVjdGVkVmFsdWVdO1xuICAgICAgX3RoaXMyLnNldE9wZW5TdGF0ZShmYWxzZSwgdHJ1ZSk7XG4gICAgfVxuICAgIF90aGlzMi5maXJlQ2hhbmdlKHZhbHVlKTtcbiAgICB2YXIgaW5wdXRWYWx1ZSA9IHZvaWQgMDtcbiAgICBpZiAoaXNDb21ib2JveChwcm9wcykpIHtcbiAgICAgIGlucHV0VmFsdWUgPSBnZXRQcm9wVmFsdWUoaXRlbSwgcHJvcHMub3B0aW9uTGFiZWxQcm9wKTtcbiAgICB9IGVsc2Uge1xuICAgICAgaW5wdXRWYWx1ZSA9ICcnO1xuICAgIH1cbiAgICBfdGhpczIuc2V0SW5wdXRWYWx1ZShpbnB1dFZhbHVlLCBmYWxzZSk7XG4gIH07XG5cbiAgdGhpcy5vbk1lbnVEZXNlbGVjdCA9IGZ1bmN0aW9uIChfcmVmMikge1xuICAgIHZhciBpdGVtID0gX3JlZjIuaXRlbSxcbiAgICAgICAgZG9tRXZlbnQgPSBfcmVmMi5kb21FdmVudDtcblxuICAgIGlmIChkb21FdmVudC50eXBlID09PSAnY2xpY2snKSB7XG4gICAgICBfdGhpczIucmVtb3ZlU2VsZWN0ZWQoZ2V0VmFsdWVQcm9wVmFsdWUoaXRlbSkpO1xuICAgIH1cbiAgICBfdGhpczIuc2V0SW5wdXRWYWx1ZSgnJywgZmFsc2UpO1xuICB9O1xuXG4gIHRoaXMub25BcnJvd0NsaWNrID0gZnVuY3Rpb24gKGUpIHtcbiAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBpZiAoIV90aGlzMi5wcm9wcy5kaXNhYmxlZCkge1xuICAgICAgX3RoaXMyLnNldE9wZW5TdGF0ZSghX3RoaXMyLnN0YXRlLm9wZW4sICFfdGhpczIuc3RhdGUub3Blbik7XG4gICAgfVxuICB9O1xuXG4gIHRoaXMub25QbGFjZWhvbGRlckNsaWNrID0gZnVuY3Rpb24gKCkge1xuICAgIGlmIChfdGhpczIuZ2V0SW5wdXRET01Ob2RlKCkpIHtcbiAgICAgIF90aGlzMi5nZXRJbnB1dERPTU5vZGUoKS5mb2N1cygpO1xuICAgIH1cbiAgfTtcblxuICB0aGlzLm9uT3V0ZXJGb2N1cyA9IGZ1bmN0aW9uIChlKSB7XG4gICAgaWYgKF90aGlzMi5wcm9wcy5kaXNhYmxlZCkge1xuICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBfdGhpczIuY2xlYXJCbHVyVGltZSgpO1xuICAgIGlmICghaXNNdWx0aXBsZU9yVGFnc09yQ29tYm9ib3goX3RoaXMyLnByb3BzKSAmJiBlLnRhcmdldCA9PT0gX3RoaXMyLmdldElucHV0RE9NTm9kZSgpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmIChfdGhpczIuX2ZvY3VzZWQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgX3RoaXMyLl9mb2N1c2VkID0gdHJ1ZTtcbiAgICBfdGhpczIudXBkYXRlRm9jdXNDbGFzc05hbWUoKTtcbiAgICBfdGhpczIudGltZW91dEZvY3VzKCk7XG4gIH07XG5cbiAgdGhpcy5vblBvcHVwRm9jdXMgPSBmdW5jdGlvbiAoKSB7XG4gICAgLy8gZml4IGllIHNjcm9sbGJhciwgZm9jdXMgZWxlbWVudCBhZ2FpblxuICAgIF90aGlzMi5tYXliZUZvY3VzKHRydWUsIHRydWUpO1xuICB9O1xuXG4gIHRoaXMub25PdXRlckJsdXIgPSBmdW5jdGlvbiAoZSkge1xuICAgIGlmIChfdGhpczIucHJvcHMuZGlzYWJsZWQpIHtcbiAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgX3RoaXMyLmJsdXJUaW1lciA9IHNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xuICAgICAgX3RoaXMyLl9mb2N1c2VkID0gZmFsc2U7XG4gICAgICBfdGhpczIudXBkYXRlRm9jdXNDbGFzc05hbWUoKTtcbiAgICAgIHZhciBwcm9wcyA9IF90aGlzMi5wcm9wcztcbiAgICAgIHZhciB2YWx1ZSA9IF90aGlzMi5zdGF0ZS52YWx1ZTtcbiAgICAgIHZhciBpbnB1dFZhbHVlID0gX3RoaXMyLnN0YXRlLmlucHV0VmFsdWU7XG5cbiAgICAgIGlmIChpc1NpbmdsZU1vZGUocHJvcHMpICYmIHByb3BzLnNob3dTZWFyY2ggJiYgaW5wdXRWYWx1ZSAmJiBwcm9wcy5kZWZhdWx0QWN0aXZlRmlyc3RPcHRpb24pIHtcbiAgICAgICAgdmFyIG9wdGlvbnMgPSBfdGhpczIuX29wdGlvbnMgfHwgW107XG4gICAgICAgIGlmIChvcHRpb25zLmxlbmd0aCkge1xuICAgICAgICAgIHZhciBmaXJzdE9wdGlvbiA9IGZpbmRGaXJzdE1lbnVJdGVtKG9wdGlvbnMpO1xuICAgICAgICAgIGlmIChmaXJzdE9wdGlvbikge1xuICAgICAgICAgICAgdmFsdWUgPSBbZ2V0VmFsdWVQcm9wVmFsdWUoZmlyc3RPcHRpb24pXTtcbiAgICAgICAgICAgIF90aGlzMi5maXJlQ2hhbmdlKHZhbHVlKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBpZiAoaXNNdWx0aXBsZU9yVGFncyhwcm9wcykgJiYgaW5wdXRWYWx1ZSkge1xuICAgICAgICAvLyB3aHkgbm90IHVzZSBzZXRTdGF0ZT9cbiAgICAgICAgX3RoaXMyLnN0YXRlLmlucHV0VmFsdWUgPSBfdGhpczIuZ2V0SW5wdXRET01Ob2RlKCkudmFsdWUgPSAnJztcblxuICAgICAgICB2YWx1ZSA9IF90aGlzMi5nZXRWYWx1ZUJ5SW5wdXQoaW5wdXRWYWx1ZSk7XG4gICAgICAgIGlmICh2YWx1ZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgX3RoaXMyLmZpcmVDaGFuZ2UodmFsdWUpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBwcm9wcy5vbkJsdXIoX3RoaXMyLmdldFZMRm9yT25DaGFuZ2UodmFsdWUpKTtcbiAgICAgIF90aGlzMi5zZXRPcGVuU3RhdGUoZmFsc2UpO1xuICAgIH0sIDEwKTtcbiAgfTtcblxuICB0aGlzLm9uQ2xlYXJTZWxlY3Rpb24gPSBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICB2YXIgcHJvcHMgPSBfdGhpczIucHJvcHM7XG4gICAgdmFyIHN0YXRlID0gX3RoaXMyLnN0YXRlO1xuICAgIGlmIChwcm9wcy5kaXNhYmxlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB2YXIgaW5wdXRWYWx1ZSA9IHN0YXRlLmlucHV0VmFsdWUsXG4gICAgICAgIHZhbHVlID0gc3RhdGUudmFsdWU7XG5cbiAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICBpZiAoaW5wdXRWYWx1ZSB8fCB2YWx1ZS5sZW5ndGgpIHtcbiAgICAgIGlmICh2YWx1ZS5sZW5ndGgpIHtcbiAgICAgICAgX3RoaXMyLmZpcmVDaGFuZ2UoW10pO1xuICAgICAgfVxuICAgICAgX3RoaXMyLnNldE9wZW5TdGF0ZShmYWxzZSwgdHJ1ZSk7XG4gICAgICBpZiAoaW5wdXRWYWx1ZSkge1xuICAgICAgICBfdGhpczIuc2V0SW5wdXRWYWx1ZSgnJyk7XG4gICAgICB9XG4gICAgfVxuICB9O1xuXG4gIHRoaXMub25DaG9pY2VBbmltYXRpb25MZWF2ZSA9IGZ1bmN0aW9uICgpIHtcbiAgICBfdGhpczIuZm9yY2VQb3B1cEFsaWduKCk7XG4gIH07XG5cbiAgdGhpcy5nZXRWYWx1ZUZyb21Qcm9wcyA9IGZ1bmN0aW9uIChwcm9wcykge1xuICAgIHZhciB2YWx1ZSA9IFtdO1xuICAgIGlmICgndmFsdWUnIGluIHByb3BzKSB7XG4gICAgICB2YWx1ZSA9IHRvQXJyYXkocHJvcHMudmFsdWUpO1xuICAgIH0gZWxzZSB7XG4gICAgICB2YWx1ZSA9IHRvQXJyYXkocHJvcHMuZGVmYXVsdFZhbHVlKTtcbiAgICB9XG4gICAgaWYgKHByb3BzLmxhYmVsSW5WYWx1ZSkge1xuICAgICAgdmFsdWUgPSB2YWx1ZS5tYXAoZnVuY3Rpb24gKHYpIHtcbiAgICAgICAgcmV0dXJuIHYua2V5O1xuICAgICAgfSk7XG4gICAgfVxuICAgIHJldHVybiB2YWx1ZTtcbiAgfTtcblxuICB0aGlzLmdldE9wdGlvbnNJbmZvRnJvbVByb3BzID0gZnVuY3Rpb24gKHByb3BzKSB7XG4gICAgdmFyIG9wdGlvbnMgPSBfdGhpczIuZ2V0T3B0aW9uc0Zyb21DaGlsZHJlbihwcm9wcy5jaGlsZHJlbik7XG4gICAgdmFyIG9sZE9wdGlvbnNJbmZvID0gX3RoaXMyLnN0YXRlID8gX3RoaXMyLnN0YXRlLm9wdGlvbnNJbmZvIDoge307XG4gICAgdmFyIHZhbHVlID0gX3RoaXMyLnN0YXRlID8gX3RoaXMyLnN0YXRlLnZhbHVlIDogW107XG4gICAgdmFyIG9wdGlvbnNJbmZvID0ge307XG4gICAgb3B0aW9ucy5mb3JFYWNoKGZ1bmN0aW9uIChvcHRpb24pIHtcbiAgICAgIHZhciBzaW5nbGVWYWx1ZSA9IGdldFZhbHVlUHJvcFZhbHVlKG9wdGlvbik7XG4gICAgICBvcHRpb25zSW5mb1tnZXRNYXBLZXkoc2luZ2xlVmFsdWUpXSA9IHtcbiAgICAgICAgb3B0aW9uOiBvcHRpb24sXG4gICAgICAgIHZhbHVlOiBzaW5nbGVWYWx1ZSxcbiAgICAgICAgbGFiZWw6IF90aGlzMi5nZXRMYWJlbEZyb21PcHRpb24ob3B0aW9uKSxcbiAgICAgICAgdGl0bGU6IG9wdGlvbi5wcm9wcy50aXRsZVxuICAgICAgfTtcbiAgICB9KTtcbiAgICB2YWx1ZS5mb3JFYWNoKGZ1bmN0aW9uICh2KSB7XG4gICAgICB2YXIga2V5ID0gZ2V0TWFwS2V5KHYpO1xuICAgICAgaWYgKCFvcHRpb25zSW5mb1trZXldKSB7XG4gICAgICAgIG9wdGlvbnNJbmZvW2tleV0gPSBvbGRPcHRpb25zSW5mb1trZXldO1xuICAgICAgfVxuICAgIH0pO1xuICAgIHJldHVybiBvcHRpb25zSW5mbztcbiAgfTtcblxuICB0aGlzLmdldE9wdGlvbkluZm9CeVNpbmdsZVZhbHVlID0gZnVuY3Rpb24gKHZhbHVlLCBvcHRpb25zSW5mbykge1xuICAgIHZhciBpbmZvID0gdm9pZCAwO1xuICAgIG9wdGlvbnNJbmZvID0gb3B0aW9uc0luZm8gfHwgX3RoaXMyLnN0YXRlLm9wdGlvbnNJbmZvO1xuICAgIGlmIChvcHRpb25zSW5mb1tnZXRNYXBLZXkodmFsdWUpXSkge1xuICAgICAgaW5mbyA9IG9wdGlvbnNJbmZvW2dldE1hcEtleSh2YWx1ZSldO1xuICAgIH1cbiAgICBpZiAoaW5mbykge1xuICAgICAgcmV0dXJuIGluZm87XG4gICAgfVxuICAgIHZhciBkZWZhdWx0TGFiZWwgPSB2YWx1ZTtcbiAgICBpZiAoX3RoaXMyLnByb3BzLmxhYmVsSW5WYWx1ZSkge1xuICAgICAgdmFyIGxhYmVsID0gZ2V0TGFiZWxGcm9tUHJvcHNWYWx1ZShfdGhpczIucHJvcHMudmFsdWUsIHZhbHVlKTtcbiAgICAgIGlmIChsYWJlbCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIGRlZmF1bHRMYWJlbCA9IGxhYmVsO1xuICAgICAgfVxuICAgIH1cbiAgICB2YXIgZGVmYXVsdEluZm8gPSB7XG4gICAgICBvcHRpb246IFJlYWN0LmNyZWF0ZUVsZW1lbnQoXG4gICAgICAgIE9wdGlvbixcbiAgICAgICAgeyB2YWx1ZTogdmFsdWUsIGtleTogdmFsdWUgfSxcbiAgICAgICAgdmFsdWVcbiAgICAgICksXG4gICAgICB2YWx1ZTogdmFsdWUsXG4gICAgICBsYWJlbDogZGVmYXVsdExhYmVsXG4gICAgfTtcbiAgICByZXR1cm4gZGVmYXVsdEluZm87XG4gIH07XG5cbiAgdGhpcy5nZXRPcHRpb25CeVNpbmdsZVZhbHVlID0gZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgdmFyIF9nZXRPcHRpb25JbmZvQnlTaW5nbCA9IF90aGlzMi5nZXRPcHRpb25JbmZvQnlTaW5nbGVWYWx1ZSh2YWx1ZSksXG4gICAgICAgIG9wdGlvbiA9IF9nZXRPcHRpb25JbmZvQnlTaW5nbC5vcHRpb247XG5cbiAgICByZXR1cm4gb3B0aW9uO1xuICB9O1xuXG4gIHRoaXMuZ2V0T3B0aW9uc0J5U2luZ2xlVmFsdWUgPSBmdW5jdGlvbiAodmFsdWVzKSB7XG4gICAgcmV0dXJuIHZhbHVlcy5tYXAoZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICByZXR1cm4gX3RoaXMyLmdldE9wdGlvbkJ5U2luZ2xlVmFsdWUodmFsdWUpO1xuICAgIH0pO1xuICB9O1xuXG4gIHRoaXMuZ2V0T3B0aW9uc0Zyb21DaGlsZHJlbiA9IGZ1bmN0aW9uIChjaGlsZHJlbikge1xuICAgIHZhciBvcHRpb25zID0gYXJndW1lbnRzLmxlbmd0aCA+IDEgJiYgYXJndW1lbnRzWzFdICE9PSB1bmRlZmluZWQgPyBhcmd1bWVudHNbMV0gOiBbXTtcblxuICAgIFJlYWN0LkNoaWxkcmVuLmZvckVhY2goY2hpbGRyZW4sIGZ1bmN0aW9uIChjaGlsZCkge1xuICAgICAgaWYgKCFjaGlsZCkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAoY2hpbGQudHlwZS5pc1NlbGVjdE9wdEdyb3VwKSB7XG4gICAgICAgIF90aGlzMi5nZXRPcHRpb25zRnJvbUNoaWxkcmVuKGNoaWxkLnByb3BzLmNoaWxkcmVuLCBvcHRpb25zKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIG9wdGlvbnMucHVzaChjaGlsZCk7XG4gICAgICB9XG4gICAgfSk7XG4gICAgcmV0dXJuIG9wdGlvbnM7XG4gIH07XG5cbiAgdGhpcy5nZXRWYWx1ZUJ5TGFiZWwgPSBmdW5jdGlvbiAobGFiZWwpIHtcbiAgICBpZiAobGFiZWwgPT09IHVuZGVmaW5lZCkge1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIHZhciB2YWx1ZSA9IG51bGw7XG4gICAgT2JqZWN0LmtleXMoX3RoaXMyLnN0YXRlLm9wdGlvbnNJbmZvKS5mb3JFYWNoKGZ1bmN0aW9uIChrZXkpIHtcbiAgICAgIHZhciBpbmZvID0gX3RoaXMyLnN0YXRlLm9wdGlvbnNJbmZvW2tleV07XG4gICAgICBpZiAodG9BcnJheShpbmZvLmxhYmVsKS5qb2luKCcnKSA9PT0gbGFiZWwpIHtcbiAgICAgICAgdmFsdWUgPSBpbmZvLnZhbHVlO1xuICAgICAgfVxuICAgIH0pO1xuICAgIHJldHVybiB2YWx1ZTtcbiAgfTtcblxuICB0aGlzLmdldExhYmVsRnJvbU9wdGlvbiA9IGZ1bmN0aW9uIChvcHRpb24pIHtcbiAgICByZXR1cm4gZ2V0UHJvcFZhbHVlKG9wdGlvbiwgX3RoaXMyLnByb3BzLm9wdGlvbkxhYmVsUHJvcCk7XG4gIH07XG5cbiAgdGhpcy5nZXRWTEJ5U2luZ2xlVmFsdWUgPSBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICBpZiAoX3RoaXMyLnByb3BzLmxhYmVsSW5WYWx1ZSkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAga2V5OiB2YWx1ZSxcbiAgICAgICAgbGFiZWw6IF90aGlzMi5nZXRMYWJlbEJ5U2luZ2xlVmFsdWUodmFsdWUpXG4gICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4gdmFsdWU7XG4gIH07XG5cbiAgdGhpcy5nZXRWTEZvck9uQ2hhbmdlID0gZnVuY3Rpb24gKHZsc18pIHtcbiAgICB2YXIgdmxzID0gdmxzXztcbiAgICBpZiAodmxzICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIGlmICghX3RoaXMyLnByb3BzLmxhYmVsSW5WYWx1ZSkge1xuICAgICAgICB2bHMgPSB2bHMubWFwKGZ1bmN0aW9uICh2KSB7XG4gICAgICAgICAgcmV0dXJuIHY7XG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdmxzID0gdmxzLm1hcChmdW5jdGlvbiAodmwpIHtcbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAga2V5OiB2bCxcbiAgICAgICAgICAgIGxhYmVsOiBfdGhpczIuZ2V0TGFiZWxCeVNpbmdsZVZhbHVlKHZsKVxuICAgICAgICAgIH07XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGlzTXVsdGlwbGVPclRhZ3MoX3RoaXMyLnByb3BzKSA/IHZscyA6IHZsc1swXTtcbiAgICB9XG4gICAgcmV0dXJuIHZscztcbiAgfTtcblxuICB0aGlzLmdldExhYmVsQnlTaW5nbGVWYWx1ZSA9IGZ1bmN0aW9uICh2YWx1ZSwgb3B0aW9uc0luZm8pIHtcbiAgICB2YXIgX2dldE9wdGlvbkluZm9CeVNpbmdsMiA9IF90aGlzMi5nZXRPcHRpb25JbmZvQnlTaW5nbGVWYWx1ZSh2YWx1ZSwgb3B0aW9uc0luZm8pLFxuICAgICAgICBsYWJlbCA9IF9nZXRPcHRpb25JbmZvQnlTaW5nbDIubGFiZWw7XG5cbiAgICByZXR1cm4gbGFiZWw7XG4gIH07XG5cbiAgdGhpcy5nZXREcm9wZG93bkNvbnRhaW5lciA9IGZ1bmN0aW9uICgpIHtcbiAgICBpZiAoIV90aGlzMi5kcm9wZG93bkNvbnRhaW5lcikge1xuICAgICAgX3RoaXMyLmRyb3Bkb3duQ29udGFpbmVyID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKF90aGlzMi5kcm9wZG93bkNvbnRhaW5lcik7XG4gICAgfVxuICAgIHJldHVybiBfdGhpczIuZHJvcGRvd25Db250YWluZXI7XG4gIH07XG5cbiAgdGhpcy5nZXRQbGFjZWhvbGRlckVsZW1lbnQgPSBmdW5jdGlvbiAoKSB7XG4gICAgdmFyIHByb3BzID0gX3RoaXMyLnByb3BzLFxuICAgICAgICBzdGF0ZSA9IF90aGlzMi5zdGF0ZTtcblxuICAgIHZhciBoaWRkZW4gPSBmYWxzZTtcbiAgICBpZiAoc3RhdGUuaW5wdXRWYWx1ZSkge1xuICAgICAgaGlkZGVuID0gdHJ1ZTtcbiAgICB9XG4gICAgaWYgKHN0YXRlLnZhbHVlLmxlbmd0aCkge1xuICAgICAgaGlkZGVuID0gdHJ1ZTtcbiAgICB9XG4gICAgaWYgKGlzQ29tYm9ib3gocHJvcHMpICYmIHN0YXRlLnZhbHVlLmxlbmd0aCA9PT0gMSAmJiAhc3RhdGUudmFsdWVbMF0pIHtcbiAgICAgIGhpZGRlbiA9IGZhbHNlO1xuICAgIH1cbiAgICB2YXIgcGxhY2Vob2xkZXIgPSBwcm9wcy5wbGFjZWhvbGRlcjtcbiAgICBpZiAocGxhY2Vob2xkZXIpIHtcbiAgICAgIHJldHVybiBSZWFjdC5jcmVhdGVFbGVtZW50KFxuICAgICAgICAnZGl2JyxcbiAgICAgICAgX2V4dGVuZHMoe1xuICAgICAgICAgIG9uTW91c2VEb3duOiBwcmV2ZW50RGVmYXVsdEV2ZW50LFxuICAgICAgICAgIHN0eWxlOiBfZXh0ZW5kcyh7XG4gICAgICAgICAgICBkaXNwbGF5OiBoaWRkZW4gPyAnbm9uZScgOiAnYmxvY2snXG4gICAgICAgICAgfSwgVU5TRUxFQ1RBQkxFX1NUWUxFKVxuICAgICAgICB9LCBVTlNFTEVDVEFCTEVfQVRUUklCVVRFLCB7XG4gICAgICAgICAgb25DbGljazogX3RoaXMyLm9uUGxhY2Vob2xkZXJDbGljayxcbiAgICAgICAgICBjbGFzc05hbWU6IHByb3BzLnByZWZpeENscyArICctc2VsZWN0aW9uX19wbGFjZWhvbGRlcidcbiAgICAgICAgfSksXG4gICAgICAgIHBsYWNlaG9sZGVyXG4gICAgICApO1xuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbiAgfTtcblxuICB0aGlzLmdldElucHV0RWxlbWVudCA9IGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgX2NsYXNzbmFtZXM7XG5cbiAgICB2YXIgcHJvcHMgPSBfdGhpczIucHJvcHM7XG4gICAgdmFyIGlucHV0RWxlbWVudCA9IHByb3BzLmdldElucHV0RWxlbWVudCA/IHByb3BzLmdldElucHV0RWxlbWVudCgpIDogUmVhY3QuY3JlYXRlRWxlbWVudCgnaW5wdXQnLCB7IGlkOiBwcm9wcy5pZCwgYXV0b0NvbXBsZXRlOiAnb2ZmJyB9KTtcbiAgICB2YXIgaW5wdXRDbHMgPSBjbGFzc25hbWVzKGlucHV0RWxlbWVudC5wcm9wcy5jbGFzc05hbWUsIChfY2xhc3NuYW1lcyA9IHt9LCBfY2xhc3NuYW1lc1twcm9wcy5wcmVmaXhDbHMgKyAnLXNlYXJjaF9fZmllbGQnXSA9IHRydWUsIF9jbGFzc25hbWVzKSk7XG4gICAgLy8gaHR0cHM6Ly9naXRodWIuY29tL2FudC1kZXNpZ24vYW50LWRlc2lnbi9pc3N1ZXMvNDk5MiNpc3N1ZWNvbW1lbnQtMjgxNTQyMTU5XG4gICAgLy8gQWRkIHNwYWNlIHRvIHRoZSBlbmQgb2YgdGhlIGlucHV0VmFsdWUgYXMgdGhlIHdpZHRoIG1lYXN1cmVtZW50IHRvbGVyYW5jZVxuICAgIHJldHVybiBSZWFjdC5jcmVhdGVFbGVtZW50KFxuICAgICAgJ2RpdicsXG4gICAgICB7IGNsYXNzTmFtZTogcHJvcHMucHJlZml4Q2xzICsgJy1zZWFyY2hfX2ZpZWxkX193cmFwJyB9LFxuICAgICAgUmVhY3QuY2xvbmVFbGVtZW50KGlucHV0RWxlbWVudCwge1xuICAgICAgICByZWY6IHNhdmVSZWYoX3RoaXMyLCAnaW5wdXRSZWYnKSxcbiAgICAgICAgb25DaGFuZ2U6IF90aGlzMi5vbklucHV0Q2hhbmdlLFxuICAgICAgICBvbktleURvd246IGNoYWluaW5nKF90aGlzMi5vbklucHV0S2V5RG93biwgaW5wdXRFbGVtZW50LnByb3BzLm9uS2V5RG93biwgX3RoaXMyLnByb3BzLm9uSW5wdXRLZXlEb3duKSxcbiAgICAgICAgdmFsdWU6IF90aGlzMi5zdGF0ZS5pbnB1dFZhbHVlLFxuICAgICAgICBkaXNhYmxlZDogcHJvcHMuZGlzYWJsZWQsXG4gICAgICAgIGNsYXNzTmFtZTogaW5wdXRDbHNcbiAgICAgIH0pLFxuICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcbiAgICAgICAgJ3NwYW4nLFxuICAgICAgICB7XG4gICAgICAgICAgcmVmOiBzYXZlUmVmKF90aGlzMiwgJ2lucHV0TWlycm9yUmVmJyksXG4gICAgICAgICAgY2xhc3NOYW1lOiBwcm9wcy5wcmVmaXhDbHMgKyAnLXNlYXJjaF9fZmllbGRfX21pcnJvcidcbiAgICAgICAgfSxcbiAgICAgICAgX3RoaXMyLnN0YXRlLmlucHV0VmFsdWUsXG4gICAgICAgICdcXHhBMCdcbiAgICAgIClcbiAgICApO1xuICB9O1xuXG4gIHRoaXMuZ2V0SW5wdXRET01Ob2RlID0gZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiBfdGhpczIudG9wQ3RybFJlZiA/IF90aGlzMi50b3BDdHJsUmVmLnF1ZXJ5U2VsZWN0b3IoJ2lucHV0LHRleHRhcmVhLGRpdltjb250ZW50RWRpdGFibGVdJykgOiBfdGhpczIuaW5wdXRSZWY7XG4gIH07XG5cbiAgdGhpcy5nZXRJbnB1dE1pcnJvckRPTU5vZGUgPSBmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIF90aGlzMi5pbnB1dE1pcnJvclJlZjtcbiAgfTtcblxuICB0aGlzLmdldFBvcHVwRE9NTm9kZSA9IGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gX3RoaXMyLnNlbGVjdFRyaWdnZXJSZWYuZ2V0UG9wdXBET01Ob2RlKCk7XG4gIH07XG5cbiAgdGhpcy5nZXRQb3B1cE1lbnVDb21wb25lbnQgPSBmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIF90aGlzMi5zZWxlY3RUcmlnZ2VyUmVmLmdldElubmVyTWVudSgpO1xuICB9O1xuXG4gIHRoaXMuc2V0T3BlblN0YXRlID0gZnVuY3Rpb24gKG9wZW4sIG5lZWRGb2N1cykge1xuICAgIHZhciBwcm9wcyA9IF90aGlzMi5wcm9wcyxcbiAgICAgICAgc3RhdGUgPSBfdGhpczIuc3RhdGU7XG5cbiAgICBpZiAoc3RhdGUub3BlbiA9PT0gb3Blbikge1xuICAgICAgX3RoaXMyLm1heWJlRm9jdXMob3BlbiwgbmVlZEZvY3VzKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdmFyIG5leHRTdGF0ZSA9IHtcbiAgICAgIG9wZW46IG9wZW4sXG4gICAgICBiYWNrZmlsbFZhbHVlOiB1bmRlZmluZWRcbiAgICB9O1xuICAgIC8vIGNsZWFyIHNlYXJjaCBpbnB1dCB2YWx1ZSB3aGVuIG9wZW4gaXMgZmFsc2UgaW4gc2luZ2xlTW9kZS5cbiAgICBpZiAoIW9wZW4gJiYgaXNTaW5nbGVNb2RlKHByb3BzKSAmJiBwcm9wcy5zaG93U2VhcmNoKSB7XG4gICAgICBfdGhpczIuc2V0SW5wdXRWYWx1ZSgnJyk7XG4gICAgfVxuICAgIGlmICghb3Blbikge1xuICAgICAgX3RoaXMyLm1heWJlRm9jdXMob3BlbiwgbmVlZEZvY3VzKTtcbiAgICB9XG4gICAgX3RoaXMyLnNldFN0YXRlKG5leHRTdGF0ZSwgZnVuY3Rpb24gKCkge1xuICAgICAgaWYgKG9wZW4pIHtcbiAgICAgICAgX3RoaXMyLm1heWJlRm9jdXMob3BlbiwgbmVlZEZvY3VzKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfTtcblxuICB0aGlzLnNldElucHV0VmFsdWUgPSBmdW5jdGlvbiAoaW5wdXRWYWx1ZSkge1xuICAgIHZhciBmaXJlU2VhcmNoID0gYXJndW1lbnRzLmxlbmd0aCA+IDEgJiYgYXJndW1lbnRzWzFdICE9PSB1bmRlZmluZWQgPyBhcmd1bWVudHNbMV0gOiB0cnVlO1xuXG4gICAgaWYgKGlucHV0VmFsdWUgIT09IF90aGlzMi5zdGF0ZS5pbnB1dFZhbHVlKSB7XG4gICAgICBfdGhpczIuc2V0U3RhdGUoe1xuICAgICAgICBpbnB1dFZhbHVlOiBpbnB1dFZhbHVlXG4gICAgICB9LCBfdGhpczIuZm9yY2VQb3B1cEFsaWduKTtcbiAgICAgIGlmIChmaXJlU2VhcmNoKSB7XG4gICAgICAgIF90aGlzMi5wcm9wcy5vblNlYXJjaChpbnB1dFZhbHVlKTtcbiAgICAgIH1cbiAgICB9XG4gIH07XG5cbiAgdGhpcy5nZXRWYWx1ZUJ5SW5wdXQgPSBmdW5jdGlvbiAoc3RyaW5nKSB7XG4gICAgdmFyIF9wcm9wczIgPSBfdGhpczIucHJvcHMsXG4gICAgICAgIG11bHRpcGxlID0gX3Byb3BzMi5tdWx0aXBsZSxcbiAgICAgICAgdG9rZW5TZXBhcmF0b3JzID0gX3Byb3BzMi50b2tlblNlcGFyYXRvcnM7XG5cbiAgICB2YXIgbmV4dFZhbHVlID0gX3RoaXMyLnN0YXRlLnZhbHVlO1xuICAgIHZhciBoYXNOZXdWYWx1ZSA9IGZhbHNlO1xuICAgIHNwbGl0QnlTZXBhcmF0b3JzKHN0cmluZywgdG9rZW5TZXBhcmF0b3JzKS5mb3JFYWNoKGZ1bmN0aW9uIChsYWJlbCkge1xuICAgICAgdmFyIHNlbGVjdGVkVmFsdWUgPSBbbGFiZWxdO1xuICAgICAgaWYgKG11bHRpcGxlKSB7XG4gICAgICAgIHZhciB2YWx1ZSA9IF90aGlzMi5nZXRWYWx1ZUJ5TGFiZWwobGFiZWwpO1xuICAgICAgICBpZiAodmFsdWUgJiYgZmluZEluZGV4SW5WYWx1ZUJ5U2luZ2xlVmFsdWUobmV4dFZhbHVlLCB2YWx1ZSkgPT09IC0xKSB7XG4gICAgICAgICAgbmV4dFZhbHVlID0gbmV4dFZhbHVlLmNvbmNhdCh2YWx1ZSk7XG4gICAgICAgICAgaGFzTmV3VmFsdWUgPSB0cnVlO1xuICAgICAgICAgIF90aGlzMi5maXJlU2VsZWN0KHZhbHVlKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gdGFnXG4gICAgICAgIGlmIChmaW5kSW5kZXhJblZhbHVlQnlTaW5nbGVWYWx1ZShuZXh0VmFsdWUsIGxhYmVsKSA9PT0gLTEpIHtcbiAgICAgICAgICBuZXh0VmFsdWUgPSBuZXh0VmFsdWUuY29uY2F0KHNlbGVjdGVkVmFsdWUpO1xuICAgICAgICAgIGhhc05ld1ZhbHVlID0gdHJ1ZTtcbiAgICAgICAgICBfdGhpczIuZmlyZVNlbGVjdChsYWJlbCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KTtcbiAgICByZXR1cm4gaGFzTmV3VmFsdWUgPyBuZXh0VmFsdWUgOiB1bmRlZmluZWQ7XG4gIH07XG5cbiAgdGhpcy5oYW5kbGVCYWNrZmlsbCA9IGZ1bmN0aW9uIChpdGVtKSB7XG4gICAgaWYgKCFfdGhpczIucHJvcHMuYmFja2ZpbGwgfHwgIShpc1NpbmdsZU1vZGUoX3RoaXMyLnByb3BzKSB8fCBpc0NvbWJvYm94KF90aGlzMi5wcm9wcykpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgdmFyIGtleSA9IGdldFZhbHVlUHJvcFZhbHVlKGl0ZW0pO1xuXG4gICAgaWYgKGlzQ29tYm9ib3goX3RoaXMyLnByb3BzKSkge1xuICAgICAgX3RoaXMyLnNldElucHV0VmFsdWUoa2V5LCBmYWxzZSk7XG4gICAgfVxuXG4gICAgX3RoaXMyLnNldFN0YXRlKHtcbiAgICAgIHZhbHVlOiBba2V5XSxcbiAgICAgIGJhY2tmaWxsVmFsdWU6IGtleVxuICAgIH0pO1xuICB9O1xuXG4gIHRoaXMuZmlsdGVyT3B0aW9uID0gZnVuY3Rpb24gKGlucHV0LCBjaGlsZCkge1xuICAgIHZhciBkZWZhdWx0RmlsdGVyID0gYXJndW1lbnRzLmxlbmd0aCA+IDIgJiYgYXJndW1lbnRzWzJdICE9PSB1bmRlZmluZWQgPyBhcmd1bWVudHNbMl0gOiBkZWZhdWx0RmlsdGVyRm47XG4gICAgdmFyIHZhbHVlID0gX3RoaXMyLnN0YXRlLnZhbHVlO1xuXG4gICAgdmFyIGxhc3RWYWx1ZSA9IHZhbHVlW3ZhbHVlLmxlbmd0aCAtIDFdO1xuICAgIGlmICghaW5wdXQgfHwgbGFzdFZhbHVlICYmIGxhc3RWYWx1ZSA9PT0gX3RoaXMyLnN0YXRlLmJhY2tmaWxsVmFsdWUpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICB2YXIgZmlsdGVyRm4gPSBfdGhpczIucHJvcHMuZmlsdGVyT3B0aW9uO1xuICAgIGlmICgnZmlsdGVyT3B0aW9uJyBpbiBfdGhpczIucHJvcHMpIHtcbiAgICAgIGlmIChfdGhpczIucHJvcHMuZmlsdGVyT3B0aW9uID09PSB0cnVlKSB7XG4gICAgICAgIGZpbHRlckZuID0gZGVmYXVsdEZpbHRlcjtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgZmlsdGVyRm4gPSBkZWZhdWx0RmlsdGVyO1xuICAgIH1cblxuICAgIGlmICghZmlsdGVyRm4pIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH0gZWxzZSBpZiAodHlwZW9mIGZpbHRlckZuID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICByZXR1cm4gZmlsdGVyRm4uY2FsbChfdGhpczIsIGlucHV0LCBjaGlsZCk7XG4gICAgfSBlbHNlIGlmIChjaGlsZC5wcm9wcy5kaXNhYmxlZCkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbiAgfTtcblxuICB0aGlzLnRpbWVvdXRGb2N1cyA9IGZ1bmN0aW9uICgpIHtcbiAgICBpZiAoX3RoaXMyLmZvY3VzVGltZXIpIHtcbiAgICAgIF90aGlzMi5jbGVhckZvY3VzVGltZSgpO1xuICAgIH1cbiAgICBfdGhpczIuZm9jdXNUaW1lciA9IHNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xuICAgICAgX3RoaXMyLnByb3BzLm9uRm9jdXMoKTtcbiAgICB9LCAxMCk7XG4gIH07XG5cbiAgdGhpcy5jbGVhckZvY3VzVGltZSA9IGZ1bmN0aW9uICgpIHtcbiAgICBpZiAoX3RoaXMyLmZvY3VzVGltZXIpIHtcbiAgICAgIGNsZWFyVGltZW91dChfdGhpczIuZm9jdXNUaW1lcik7XG4gICAgICBfdGhpczIuZm9jdXNUaW1lciA9IG51bGw7XG4gICAgfVxuICB9O1xuXG4gIHRoaXMuY2xlYXJCbHVyVGltZSA9IGZ1bmN0aW9uICgpIHtcbiAgICBpZiAoX3RoaXMyLmJsdXJUaW1lcikge1xuICAgICAgY2xlYXJUaW1lb3V0KF90aGlzMi5ibHVyVGltZXIpO1xuICAgICAgX3RoaXMyLmJsdXJUaW1lciA9IG51bGw7XG4gICAgfVxuICB9O1xuXG4gIHRoaXMuY2xlYXJBZGp1c3RUaW1lciA9IGZ1bmN0aW9uICgpIHtcbiAgICBpZiAoX3RoaXMyLnNraXBBZGp1c3RPcGVuVGltZXIpIHtcbiAgICAgIGNsZWFyVGltZW91dChfdGhpczIuc2tpcEFkanVzdE9wZW5UaW1lcik7XG4gICAgICBfdGhpczIuc2tpcEFkanVzdE9wZW5UaW1lciA9IG51bGw7XG4gICAgfVxuICB9O1xuXG4gIHRoaXMudXBkYXRlRm9jdXNDbGFzc05hbWUgPSBmdW5jdGlvbiAoKSB7XG4gICAgdmFyIHJvb3RSZWYgPSBfdGhpczIucm9vdFJlZixcbiAgICAgICAgcHJvcHMgPSBfdGhpczIucHJvcHM7XG4gICAgLy8gYXZvaWQgc2V0U3RhdGUgYW5kIGl0cyBzaWRlIGVmZmVjdFxuXG4gICAgaWYgKF90aGlzMi5fZm9jdXNlZCkge1xuICAgICAgY2xhc3Nlcyhyb290UmVmKS5hZGQocHJvcHMucHJlZml4Q2xzICsgJy1mb2N1c2VkJyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNsYXNzZXMocm9vdFJlZikucmVtb3ZlKHByb3BzLnByZWZpeENscyArICctZm9jdXNlZCcpO1xuICAgIH1cbiAgfTtcblxuICB0aGlzLm1heWJlRm9jdXMgPSBmdW5jdGlvbiAob3BlbiwgbmVlZEZvY3VzKSB7XG4gICAgaWYgKG5lZWRGb2N1cyB8fCBvcGVuKSB7XG4gICAgICB2YXIgaW5wdXQgPSBfdGhpczIuZ2V0SW5wdXRET01Ob2RlKCk7XG4gICAgICB2YXIgX2RvY3VtZW50ID0gZG9jdW1lbnQsXG4gICAgICAgICAgYWN0aXZlRWxlbWVudCA9IF9kb2N1bWVudC5hY3RpdmVFbGVtZW50O1xuXG4gICAgICBpZiAoaW5wdXQgJiYgKG9wZW4gfHwgaXNNdWx0aXBsZU9yVGFnc09yQ29tYm9ib3goX3RoaXMyLnByb3BzKSkpIHtcbiAgICAgICAgaWYgKGFjdGl2ZUVsZW1lbnQgIT09IGlucHV0KSB7XG4gICAgICAgICAgaW5wdXQuZm9jdXMoKTtcbiAgICAgICAgICBfdGhpczIuX2ZvY3VzZWQgPSB0cnVlO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBpZiAoYWN0aXZlRWxlbWVudCAhPT0gX3RoaXMyLnNlbGVjdGlvblJlZikge1xuICAgICAgICAgIF90aGlzMi5zZWxlY3Rpb25SZWYuZm9jdXMoKTtcbiAgICAgICAgICBfdGhpczIuX2ZvY3VzZWQgPSB0cnVlO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9O1xuXG4gIHRoaXMucmVtb3ZlU2VsZWN0ZWQgPSBmdW5jdGlvbiAoc2VsZWN0ZWRLZXkpIHtcbiAgICB2YXIgcHJvcHMgPSBfdGhpczIucHJvcHM7XG4gICAgaWYgKHByb3BzLmRpc2FibGVkIHx8IF90aGlzMi5pc0NoaWxkRGlzYWJsZWQoc2VsZWN0ZWRLZXkpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHZhciB2YWx1ZSA9IF90aGlzMi5zdGF0ZS52YWx1ZS5maWx0ZXIoZnVuY3Rpb24gKHNpbmdsZVZhbHVlKSB7XG4gICAgICByZXR1cm4gc2luZ2xlVmFsdWUgIT09IHNlbGVjdGVkS2V5O1xuICAgIH0pO1xuICAgIHZhciBjYW5NdWx0aXBsZSA9IGlzTXVsdGlwbGVPclRhZ3MocHJvcHMpO1xuXG4gICAgaWYgKGNhbk11bHRpcGxlKSB7XG4gICAgICB2YXIgZXZlbnQgPSBzZWxlY3RlZEtleTtcbiAgICAgIGlmIChwcm9wcy5sYWJlbEluVmFsdWUpIHtcbiAgICAgICAgZXZlbnQgPSB7XG4gICAgICAgICAga2V5OiBzZWxlY3RlZEtleSxcbiAgICAgICAgICBsYWJlbDogX3RoaXMyLmdldExhYmVsQnlTaW5nbGVWYWx1ZShzZWxlY3RlZEtleSlcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIHByb3BzLm9uRGVzZWxlY3QoZXZlbnQsIF90aGlzMi5nZXRPcHRpb25CeVNpbmdsZVZhbHVlKHNlbGVjdGVkS2V5KSk7XG4gICAgfVxuICAgIF90aGlzMi5maXJlQ2hhbmdlKHZhbHVlKTtcbiAgfTtcblxuICB0aGlzLm9wZW5JZkhhc0NoaWxkcmVuID0gZnVuY3Rpb24gKCkge1xuICAgIHZhciBwcm9wcyA9IF90aGlzMi5wcm9wcztcbiAgICBpZiAoUmVhY3QuQ2hpbGRyZW4uY291bnQocHJvcHMuY2hpbGRyZW4pIHx8IGlzU2luZ2xlTW9kZShwcm9wcykpIHtcbiAgICAgIF90aGlzMi5zZXRPcGVuU3RhdGUodHJ1ZSk7XG4gICAgfVxuICB9O1xuXG4gIHRoaXMuZmlyZVNlbGVjdCA9IGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgIF90aGlzMi5wcm9wcy5vblNlbGVjdChfdGhpczIuZ2V0VkxCeVNpbmdsZVZhbHVlKHZhbHVlKSwgX3RoaXMyLmdldE9wdGlvbkJ5U2luZ2xlVmFsdWUodmFsdWUpKTtcbiAgfTtcblxuICB0aGlzLmZpcmVDaGFuZ2UgPSBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICB2YXIgcHJvcHMgPSBfdGhpczIucHJvcHM7XG4gICAgaWYgKCEoJ3ZhbHVlJyBpbiBwcm9wcykpIHtcbiAgICAgIF90aGlzMi5zZXRTdGF0ZSh7XG4gICAgICAgIHZhbHVlOiB2YWx1ZVxuICAgICAgfSwgX3RoaXMyLmZvcmNlUG9wdXBBbGlnbik7XG4gICAgfVxuICAgIHZhciB2bHMgPSBfdGhpczIuZ2V0VkxGb3JPbkNoYW5nZSh2YWx1ZSk7XG4gICAgdmFyIG9wdGlvbnMgPSBfdGhpczIuZ2V0T3B0aW9uc0J5U2luZ2xlVmFsdWUodmFsdWUpO1xuICAgIHByb3BzLm9uQ2hhbmdlKHZscywgaXNNdWx0aXBsZU9yVGFncyhfdGhpczIucHJvcHMpID8gb3B0aW9ucyA6IG9wdGlvbnNbMF0pO1xuICB9O1xuXG4gIHRoaXMuaXNDaGlsZERpc2FibGVkID0gZnVuY3Rpb24gKGtleSkge1xuICAgIHJldHVybiBjaGlsZHJlblRvQXJyYXkoX3RoaXMyLnByb3BzLmNoaWxkcmVuKS5zb21lKGZ1bmN0aW9uIChjaGlsZCkge1xuICAgICAgdmFyIGNoaWxkVmFsdWUgPSBnZXRWYWx1ZVByb3BWYWx1ZShjaGlsZCk7XG4gICAgICByZXR1cm4gY2hpbGRWYWx1ZSA9PT0ga2V5ICYmIGNoaWxkLnByb3BzICYmIGNoaWxkLnByb3BzLmRpc2FibGVkO1xuICAgIH0pO1xuICB9O1xuXG4gIHRoaXMuYWRqdXN0T3BlblN0YXRlID0gZnVuY3Rpb24gKCkge1xuICAgIGlmIChfdGhpczIuc2tpcEFkanVzdE9wZW4pIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdmFyIG9wZW4gPSBfdGhpczIuc3RhdGUub3BlbjtcblxuICAgIHZhciBvcHRpb25zID0gW107XG4gICAgLy8gSWYgaGlkZGVuIG1lbnUgZHVlIHRvIG5vIG9wdGlvbnMsIHRoZW4gaXQgc2hvdWxkIGJlIGNhbGN1bGF0ZWQgYWdhaW5cbiAgICBpZiAob3BlbiB8fCBfdGhpczIuaGlkZGVuRm9yTm9PcHRpb25zKSB7XG4gICAgICBvcHRpb25zID0gX3RoaXMyLnJlbmRlckZpbHRlck9wdGlvbnMoKTtcbiAgICB9XG4gICAgX3RoaXMyLl9vcHRpb25zID0gb3B0aW9ucztcblxuICAgIGlmIChpc011bHRpcGxlT3JUYWdzT3JDb21ib2JveChfdGhpczIucHJvcHMpIHx8ICFfdGhpczIucHJvcHMuc2hvd1NlYXJjaCkge1xuICAgICAgaWYgKG9wZW4gJiYgIW9wdGlvbnMubGVuZ3RoKSB7XG4gICAgICAgIG9wZW4gPSBmYWxzZTtcbiAgICAgICAgX3RoaXMyLmhpZGRlbkZvck5vT3B0aW9ucyA9IHRydWU7XG4gICAgICB9XG4gICAgICAvLyBLZWVwIG1lbnUgb3BlbiBpZiB0aGVyZSBhcmUgb3B0aW9ucyBhbmQgaGlkZGVuIGZvciBubyBvcHRpb25zIGJlZm9yZVxuICAgICAgaWYgKF90aGlzMi5oaWRkZW5Gb3JOb09wdGlvbnMgJiYgb3B0aW9ucy5sZW5ndGgpIHtcbiAgICAgICAgb3BlbiA9IHRydWU7XG4gICAgICAgIF90aGlzMi5oaWRkZW5Gb3JOb09wdGlvbnMgPSBmYWxzZTtcbiAgICAgIH1cbiAgICB9XG4gICAgX3RoaXMyLnN0YXRlLm9wZW4gPSBvcGVuO1xuICB9O1xuXG4gIHRoaXMuZm9yY2VQb3B1cEFsaWduID0gZnVuY3Rpb24gKCkge1xuICAgIF90aGlzMi5zZWxlY3RUcmlnZ2VyUmVmLnRyaWdnZXJSZWYuZm9yY2VQb3B1cEFsaWduKCk7XG4gIH07XG5cbiAgdGhpcy5yZW5kZXJGaWx0ZXJPcHRpb25zID0gZnVuY3Rpb24gKCkge1xuICAgIHZhciBpbnB1dFZhbHVlID0gX3RoaXMyLnN0YXRlLmlucHV0VmFsdWU7XG4gICAgdmFyIF9wcm9wczMgPSBfdGhpczIucHJvcHMsXG4gICAgICAgIGNoaWxkcmVuID0gX3Byb3BzMy5jaGlsZHJlbixcbiAgICAgICAgdGFncyA9IF9wcm9wczMudGFncyxcbiAgICAgICAgZmlsdGVyT3B0aW9uID0gX3Byb3BzMy5maWx0ZXJPcHRpb24sXG4gICAgICAgIG5vdEZvdW5kQ29udGVudCA9IF9wcm9wczMubm90Rm91bmRDb250ZW50O1xuXG4gICAgdmFyIG1lbnVJdGVtcyA9IFtdO1xuICAgIHZhciBjaGlsZHJlbktleXMgPSBbXTtcbiAgICB2YXIgb3B0aW9ucyA9IF90aGlzMi5yZW5kZXJGaWx0ZXJPcHRpb25zRnJvbUNoaWxkcmVuKGNoaWxkcmVuLCBjaGlsZHJlbktleXMsIG1lbnVJdGVtcyk7XG4gICAgaWYgKHRhZ3MpIHtcbiAgICAgIC8vIHRhZ3MgdmFsdWUgbXVzdCBiZSBzdHJpbmdcbiAgICAgIHZhciB2YWx1ZSA9IF90aGlzMi5zdGF0ZS52YWx1ZSB8fCBbXTtcbiAgICAgIHZhbHVlID0gdmFsdWUuZmlsdGVyKGZ1bmN0aW9uIChzaW5nbGVWYWx1ZSkge1xuICAgICAgICByZXR1cm4gY2hpbGRyZW5LZXlzLmluZGV4T2Yoc2luZ2xlVmFsdWUpID09PSAtMSAmJiAoIWlucHV0VmFsdWUgfHwgU3RyaW5nKHNpbmdsZVZhbHVlKS5pbmRleE9mKFN0cmluZyhpbnB1dFZhbHVlKSkgPiAtMSk7XG4gICAgICB9KTtcbiAgICAgIHZhbHVlLmZvckVhY2goZnVuY3Rpb24gKHNpbmdsZVZhbHVlKSB7XG4gICAgICAgIHZhciBrZXkgPSBzaW5nbGVWYWx1ZTtcbiAgICAgICAgdmFyIG1lbnVJdGVtID0gUmVhY3QuY3JlYXRlRWxlbWVudChcbiAgICAgICAgICBNZW51SXRlbSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBzdHlsZTogVU5TRUxFQ1RBQkxFX1NUWUxFLFxuICAgICAgICAgICAgYXR0cmlidXRlOiBVTlNFTEVDVEFCTEVfQVRUUklCVVRFLFxuICAgICAgICAgICAgdmFsdWU6IGtleSxcbiAgICAgICAgICAgIGtleToga2V5XG4gICAgICAgICAgfSxcbiAgICAgICAgICBrZXlcbiAgICAgICAgKTtcbiAgICAgICAgb3B0aW9ucy5wdXNoKG1lbnVJdGVtKTtcbiAgICAgICAgbWVudUl0ZW1zLnB1c2gobWVudUl0ZW0pO1xuICAgICAgfSk7XG4gICAgICBpZiAoaW5wdXRWYWx1ZSkge1xuICAgICAgICB2YXIgbm90RmluZElucHV0SXRlbSA9IG1lbnVJdGVtcy5ldmVyeShmdW5jdGlvbiAob3B0aW9uKSB7XG4gICAgICAgICAgLy8gdGhpcy5maWx0ZXJPcHRpb24gcmV0dXJuIHRydWUgaGFzIHR3byBtZWFuaW5nLFxuICAgICAgICAgIC8vIDEsIHNvbWUgb25lIGV4aXN0cyBhZnRlciBmaWx0ZXJpbmdcbiAgICAgICAgICAvLyAyLCBmaWx0ZXJPcHRpb24gaXMgc2V0IHRvIGZhbHNlXG4gICAgICAgICAgLy8gY29uZGl0aW9uIDIgZG9lcyBub3QgbWVhbiB0aGUgb3B0aW9uIGhhcyBzYW1lIHZhbHVlIHdpdGggaW5wdXRWYWx1ZVxuICAgICAgICAgIHZhciBmaWx0ZXJGbiA9IGZ1bmN0aW9uIGZpbHRlckZuKCkge1xuICAgICAgICAgICAgcmV0dXJuIGdldFZhbHVlUHJvcFZhbHVlKG9wdGlvbikgPT09IGlucHV0VmFsdWU7XG4gICAgICAgICAgfTtcbiAgICAgICAgICBpZiAoZmlsdGVyT3B0aW9uICE9PSBmYWxzZSkge1xuICAgICAgICAgICAgcmV0dXJuICFfdGhpczIuZmlsdGVyT3B0aW9uLmNhbGwoX3RoaXMyLCBpbnB1dFZhbHVlLCBvcHRpb24sIGZpbHRlckZuKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuICFmaWx0ZXJGbigpO1xuICAgICAgICB9KTtcbiAgICAgICAgaWYgKG5vdEZpbmRJbnB1dEl0ZW0pIHtcbiAgICAgICAgICBvcHRpb25zLnVuc2hpZnQoUmVhY3QuY3JlYXRlRWxlbWVudChcbiAgICAgICAgICAgIE1lbnVJdGVtLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBzdHlsZTogVU5TRUxFQ1RBQkxFX1NUWUxFLFxuICAgICAgICAgICAgICBhdHRyaWJ1dGU6IFVOU0VMRUNUQUJMRV9BVFRSSUJVVEUsXG4gICAgICAgICAgICAgIHZhbHVlOiBpbnB1dFZhbHVlLFxuICAgICAgICAgICAgICBrZXk6IGlucHV0VmFsdWVcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBpbnB1dFZhbHVlXG4gICAgICAgICAgKSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAoIW9wdGlvbnMubGVuZ3RoICYmIG5vdEZvdW5kQ29udGVudCkge1xuICAgICAgb3B0aW9ucyA9IFtSZWFjdC5jcmVhdGVFbGVtZW50KFxuICAgICAgICBNZW51SXRlbSxcbiAgICAgICAge1xuICAgICAgICAgIHN0eWxlOiBVTlNFTEVDVEFCTEVfU1RZTEUsXG4gICAgICAgICAgYXR0cmlidXRlOiBVTlNFTEVDVEFCTEVfQVRUUklCVVRFLFxuICAgICAgICAgIGRpc2FibGVkOiB0cnVlLFxuICAgICAgICAgIHZhbHVlOiAnTk9UX0ZPVU5EJyxcbiAgICAgICAgICBrZXk6ICdOT1RfRk9VTkQnXG4gICAgICAgIH0sXG4gICAgICAgIG5vdEZvdW5kQ29udGVudFxuICAgICAgKV07XG4gICAgfVxuICAgIHJldHVybiBvcHRpb25zO1xuICB9O1xuXG4gIHRoaXMucmVuZGVyRmlsdGVyT3B0aW9uc0Zyb21DaGlsZHJlbiA9IGZ1bmN0aW9uIChjaGlsZHJlbiwgY2hpbGRyZW5LZXlzLCBtZW51SXRlbXMpIHtcbiAgICB2YXIgc2VsID0gW107XG4gICAgdmFyIHByb3BzID0gX3RoaXMyLnByb3BzO1xuICAgIHZhciBpbnB1dFZhbHVlID0gX3RoaXMyLnN0YXRlLmlucHV0VmFsdWU7XG5cbiAgICB2YXIgdGFncyA9IHByb3BzLnRhZ3M7XG4gICAgUmVhY3QuQ2hpbGRyZW4uZm9yRWFjaChjaGlsZHJlbiwgZnVuY3Rpb24gKGNoaWxkKSB7XG4gICAgICBpZiAoIWNoaWxkKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmIChjaGlsZC50eXBlLmlzU2VsZWN0T3B0R3JvdXApIHtcbiAgICAgICAgdmFyIGlubmVySXRlbXMgPSBfdGhpczIucmVuZGVyRmlsdGVyT3B0aW9uc0Zyb21DaGlsZHJlbihjaGlsZC5wcm9wcy5jaGlsZHJlbiwgY2hpbGRyZW5LZXlzLCBtZW51SXRlbXMpO1xuICAgICAgICBpZiAoaW5uZXJJdGVtcy5sZW5ndGgpIHtcbiAgICAgICAgICB2YXIgbGFiZWwgPSBjaGlsZC5wcm9wcy5sYWJlbDtcbiAgICAgICAgICB2YXIga2V5ID0gY2hpbGQua2V5O1xuICAgICAgICAgIGlmICgha2V5ICYmIHR5cGVvZiBsYWJlbCA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgIGtleSA9IGxhYmVsO1xuICAgICAgICAgIH0gZWxzZSBpZiAoIWxhYmVsICYmIGtleSkge1xuICAgICAgICAgICAgbGFiZWwgPSBrZXk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHNlbC5wdXNoKFJlYWN0LmNyZWF0ZUVsZW1lbnQoXG4gICAgICAgICAgICBNZW51SXRlbUdyb3VwLFxuICAgICAgICAgICAgeyBrZXk6IGtleSwgdGl0bGU6IGxhYmVsIH0sXG4gICAgICAgICAgICBpbm5lckl0ZW1zXG4gICAgICAgICAgKSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICB3YXJuaW5nKGNoaWxkLnR5cGUuaXNTZWxlY3RPcHRpb24sICd0aGUgY2hpbGRyZW4gb2YgYFNlbGVjdGAgc2hvdWxkIGJlIGBTZWxlY3QuT3B0aW9uYCBvciBgU2VsZWN0Lk9wdEdyb3VwYCwgJyArICgnaW5zdGVhZCBvZiBgJyArIChjaGlsZC50eXBlLm5hbWUgfHwgY2hpbGQudHlwZS5kaXNwbGF5TmFtZSB8fCBjaGlsZC50eXBlKSArICdgLicpKTtcblxuICAgICAgdmFyIGNoaWxkVmFsdWUgPSBnZXRWYWx1ZVByb3BWYWx1ZShjaGlsZCk7XG5cbiAgICAgIHZhbGlkYXRlT3B0aW9uVmFsdWUoY2hpbGRWYWx1ZSwgX3RoaXMyLnByb3BzKTtcblxuICAgICAgaWYgKF90aGlzMi5maWx0ZXJPcHRpb24oaW5wdXRWYWx1ZSwgY2hpbGQpKSB7XG4gICAgICAgIHZhciBtZW51SXRlbSA9IFJlYWN0LmNyZWF0ZUVsZW1lbnQoTWVudUl0ZW0sIF9leHRlbmRzKHtcbiAgICAgICAgICBzdHlsZTogVU5TRUxFQ1RBQkxFX1NUWUxFLFxuICAgICAgICAgIGF0dHJpYnV0ZTogVU5TRUxFQ1RBQkxFX0FUVFJJQlVURSxcbiAgICAgICAgICB2YWx1ZTogY2hpbGRWYWx1ZSxcbiAgICAgICAgICBrZXk6IGNoaWxkVmFsdWVcbiAgICAgICAgfSwgY2hpbGQucHJvcHMpKTtcbiAgICAgICAgc2VsLnB1c2gobWVudUl0ZW0pO1xuICAgICAgICBtZW51SXRlbXMucHVzaChtZW51SXRlbSk7XG4gICAgICB9XG4gICAgICBpZiAodGFncyAmJiAhY2hpbGQucHJvcHMuZGlzYWJsZWQpIHtcbiAgICAgICAgY2hpbGRyZW5LZXlzLnB1c2goY2hpbGRWYWx1ZSk7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICByZXR1cm4gc2VsO1xuICB9O1xuXG4gIHRoaXMucmVuZGVyVG9wQ29udHJvbE5vZGUgPSBmdW5jdGlvbiAoKSB7XG4gICAgdmFyIF9zdGF0ZTIgPSBfdGhpczIuc3RhdGUsXG4gICAgICAgIHZhbHVlID0gX3N0YXRlMi52YWx1ZSxcbiAgICAgICAgb3BlbiA9IF9zdGF0ZTIub3BlbixcbiAgICAgICAgaW5wdXRWYWx1ZSA9IF9zdGF0ZTIuaW5wdXRWYWx1ZTtcblxuICAgIHZhciBwcm9wcyA9IF90aGlzMi5wcm9wcztcbiAgICB2YXIgY2hvaWNlVHJhbnNpdGlvbk5hbWUgPSBwcm9wcy5jaG9pY2VUcmFuc2l0aW9uTmFtZSxcbiAgICAgICAgcHJlZml4Q2xzID0gcHJvcHMucHJlZml4Q2xzLFxuICAgICAgICBtYXhUYWdUZXh0TGVuZ3RoID0gcHJvcHMubWF4VGFnVGV4dExlbmd0aCxcbiAgICAgICAgbWF4VGFnQ291bnQgPSBwcm9wcy5tYXhUYWdDb3VudCxcbiAgICAgICAgbWF4VGFnUGxhY2Vob2xkZXIgPSBwcm9wcy5tYXhUYWdQbGFjZWhvbGRlcixcbiAgICAgICAgc2hvd1NlYXJjaCA9IHByb3BzLnNob3dTZWFyY2g7XG5cbiAgICB2YXIgY2xhc3NOYW1lID0gcHJlZml4Q2xzICsgJy1zZWxlY3Rpb25fX3JlbmRlcmVkJztcbiAgICAvLyBzZWFyY2ggaW5wdXQgaXMgaW5zaWRlIHRvcENvbnRyb2xOb2RlIGluIHNpbmdsZSwgbXVsdGlwbGUgJiBjb21ib2JveC4gMjAxNi8wNC8xM1xuICAgIHZhciBpbm5lck5vZGUgPSBudWxsO1xuICAgIGlmIChpc1NpbmdsZU1vZGUocHJvcHMpKSB7XG4gICAgICB2YXIgc2VsZWN0ZWRWYWx1ZSA9IG51bGw7XG4gICAgICBpZiAodmFsdWUubGVuZ3RoKSB7XG4gICAgICAgIHZhciBzaG93U2VsZWN0ZWRWYWx1ZSA9IGZhbHNlO1xuICAgICAgICB2YXIgb3BhY2l0eSA9IDE7XG4gICAgICAgIGlmICghc2hvd1NlYXJjaCkge1xuICAgICAgICAgIHNob3dTZWxlY3RlZFZhbHVlID0gdHJ1ZTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBpZiAob3Blbikge1xuICAgICAgICAgICAgc2hvd1NlbGVjdGVkVmFsdWUgPSAhaW5wdXRWYWx1ZTtcbiAgICAgICAgICAgIGlmIChzaG93U2VsZWN0ZWRWYWx1ZSkge1xuICAgICAgICAgICAgICBvcGFjaXR5ID0gMC40O1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBzaG93U2VsZWN0ZWRWYWx1ZSA9IHRydWU7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHZhciBzaW5nbGVWYWx1ZSA9IHZhbHVlWzBdO1xuXG4gICAgICAgIHZhciBfZ2V0T3B0aW9uSW5mb0J5U2luZ2wzID0gX3RoaXMyLmdldE9wdGlvbkluZm9CeVNpbmdsZVZhbHVlKHNpbmdsZVZhbHVlKSxcbiAgICAgICAgICAgIGxhYmVsID0gX2dldE9wdGlvbkluZm9CeVNpbmdsMy5sYWJlbCxcbiAgICAgICAgICAgIHRpdGxlID0gX2dldE9wdGlvbkluZm9CeVNpbmdsMy50aXRsZTtcblxuICAgICAgICBzZWxlY3RlZFZhbHVlID0gUmVhY3QuY3JlYXRlRWxlbWVudChcbiAgICAgICAgICAnZGl2JyxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBrZXk6ICd2YWx1ZScsXG4gICAgICAgICAgICBjbGFzc05hbWU6IHByZWZpeENscyArICctc2VsZWN0aW9uLXNlbGVjdGVkLXZhbHVlJyxcbiAgICAgICAgICAgIHRpdGxlOiB0aXRsZSB8fCBsYWJlbCxcbiAgICAgICAgICAgIHN0eWxlOiB7XG4gICAgICAgICAgICAgIGRpc3BsYXk6IHNob3dTZWxlY3RlZFZhbHVlID8gJ2Jsb2NrJyA6ICdub25lJyxcbiAgICAgICAgICAgICAgb3BhY2l0eTogb3BhY2l0eVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0sXG4gICAgICAgICAgbGFiZWxcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIGlmICghc2hvd1NlYXJjaCkge1xuICAgICAgICBpbm5lck5vZGUgPSBbc2VsZWN0ZWRWYWx1ZV07XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBpbm5lck5vZGUgPSBbc2VsZWN0ZWRWYWx1ZSwgUmVhY3QuY3JlYXRlRWxlbWVudChcbiAgICAgICAgICAnZGl2JyxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBjbGFzc05hbWU6IHByZWZpeENscyArICctc2VhcmNoICcgKyBwcmVmaXhDbHMgKyAnLXNlYXJjaC0taW5saW5lJyxcbiAgICAgICAgICAgIGtleTogJ2lucHV0JyxcbiAgICAgICAgICAgIHN0eWxlOiB7XG4gICAgICAgICAgICAgIGRpc3BsYXk6IG9wZW4gPyAnYmxvY2snIDogJ25vbmUnXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSxcbiAgICAgICAgICBfdGhpczIuZ2V0SW5wdXRFbGVtZW50KClcbiAgICAgICAgKV07XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHZhciBzZWxlY3RlZFZhbHVlTm9kZXMgPSBbXTtcbiAgICAgIHZhciBsaW1pdGVkQ291bnRWYWx1ZSA9IHZhbHVlO1xuICAgICAgdmFyIG1heFRhZ1BsYWNlaG9sZGVyRWwgPSB2b2lkIDA7XG4gICAgICBpZiAobWF4VGFnQ291bnQgIT09IHVuZGVmaW5lZCAmJiB2YWx1ZS5sZW5ndGggPiBtYXhUYWdDb3VudCkge1xuICAgICAgICBsaW1pdGVkQ291bnRWYWx1ZSA9IGxpbWl0ZWRDb3VudFZhbHVlLnNsaWNlKDAsIG1heFRhZ0NvdW50KTtcbiAgICAgICAgdmFyIG9taXR0ZWRWYWx1ZXMgPSBfdGhpczIuZ2V0VkxGb3JPbkNoYW5nZSh2YWx1ZS5zbGljZShtYXhUYWdDb3VudCwgdmFsdWUubGVuZ3RoKSk7XG4gICAgICAgIHZhciBjb250ZW50ID0gJysgJyArICh2YWx1ZS5sZW5ndGggLSBtYXhUYWdDb3VudCkgKyAnIC4uLic7XG4gICAgICAgIGlmIChtYXhUYWdQbGFjZWhvbGRlcikge1xuICAgICAgICAgIGNvbnRlbnQgPSB0eXBlb2YgbWF4VGFnUGxhY2Vob2xkZXIgPT09ICdmdW5jdGlvbicgPyBtYXhUYWdQbGFjZWhvbGRlcihvbWl0dGVkVmFsdWVzKSA6IG1heFRhZ1BsYWNlaG9sZGVyO1xuICAgICAgICB9XG4gICAgICAgIG1heFRhZ1BsYWNlaG9sZGVyRWwgPSBSZWFjdC5jcmVhdGVFbGVtZW50KFxuICAgICAgICAgICdsaScsXG4gICAgICAgICAgX2V4dGVuZHMoe1xuICAgICAgICAgICAgc3R5bGU6IFVOU0VMRUNUQUJMRV9TVFlMRVxuICAgICAgICAgIH0sIFVOU0VMRUNUQUJMRV9BVFRSSUJVVEUsIHtcbiAgICAgICAgICAgIG9uTW91c2VEb3duOiBwcmV2ZW50RGVmYXVsdEV2ZW50LFxuICAgICAgICAgICAgY2xhc3NOYW1lOiBwcmVmaXhDbHMgKyAnLXNlbGVjdGlvbl9fY2hvaWNlICcgKyBwcmVmaXhDbHMgKyAnLXNlbGVjdGlvbl9fY2hvaWNlX19kaXNhYmxlZCcsXG4gICAgICAgICAgICBrZXk6ICdtYXhUYWdQbGFjZWhvbGRlcicsXG4gICAgICAgICAgICB0aXRsZTogY29udGVudFxuICAgICAgICAgIH0pLFxuICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXG4gICAgICAgICAgICAnZGl2JyxcbiAgICAgICAgICAgIHsgY2xhc3NOYW1lOiBwcmVmaXhDbHMgKyAnLXNlbGVjdGlvbl9fY2hvaWNlX19jb250ZW50JyB9LFxuICAgICAgICAgICAgY29udGVudFxuICAgICAgICAgIClcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIGlmIChpc011bHRpcGxlT3JUYWdzKHByb3BzKSkge1xuICAgICAgICBzZWxlY3RlZFZhbHVlTm9kZXMgPSBsaW1pdGVkQ291bnRWYWx1ZS5tYXAoZnVuY3Rpb24gKHNpbmdsZVZhbHVlKSB7XG4gICAgICAgICAgdmFyIGluZm8gPSBfdGhpczIuZ2V0T3B0aW9uSW5mb0J5U2luZ2xlVmFsdWUoc2luZ2xlVmFsdWUpO1xuICAgICAgICAgIHZhciBjb250ZW50ID0gaW5mby5sYWJlbDtcbiAgICAgICAgICB2YXIgdGl0bGUgPSBpbmZvLnRpdGxlIHx8IGNvbnRlbnQ7XG4gICAgICAgICAgaWYgKG1heFRhZ1RleHRMZW5ndGggJiYgdHlwZW9mIGNvbnRlbnQgPT09ICdzdHJpbmcnICYmIGNvbnRlbnQubGVuZ3RoID4gbWF4VGFnVGV4dExlbmd0aCkge1xuICAgICAgICAgICAgY29udGVudCA9IGNvbnRlbnQuc2xpY2UoMCwgbWF4VGFnVGV4dExlbmd0aCkgKyAnLi4uJztcbiAgICAgICAgICB9XG4gICAgICAgICAgdmFyIGRpc2FibGVkID0gX3RoaXMyLmlzQ2hpbGREaXNhYmxlZChzaW5nbGVWYWx1ZSk7XG4gICAgICAgICAgdmFyIGNob2ljZUNsYXNzTmFtZSA9IGRpc2FibGVkID8gcHJlZml4Q2xzICsgJy1zZWxlY3Rpb25fX2Nob2ljZSAnICsgcHJlZml4Q2xzICsgJy1zZWxlY3Rpb25fX2Nob2ljZV9fZGlzYWJsZWQnIDogcHJlZml4Q2xzICsgJy1zZWxlY3Rpb25fX2Nob2ljZSc7XG4gICAgICAgICAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXG4gICAgICAgICAgICAnbGknLFxuICAgICAgICAgICAgX2V4dGVuZHMoe1xuICAgICAgICAgICAgICBzdHlsZTogVU5TRUxFQ1RBQkxFX1NUWUxFXG4gICAgICAgICAgICB9LCBVTlNFTEVDVEFCTEVfQVRUUklCVVRFLCB7XG4gICAgICAgICAgICAgIG9uTW91c2VEb3duOiBwcmV2ZW50RGVmYXVsdEV2ZW50LFxuICAgICAgICAgICAgICBjbGFzc05hbWU6IGNob2ljZUNsYXNzTmFtZSxcbiAgICAgICAgICAgICAga2V5OiBzaW5nbGVWYWx1ZSxcbiAgICAgICAgICAgICAgdGl0bGU6IHRpdGxlXG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXG4gICAgICAgICAgICAgICdkaXYnLFxuICAgICAgICAgICAgICB7IGNsYXNzTmFtZTogcHJlZml4Q2xzICsgJy1zZWxlY3Rpb25fX2Nob2ljZV9fY29udGVudCcgfSxcbiAgICAgICAgICAgICAgY29udGVudFxuICAgICAgICAgICAgKSxcbiAgICAgICAgICAgIGRpc2FibGVkID8gbnVsbCA6IFJlYWN0LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nLCB7XG4gICAgICAgICAgICAgIGNsYXNzTmFtZTogcHJlZml4Q2xzICsgJy1zZWxlY3Rpb25fX2Nob2ljZV9fcmVtb3ZlJyxcbiAgICAgICAgICAgICAgb25DbGljazogX3RoaXMyLnJlbW92ZVNlbGVjdGVkLmJpbmQoX3RoaXMyLCBzaW5nbGVWYWx1ZSlcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgKTtcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICBpZiAobWF4VGFnUGxhY2Vob2xkZXJFbCkge1xuICAgICAgICBzZWxlY3RlZFZhbHVlTm9kZXMucHVzaChtYXhUYWdQbGFjZWhvbGRlckVsKTtcbiAgICAgIH1cbiAgICAgIHNlbGVjdGVkVmFsdWVOb2Rlcy5wdXNoKFJlYWN0LmNyZWF0ZUVsZW1lbnQoXG4gICAgICAgICdsaScsXG4gICAgICAgIHtcbiAgICAgICAgICBjbGFzc05hbWU6IHByZWZpeENscyArICctc2VhcmNoICcgKyBwcmVmaXhDbHMgKyAnLXNlYXJjaC0taW5saW5lJyxcbiAgICAgICAgICBrZXk6ICdfX2lucHV0J1xuICAgICAgICB9LFxuICAgICAgICBfdGhpczIuZ2V0SW5wdXRFbGVtZW50KClcbiAgICAgICkpO1xuXG4gICAgICBpZiAoaXNNdWx0aXBsZU9yVGFncyhwcm9wcykgJiYgY2hvaWNlVHJhbnNpdGlvbk5hbWUpIHtcbiAgICAgICAgaW5uZXJOb2RlID0gUmVhY3QuY3JlYXRlRWxlbWVudChcbiAgICAgICAgICBBbmltYXRlLFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIG9uTGVhdmU6IF90aGlzMi5vbkNob2ljZUFuaW1hdGlvbkxlYXZlLFxuICAgICAgICAgICAgY29tcG9uZW50OiAndWwnLFxuICAgICAgICAgICAgdHJhbnNpdGlvbk5hbWU6IGNob2ljZVRyYW5zaXRpb25OYW1lXG4gICAgICAgICAgfSxcbiAgICAgICAgICBzZWxlY3RlZFZhbHVlTm9kZXNcbiAgICAgICAgKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGlubmVyTm9kZSA9IFJlYWN0LmNyZWF0ZUVsZW1lbnQoXG4gICAgICAgICAgJ3VsJyxcbiAgICAgICAgICBudWxsLFxuICAgICAgICAgIHNlbGVjdGVkVmFsdWVOb2Rlc1xuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gUmVhY3QuY3JlYXRlRWxlbWVudChcbiAgICAgICdkaXYnLFxuICAgICAgeyBjbGFzc05hbWU6IGNsYXNzTmFtZSwgcmVmOiBzYXZlUmVmKF90aGlzMiwgJ3RvcEN0cmxSZWYnKSB9LFxuICAgICAgX3RoaXMyLmdldFBsYWNlaG9sZGVyRWxlbWVudCgpLFxuICAgICAgaW5uZXJOb2RlXG4gICAgKTtcbiAgfTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IFNlbGVjdDtcblxuXG5TZWxlY3QuZGlzcGxheU5hbWUgPSAnU2VsZWN0JzsiLCJpbXBvcnQgX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzIGZyb20gJ2JhYmVsLXJ1bnRpbWUvaGVscGVycy9vYmplY3RXaXRob3V0UHJvcGVydGllcyc7XG5pbXBvcnQgX2V4dGVuZHMgZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL2V4dGVuZHMnO1xuaW1wb3J0IF9jbGFzc0NhbGxDaGVjayBmcm9tICdiYWJlbC1ydW50aW1lL2hlbHBlcnMvY2xhc3NDYWxsQ2hlY2snO1xuaW1wb3J0IF9wb3NzaWJsZUNvbnN0cnVjdG9yUmV0dXJuIGZyb20gJ2JhYmVsLXJ1bnRpbWUvaGVscGVycy9wb3NzaWJsZUNvbnN0cnVjdG9yUmV0dXJuJztcbmltcG9ydCBfaW5oZXJpdHMgZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL2luaGVyaXRzJztcbmltcG9ydCBUcmlnZ2VyIGZyb20gJ3JjLXRyaWdnZXInO1xuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcyc7XG5pbXBvcnQgY2xhc3NuYW1lcyBmcm9tICdjbGFzc25hbWVzJztcbmltcG9ydCBEcm9wZG93bk1lbnUgZnJvbSAnLi9Ecm9wZG93bk1lbnUnO1xuaW1wb3J0IFJlYWN0RE9NIGZyb20gJ3JlYWN0LWRvbSc7XG5pbXBvcnQgeyBpc1NpbmdsZU1vZGUsIHNhdmVSZWYgfSBmcm9tICcuL3V0aWwnO1xuXG5UcmlnZ2VyLmRpc3BsYXlOYW1lID0gJ1RyaWdnZXInO1xuXG52YXIgQlVJTFRfSU5fUExBQ0VNRU5UUyA9IHtcbiAgYm90dG9tTGVmdDoge1xuICAgIHBvaW50czogWyd0bCcsICdibCddLFxuICAgIG9mZnNldDogWzAsIDRdLFxuICAgIG92ZXJmbG93OiB7XG4gICAgICBhZGp1c3RYOiAwLFxuICAgICAgYWRqdXN0WTogMVxuICAgIH1cbiAgfSxcbiAgdG9wTGVmdDoge1xuICAgIHBvaW50czogWydibCcsICd0bCddLFxuICAgIG9mZnNldDogWzAsIC00XSxcbiAgICBvdmVyZmxvdzoge1xuICAgICAgYWRqdXN0WDogMCxcbiAgICAgIGFkanVzdFk6IDFcbiAgICB9XG4gIH1cbn07XG5cbnZhciBTZWxlY3RUcmlnZ2VyID0gZnVuY3Rpb24gKF9SZWFjdCRDb21wb25lbnQpIHtcbiAgX2luaGVyaXRzKFNlbGVjdFRyaWdnZXIsIF9SZWFjdCRDb21wb25lbnQpO1xuXG4gIGZ1bmN0aW9uIFNlbGVjdFRyaWdnZXIoKSB7XG4gICAgdmFyIF90ZW1wLCBfdGhpcywgX3JldDtcblxuICAgIF9jbGFzc0NhbGxDaGVjayh0aGlzLCBTZWxlY3RUcmlnZ2VyKTtcblxuICAgIGZvciAodmFyIF9sZW4gPSBhcmd1bWVudHMubGVuZ3RoLCBhcmdzID0gQXJyYXkoX2xlbiksIF9rZXkgPSAwOyBfa2V5IDwgX2xlbjsgX2tleSsrKSB7XG4gICAgICBhcmdzW19rZXldID0gYXJndW1lbnRzW19rZXldO1xuICAgIH1cblxuICAgIHJldHVybiBfcmV0ID0gKF90ZW1wID0gKF90aGlzID0gX3Bvc3NpYmxlQ29uc3RydWN0b3JSZXR1cm4odGhpcywgX1JlYWN0JENvbXBvbmVudC5jYWxsLmFwcGx5KF9SZWFjdCRDb21wb25lbnQsIFt0aGlzXS5jb25jYXQoYXJncykpKSwgX3RoaXMpLCBfdGhpcy5zdGF0ZSA9IHtcbiAgICAgIGRyb3Bkb3duV2lkdGg6IG51bGxcbiAgICB9LCBfdGhpcy5zZXREcm9wZG93bldpZHRoID0gZnVuY3Rpb24gKCkge1xuICAgICAgdmFyIHdpZHRoID0gUmVhY3RET00uZmluZERPTU5vZGUoX3RoaXMpLm9mZnNldFdpZHRoO1xuICAgICAgaWYgKHdpZHRoICE9PSBfdGhpcy5zdGF0ZS5kcm9wZG93bldpZHRoKSB7XG4gICAgICAgIF90aGlzLnNldFN0YXRlKHsgZHJvcGRvd25XaWR0aDogd2lkdGggfSk7XG4gICAgICB9XG4gICAgfSwgX3RoaXMuZ2V0SW5uZXJNZW51ID0gZnVuY3Rpb24gKCkge1xuICAgICAgcmV0dXJuIF90aGlzLmRyb3Bkb3duTWVudVJlZiAmJiBfdGhpcy5kcm9wZG93bk1lbnVSZWYubWVudVJlZjtcbiAgICB9LCBfdGhpcy5nZXRQb3B1cERPTU5vZGUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICByZXR1cm4gX3RoaXMudHJpZ2dlclJlZi5nZXRQb3B1cERvbU5vZGUoKTtcbiAgICB9LCBfdGhpcy5nZXREcm9wZG93bkVsZW1lbnQgPSBmdW5jdGlvbiAobmV3UHJvcHMpIHtcbiAgICAgIHZhciBwcm9wcyA9IF90aGlzLnByb3BzO1xuICAgICAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoRHJvcGRvd25NZW51LCBfZXh0ZW5kcyh7XG4gICAgICAgIHJlZjogc2F2ZVJlZihfdGhpcywgJ2Ryb3Bkb3duTWVudVJlZicpXG4gICAgICB9LCBuZXdQcm9wcywge1xuICAgICAgICBwcmVmaXhDbHM6IF90aGlzLmdldERyb3Bkb3duUHJlZml4Q2xzKCksXG4gICAgICAgIG9uTWVudVNlbGVjdDogcHJvcHMub25NZW51U2VsZWN0LFxuICAgICAgICBvbk1lbnVEZXNlbGVjdDogcHJvcHMub25NZW51RGVzZWxlY3QsXG4gICAgICAgIG9uUG9wdXBTY3JvbGw6IHByb3BzLm9uUG9wdXBTY3JvbGwsXG4gICAgICAgIHZhbHVlOiBwcm9wcy52YWx1ZSxcbiAgICAgICAgYmFja2ZpbGxWYWx1ZTogcHJvcHMuYmFja2ZpbGxWYWx1ZSxcbiAgICAgICAgZmlyc3RBY3RpdmVWYWx1ZTogcHJvcHMuZmlyc3RBY3RpdmVWYWx1ZSxcbiAgICAgICAgZGVmYXVsdEFjdGl2ZUZpcnN0T3B0aW9uOiBwcm9wcy5kZWZhdWx0QWN0aXZlRmlyc3RPcHRpb24sXG4gICAgICAgIGRyb3Bkb3duTWVudVN0eWxlOiBwcm9wcy5kcm9wZG93bk1lbnVTdHlsZVxuICAgICAgfSkpO1xuICAgIH0sIF90aGlzLmdldERyb3Bkb3duVHJhbnNpdGlvbk5hbWUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICB2YXIgcHJvcHMgPSBfdGhpcy5wcm9wcztcbiAgICAgIHZhciB0cmFuc2l0aW9uTmFtZSA9IHByb3BzLnRyYW5zaXRpb25OYW1lO1xuICAgICAgaWYgKCF0cmFuc2l0aW9uTmFtZSAmJiBwcm9wcy5hbmltYXRpb24pIHtcbiAgICAgICAgdHJhbnNpdGlvbk5hbWUgPSBfdGhpcy5nZXREcm9wZG93blByZWZpeENscygpICsgJy0nICsgcHJvcHMuYW5pbWF0aW9uO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHRyYW5zaXRpb25OYW1lO1xuICAgIH0sIF90aGlzLmdldERyb3Bkb3duUHJlZml4Q2xzID0gZnVuY3Rpb24gKCkge1xuICAgICAgcmV0dXJuIF90aGlzLnByb3BzLnByZWZpeENscyArICctZHJvcGRvd24nO1xuICAgIH0sIF90ZW1wKSwgX3Bvc3NpYmxlQ29uc3RydWN0b3JSZXR1cm4oX3RoaXMsIF9yZXQpO1xuICB9XG5cbiAgU2VsZWN0VHJpZ2dlci5wcm90b3R5cGUuY29tcG9uZW50RGlkTW91bnQgPSBmdW5jdGlvbiBjb21wb25lbnREaWRNb3VudCgpIHtcbiAgICB0aGlzLnNldERyb3Bkb3duV2lkdGgoKTtcbiAgfTtcblxuICBTZWxlY3RUcmlnZ2VyLnByb3RvdHlwZS5jb21wb25lbnREaWRVcGRhdGUgPSBmdW5jdGlvbiBjb21wb25lbnREaWRVcGRhdGUoKSB7XG4gICAgdGhpcy5zZXREcm9wZG93bldpZHRoKCk7XG4gIH07XG5cbiAgU2VsZWN0VHJpZ2dlci5wcm90b3R5cGUucmVuZGVyID0gZnVuY3Rpb24gcmVuZGVyKCkge1xuICAgIHZhciBfcG9wdXBDbGFzc05hbWU7XG5cbiAgICB2YXIgX3Byb3BzID0gdGhpcy5wcm9wcyxcbiAgICAgICAgb25Qb3B1cEZvY3VzID0gX3Byb3BzLm9uUG9wdXBGb2N1cyxcbiAgICAgICAgcHJvcHMgPSBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXMoX3Byb3BzLCBbJ29uUG9wdXBGb2N1cyddKTtcblxuICAgIHZhciBtdWx0aXBsZSA9IHByb3BzLm11bHRpcGxlLFxuICAgICAgICB2aXNpYmxlID0gcHJvcHMudmlzaWJsZSxcbiAgICAgICAgaW5wdXRWYWx1ZSA9IHByb3BzLmlucHV0VmFsdWUsXG4gICAgICAgIGRyb3Bkb3duQWxpZ24gPSBwcm9wcy5kcm9wZG93bkFsaWduLFxuICAgICAgICBkaXNhYmxlZCA9IHByb3BzLmRpc2FibGVkLFxuICAgICAgICBzaG93U2VhcmNoID0gcHJvcHMuc2hvd1NlYXJjaCxcbiAgICAgICAgZHJvcGRvd25DbGFzc05hbWUgPSBwcm9wcy5kcm9wZG93bkNsYXNzTmFtZSxcbiAgICAgICAgZHJvcGRvd25TdHlsZSA9IHByb3BzLmRyb3Bkb3duU3R5bGUsXG4gICAgICAgIGRyb3Bkb3duTWF0Y2hTZWxlY3RXaWR0aCA9IHByb3BzLmRyb3Bkb3duTWF0Y2hTZWxlY3RXaWR0aDtcblxuICAgIHZhciBkcm9wZG93blByZWZpeENscyA9IHRoaXMuZ2V0RHJvcGRvd25QcmVmaXhDbHMoKTtcbiAgICB2YXIgcG9wdXBDbGFzc05hbWUgPSAoX3BvcHVwQ2xhc3NOYW1lID0ge30sIF9wb3B1cENsYXNzTmFtZVtkcm9wZG93bkNsYXNzTmFtZV0gPSAhIWRyb3Bkb3duQ2xhc3NOYW1lLCBfcG9wdXBDbGFzc05hbWVbZHJvcGRvd25QcmVmaXhDbHMgKyAnLS0nICsgKG11bHRpcGxlID8gJ211bHRpcGxlJyA6ICdzaW5nbGUnKV0gPSAxLCBfcG9wdXBDbGFzc05hbWUpO1xuICAgIHZhciBwb3B1cEVsZW1lbnQgPSB0aGlzLmdldERyb3Bkb3duRWxlbWVudCh7XG4gICAgICBtZW51SXRlbXM6IHByb3BzLm9wdGlvbnMsXG4gICAgICBvblBvcHVwRm9jdXM6IG9uUG9wdXBGb2N1cyxcbiAgICAgIG11bHRpcGxlOiBtdWx0aXBsZSxcbiAgICAgIGlucHV0VmFsdWU6IGlucHV0VmFsdWUsXG4gICAgICB2aXNpYmxlOiB2aXNpYmxlXG4gICAgfSk7XG4gICAgdmFyIGhpZGVBY3Rpb24gPSB2b2lkIDA7XG4gICAgaWYgKGRpc2FibGVkKSB7XG4gICAgICBoaWRlQWN0aW9uID0gW107XG4gICAgfSBlbHNlIGlmIChpc1NpbmdsZU1vZGUocHJvcHMpICYmICFzaG93U2VhcmNoKSB7XG4gICAgICBoaWRlQWN0aW9uID0gWydjbGljayddO1xuICAgIH0gZWxzZSB7XG4gICAgICBoaWRlQWN0aW9uID0gWydibHVyJ107XG4gICAgfVxuICAgIHZhciBwb3B1cFN0eWxlID0gX2V4dGVuZHMoe30sIGRyb3Bkb3duU3R5bGUpO1xuICAgIHZhciB3aWR0aFByb3AgPSBkcm9wZG93bk1hdGNoU2VsZWN0V2lkdGggPyAnd2lkdGgnIDogJ21pbldpZHRoJztcbiAgICBpZiAodGhpcy5zdGF0ZS5kcm9wZG93bldpZHRoKSB7XG4gICAgICBwb3B1cFN0eWxlW3dpZHRoUHJvcF0gPSB0aGlzLnN0YXRlLmRyb3Bkb3duV2lkdGggKyAncHgnO1xuICAgIH1cblxuICAgIHJldHVybiBSZWFjdC5jcmVhdGVFbGVtZW50KFxuICAgICAgVHJpZ2dlcixcbiAgICAgIF9leHRlbmRzKHt9LCBwcm9wcywge1xuICAgICAgICBzaG93QWN0aW9uOiBkaXNhYmxlZCA/IFtdIDogdGhpcy5wcm9wcy5zaG93QWN0aW9uLFxuICAgICAgICBoaWRlQWN0aW9uOiBoaWRlQWN0aW9uLFxuICAgICAgICByZWY6IHNhdmVSZWYodGhpcywgJ3RyaWdnZXJSZWYnKSxcbiAgICAgICAgcG9wdXBQbGFjZW1lbnQ6ICdib3R0b21MZWZ0JyxcbiAgICAgICAgYnVpbHRpblBsYWNlbWVudHM6IEJVSUxUX0lOX1BMQUNFTUVOVFMsXG4gICAgICAgIHByZWZpeENsczogZHJvcGRvd25QcmVmaXhDbHMsXG4gICAgICAgIHBvcHVwVHJhbnNpdGlvbk5hbWU6IHRoaXMuZ2V0RHJvcGRvd25UcmFuc2l0aW9uTmFtZSgpLFxuICAgICAgICBvblBvcHVwVmlzaWJsZUNoYW5nZTogcHJvcHMub25Ecm9wZG93blZpc2libGVDaGFuZ2UsXG4gICAgICAgIHBvcHVwOiBwb3B1cEVsZW1lbnQsXG4gICAgICAgIHBvcHVwQWxpZ246IGRyb3Bkb3duQWxpZ24sXG4gICAgICAgIHBvcHVwVmlzaWJsZTogdmlzaWJsZSxcbiAgICAgICAgZ2V0UG9wdXBDb250YWluZXI6IHByb3BzLmdldFBvcHVwQ29udGFpbmVyLFxuICAgICAgICBwb3B1cENsYXNzTmFtZTogY2xhc3NuYW1lcyhwb3B1cENsYXNzTmFtZSksXG4gICAgICAgIHBvcHVwU3R5bGU6IHBvcHVwU3R5bGVcbiAgICAgIH0pLFxuICAgICAgcHJvcHMuY2hpbGRyZW5cbiAgICApO1xuICB9O1xuXG4gIHJldHVybiBTZWxlY3RUcmlnZ2VyO1xufShSZWFjdC5Db21wb25lbnQpO1xuXG5TZWxlY3RUcmlnZ2VyLnByb3BUeXBlcyA9IHtcbiAgb25Qb3B1cEZvY3VzOiBQcm9wVHlwZXMuZnVuYyxcbiAgb25Qb3B1cFNjcm9sbDogUHJvcFR5cGVzLmZ1bmMsXG4gIGRyb3Bkb3duTWF0Y2hTZWxlY3RXaWR0aDogUHJvcFR5cGVzLmJvb2wsXG4gIGRyb3Bkb3duQWxpZ246IFByb3BUeXBlcy5vYmplY3QsXG4gIHZpc2libGU6IFByb3BUeXBlcy5ib29sLFxuICBkaXNhYmxlZDogUHJvcFR5cGVzLmJvb2wsXG4gIHNob3dTZWFyY2g6IFByb3BUeXBlcy5ib29sLFxuICBkcm9wZG93bkNsYXNzTmFtZTogUHJvcFR5cGVzLnN0cmluZyxcbiAgbXVsdGlwbGU6IFByb3BUeXBlcy5ib29sLFxuICBpbnB1dFZhbHVlOiBQcm9wVHlwZXMuc3RyaW5nLFxuICBmaWx0ZXJPcHRpb246IFByb3BUeXBlcy5hbnksXG4gIG9wdGlvbnM6IFByb3BUeXBlcy5hbnksXG4gIHByZWZpeENsczogUHJvcFR5cGVzLnN0cmluZyxcbiAgcG9wdXBDbGFzc05hbWU6IFByb3BUeXBlcy5zdHJpbmcsXG4gIGNoaWxkcmVuOiBQcm9wVHlwZXMuYW55LFxuICBzaG93QWN0aW9uOiBQcm9wVHlwZXMuYXJyYXlPZihQcm9wVHlwZXMuc3RyaW5nKVxufTtcbmV4cG9ydCBkZWZhdWx0IFNlbGVjdFRyaWdnZXI7XG5cblxuU2VsZWN0VHJpZ2dlci5kaXNwbGF5TmFtZSA9ICdTZWxlY3RUcmlnZ2VyJzsiLCJpbXBvcnQgU2VsZWN0IGZyb20gJy4vU2VsZWN0JztcbmltcG9ydCBPcHRpb24gZnJvbSAnLi9PcHRpb24nO1xuaW1wb3J0IHsgU2VsZWN0UHJvcFR5cGVzIH0gZnJvbSAnLi9Qcm9wVHlwZXMnO1xuaW1wb3J0IE9wdEdyb3VwIGZyb20gJy4vT3B0R3JvdXAnO1xuU2VsZWN0Lk9wdGlvbiA9IE9wdGlvbjtcblNlbGVjdC5PcHRHcm91cCA9IE9wdEdyb3VwO1xuZXhwb3J0IHsgT3B0aW9uLCBPcHRHcm91cCwgU2VsZWN0UHJvcFR5cGVzIH07XG5leHBvcnQgZGVmYXVsdCBTZWxlY3Q7IiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcblxuZXhwb3J0IGZ1bmN0aW9uIGdldFZhbHVlUHJvcFZhbHVlKGNoaWxkKSB7XG4gIHZhciBwcm9wcyA9IGNoaWxkLnByb3BzO1xuICBpZiAoJ3ZhbHVlJyBpbiBwcm9wcykge1xuICAgIHJldHVybiBwcm9wcy52YWx1ZTtcbiAgfVxuICBpZiAoY2hpbGQua2V5KSB7XG4gICAgcmV0dXJuIGNoaWxkLmtleTtcbiAgfVxuICBpZiAoY2hpbGQudHlwZSAmJiBjaGlsZC50eXBlLmlzU2VsZWN0T3B0R3JvdXAgJiYgcHJvcHMubGFiZWwpIHtcbiAgICByZXR1cm4gcHJvcHMubGFiZWw7XG4gIH1cbiAgdGhyb3cgbmV3IEVycm9yKCdOZWVkIGF0IGxlYXN0IGEga2V5IG9yIGEgdmFsdWUgb3IgYSBsYWJlbCAob25seSBmb3IgT3B0R3JvdXApIGZvciAnICsgY2hpbGQpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZ2V0UHJvcFZhbHVlKGNoaWxkLCBwcm9wKSB7XG4gIGlmIChwcm9wID09PSAndmFsdWUnKSB7XG4gICAgcmV0dXJuIGdldFZhbHVlUHJvcFZhbHVlKGNoaWxkKTtcbiAgfVxuICByZXR1cm4gY2hpbGQucHJvcHNbcHJvcF07XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpc011bHRpcGxlKHByb3BzKSB7XG4gIHJldHVybiBwcm9wcy5tdWx0aXBsZTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzQ29tYm9ib3gocHJvcHMpIHtcbiAgcmV0dXJuIHByb3BzLmNvbWJvYm94O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gaXNNdWx0aXBsZU9yVGFncyhwcm9wcykge1xuICByZXR1cm4gcHJvcHMubXVsdGlwbGUgfHwgcHJvcHMudGFncztcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzTXVsdGlwbGVPclRhZ3NPckNvbWJvYm94KHByb3BzKSB7XG4gIHJldHVybiBpc011bHRpcGxlT3JUYWdzKHByb3BzKSB8fCBpc0NvbWJvYm94KHByb3BzKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzU2luZ2xlTW9kZShwcm9wcykge1xuICByZXR1cm4gIWlzTXVsdGlwbGVPclRhZ3NPckNvbWJvYm94KHByb3BzKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHRvQXJyYXkodmFsdWUpIHtcbiAgdmFyIHJldCA9IHZhbHVlO1xuICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCkge1xuICAgIHJldCA9IFtdO1xuICB9IGVsc2UgaWYgKCFBcnJheS5pc0FycmF5KHZhbHVlKSkge1xuICAgIHJldCA9IFt2YWx1ZV07XG4gIH1cbiAgcmV0dXJuIHJldDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldE1hcEtleSh2YWx1ZSkge1xuICByZXR1cm4gdHlwZW9mIHZhbHVlICsgJy0nICsgdmFsdWU7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBwcmV2ZW50RGVmYXVsdEV2ZW50KGUpIHtcbiAgZS5wcmV2ZW50RGVmYXVsdCgpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZmluZEluZGV4SW5WYWx1ZUJ5U2luZ2xlVmFsdWUodmFsdWUsIHNpbmdsZVZhbHVlKSB7XG4gIHZhciBpbmRleCA9IC0xO1xuICBmb3IgKHZhciBpID0gMDsgaSA8IHZhbHVlLmxlbmd0aDsgaSsrKSB7XG4gICAgaWYgKHZhbHVlW2ldID09PSBzaW5nbGVWYWx1ZSkge1xuICAgICAgaW5kZXggPSBpO1xuICAgICAgYnJlYWs7XG4gICAgfVxuICB9XG4gIHJldHVybiBpbmRleDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldExhYmVsRnJvbVByb3BzVmFsdWUodmFsdWUsIGtleSkge1xuICB2YXIgbGFiZWwgPSB2b2lkIDA7XG4gIHZhbHVlID0gdG9BcnJheSh2YWx1ZSk7XG4gIGZvciAodmFyIGkgPSAwOyBpIDwgdmFsdWUubGVuZ3RoOyBpKyspIHtcbiAgICBpZiAodmFsdWVbaV0ua2V5ID09PSBrZXkpIHtcbiAgICAgIGxhYmVsID0gdmFsdWVbaV0ubGFiZWw7XG4gICAgICBicmVhaztcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGxhYmVsO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZ2V0U2VsZWN0S2V5cyhtZW51SXRlbXMsIHZhbHVlKSB7XG4gIGlmICh2YWx1ZSA9PT0gbnVsbCB8fCB2YWx1ZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgcmV0dXJuIFtdO1xuICB9XG4gIHZhciBzZWxlY3RlZEtleXMgPSBbXTtcbiAgUmVhY3QuQ2hpbGRyZW4uZm9yRWFjaChtZW51SXRlbXMsIGZ1bmN0aW9uIChpdGVtKSB7XG4gICAgaWYgKGl0ZW0udHlwZS5pc01lbnVJdGVtR3JvdXApIHtcbiAgICAgIHNlbGVjdGVkS2V5cyA9IHNlbGVjdGVkS2V5cy5jb25jYXQoZ2V0U2VsZWN0S2V5cyhpdGVtLnByb3BzLmNoaWxkcmVuLCB2YWx1ZSkpO1xuICAgIH0gZWxzZSB7XG4gICAgICB2YXIgaXRlbVZhbHVlID0gZ2V0VmFsdWVQcm9wVmFsdWUoaXRlbSk7XG4gICAgICB2YXIgaXRlbUtleSA9IGl0ZW0ua2V5O1xuICAgICAgaWYgKGZpbmRJbmRleEluVmFsdWVCeVNpbmdsZVZhbHVlKHZhbHVlLCBpdGVtVmFsdWUpICE9PSAtMSAmJiBpdGVtS2V5KSB7XG4gICAgICAgIHNlbGVjdGVkS2V5cy5wdXNoKGl0ZW1LZXkpO1xuICAgICAgfVxuICAgIH1cbiAgfSk7XG4gIHJldHVybiBzZWxlY3RlZEtleXM7XG59XG5cbmV4cG9ydCB2YXIgVU5TRUxFQ1RBQkxFX1NUWUxFID0ge1xuICB1c2VyU2VsZWN0OiAnbm9uZScsXG4gIFdlYmtpdFVzZXJTZWxlY3Q6ICdub25lJ1xufTtcblxuZXhwb3J0IHZhciBVTlNFTEVDVEFCTEVfQVRUUklCVVRFID0ge1xuICB1bnNlbGVjdGFibGU6ICd1bnNlbGVjdGFibGUnXG59O1xuXG5leHBvcnQgZnVuY3Rpb24gZmluZEZpcnN0TWVudUl0ZW0oY2hpbGRyZW4pIHtcbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBjaGlsZHJlbi5sZW5ndGg7IGkrKykge1xuICAgIHZhciBjaGlsZCA9IGNoaWxkcmVuW2ldO1xuICAgIGlmIChjaGlsZC50eXBlLmlzTWVudUl0ZW1Hcm91cCkge1xuICAgICAgdmFyIGZvdW5kID0gZmluZEZpcnN0TWVudUl0ZW0oY2hpbGQucHJvcHMuY2hpbGRyZW4pO1xuICAgICAgaWYgKGZvdW5kKSB7XG4gICAgICAgIHJldHVybiBmb3VuZDtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKCFjaGlsZC5wcm9wcy5kaXNhYmxlZCkge1xuICAgICAgcmV0dXJuIGNoaWxkO1xuICAgIH1cbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGluY2x1ZGVzU2VwYXJhdG9ycyhzdHJpbmcsIHNlcGFyYXRvcnMpIHtcbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBzZXBhcmF0b3JzLmxlbmd0aDsgKytpKSB7XG4gICAgaWYgKHN0cmluZy5sYXN0SW5kZXhPZihzZXBhcmF0b3JzW2ldKSA+IDApIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgfVxuICByZXR1cm4gZmFsc2U7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBzcGxpdEJ5U2VwYXJhdG9ycyhzdHJpbmcsIHNlcGFyYXRvcnMpIHtcbiAgdmFyIHJlZyA9IG5ldyBSZWdFeHAoJ1snICsgc2VwYXJhdG9ycy5qb2luKCkgKyAnXScpO1xuICByZXR1cm4gc3RyaW5nLnNwbGl0KHJlZykuZmlsdGVyKGZ1bmN0aW9uICh0b2tlbikge1xuICAgIHJldHVybiB0b2tlbjtcbiAgfSk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBkZWZhdWx0RmlsdGVyRm4oaW5wdXQsIGNoaWxkKSB7XG4gIGlmIChjaGlsZC5wcm9wcy5kaXNhYmxlZCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICB2YXIgdmFsdWUgPSB0b0FycmF5KGdldFByb3BWYWx1ZShjaGlsZCwgdGhpcy5wcm9wcy5vcHRpb25GaWx0ZXJQcm9wKSkuam9pbignJyk7XG4gIHJldHVybiB2YWx1ZS50b0xvd2VyQ2FzZSgpLmluZGV4T2YoaW5wdXQudG9Mb3dlckNhc2UoKSkgPiAtMTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHZhbGlkYXRlT3B0aW9uVmFsdWUodmFsdWUsIHByb3BzKSB7XG4gIGlmIChpc1NpbmdsZU1vZGUocHJvcHMpIHx8IGlzTXVsdGlwbGUocHJvcHMpKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmICh0eXBlb2YgdmFsdWUgIT09ICdzdHJpbmcnKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdJbnZhbGlkIGB2YWx1ZWAgb2YgdHlwZSBgJyArIHR5cGVvZiB2YWx1ZSArICdgIHN1cHBsaWVkIHRvIE9wdGlvbiwgJyArICdleHBlY3RlZCBgc3RyaW5nYCB3aGVuIGB0YWdzL2NvbWJvYm94YCBpcyBgdHJ1ZWAuJyk7XG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHNhdmVSZWYoaW5zdGFuY2UsIG5hbWUpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIChub2RlKSB7XG4gICAgaW5zdGFuY2VbbmFtZV0gPSBub2RlO1xuICB9O1xufSIsImltcG9ydCBfZGVmaW5lUHJvcGVydHkgZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL2RlZmluZVByb3BlcnR5JztcbmltcG9ydCB7IHNldFRyYW5zZm9ybSwgaXNUcmFuc2Zvcm1TdXBwb3J0ZWQgfSBmcm9tICcuL3V0aWxzJztcbmltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgY2xhc3NuYW1lcyBmcm9tICdjbGFzc25hbWVzJztcblxudmFyIGlzRGV2ID0gcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJztcblxuZXhwb3J0IGZ1bmN0aW9uIGdldFNjcm9sbCh3LCB0b3ApIHtcbiAgdmFyIHJldCA9IHdbJ3BhZ2UnICsgKHRvcCA/ICdZJyA6ICdYJykgKyAnT2Zmc2V0J107XG4gIHZhciBtZXRob2QgPSAnc2Nyb2xsJyArICh0b3AgPyAnVG9wJyA6ICdMZWZ0Jyk7XG4gIGlmICh0eXBlb2YgcmV0ICE9PSAnbnVtYmVyJykge1xuICAgIHZhciBkID0gdy5kb2N1bWVudDtcbiAgICAvLyBpZTYsNyw4IHN0YW5kYXJkIG1vZGVcbiAgICByZXQgPSBkLmRvY3VtZW50RWxlbWVudFttZXRob2RdO1xuICAgIGlmICh0eXBlb2YgcmV0ICE9PSAnbnVtYmVyJykge1xuICAgICAgLy8gcXVpcmtzIG1vZGVcbiAgICAgIHJldCA9IGQuYm9keVttZXRob2RdO1xuICAgIH1cbiAgfVxuICByZXR1cm4gcmV0O1xufVxuXG5mdW5jdGlvbiBvZmZzZXQoZWxlbSkge1xuICB2YXIgYm94ID0gdm9pZCAwO1xuICB2YXIgeCA9IHZvaWQgMDtcbiAgdmFyIHkgPSB2b2lkIDA7XG4gIHZhciBkb2MgPSBlbGVtLm93bmVyRG9jdW1lbnQ7XG4gIHZhciBib2R5ID0gZG9jLmJvZHk7XG4gIHZhciBkb2NFbGVtID0gZG9jICYmIGRvYy5kb2N1bWVudEVsZW1lbnQ7XG4gIGJveCA9IGVsZW0uZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gIHggPSBib3gubGVmdDtcbiAgeSA9IGJveC50b3A7XG4gIHggLT0gZG9jRWxlbS5jbGllbnRMZWZ0IHx8IGJvZHkuY2xpZW50TGVmdCB8fCAwO1xuICB5IC09IGRvY0VsZW0uY2xpZW50VG9wIHx8IGJvZHkuY2xpZW50VG9wIHx8IDA7XG4gIHZhciB3ID0gZG9jLmRlZmF1bHRWaWV3IHx8IGRvYy5wYXJlbnRXaW5kb3c7XG4gIHggKz0gZ2V0U2Nyb2xsKHcpO1xuICB5ICs9IGdldFNjcm9sbCh3LCB0cnVlKTtcbiAgcmV0dXJuIHtcbiAgICBsZWZ0OiB4LCB0b3A6IHlcbiAgfTtcbn1cblxuZnVuY3Rpb24gX2NvbXBvbmVudERpZFVwZGF0ZShjb21wb25lbnQsIGluaXQpIHtcbiAgdmFyIHN0eWxlcyA9IGNvbXBvbmVudC5wcm9wcy5zdHlsZXM7XG5cbiAgdmFyIHJvb3ROb2RlID0gY29tcG9uZW50LnJvb3Q7XG4gIHZhciB3cmFwTm9kZSA9IGNvbXBvbmVudC5uYXYgfHwgcm9vdE5vZGU7XG4gIHZhciBjb250YWluZXJPZmZzZXQgPSBvZmZzZXQod3JhcE5vZGUpO1xuICB2YXIgaW5rQmFyTm9kZSA9IGNvbXBvbmVudC5pbmtCYXI7XG4gIHZhciBhY3RpdmVUYWIgPSBjb21wb25lbnQuYWN0aXZlVGFiO1xuICB2YXIgaW5rQmFyTm9kZVN0eWxlID0gaW5rQmFyTm9kZS5zdHlsZTtcbiAgdmFyIHRhYkJhclBvc2l0aW9uID0gY29tcG9uZW50LnByb3BzLnRhYkJhclBvc2l0aW9uO1xuICBpZiAoaW5pdCkge1xuICAgIC8vIHByZXZlbnQgbW91bnQgYW5pbWF0aW9uXG4gICAgaW5rQmFyTm9kZVN0eWxlLmRpc3BsYXkgPSAnbm9uZSc7XG4gIH1cbiAgaWYgKGFjdGl2ZVRhYikge1xuICAgIHZhciB0YWJOb2RlID0gYWN0aXZlVGFiO1xuICAgIHZhciB0YWJPZmZzZXQgPSBvZmZzZXQodGFiTm9kZSk7XG4gICAgdmFyIHRyYW5zZm9ybVN1cHBvcnRlZCA9IGlzVHJhbnNmb3JtU3VwcG9ydGVkKGlua0Jhck5vZGVTdHlsZSk7XG4gICAgaWYgKHRhYkJhclBvc2l0aW9uID09PSAndG9wJyB8fCB0YWJCYXJQb3NpdGlvbiA9PT0gJ2JvdHRvbScpIHtcbiAgICAgIHZhciBsZWZ0ID0gdGFiT2Zmc2V0LmxlZnQgLSBjb250YWluZXJPZmZzZXQubGVmdDtcbiAgICAgIHZhciB3aWR0aCA9IHRhYk5vZGUub2Zmc2V0V2lkdGg7XG5cbiAgICAgIC8vIElmIHRhYk5vZGUnd2lkdGggd2lkdGggZXF1YWwgdG8gd3JhcE5vZGUnd2lkdGggd2hlbiB0YWJCYXJQb3NpdGlvbiBpcyB0b3Agb3IgYm90dG9tXG4gICAgICAvLyBJdCBtZWFucyBubyBjc3Mgd29ya2luZywgdGhlbiBpbmsgYmFyIHNob3VsZCBub3QgaGF2ZSB3aWR0aCB1bnRpbCBjc3MgaXMgbG9hZGVkXG4gICAgICAvLyBGaXggaHR0cHM6Ly9naXRodWIuY29tL2FudC1kZXNpZ24vYW50LWRlc2lnbi9pc3N1ZXMvNzU2NFxuICAgICAgaWYgKHdpZHRoID09PSByb290Tm9kZS5vZmZzZXRXaWR0aCkge1xuICAgICAgICB3aWR0aCA9IDA7XG4gICAgICB9IGVsc2UgaWYgKHN0eWxlcy5pbmtCYXIgJiYgc3R5bGVzLmlua0Jhci53aWR0aCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHdpZHRoID0gcGFyc2VGbG9hdChzdHlsZXMuaW5rQmFyLndpZHRoLCAxMCk7XG4gICAgICAgIGlmICh3aWR0aCkge1xuICAgICAgICAgIGxlZnQgPSBsZWZ0ICsgKHRhYk5vZGUub2Zmc2V0V2lkdGggLSB3aWR0aCkgLyAyO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICAvLyB1c2UgM2QgZ3B1IHRvIG9wdGltaXplIHJlbmRlclxuICAgICAgaWYgKHRyYW5zZm9ybVN1cHBvcnRlZCkge1xuICAgICAgICBzZXRUcmFuc2Zvcm0oaW5rQmFyTm9kZVN0eWxlLCAndHJhbnNsYXRlM2QoJyArIGxlZnQgKyAncHgsMCwwKScpO1xuICAgICAgICBpbmtCYXJOb2RlU3R5bGUud2lkdGggPSB3aWR0aCArICdweCc7XG4gICAgICAgIGlua0Jhck5vZGVTdHlsZS5oZWlnaHQgPSAnJztcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGlua0Jhck5vZGVTdHlsZS5sZWZ0ID0gbGVmdCArICdweCc7XG4gICAgICAgIGlua0Jhck5vZGVTdHlsZS50b3AgPSAnJztcbiAgICAgICAgaW5rQmFyTm9kZVN0eWxlLmJvdHRvbSA9ICcnO1xuICAgICAgICBpbmtCYXJOb2RlU3R5bGUucmlnaHQgPSB3cmFwTm9kZS5vZmZzZXRXaWR0aCAtIGxlZnQgLSB3aWR0aCArICdweCc7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHZhciB0b3AgPSB0YWJPZmZzZXQudG9wIC0gY29udGFpbmVyT2Zmc2V0LnRvcDtcbiAgICAgIHZhciBoZWlnaHQgPSB0YWJOb2RlLm9mZnNldEhlaWdodDtcbiAgICAgIGlmIChzdHlsZXMuaW5rQmFyICYmIHN0eWxlcy5pbmtCYXIuaGVpZ2h0ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgaGVpZ2h0ID0gcGFyc2VGbG9hdChzdHlsZXMuaW5rQmFyLmhlaWdodCwgMTApO1xuICAgICAgICBpZiAoaGVpZ2h0KSB7XG4gICAgICAgICAgdG9wID0gdG9wICsgKHRhYk5vZGUub2Zmc2V0SGVpZ2h0IC0gaGVpZ2h0KSAvIDI7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmICh0cmFuc2Zvcm1TdXBwb3J0ZWQpIHtcbiAgICAgICAgc2V0VHJhbnNmb3JtKGlua0Jhck5vZGVTdHlsZSwgJ3RyYW5zbGF0ZTNkKDAsJyArIHRvcCArICdweCwwKScpO1xuICAgICAgICBpbmtCYXJOb2RlU3R5bGUuaGVpZ2h0ID0gaGVpZ2h0ICsgJ3B4JztcbiAgICAgICAgaW5rQmFyTm9kZVN0eWxlLndpZHRoID0gJyc7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBpbmtCYXJOb2RlU3R5bGUubGVmdCA9ICcnO1xuICAgICAgICBpbmtCYXJOb2RlU3R5bGUucmlnaHQgPSAnJztcbiAgICAgICAgaW5rQmFyTm9kZVN0eWxlLnRvcCA9IHRvcCArICdweCc7XG4gICAgICAgIGlua0Jhck5vZGVTdHlsZS5ib3R0b20gPSB3cmFwTm9kZS5vZmZzZXRIZWlnaHQgLSB0b3AgLSBoZWlnaHQgKyAncHgnO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBpbmtCYXJOb2RlU3R5bGUuZGlzcGxheSA9IGFjdGl2ZVRhYiA/ICdibG9jaycgOiAnbm9uZSc7XG59XG5cbmV4cG9ydCBkZWZhdWx0IHtcbiAgZ2V0RGVmYXVsdFByb3BzOiBmdW5jdGlvbiBnZXREZWZhdWx0UHJvcHMoKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGlua0JhckFuaW1hdGVkOiB0cnVlXG4gICAgfTtcbiAgfSxcbiAgY29tcG9uZW50RGlkVXBkYXRlOiBmdW5jdGlvbiBjb21wb25lbnREaWRVcGRhdGUoKSB7XG4gICAgX2NvbXBvbmVudERpZFVwZGF0ZSh0aGlzKTtcbiAgfSxcbiAgY29tcG9uZW50RGlkTW91bnQ6IGZ1bmN0aW9uIGNvbXBvbmVudERpZE1vdW50KCkge1xuICAgIHZhciBfdGhpcyA9IHRoaXM7XG5cbiAgICBpZiAoaXNEZXYpIHtcbiAgICAgIC8vIGh0dHBzOi8vZ2l0aHViLmNvbS9hbnQtZGVzaWduL2FudC1kZXNpZ24vaXNzdWVzLzg2NzhcbiAgICAgIHRoaXMudGltZW91dCA9IHNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xuICAgICAgICBfY29tcG9uZW50RGlkVXBkYXRlKF90aGlzLCB0cnVlKTtcbiAgICAgIH0sIDApO1xuICAgIH0gZWxzZSB7XG4gICAgICBfY29tcG9uZW50RGlkVXBkYXRlKHRoaXMsIHRydWUpO1xuICAgIH1cbiAgfSxcbiAgY29tcG9uZW50V2lsbFVubW91bnQ6IGZ1bmN0aW9uIGNvbXBvbmVudFdpbGxVbm1vdW50KCkge1xuICAgIGNsZWFyVGltZW91dCh0aGlzLnRpbWVvdXQpO1xuICB9LFxuICBnZXRJbmtCYXJOb2RlOiBmdW5jdGlvbiBnZXRJbmtCYXJOb2RlKCkge1xuICAgIHZhciBfY2xhc3NuYW1lcztcblxuICAgIHZhciBfcHJvcHMgPSB0aGlzLnByb3BzLFxuICAgICAgICBwcmVmaXhDbHMgPSBfcHJvcHMucHJlZml4Q2xzLFxuICAgICAgICBzdHlsZXMgPSBfcHJvcHMuc3R5bGVzLFxuICAgICAgICBpbmtCYXJBbmltYXRlZCA9IF9wcm9wcy5pbmtCYXJBbmltYXRlZDtcblxuICAgIHZhciBjbGFzc05hbWUgPSBwcmVmaXhDbHMgKyAnLWluay1iYXInO1xuICAgIHZhciBjbGFzc2VzID0gY2xhc3NuYW1lcygoX2NsYXNzbmFtZXMgPSB7fSwgX2RlZmluZVByb3BlcnR5KF9jbGFzc25hbWVzLCBjbGFzc05hbWUsIHRydWUpLCBfZGVmaW5lUHJvcGVydHkoX2NsYXNzbmFtZXMsIGlua0JhckFuaW1hdGVkID8gY2xhc3NOYW1lICsgJy1hbmltYXRlZCcgOiBjbGFzc05hbWUgKyAnLW5vLWFuaW1hdGVkJywgdHJ1ZSksIF9jbGFzc25hbWVzKSk7XG4gICAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoJ2RpdicsIHtcbiAgICAgIHN0eWxlOiBzdHlsZXMuaW5rQmFyLFxuICAgICAgY2xhc3NOYW1lOiBjbGFzc2VzLFxuICAgICAga2V5OiAnaW5rQmFyJyxcbiAgICAgIHJlZjogdGhpcy5zYXZlUmVmKCdpbmtCYXInKVxuICAgIH0pO1xuICB9XG59OyIsImV4cG9ydCBkZWZhdWx0IHtcbiAgLyoqXG4gICAqIExFRlRcbiAgICovXG4gIExFRlQ6IDM3LCAvLyBhbHNvIE5VTV9XRVNUXG4gIC8qKlxuICAgKiBVUFxuICAgKi9cbiAgVVA6IDM4LCAvLyBhbHNvIE5VTV9OT1JUSFxuICAvKipcbiAgICogUklHSFRcbiAgICovXG4gIFJJR0hUOiAzOSwgLy8gYWxzbyBOVU1fRUFTVFxuICAvKipcbiAgICogRE9XTlxuICAgKi9cbiAgRE9XTjogNDAgLy8gYWxzbyBOVU1fU09VVEhcbn07IiwiZXhwb3J0IGRlZmF1bHQge1xuICBzYXZlUmVmOiBmdW5jdGlvbiBzYXZlUmVmKG5hbWUpIHtcbiAgICB2YXIgX3RoaXMgPSB0aGlzO1xuXG4gICAgcmV0dXJuIGZ1bmN0aW9uIChub2RlKSB7XG4gICAgICBfdGhpc1tuYW1lXSA9IG5vZGU7XG4gICAgfTtcbiAgfVxufTsiLCJpbXBvcnQgY3JlYXRlUmVhY3RDbGFzcyBmcm9tICdjcmVhdGUtcmVhY3QtY2xhc3MnO1xuaW1wb3J0IElua1RhYkJhck1peGluIGZyb20gJy4vSW5rVGFiQmFyTWl4aW4nO1xuaW1wb3J0IFNjcm9sbGFibGVUYWJCYXJNaXhpbiBmcm9tICcuL1Njcm9sbGFibGVUYWJCYXJNaXhpbic7XG5pbXBvcnQgVGFiQmFyTWl4aW4gZnJvbSAnLi9UYWJCYXJNaXhpbic7XG5pbXBvcnQgUmVmTWl4aW4gZnJvbSAnLi9SZWZNaXhpbic7XG5cbnZhciBTY3JvbGxhYmxlSW5rVGFiQmFyID0gY3JlYXRlUmVhY3RDbGFzcyh7XG4gIGRpc3BsYXlOYW1lOiAnU2Nyb2xsYWJsZUlua1RhYkJhcicsXG4gIG1peGluczogW1JlZk1peGluLCBUYWJCYXJNaXhpbiwgSW5rVGFiQmFyTWl4aW4sIFNjcm9sbGFibGVUYWJCYXJNaXhpbl0sXG4gIHJlbmRlcjogZnVuY3Rpb24gcmVuZGVyKCkge1xuICAgIHZhciBpbmtCYXJOb2RlID0gdGhpcy5nZXRJbmtCYXJOb2RlKCk7XG4gICAgdmFyIHRhYnMgPSB0aGlzLmdldFRhYnMoKTtcbiAgICB2YXIgc2Nyb2xsYmFyTm9kZSA9IHRoaXMuZ2V0U2Nyb2xsQmFyTm9kZShbaW5rQmFyTm9kZSwgdGFic10pO1xuICAgIHJldHVybiB0aGlzLmdldFJvb3ROb2RlKHNjcm9sbGJhck5vZGUpO1xuICB9XG59KTtcblxuZXhwb3J0IGRlZmF1bHQgU2Nyb2xsYWJsZUlua1RhYkJhcjsiLCJpbXBvcnQgX2RlZmluZVByb3BlcnR5IGZyb20gJ2JhYmVsLXJ1bnRpbWUvaGVscGVycy9kZWZpbmVQcm9wZXJ0eSc7XG5pbXBvcnQgY2xhc3NuYW1lcyBmcm9tICdjbGFzc25hbWVzJztcbmltcG9ydCB7IHNldFRyYW5zZm9ybSwgaXNUcmFuc2Zvcm1TdXBwb3J0ZWQgfSBmcm9tICcuL3V0aWxzJztcbmltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgYWRkRXZlbnRMaXN0ZW5lciBmcm9tICdyYy11dGlsL2VzL0RvbS9hZGRFdmVudExpc3RlbmVyJztcbmltcG9ydCBkZWJvdW5jZSBmcm9tICdsb2Rhc2gvZGVib3VuY2UnO1xuXG5leHBvcnQgZGVmYXVsdCB7XG4gIGdldERlZmF1bHRQcm9wczogZnVuY3Rpb24gZ2V0RGVmYXVsdFByb3BzKCkge1xuICAgIHJldHVybiB7XG4gICAgICBzY3JvbGxBbmltYXRlZDogdHJ1ZSxcbiAgICAgIG9uUHJldkNsaWNrOiBmdW5jdGlvbiBvblByZXZDbGljaygpIHt9LFxuICAgICAgb25OZXh0Q2xpY2s6IGZ1bmN0aW9uIG9uTmV4dENsaWNrKCkge31cbiAgICB9O1xuICB9LFxuICBnZXRJbml0aWFsU3RhdGU6IGZ1bmN0aW9uIGdldEluaXRpYWxTdGF0ZSgpIHtcbiAgICB0aGlzLm9mZnNldCA9IDA7XG4gICAgcmV0dXJuIHtcbiAgICAgIG5leHQ6IGZhbHNlLFxuICAgICAgcHJldjogZmFsc2VcbiAgICB9O1xuICB9LFxuICBjb21wb25lbnREaWRNb3VudDogZnVuY3Rpb24gY29tcG9uZW50RGlkTW91bnQoKSB7XG4gICAgdmFyIF90aGlzID0gdGhpcztcblxuICAgIHRoaXMuY29tcG9uZW50RGlkVXBkYXRlKCk7XG4gICAgdGhpcy5kZWJvdW5jZWRSZXNpemUgPSBkZWJvdW5jZShmdW5jdGlvbiAoKSB7XG4gICAgICBfdGhpcy5zZXROZXh0UHJldigpO1xuICAgICAgX3RoaXMuc2Nyb2xsVG9BY3RpdmVUYWIoKTtcbiAgICB9LCAyMDApO1xuICAgIHRoaXMucmVzaXplRXZlbnQgPSBhZGRFdmVudExpc3RlbmVyKHdpbmRvdywgJ3Jlc2l6ZScsIHRoaXMuZGVib3VuY2VkUmVzaXplKTtcbiAgfSxcbiAgY29tcG9uZW50RGlkVXBkYXRlOiBmdW5jdGlvbiBjb21wb25lbnREaWRVcGRhdGUocHJldlByb3BzKSB7XG4gICAgdmFyIHByb3BzID0gdGhpcy5wcm9wcztcbiAgICBpZiAocHJldlByb3BzICYmIHByZXZQcm9wcy50YWJCYXJQb3NpdGlvbiAhPT0gcHJvcHMudGFiQmFyUG9zaXRpb24pIHtcbiAgICAgIHRoaXMuc2V0T2Zmc2V0KDApO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB2YXIgbmV4dFByZXYgPSB0aGlzLnNldE5leHRQcmV2KCk7XG4gICAgICAgIFxuICAgIGlmICh0aGlzLmlzTmV4dFByZXZTaG93bih0aGlzLnN0YXRlKSAhPT0gdGhpcy5pc05leHRQcmV2U2hvd24obmV4dFByZXYpKSB7XG4gICAgICB0aGlzLnNldFN0YXRlKHt9LCB0aGlzLnNjcm9sbFRvQWN0aXZlVGFiKTtcbiAgICB9IGVsc2UgaWYgKCFwcmV2UHJvcHMgfHwgcHJvcHMuYWN0aXZlS2V5ICE9PSBwcmV2UHJvcHMuYWN0aXZlS2V5KSB7XG4gICAgICAgICAgICB0aGlzLnNjcm9sbFRvQWN0aXZlVGFiKCk7XG4gICAgfVxuICB9LFxuICBjb21wb25lbnRXaWxsVW5tb3VudDogZnVuY3Rpb24gY29tcG9uZW50V2lsbFVubW91bnQoKSB7XG4gICAgaWYgKHRoaXMucmVzaXplRXZlbnQpIHtcbiAgICAgIHRoaXMucmVzaXplRXZlbnQucmVtb3ZlKCk7XG4gICAgfVxuICAgIGlmICh0aGlzLmRlYm91bmNlZFJlc2l6ZSAmJiB0aGlzLmRlYm91bmNlZFJlc2l6ZS5jYW5jZWwpIHtcbiAgICAgIHRoaXMuZGVib3VuY2VkUmVzaXplLmNhbmNlbCgpO1xuICAgIH1cbiAgfSxcbiAgc2V0TmV4dFByZXY6IGZ1bmN0aW9uIHNldE5leHRQcmV2KCkge1xuICAgIHZhciBuYXZOb2RlID0gdGhpcy5uYXY7XG4gICAgdmFyIG5hdk5vZGVXSCA9IHRoaXMuZ2V0U2Nyb2xsV0gobmF2Tm9kZSk7XG4gICAgdmFyIGNvbnRhaW5lcldIID0gdGhpcy5nZXRPZmZzZXRXSCh0aGlzLmNvbnRhaW5lcik7XG4gICAgdmFyIG5hdldyYXBOb2RlV0ggPSB0aGlzLmdldE9mZnNldFdIKHRoaXMubmF2V3JhcCk7XG4gICAgdmFyIG9mZnNldCA9IHRoaXMub2Zmc2V0O1xuXG4gICAgdmFyIG1pbk9mZnNldCA9IGNvbnRhaW5lcldIIC0gbmF2Tm9kZVdIO1xuICAgIHZhciBfc3RhdGUgPSB0aGlzLnN0YXRlLFxuICAgICAgICBuZXh0ID0gX3N0YXRlLm5leHQsXG4gICAgICAgIHByZXYgPSBfc3RhdGUucHJldjtcblxuICAgIGlmIChtaW5PZmZzZXQgPj0gMCkge1xuICAgICAgbmV4dCA9IGZhbHNlO1xuICAgICAgdGhpcy5zZXRPZmZzZXQoMCwgZmFsc2UpO1xuICAgICAgb2Zmc2V0ID0gMDtcbiAgICB9IGVsc2UgaWYgKG1pbk9mZnNldCA8IG9mZnNldCkge1xuICAgICAgbmV4dCA9IHRydWU7XG4gICAgfSBlbHNlIHtcbiAgICAgIG5leHQgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciByZWFsT2Zmc2V0ID0gbmF2V3JhcE5vZGVXSCAtIG5hdk5vZGVXSDtcbiAgICAgIHRoaXMuc2V0T2Zmc2V0KHJlYWxPZmZzZXQsIGZhbHNlKTtcbiAgICAgIG9mZnNldCA9IHJlYWxPZmZzZXQ7XG4gICAgfVxuXG4gICAgaWYgKG9mZnNldCA8IDApIHtcbiAgICAgIHByZXYgPSB0cnVlO1xuICAgIH0gZWxzZSB7XG4gICAgICBwcmV2ID0gZmFsc2U7XG4gICAgfVxuXG4gICAgdGhpcy5zZXROZXh0KG5leHQpO1xuICAgIHRoaXMuc2V0UHJldihwcmV2KTtcbiAgICByZXR1cm4ge1xuICAgICAgbmV4dDogbmV4dCxcbiAgICAgIHByZXY6IHByZXZcbiAgICB9O1xuICB9LFxuICBnZXRPZmZzZXRXSDogZnVuY3Rpb24gZ2V0T2Zmc2V0V0gobm9kZSkge1xuICAgIHZhciB0YWJCYXJQb3NpdGlvbiA9IHRoaXMucHJvcHMudGFiQmFyUG9zaXRpb247XG4gICAgdmFyIHByb3AgPSAnb2Zmc2V0V2lkdGgnO1xuICAgIGlmICh0YWJCYXJQb3NpdGlvbiA9PT0gJ2xlZnQnIHx8IHRhYkJhclBvc2l0aW9uID09PSAncmlnaHQnKSB7XG4gICAgICBwcm9wID0gJ29mZnNldEhlaWdodCc7XG4gICAgfVxuICAgIHJldHVybiBub2RlW3Byb3BdO1xuICB9LFxuICBnZXRTY3JvbGxXSDogZnVuY3Rpb24gZ2V0U2Nyb2xsV0gobm9kZSkge1xuICAgIHZhciB0YWJCYXJQb3NpdGlvbiA9IHRoaXMucHJvcHMudGFiQmFyUG9zaXRpb247XG4gICAgdmFyIHByb3AgPSAnc2Nyb2xsV2lkdGgnO1xuICAgIGlmICh0YWJCYXJQb3NpdGlvbiA9PT0gJ2xlZnQnIHx8IHRhYkJhclBvc2l0aW9uID09PSAncmlnaHQnKSB7XG4gICAgICBwcm9wID0gJ3Njcm9sbEhlaWdodCc7XG4gICAgfVxuICAgIHJldHVybiBub2RlW3Byb3BdO1xuICB9LFxuICBnZXRPZmZzZXRMVDogZnVuY3Rpb24gZ2V0T2Zmc2V0TFQobm9kZSkge1xuICAgIHZhciB0YWJCYXJQb3NpdGlvbiA9IHRoaXMucHJvcHMudGFiQmFyUG9zaXRpb247XG4gICAgdmFyIHByb3AgPSAnbGVmdCc7XG4gICAgaWYgKHRhYkJhclBvc2l0aW9uID09PSAnbGVmdCcgfHwgdGFiQmFyUG9zaXRpb24gPT09ICdyaWdodCcpIHtcbiAgICAgIHByb3AgPSAndG9wJztcbiAgICB9XG4gICAgcmV0dXJuIG5vZGUuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KClbcHJvcF07XG4gIH0sXG4gIHNldE9mZnNldDogZnVuY3Rpb24gc2V0T2Zmc2V0KG9mZnNldCkge1xuICAgIHZhciBjaGVja05leHRQcmV2ID0gYXJndW1lbnRzLmxlbmd0aCA+IDEgJiYgYXJndW1lbnRzWzFdICE9PSB1bmRlZmluZWQgPyBhcmd1bWVudHNbMV0gOiB0cnVlO1xuXG4gICAgdmFyIHRhcmdldCA9IE1hdGgubWluKDAsIG9mZnNldCk7XG4gICAgaWYgKHRoaXMub2Zmc2V0ICE9PSB0YXJnZXQpIHtcbiAgICAgIHRoaXMub2Zmc2V0ID0gdGFyZ2V0O1xuICAgICAgdmFyIG5hdk9mZnNldCA9IHt9O1xuICAgICAgdmFyIHRhYkJhclBvc2l0aW9uID0gdGhpcy5wcm9wcy50YWJCYXJQb3NpdGlvbjtcbiAgICAgIHZhciBuYXZTdHlsZSA9IHRoaXMubmF2LnN0eWxlO1xuICAgICAgdmFyIHRyYW5zZm9ybVN1cHBvcnRlZCA9IGlzVHJhbnNmb3JtU3VwcG9ydGVkKG5hdlN0eWxlKTtcbiAgICAgIGlmICh0YWJCYXJQb3NpdGlvbiA9PT0gJ2xlZnQnIHx8IHRhYkJhclBvc2l0aW9uID09PSAncmlnaHQnKSB7XG4gICAgICAgIGlmICh0cmFuc2Zvcm1TdXBwb3J0ZWQpIHtcbiAgICAgICAgICBuYXZPZmZzZXQgPSB7XG4gICAgICAgICAgICB2YWx1ZTogJ3RyYW5zbGF0ZTNkKDAsJyArIHRhcmdldCArICdweCwwKSdcbiAgICAgICAgICB9O1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIG5hdk9mZnNldCA9IHtcbiAgICAgICAgICAgIG5hbWU6ICd0b3AnLFxuICAgICAgICAgICAgdmFsdWU6IHRhcmdldCArICdweCdcbiAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBpZiAodHJhbnNmb3JtU3VwcG9ydGVkKSB7XG4gICAgICAgICAgbmF2T2Zmc2V0ID0ge1xuICAgICAgICAgICAgdmFsdWU6ICd0cmFuc2xhdGUzZCgnICsgdGFyZ2V0ICsgJ3B4LDAsMCknXG4gICAgICAgICAgfTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBuYXZPZmZzZXQgPSB7XG4gICAgICAgICAgICBuYW1lOiAnbGVmdCcsXG4gICAgICAgICAgICB2YWx1ZTogdGFyZ2V0ICsgJ3B4J1xuICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmICh0cmFuc2Zvcm1TdXBwb3J0ZWQpIHtcbiAgICAgICAgc2V0VHJhbnNmb3JtKG5hdlN0eWxlLCBuYXZPZmZzZXQudmFsdWUpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbmF2U3R5bGVbbmF2T2Zmc2V0Lm5hbWVdID0gbmF2T2Zmc2V0LnZhbHVlO1xuICAgICAgfVxuICAgICAgaWYgKGNoZWNrTmV4dFByZXYpIHtcbiAgICAgICAgdGhpcy5zZXROZXh0UHJldigpO1xuICAgICAgfVxuICAgIH1cbiAgfSxcbiAgc2V0UHJldjogZnVuY3Rpb24gc2V0UHJldih2KSB7XG4gICAgaWYgKHRoaXMuc3RhdGUucHJldiAhPT0gdikge1xuICAgICAgdGhpcy5zZXRTdGF0ZSh7XG4gICAgICAgIHByZXY6IHZcbiAgICAgIH0pO1xuICAgIH1cbiAgfSxcbiAgc2V0TmV4dDogZnVuY3Rpb24gc2V0TmV4dCh2KSB7XG4gICAgaWYgKHRoaXMuc3RhdGUubmV4dCAhPT0gdikge1xuICAgICAgdGhpcy5zZXRTdGF0ZSh7XG4gICAgICAgIG5leHQ6IHZcbiAgICAgIH0pO1xuICAgIH1cbiAgfSxcbiAgaXNOZXh0UHJldlNob3duOiBmdW5jdGlvbiBpc05leHRQcmV2U2hvd24oc3RhdGUpIHtcbiAgICBpZiAoc3RhdGUpIHtcbiAgICAgIHJldHVybiBzdGF0ZS5uZXh0IHx8IHN0YXRlLnByZXY7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLnN0YXRlLm5leHQgfHwgdGhpcy5zdGF0ZS5wcmV2O1xuICB9LFxuICBwcmV2VHJhbnNpdGlvbkVuZDogZnVuY3Rpb24gcHJldlRyYW5zaXRpb25FbmQoZSkge1xuICAgIGlmIChlLnByb3BlcnR5TmFtZSAhPT0gJ29wYWNpdHknKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHZhciBjb250YWluZXIgPSB0aGlzLmNvbnRhaW5lcjtcblxuICAgIHRoaXMuc2Nyb2xsVG9BY3RpdmVUYWIoe1xuICAgICAgdGFyZ2V0OiBjb250YWluZXIsXG4gICAgICBjdXJyZW50VGFyZ2V0OiBjb250YWluZXJcbiAgICB9KTtcbiAgfSxcbiAgc2Nyb2xsVG9BY3RpdmVUYWI6IGZ1bmN0aW9uIHNjcm9sbFRvQWN0aXZlVGFiKGUpIHtcbiAgICB2YXIgYWN0aXZlVGFiID0gdGhpcy5hY3RpdmVUYWIsXG4gICAgICAgIG5hdldyYXAgPSB0aGlzLm5hdldyYXA7XG5cbiAgICBpZiAoZSAmJiBlLnRhcmdldCAhPT0gZS5jdXJyZW50VGFyZ2V0IHx8ICFhY3RpdmVUYWIpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAgICAgdmFyIG5lZWRUb1Nyb2xsID0gdGhpcy5pc05leHRQcmV2U2hvd24oKSAmJiB0aGlzLmxhc3ROZXh0UHJldlNob3duO1xuICAgIHRoaXMubGFzdE5leHRQcmV2U2hvd24gPSB0aGlzLmlzTmV4dFByZXZTaG93bigpO1xuICAgIGlmICghbmVlZFRvU3JvbGwpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICB2YXIgYWN0aXZlVGFiV0ggPSB0aGlzLmdldFNjcm9sbFdIKGFjdGl2ZVRhYik7XG4gICAgdmFyIG5hdldyYXBOb2RlV0ggPSB0aGlzLmdldE9mZnNldFdIKG5hdldyYXApO1xuICAgIHZhciBvZmZzZXQgPSB0aGlzLm9mZnNldDtcblxuICAgIHZhciB3cmFwT2Zmc2V0ID0gdGhpcy5nZXRPZmZzZXRMVChuYXZXcmFwKTtcbiAgICB2YXIgYWN0aXZlVGFiT2Zmc2V0ID0gdGhpcy5nZXRPZmZzZXRMVChhY3RpdmVUYWIpO1xuICAgIGlmICh3cmFwT2Zmc2V0ID4gYWN0aXZlVGFiT2Zmc2V0KSB7XG4gICAgICBvZmZzZXQgKz0gd3JhcE9mZnNldCAtIGFjdGl2ZVRhYk9mZnNldDtcbiAgICAgIHRoaXMuc2V0T2Zmc2V0KG9mZnNldCk7XG4gICAgfSBlbHNlIGlmICh3cmFwT2Zmc2V0ICsgbmF2V3JhcE5vZGVXSCA8IGFjdGl2ZVRhYk9mZnNldCArIGFjdGl2ZVRhYldIKSB7XG4gICAgICBvZmZzZXQgLT0gYWN0aXZlVGFiT2Zmc2V0ICsgYWN0aXZlVGFiV0ggLSAod3JhcE9mZnNldCArIG5hdldyYXBOb2RlV0gpO1xuICAgICAgdGhpcy5zZXRPZmZzZXQob2Zmc2V0KTtcbiAgICB9XG4gIH0sXG4gIHByZXY6IGZ1bmN0aW9uIHByZXYoZSkge1xuICAgIHRoaXMucHJvcHMub25QcmV2Q2xpY2soZSk7XG4gICAgdmFyIG5hdldyYXBOb2RlID0gdGhpcy5uYXZXcmFwO1xuICAgIHZhciBuYXZXcmFwTm9kZVdIID0gdGhpcy5nZXRPZmZzZXRXSChuYXZXcmFwTm9kZSk7XG4gICAgdmFyIG9mZnNldCA9IHRoaXMub2Zmc2V0O1xuXG4gICAgdGhpcy5zZXRPZmZzZXQob2Zmc2V0ICsgbmF2V3JhcE5vZGVXSCk7XG4gIH0sXG4gIG5leHQ6IGZ1bmN0aW9uIG5leHQoZSkge1xuICAgIHRoaXMucHJvcHMub25OZXh0Q2xpY2soZSk7XG4gICAgdmFyIG5hdldyYXBOb2RlID0gdGhpcy5uYXZXcmFwO1xuICAgIHZhciBuYXZXcmFwTm9kZVdIID0gdGhpcy5nZXRPZmZzZXRXSChuYXZXcmFwTm9kZSk7XG4gICAgdmFyIG9mZnNldCA9IHRoaXMub2Zmc2V0O1xuXG4gICAgdGhpcy5zZXRPZmZzZXQob2Zmc2V0IC0gbmF2V3JhcE5vZGVXSCk7XG4gIH0sXG4gIGdldFNjcm9sbEJhck5vZGU6IGZ1bmN0aW9uIGdldFNjcm9sbEJhck5vZGUoY29udGVudCkge1xuICAgIHZhciBfY2xhc3NuYW1lcywgX2NsYXNzbmFtZXMyLCBfY2xhc3NuYW1lczMsIF9jbGFzc25hbWVzNDtcblxuICAgIHZhciBfc3RhdGUyID0gdGhpcy5zdGF0ZSxcbiAgICAgICAgbmV4dCA9IF9zdGF0ZTIubmV4dCxcbiAgICAgICAgcHJldiA9IF9zdGF0ZTIucHJldjtcbiAgICB2YXIgX3Byb3BzID0gdGhpcy5wcm9wcyxcbiAgICAgICAgcHJlZml4Q2xzID0gX3Byb3BzLnByZWZpeENscyxcbiAgICAgICAgc2Nyb2xsQW5pbWF0ZWQgPSBfcHJvcHMuc2Nyb2xsQW5pbWF0ZWQ7XG5cbiAgICB2YXIgc2hvd05leHRQcmV2ID0gcHJldiB8fCBuZXh0O1xuXG4gICAgdmFyIHByZXZCdXR0b24gPSBSZWFjdC5jcmVhdGVFbGVtZW50KFxuICAgICAgJ3NwYW4nLFxuICAgICAge1xuICAgICAgICBvbkNsaWNrOiBwcmV2ID8gdGhpcy5wcmV2IDogbnVsbCxcbiAgICAgICAgdW5zZWxlY3RhYmxlOiAndW5zZWxlY3RhYmxlJyxcbiAgICAgICAgY2xhc3NOYW1lOiBjbGFzc25hbWVzKChfY2xhc3NuYW1lcyA9IHt9LCBfZGVmaW5lUHJvcGVydHkoX2NsYXNzbmFtZXMsIHByZWZpeENscyArICctdGFiLXByZXYnLCAxKSwgX2RlZmluZVByb3BlcnR5KF9jbGFzc25hbWVzLCBwcmVmaXhDbHMgKyAnLXRhYi1idG4tZGlzYWJsZWQnLCAhcHJldiksIF9kZWZpbmVQcm9wZXJ0eShfY2xhc3NuYW1lcywgcHJlZml4Q2xzICsgJy10YWItYXJyb3ctc2hvdycsIHNob3dOZXh0UHJldiksIF9jbGFzc25hbWVzKSksXG4gICAgICAgIG9uVHJhbnNpdGlvbkVuZDogdGhpcy5wcmV2VHJhbnNpdGlvbkVuZFxuICAgICAgfSxcbiAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nLCB7IGNsYXNzTmFtZTogcHJlZml4Q2xzICsgJy10YWItcHJldi1pY29uJyB9KVxuICAgICk7XG5cbiAgICB2YXIgbmV4dEJ1dHRvbiA9IFJlYWN0LmNyZWF0ZUVsZW1lbnQoXG4gICAgICAnc3BhbicsXG4gICAgICB7XG4gICAgICAgIG9uQ2xpY2s6IG5leHQgPyB0aGlzLm5leHQgOiBudWxsLFxuICAgICAgICB1bnNlbGVjdGFibGU6ICd1bnNlbGVjdGFibGUnLFxuICAgICAgICBjbGFzc05hbWU6IGNsYXNzbmFtZXMoKF9jbGFzc25hbWVzMiA9IHt9LCBfZGVmaW5lUHJvcGVydHkoX2NsYXNzbmFtZXMyLCBwcmVmaXhDbHMgKyAnLXRhYi1uZXh0JywgMSksIF9kZWZpbmVQcm9wZXJ0eShfY2xhc3NuYW1lczIsIHByZWZpeENscyArICctdGFiLWJ0bi1kaXNhYmxlZCcsICFuZXh0KSwgX2RlZmluZVByb3BlcnR5KF9jbGFzc25hbWVzMiwgcHJlZml4Q2xzICsgJy10YWItYXJyb3ctc2hvdycsIHNob3dOZXh0UHJldiksIF9jbGFzc25hbWVzMikpXG4gICAgICB9LFxuICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudCgnc3BhbicsIHsgY2xhc3NOYW1lOiBwcmVmaXhDbHMgKyAnLXRhYi1uZXh0LWljb24nIH0pXG4gICAgKTtcblxuICAgIHZhciBuYXZDbGFzc05hbWUgPSBwcmVmaXhDbHMgKyAnLW5hdic7XG4gICAgdmFyIG5hdkNsYXNzZXMgPSBjbGFzc25hbWVzKChfY2xhc3NuYW1lczMgPSB7fSwgX2RlZmluZVByb3BlcnR5KF9jbGFzc25hbWVzMywgbmF2Q2xhc3NOYW1lLCB0cnVlKSwgX2RlZmluZVByb3BlcnR5KF9jbGFzc25hbWVzMywgc2Nyb2xsQW5pbWF0ZWQgPyBuYXZDbGFzc05hbWUgKyAnLWFuaW1hdGVkJyA6IG5hdkNsYXNzTmFtZSArICctbm8tYW5pbWF0ZWQnLCB0cnVlKSwgX2NsYXNzbmFtZXMzKSk7XG5cbiAgICByZXR1cm4gUmVhY3QuY3JlYXRlRWxlbWVudChcbiAgICAgICdkaXYnLFxuICAgICAge1xuICAgICAgICBjbGFzc05hbWU6IGNsYXNzbmFtZXMoKF9jbGFzc25hbWVzNCA9IHt9LCBfZGVmaW5lUHJvcGVydHkoX2NsYXNzbmFtZXM0LCBwcmVmaXhDbHMgKyAnLW5hdi1jb250YWluZXInLCAxKSwgX2RlZmluZVByb3BlcnR5KF9jbGFzc25hbWVzNCwgcHJlZml4Q2xzICsgJy1uYXYtY29udGFpbmVyLXNjcm9sbGluZycsIHNob3dOZXh0UHJldiksIF9jbGFzc25hbWVzNCkpLFxuICAgICAgICBrZXk6ICdjb250YWluZXInLFxuICAgICAgICByZWY6IHRoaXMuc2F2ZVJlZignY29udGFpbmVyJylcbiAgICAgIH0sXG4gICAgICBwcmV2QnV0dG9uLFxuICAgICAgbmV4dEJ1dHRvbixcbiAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXG4gICAgICAgICdkaXYnLFxuICAgICAgICB7IGNsYXNzTmFtZTogcHJlZml4Q2xzICsgJy1uYXYtd3JhcCcsIHJlZjogdGhpcy5zYXZlUmVmKCduYXZXcmFwJykgfSxcbiAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcbiAgICAgICAgICAnZGl2JyxcbiAgICAgICAgICB7IGNsYXNzTmFtZTogcHJlZml4Q2xzICsgJy1uYXYtc2Nyb2xsJyB9LFxuICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXG4gICAgICAgICAgICAnZGl2JyxcbiAgICAgICAgICAgIHsgY2xhc3NOYW1lOiBuYXZDbGFzc2VzLCByZWY6IHRoaXMuc2F2ZVJlZignbmF2JykgfSxcbiAgICAgICAgICAgIGNvbnRlbnRcbiAgICAgICAgICApXG4gICAgICAgIClcbiAgICAgIClcbiAgICApO1xuICB9XG59OyIsImltcG9ydCBfZGVmaW5lUHJvcGVydHkgZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL2RlZmluZVByb3BlcnR5JztcbmltcG9ydCBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXMgZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzJztcbmltcG9ydCBfZXh0ZW5kcyBmcm9tICdiYWJlbC1ydW50aW1lL2hlbHBlcnMvZXh0ZW5kcyc7XG5pbXBvcnQgUmVhY3QsIHsgY2xvbmVFbGVtZW50IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IGNsYXNzbmFtZXMgZnJvbSAnY2xhc3NuYW1lcyc7XG5pbXBvcnQgd2FybmluZyBmcm9tICd3YXJuaW5nJztcbmltcG9ydCB7IGdldERhdGFBdHRyIH0gZnJvbSAnLi91dGlscyc7XG5cbmV4cG9ydCBkZWZhdWx0IHtcbiAgZ2V0RGVmYXVsdFByb3BzOiBmdW5jdGlvbiBnZXREZWZhdWx0UHJvcHMoKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIHN0eWxlczoge31cbiAgICB9O1xuICB9LFxuICBvblRhYkNsaWNrOiBmdW5jdGlvbiBvblRhYkNsaWNrKGtleSkge1xuICAgIHRoaXMucHJvcHMub25UYWJDbGljayhrZXkpO1xuICB9LFxuICBnZXRUYWJzOiBmdW5jdGlvbiBnZXRUYWJzKCkge1xuICAgIHZhciBfdGhpcyA9IHRoaXM7XG5cbiAgICB2YXIgX3Byb3BzID0gdGhpcy5wcm9wcyxcbiAgICAgICAgY2hpbGRyZW4gPSBfcHJvcHMucGFuZWxzLFxuICAgICAgICBhY3RpdmVLZXkgPSBfcHJvcHMuYWN0aXZlS2V5LFxuICAgICAgICBwcmVmaXhDbHMgPSBfcHJvcHMucHJlZml4Q2xzLFxuICAgICAgICB0YWJCYXJHdXR0ZXIgPSBfcHJvcHMudGFiQmFyR3V0dGVyO1xuXG4gICAgdmFyIHJzdCA9IFtdO1xuXG4gICAgUmVhY3QuQ2hpbGRyZW4uZm9yRWFjaChjaGlsZHJlbiwgZnVuY3Rpb24gKGNoaWxkLCBpbmRleCkge1xuICAgICAgaWYgKCFjaGlsZCkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICB2YXIga2V5ID0gY2hpbGQua2V5O1xuICAgICAgdmFyIGNscyA9IGFjdGl2ZUtleSA9PT0ga2V5ID8gcHJlZml4Q2xzICsgJy10YWItYWN0aXZlJyA6ICcnO1xuICAgICAgY2xzICs9ICcgJyArIHByZWZpeENscyArICctdGFiJztcbiAgICAgIHZhciBldmVudHMgPSB7fTtcbiAgICAgIGlmIChjaGlsZC5wcm9wcy5kaXNhYmxlZCkge1xuICAgICAgICBjbHMgKz0gJyAnICsgcHJlZml4Q2xzICsgJy10YWItZGlzYWJsZWQnO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgZXZlbnRzID0ge1xuICAgICAgICAgIG9uQ2xpY2s6IF90aGlzLm9uVGFiQ2xpY2suYmluZChfdGhpcywga2V5KVxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgdmFyIHJlZiA9IHt9O1xuICAgICAgaWYgKGFjdGl2ZUtleSA9PT0ga2V5KSB7XG4gICAgICAgIHJlZi5yZWYgPSBfdGhpcy5zYXZlUmVmKCdhY3RpdmVUYWInKTtcbiAgICAgIH1cbiAgICAgIHdhcm5pbmcoJ3RhYicgaW4gY2hpbGQucHJvcHMsICdUaGVyZSBtdXN0IGJlIGB0YWJgIHByb3BlcnR5IG9uIGNoaWxkcmVuIG9mIFRhYnMuJyk7XG4gICAgICByc3QucHVzaChSZWFjdC5jcmVhdGVFbGVtZW50KFxuICAgICAgICAnZGl2JyxcbiAgICAgICAgX2V4dGVuZHMoe1xuICAgICAgICAgIHJvbGU6ICd0YWInLFxuICAgICAgICAgICdhcmlhLWRpc2FibGVkJzogY2hpbGQucHJvcHMuZGlzYWJsZWQgPyAndHJ1ZScgOiAnZmFsc2UnLFxuICAgICAgICAgICdhcmlhLXNlbGVjdGVkJzogYWN0aXZlS2V5ID09PSBrZXkgPyAndHJ1ZScgOiAnZmFsc2UnXG4gICAgICAgIH0sIGV2ZW50cywge1xuICAgICAgICAgIGNsYXNzTmFtZTogY2xzLFxuICAgICAgICAgIGtleToga2V5LFxuICAgICAgICAgIHN0eWxlOiB7IG1hcmdpblJpZ2h0OiB0YWJCYXJHdXR0ZXIgJiYgaW5kZXggPT09IGNoaWxkcmVuLmxlbmd0aCAtIDEgPyAwIDogdGFiQmFyR3V0dGVyIH1cbiAgICAgICAgfSwgcmVmKSxcbiAgICAgICAgY2hpbGQucHJvcHMudGFiXG4gICAgICApKTtcbiAgICB9KTtcblxuICAgIHJldHVybiByc3Q7XG4gIH0sXG4gIGdldFJvb3ROb2RlOiBmdW5jdGlvbiBnZXRSb290Tm9kZShjb250ZW50cykge1xuICAgIHZhciBfcHJvcHMyID0gdGhpcy5wcm9wcyxcbiAgICAgICAgcHJlZml4Q2xzID0gX3Byb3BzMi5wcmVmaXhDbHMsXG4gICAgICAgIG9uS2V5RG93biA9IF9wcm9wczIub25LZXlEb3duLFxuICAgICAgICBjbGFzc05hbWUgPSBfcHJvcHMyLmNsYXNzTmFtZSxcbiAgICAgICAgZXh0cmFDb250ZW50ID0gX3Byb3BzMi5leHRyYUNvbnRlbnQsXG4gICAgICAgIHN0eWxlID0gX3Byb3BzMi5zdHlsZSxcbiAgICAgICAgdGFiQmFyUG9zaXRpb24gPSBfcHJvcHMyLnRhYkJhclBvc2l0aW9uLFxuICAgICAgICByZXN0UHJvcHMgPSBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXMoX3Byb3BzMiwgWydwcmVmaXhDbHMnLCAnb25LZXlEb3duJywgJ2NsYXNzTmFtZScsICdleHRyYUNvbnRlbnQnLCAnc3R5bGUnLCAndGFiQmFyUG9zaXRpb24nXSk7XG5cbiAgICB2YXIgY2xzID0gY2xhc3NuYW1lcyhwcmVmaXhDbHMgKyAnLWJhcicsIF9kZWZpbmVQcm9wZXJ0eSh7fSwgY2xhc3NOYW1lLCAhIWNsYXNzTmFtZSkpO1xuICAgIHZhciB0b3BPckJvdHRvbSA9IHRhYkJhclBvc2l0aW9uID09PSAndG9wJyB8fCB0YWJCYXJQb3NpdGlvbiA9PT0gJ2JvdHRvbSc7XG4gICAgdmFyIHRhYkJhckV4dHJhQ29udGVudFN0eWxlID0gdG9wT3JCb3R0b20gPyB7IGZsb2F0OiAncmlnaHQnIH0gOiB7fTtcbiAgICB2YXIgZXh0cmFDb250ZW50U3R5bGUgPSBleHRyYUNvbnRlbnQgJiYgZXh0cmFDb250ZW50LnByb3BzID8gZXh0cmFDb250ZW50LnByb3BzLnN0eWxlIDoge307XG4gICAgdmFyIGNoaWxkcmVuID0gY29udGVudHM7XG4gICAgaWYgKGV4dHJhQ29udGVudCkge1xuICAgICAgY2hpbGRyZW4gPSBbY2xvbmVFbGVtZW50KGV4dHJhQ29udGVudCwge1xuICAgICAgICBrZXk6ICdleHRyYScsXG4gICAgICAgIHN0eWxlOiBfZXh0ZW5kcyh7fSwgdGFiQmFyRXh0cmFDb250ZW50U3R5bGUsIGV4dHJhQ29udGVudFN0eWxlKVxuICAgICAgfSksIGNsb25lRWxlbWVudChjb250ZW50cywgeyBrZXk6ICdjb250ZW50JyB9KV07XG4gICAgICBjaGlsZHJlbiA9IHRvcE9yQm90dG9tID8gY2hpbGRyZW4gOiBjaGlsZHJlbi5yZXZlcnNlKCk7XG4gICAgfVxuICAgIHJldHVybiBSZWFjdC5jcmVhdGVFbGVtZW50KFxuICAgICAgJ2RpdicsXG4gICAgICBfZXh0ZW5kcyh7XG4gICAgICAgIHJvbGU6ICd0YWJsaXN0JyxcbiAgICAgICAgY2xhc3NOYW1lOiBjbHMsXG4gICAgICAgIHRhYkluZGV4OiAnMCcsXG4gICAgICAgIHJlZjogdGhpcy5zYXZlUmVmKCdyb290JyksXG4gICAgICAgIG9uS2V5RG93bjogb25LZXlEb3duLFxuICAgICAgICBzdHlsZTogc3R5bGVcbiAgICAgIH0sIGdldERhdGFBdHRyKHJlc3RQcm9wcykpLFxuICAgICAgY2hpbGRyZW5cbiAgICApO1xuICB9XG59OyIsImltcG9ydCBfZXh0ZW5kcyBmcm9tICdiYWJlbC1ydW50aW1lL2hlbHBlcnMvZXh0ZW5kcyc7XG5pbXBvcnQgX2RlZmluZVByb3BlcnR5IGZyb20gJ2JhYmVsLXJ1bnRpbWUvaGVscGVycy9kZWZpbmVQcm9wZXJ0eSc7XG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IGNyZWF0ZVJlYWN0Q2xhc3MgZnJvbSAnY3JlYXRlLXJlYWN0LWNsYXNzJztcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcyc7XG5pbXBvcnQgY2xhc3NuYW1lcyBmcm9tICdjbGFzc25hbWVzJztcbmltcG9ydCB7IGdldFRyYW5zZm9ybUJ5SW5kZXgsIGdldEFjdGl2ZUluZGV4LCBnZXRUcmFuc2Zvcm1Qcm9wVmFsdWUsIGdldE1hcmdpblN0eWxlIH0gZnJvbSAnLi91dGlscyc7XG5cbnZhciBUYWJDb250ZW50ID0gY3JlYXRlUmVhY3RDbGFzcyh7XG4gIGRpc3BsYXlOYW1lOiAnVGFiQ29udGVudCcsXG4gIHByb3BUeXBlczoge1xuICAgIGFuaW1hdGVkOiBQcm9wVHlwZXMuYm9vbCxcbiAgICBhbmltYXRlZFdpdGhNYXJnaW46IFByb3BUeXBlcy5ib29sLFxuICAgIHByZWZpeENsczogUHJvcFR5cGVzLnN0cmluZyxcbiAgICBjaGlsZHJlbjogUHJvcFR5cGVzLmFueSxcbiAgICBhY3RpdmVLZXk6IFByb3BUeXBlcy5zdHJpbmcsXG4gICAgc3R5bGU6IFByb3BUeXBlcy5hbnksXG4gICAgdGFiQmFyUG9zaXRpb246IFByb3BUeXBlcy5zdHJpbmdcbiAgfSxcbiAgZ2V0RGVmYXVsdFByb3BzOiBmdW5jdGlvbiBnZXREZWZhdWx0UHJvcHMoKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGFuaW1hdGVkOiB0cnVlXG4gICAgfTtcbiAgfSxcbiAgZ2V0VGFiUGFuZXM6IGZ1bmN0aW9uIGdldFRhYlBhbmVzKCkge1xuICAgIHZhciBwcm9wcyA9IHRoaXMucHJvcHM7XG4gICAgdmFyIGFjdGl2ZUtleSA9IHByb3BzLmFjdGl2ZUtleTtcbiAgICB2YXIgY2hpbGRyZW4gPSBwcm9wcy5jaGlsZHJlbjtcbiAgICB2YXIgbmV3Q2hpbGRyZW4gPSBbXTtcblxuICAgIFJlYWN0LkNoaWxkcmVuLmZvckVhY2goY2hpbGRyZW4sIGZ1bmN0aW9uIChjaGlsZCkge1xuICAgICAgaWYgKCFjaGlsZCkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICB2YXIga2V5ID0gY2hpbGQua2V5O1xuICAgICAgdmFyIGFjdGl2ZSA9IGFjdGl2ZUtleSA9PT0ga2V5O1xuICAgICAgbmV3Q2hpbGRyZW4ucHVzaChSZWFjdC5jbG9uZUVsZW1lbnQoY2hpbGQsIHtcbiAgICAgICAgYWN0aXZlOiBhY3RpdmUsXG4gICAgICAgIGRlc3Ryb3lJbmFjdGl2ZVRhYlBhbmU6IHByb3BzLmRlc3Ryb3lJbmFjdGl2ZVRhYlBhbmUsXG4gICAgICAgIHJvb3RQcmVmaXhDbHM6IHByb3BzLnByZWZpeENsc1xuICAgICAgfSkpO1xuICAgIH0pO1xuXG4gICAgcmV0dXJuIG5ld0NoaWxkcmVuO1xuICB9LFxuICByZW5kZXI6IGZ1bmN0aW9uIHJlbmRlcigpIHtcbiAgICB2YXIgX2NsYXNzbmFtZXM7XG5cbiAgICB2YXIgcHJvcHMgPSB0aGlzLnByb3BzO1xuICAgIHZhciBwcmVmaXhDbHMgPSBwcm9wcy5wcmVmaXhDbHMsXG4gICAgICAgIGNoaWxkcmVuID0gcHJvcHMuY2hpbGRyZW4sXG4gICAgICAgIGFjdGl2ZUtleSA9IHByb3BzLmFjdGl2ZUtleSxcbiAgICAgICAgdGFiQmFyUG9zaXRpb24gPSBwcm9wcy50YWJCYXJQb3NpdGlvbixcbiAgICAgICAgYW5pbWF0ZWQgPSBwcm9wcy5hbmltYXRlZCxcbiAgICAgICAgYW5pbWF0ZWRXaXRoTWFyZ2luID0gcHJvcHMuYW5pbWF0ZWRXaXRoTWFyZ2luO1xuICAgIHZhciBzdHlsZSA9IHByb3BzLnN0eWxlO1xuXG4gICAgdmFyIGNsYXNzZXMgPSBjbGFzc25hbWVzKChfY2xhc3NuYW1lcyA9IHt9LCBfZGVmaW5lUHJvcGVydHkoX2NsYXNzbmFtZXMsIHByZWZpeENscyArICctY29udGVudCcsIHRydWUpLCBfZGVmaW5lUHJvcGVydHkoX2NsYXNzbmFtZXMsIGFuaW1hdGVkID8gcHJlZml4Q2xzICsgJy1jb250ZW50LWFuaW1hdGVkJyA6IHByZWZpeENscyArICctY29udGVudC1uby1hbmltYXRlZCcsIHRydWUpLCBfY2xhc3NuYW1lcykpO1xuICAgIGlmIChhbmltYXRlZCkge1xuICAgICAgdmFyIGFjdGl2ZUluZGV4ID0gZ2V0QWN0aXZlSW5kZXgoY2hpbGRyZW4sIGFjdGl2ZUtleSk7XG4gICAgICBpZiAoYWN0aXZlSW5kZXggIT09IC0xKSB7XG4gICAgICAgIHZhciBhbmltYXRlZFN0eWxlID0gYW5pbWF0ZWRXaXRoTWFyZ2luID8gZ2V0TWFyZ2luU3R5bGUoYWN0aXZlSW5kZXgsIHRhYkJhclBvc2l0aW9uKSA6IGdldFRyYW5zZm9ybVByb3BWYWx1ZShnZXRUcmFuc2Zvcm1CeUluZGV4KGFjdGl2ZUluZGV4LCB0YWJCYXJQb3NpdGlvbikpO1xuICAgICAgICBzdHlsZSA9IF9leHRlbmRzKHt9LCBzdHlsZSwgYW5pbWF0ZWRTdHlsZSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzdHlsZSA9IF9leHRlbmRzKHt9LCBzdHlsZSwge1xuICAgICAgICAgIGRpc3BsYXk6ICdub25lJ1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXG4gICAgICAnZGl2JyxcbiAgICAgIHtcbiAgICAgICAgY2xhc3NOYW1lOiBjbGFzc2VzLFxuICAgICAgICBzdHlsZTogc3R5bGVcbiAgICAgIH0sXG4gICAgICB0aGlzLmdldFRhYlBhbmVzKClcbiAgICApO1xuICB9XG59KTtcblxuZXhwb3J0IGRlZmF1bHQgVGFiQ29udGVudDsiLCJpbXBvcnQgX2V4dGVuZHMgZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL2V4dGVuZHMnO1xuaW1wb3J0IF9kZWZpbmVQcm9wZXJ0eSBmcm9tICdiYWJlbC1ydW50aW1lL2hlbHBlcnMvZGVmaW5lUHJvcGVydHknO1xuaW1wb3J0IF9vYmplY3RXaXRob3V0UHJvcGVydGllcyBmcm9tICdiYWJlbC1ydW50aW1lL2hlbHBlcnMvb2JqZWN0V2l0aG91dFByb3BlcnRpZXMnO1xuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcyc7XG5pbXBvcnQgY3JlYXRlUmVhY3RDbGFzcyBmcm9tICdjcmVhdGUtcmVhY3QtY2xhc3MnO1xuaW1wb3J0IGNsYXNzbmFtZXMgZnJvbSAnY2xhc3NuYW1lcyc7XG5pbXBvcnQgeyBnZXREYXRhQXR0ciB9IGZyb20gJy4vdXRpbHMnO1xuXG52YXIgVGFiUGFuZSA9IGNyZWF0ZVJlYWN0Q2xhc3Moe1xuICBkaXNwbGF5TmFtZTogJ1RhYlBhbmUnLFxuICBwcm9wVHlwZXM6IHtcbiAgICBjbGFzc05hbWU6IFByb3BUeXBlcy5zdHJpbmcsXG4gICAgYWN0aXZlOiBQcm9wVHlwZXMuYm9vbCxcbiAgICBzdHlsZTogUHJvcFR5cGVzLmFueSxcbiAgICBkZXN0cm95SW5hY3RpdmVUYWJQYW5lOiBQcm9wVHlwZXMuYm9vbCxcbiAgICBmb3JjZVJlbmRlcjogUHJvcFR5cGVzLmJvb2wsXG4gICAgcGxhY2Vob2xkZXI6IFByb3BUeXBlcy5ub2RlXG4gIH0sXG4gIGdldERlZmF1bHRQcm9wczogZnVuY3Rpb24gZ2V0RGVmYXVsdFByb3BzKCkge1xuICAgIHJldHVybiB7IHBsYWNlaG9sZGVyOiBudWxsIH07XG4gIH0sXG4gIHJlbmRlcjogZnVuY3Rpb24gcmVuZGVyKCkge1xuICAgIHZhciBfY2xhc3NuYW1lcztcblxuICAgIHZhciBfcHJvcHMgPSB0aGlzLnByb3BzLFxuICAgICAgICBjbGFzc05hbWUgPSBfcHJvcHMuY2xhc3NOYW1lLFxuICAgICAgICBkZXN0cm95SW5hY3RpdmVUYWJQYW5lID0gX3Byb3BzLmRlc3Ryb3lJbmFjdGl2ZVRhYlBhbmUsXG4gICAgICAgIGFjdGl2ZSA9IF9wcm9wcy5hY3RpdmUsXG4gICAgICAgIGZvcmNlUmVuZGVyID0gX3Byb3BzLmZvcmNlUmVuZGVyLFxuICAgICAgICByb290UHJlZml4Q2xzID0gX3Byb3BzLnJvb3RQcmVmaXhDbHMsXG4gICAgICAgIHN0eWxlID0gX3Byb3BzLnN0eWxlLFxuICAgICAgICBjaGlsZHJlbiA9IF9wcm9wcy5jaGlsZHJlbixcbiAgICAgICAgcGxhY2Vob2xkZXIgPSBfcHJvcHMucGxhY2Vob2xkZXIsXG4gICAgICAgIHJlc3RQcm9wcyA9IF9vYmplY3RXaXRob3V0UHJvcGVydGllcyhfcHJvcHMsIFsnY2xhc3NOYW1lJywgJ2Rlc3Ryb3lJbmFjdGl2ZVRhYlBhbmUnLCAnYWN0aXZlJywgJ2ZvcmNlUmVuZGVyJywgJ3Jvb3RQcmVmaXhDbHMnLCAnc3R5bGUnLCAnY2hpbGRyZW4nLCAncGxhY2Vob2xkZXInXSk7XG5cbiAgICB0aGlzLl9pc0FjdGl2ZWQgPSB0aGlzLl9pc0FjdGl2ZWQgfHwgYWN0aXZlO1xuICAgIHZhciBwcmVmaXhDbHMgPSByb290UHJlZml4Q2xzICsgJy10YWJwYW5lJztcbiAgICB2YXIgY2xzID0gY2xhc3NuYW1lcygoX2NsYXNzbmFtZXMgPSB7fSwgX2RlZmluZVByb3BlcnR5KF9jbGFzc25hbWVzLCBwcmVmaXhDbHMsIDEpLCBfZGVmaW5lUHJvcGVydHkoX2NsYXNzbmFtZXMsIHByZWZpeENscyArICctaW5hY3RpdmUnLCAhYWN0aXZlKSwgX2RlZmluZVByb3BlcnR5KF9jbGFzc25hbWVzLCBwcmVmaXhDbHMgKyAnLWFjdGl2ZScsIGFjdGl2ZSksIF9kZWZpbmVQcm9wZXJ0eShfY2xhc3NuYW1lcywgY2xhc3NOYW1lLCBjbGFzc05hbWUpLCBfY2xhc3NuYW1lcykpO1xuICAgIHZhciBpc1JlbmRlciA9IGRlc3Ryb3lJbmFjdGl2ZVRhYlBhbmUgPyBhY3RpdmUgOiB0aGlzLl9pc0FjdGl2ZWQ7XG4gICAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXG4gICAgICAnZGl2JyxcbiAgICAgIF9leHRlbmRzKHtcbiAgICAgICAgc3R5bGU6IHN0eWxlLFxuICAgICAgICByb2xlOiAndGFicGFuZWwnLFxuICAgICAgICAnYXJpYS1oaWRkZW4nOiBhY3RpdmUgPyAnZmFsc2UnIDogJ3RydWUnLFxuICAgICAgICBjbGFzc05hbWU6IGNsc1xuICAgICAgfSwgZ2V0RGF0YUF0dHIocmVzdFByb3BzKSksXG4gICAgICBpc1JlbmRlciB8fCBmb3JjZVJlbmRlciA/IGNoaWxkcmVuIDogcGxhY2Vob2xkZXJcbiAgICApO1xuICB9XG59KTtcblxuZXhwb3J0IGRlZmF1bHQgVGFiUGFuZTsiLCJpbXBvcnQgX2V4dGVuZHMgZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL2V4dGVuZHMnO1xuaW1wb3J0IF9kZWZpbmVQcm9wZXJ0eSBmcm9tICdiYWJlbC1ydW50aW1lL2hlbHBlcnMvZGVmaW5lUHJvcGVydHknO1xuaW1wb3J0IF9vYmplY3RXaXRob3V0UHJvcGVydGllcyBmcm9tICdiYWJlbC1ydW50aW1lL2hlbHBlcnMvb2JqZWN0V2l0aG91dFByb3BlcnRpZXMnO1xuaW1wb3J0IF9jbGFzc0NhbGxDaGVjayBmcm9tICdiYWJlbC1ydW50aW1lL2hlbHBlcnMvY2xhc3NDYWxsQ2hlY2snO1xuaW1wb3J0IF9jcmVhdGVDbGFzcyBmcm9tICdiYWJlbC1ydW50aW1lL2hlbHBlcnMvY3JlYXRlQ2xhc3MnO1xuaW1wb3J0IF9wb3NzaWJsZUNvbnN0cnVjdG9yUmV0dXJuIGZyb20gJ2JhYmVsLXJ1bnRpbWUvaGVscGVycy9wb3NzaWJsZUNvbnN0cnVjdG9yUmV0dXJuJztcbmltcG9ydCBfaW5oZXJpdHMgZnJvbSAnYmFiZWwtcnVudGltZS9oZWxwZXJzL2luaGVyaXRzJztcbmltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnO1xuaW1wb3J0IEtleUNvZGUgZnJvbSAnLi9LZXlDb2RlJztcbmltcG9ydCBUYWJQYW5lIGZyb20gJy4vVGFiUGFuZSc7XG5pbXBvcnQgY2xhc3NuYW1lcyBmcm9tICdjbGFzc25hbWVzJztcbmltcG9ydCB7IGdldERhdGFBdHRyIH0gZnJvbSAnLi91dGlscyc7XG5cbmZ1bmN0aW9uIG5vb3AoKSB7fVxuXG5mdW5jdGlvbiBnZXREZWZhdWx0QWN0aXZlS2V5KHByb3BzKSB7XG4gIHZhciBhY3RpdmVLZXkgPSB2b2lkIDA7XG4gIFJlYWN0LkNoaWxkcmVuLmZvckVhY2gocHJvcHMuY2hpbGRyZW4sIGZ1bmN0aW9uIChjaGlsZCkge1xuICAgIGlmIChjaGlsZCAmJiAhYWN0aXZlS2V5ICYmICFjaGlsZC5wcm9wcy5kaXNhYmxlZCkge1xuICAgICAgYWN0aXZlS2V5ID0gY2hpbGQua2V5O1xuICAgIH1cbiAgfSk7XG4gIHJldHVybiBhY3RpdmVLZXk7XG59XG5cbmZ1bmN0aW9uIGFjdGl2ZUtleUlzVmFsaWQocHJvcHMsIGtleSkge1xuICB2YXIga2V5cyA9IFJlYWN0LkNoaWxkcmVuLm1hcChwcm9wcy5jaGlsZHJlbiwgZnVuY3Rpb24gKGNoaWxkKSB7XG4gICAgcmV0dXJuIGNoaWxkICYmIGNoaWxkLmtleTtcbiAgfSk7XG4gIHJldHVybiBrZXlzLmluZGV4T2Yoa2V5KSA+PSAwO1xufVxuXG52YXIgVGFicyA9IGZ1bmN0aW9uIChfUmVhY3QkQ29tcG9uZW50KSB7XG4gIF9pbmhlcml0cyhUYWJzLCBfUmVhY3QkQ29tcG9uZW50KTtcblxuICBmdW5jdGlvbiBUYWJzKHByb3BzKSB7XG4gICAgX2NsYXNzQ2FsbENoZWNrKHRoaXMsIFRhYnMpO1xuXG4gICAgdmFyIF90aGlzID0gX3Bvc3NpYmxlQ29uc3RydWN0b3JSZXR1cm4odGhpcywgKFRhYnMuX19wcm90b19fIHx8IE9iamVjdC5nZXRQcm90b3R5cGVPZihUYWJzKSkuY2FsbCh0aGlzLCBwcm9wcykpO1xuXG4gICAgX2luaXRpYWxpc2VQcm9wcy5jYWxsKF90aGlzKTtcblxuICAgIHZhciBhY3RpdmVLZXkgPSB2b2lkIDA7XG4gICAgaWYgKCdhY3RpdmVLZXknIGluIHByb3BzKSB7XG4gICAgICBhY3RpdmVLZXkgPSBwcm9wcy5hY3RpdmVLZXk7XG4gICAgfSBlbHNlIGlmICgnZGVmYXVsdEFjdGl2ZUtleScgaW4gcHJvcHMpIHtcbiAgICAgIGFjdGl2ZUtleSA9IHByb3BzLmRlZmF1bHRBY3RpdmVLZXk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGFjdGl2ZUtleSA9IGdldERlZmF1bHRBY3RpdmVLZXkocHJvcHMpO1xuICAgIH1cblxuICAgIF90aGlzLnN0YXRlID0ge1xuICAgICAgYWN0aXZlS2V5OiBhY3RpdmVLZXlcbiAgICB9O1xuICAgIHJldHVybiBfdGhpcztcbiAgfVxuXG4gIF9jcmVhdGVDbGFzcyhUYWJzLCBbe1xuICAgIGtleTogJ2NvbXBvbmVudFdpbGxSZWNlaXZlUHJvcHMnLFxuICAgIHZhbHVlOiBmdW5jdGlvbiBjb21wb25lbnRXaWxsUmVjZWl2ZVByb3BzKG5leHRQcm9wcykge1xuICAgICAgaWYgKCdhY3RpdmVLZXknIGluIG5leHRQcm9wcykge1xuICAgICAgICB0aGlzLnNldFN0YXRlKHtcbiAgICAgICAgICBhY3RpdmVLZXk6IG5leHRQcm9wcy5hY3RpdmVLZXlcbiAgICAgICAgfSk7XG4gICAgICB9IGVsc2UgaWYgKCFhY3RpdmVLZXlJc1ZhbGlkKG5leHRQcm9wcywgdGhpcy5zdGF0ZS5hY3RpdmVLZXkpKSB7XG4gICAgICAgIC8vIGh0dHBzOi8vZ2l0aHViLmNvbS9hbnQtZGVzaWduL2FudC1kZXNpZ24vaXNzdWVzLzcwOTNcbiAgICAgICAgdGhpcy5zZXRTdGF0ZSh7XG4gICAgICAgICAgYWN0aXZlS2V5OiBnZXREZWZhdWx0QWN0aXZlS2V5KG5leHRQcm9wcylcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICB9LCB7XG4gICAga2V5OiAncmVuZGVyJyxcbiAgICB2YWx1ZTogZnVuY3Rpb24gcmVuZGVyKCkge1xuICAgICAgdmFyIF9jbGFzc25hbWVzO1xuXG4gICAgICB2YXIgcHJvcHMgPSB0aGlzLnByb3BzO1xuXG4gICAgICB2YXIgcHJlZml4Q2xzID0gcHJvcHMucHJlZml4Q2xzLFxuICAgICAgICAgIHRhYkJhclBvc2l0aW9uID0gcHJvcHMudGFiQmFyUG9zaXRpb24sXG4gICAgICAgICAgY2xhc3NOYW1lID0gcHJvcHMuY2xhc3NOYW1lLFxuICAgICAgICAgIHJlbmRlclRhYkNvbnRlbnQgPSBwcm9wcy5yZW5kZXJUYWJDb250ZW50LFxuICAgICAgICAgIHJlbmRlclRhYkJhciA9IHByb3BzLnJlbmRlclRhYkJhcixcbiAgICAgICAgICBkZXN0cm95SW5hY3RpdmVUYWJQYW5lID0gcHJvcHMuZGVzdHJveUluYWN0aXZlVGFiUGFuZSxcbiAgICAgICAgICByZXN0UHJvcHMgPSBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXMocHJvcHMsIFsncHJlZml4Q2xzJywgJ3RhYkJhclBvc2l0aW9uJywgJ2NsYXNzTmFtZScsICdyZW5kZXJUYWJDb250ZW50JywgJ3JlbmRlclRhYkJhcicsICdkZXN0cm95SW5hY3RpdmVUYWJQYW5lJ10pO1xuXG4gICAgICB2YXIgY2xzID0gY2xhc3NuYW1lcygoX2NsYXNzbmFtZXMgPSB7fSwgX2RlZmluZVByb3BlcnR5KF9jbGFzc25hbWVzLCBwcmVmaXhDbHMsIDEpLCBfZGVmaW5lUHJvcGVydHkoX2NsYXNzbmFtZXMsIHByZWZpeENscyArICctJyArIHRhYkJhclBvc2l0aW9uLCAxKSwgX2RlZmluZVByb3BlcnR5KF9jbGFzc25hbWVzLCBjbGFzc05hbWUsICEhY2xhc3NOYW1lKSwgX2NsYXNzbmFtZXMpKTtcblxuICAgICAgdGhpcy50YWJCYXIgPSByZW5kZXJUYWJCYXIoKTtcbiAgICAgIHZhciBjb250ZW50cyA9IFtSZWFjdC5jbG9uZUVsZW1lbnQodGhpcy50YWJCYXIsIHtcbiAgICAgICAgcHJlZml4Q2xzOiBwcmVmaXhDbHMsXG4gICAgICAgIGtleTogJ3RhYkJhcicsXG4gICAgICAgIG9uS2V5RG93bjogdGhpcy5vbk5hdktleURvd24sXG4gICAgICAgIHRhYkJhclBvc2l0aW9uOiB0YWJCYXJQb3NpdGlvbixcbiAgICAgICAgb25UYWJDbGljazogdGhpcy5vblRhYkNsaWNrLFxuICAgICAgICBwYW5lbHM6IHByb3BzLmNoaWxkcmVuLFxuICAgICAgICBhY3RpdmVLZXk6IHRoaXMuc3RhdGUuYWN0aXZlS2V5XG4gICAgICB9KSwgUmVhY3QuY2xvbmVFbGVtZW50KHJlbmRlclRhYkNvbnRlbnQoKSwge1xuICAgICAgICBwcmVmaXhDbHM6IHByZWZpeENscyxcbiAgICAgICAgdGFiQmFyUG9zaXRpb246IHRhYkJhclBvc2l0aW9uLFxuICAgICAgICBhY3RpdmVLZXk6IHRoaXMuc3RhdGUuYWN0aXZlS2V5LFxuICAgICAgICBkZXN0cm95SW5hY3RpdmVUYWJQYW5lOiBkZXN0cm95SW5hY3RpdmVUYWJQYW5lLFxuICAgICAgICBjaGlsZHJlbjogcHJvcHMuY2hpbGRyZW4sXG4gICAgICAgIG9uQ2hhbmdlOiB0aGlzLnNldEFjdGl2ZUtleSxcbiAgICAgICAga2V5OiAndGFiQ29udGVudCdcbiAgICAgIH0pXTtcbiAgICAgIGlmICh0YWJCYXJQb3NpdGlvbiA9PT0gJ2JvdHRvbScpIHtcbiAgICAgICAgY29udGVudHMucmV2ZXJzZSgpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXG4gICAgICAgICdkaXYnLFxuICAgICAgICBfZXh0ZW5kcyh7XG4gICAgICAgICAgY2xhc3NOYW1lOiBjbHMsXG4gICAgICAgICAgc3R5bGU6IHByb3BzLnN0eWxlXG4gICAgICAgIH0sIGdldERhdGFBdHRyKHJlc3RQcm9wcykpLFxuICAgICAgICBjb250ZW50c1xuICAgICAgKTtcbiAgICB9XG4gIH1dKTtcblxuICByZXR1cm4gVGFicztcbn0oUmVhY3QuQ29tcG9uZW50KTtcblxudmFyIF9pbml0aWFsaXNlUHJvcHMgPSBmdW5jdGlvbiBfaW5pdGlhbGlzZVByb3BzKCkge1xuICB2YXIgX3RoaXMyID0gdGhpcztcblxuICB0aGlzLm9uVGFiQ2xpY2sgPSBmdW5jdGlvbiAoYWN0aXZlS2V5KSB7XG4gICAgaWYgKF90aGlzMi50YWJCYXIucHJvcHMub25UYWJDbGljaykge1xuICAgICAgX3RoaXMyLnRhYkJhci5wcm9wcy5vblRhYkNsaWNrKGFjdGl2ZUtleSk7XG4gICAgfVxuICAgIF90aGlzMi5zZXRBY3RpdmVLZXkoYWN0aXZlS2V5KTtcbiAgfTtcblxuICB0aGlzLm9uTmF2S2V5RG93biA9IGZ1bmN0aW9uIChlKSB7XG4gICAgdmFyIGV2ZW50S2V5Q29kZSA9IGUua2V5Q29kZTtcbiAgICBpZiAoZXZlbnRLZXlDb2RlID09PSBLZXlDb2RlLlJJR0hUIHx8IGV2ZW50S2V5Q29kZSA9PT0gS2V5Q29kZS5ET1dOKSB7XG4gICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICB2YXIgbmV4dEtleSA9IF90aGlzMi5nZXROZXh0QWN0aXZlS2V5KHRydWUpO1xuICAgICAgX3RoaXMyLm9uVGFiQ2xpY2sobmV4dEtleSk7XG4gICAgfSBlbHNlIGlmIChldmVudEtleUNvZGUgPT09IEtleUNvZGUuTEVGVCB8fCBldmVudEtleUNvZGUgPT09IEtleUNvZGUuVVApIHtcbiAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgIHZhciBwcmV2aW91c0tleSA9IF90aGlzMi5nZXROZXh0QWN0aXZlS2V5KGZhbHNlKTtcbiAgICAgIF90aGlzMi5vblRhYkNsaWNrKHByZXZpb3VzS2V5KTtcbiAgICB9XG4gIH07XG5cbiAgdGhpcy5zZXRBY3RpdmVLZXkgPSBmdW5jdGlvbiAoYWN0aXZlS2V5KSB7XG4gICAgaWYgKF90aGlzMi5zdGF0ZS5hY3RpdmVLZXkgIT09IGFjdGl2ZUtleSkge1xuICAgICAgaWYgKCEoJ2FjdGl2ZUtleScgaW4gX3RoaXMyLnByb3BzKSkge1xuICAgICAgICBfdGhpczIuc2V0U3RhdGUoe1xuICAgICAgICAgIGFjdGl2ZUtleTogYWN0aXZlS2V5XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgX3RoaXMyLnByb3BzLm9uQ2hhbmdlKGFjdGl2ZUtleSk7XG4gICAgfVxuICB9O1xuXG4gIHRoaXMuZ2V0TmV4dEFjdGl2ZUtleSA9IGZ1bmN0aW9uIChuZXh0KSB7XG4gICAgdmFyIGFjdGl2ZUtleSA9IF90aGlzMi5zdGF0ZS5hY3RpdmVLZXk7XG4gICAgdmFyIGNoaWxkcmVuID0gW107XG4gICAgUmVhY3QuQ2hpbGRyZW4uZm9yRWFjaChfdGhpczIucHJvcHMuY2hpbGRyZW4sIGZ1bmN0aW9uIChjKSB7XG4gICAgICBpZiAoYyAmJiAhYy5wcm9wcy5kaXNhYmxlZCkge1xuICAgICAgICBpZiAobmV4dCkge1xuICAgICAgICAgIGNoaWxkcmVuLnB1c2goYyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY2hpbGRyZW4udW5zaGlmdChjKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pO1xuICAgIHZhciBsZW5ndGggPSBjaGlsZHJlbi5sZW5ndGg7XG4gICAgdmFyIHJldCA9IGxlbmd0aCAmJiBjaGlsZHJlblswXS5rZXk7XG4gICAgY2hpbGRyZW4uZm9yRWFjaChmdW5jdGlvbiAoY2hpbGQsIGkpIHtcbiAgICAgIGlmIChjaGlsZC5rZXkgPT09IGFjdGl2ZUtleSkge1xuICAgICAgICBpZiAoaSA9PT0gbGVuZ3RoIC0gMSkge1xuICAgICAgICAgIHJldCA9IGNoaWxkcmVuWzBdLmtleTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXQgPSBjaGlsZHJlbltpICsgMV0ua2V5O1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSk7XG4gICAgcmV0dXJuIHJldDtcbiAgfTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IFRhYnM7XG5cblxuVGFicy5wcm9wVHlwZXMgPSB7XG4gIGRlc3Ryb3lJbmFjdGl2ZVRhYlBhbmU6IFByb3BUeXBlcy5ib29sLFxuICByZW5kZXJUYWJCYXI6IFByb3BUeXBlcy5mdW5jLmlzUmVxdWlyZWQsXG4gIHJlbmRlclRhYkNvbnRlbnQ6IFByb3BUeXBlcy5mdW5jLmlzUmVxdWlyZWQsXG4gIG9uQ2hhbmdlOiBQcm9wVHlwZXMuZnVuYyxcbiAgY2hpbGRyZW46IFByb3BUeXBlcy5hbnksXG4gIHByZWZpeENsczogUHJvcFR5cGVzLnN0cmluZyxcbiAgY2xhc3NOYW1lOiBQcm9wVHlwZXMuc3RyaW5nLFxuICB0YWJCYXJQb3NpdGlvbjogUHJvcFR5cGVzLnN0cmluZyxcbiAgc3R5bGU6IFByb3BUeXBlcy5vYmplY3QsXG4gIGFjdGl2ZUtleTogUHJvcFR5cGVzLnN0cmluZyxcbiAgZGVmYXVsdEFjdGl2ZUtleTogUHJvcFR5cGVzLnN0cmluZ1xufTtcblxuVGFicy5kZWZhdWx0UHJvcHMgPSB7XG4gIHByZWZpeENsczogJ3JjLXRhYnMnLFxuICBkZXN0cm95SW5hY3RpdmVUYWJQYW5lOiBmYWxzZSxcbiAgb25DaGFuZ2U6IG5vb3AsXG4gIHRhYkJhclBvc2l0aW9uOiAndG9wJyxcbiAgc3R5bGU6IHt9XG59O1xuXG5UYWJzLlRhYlBhbmUgPSBUYWJQYW5lOyIsImltcG9ydCBUYWJzIGZyb20gJy4vVGFicyc7XG5pbXBvcnQgVGFiUGFuZSBmcm9tICcuL1RhYlBhbmUnO1xuaW1wb3J0IFRhYkNvbnRlbnQgZnJvbSAnLi9UYWJDb250ZW50JztcblxuZXhwb3J0IGRlZmF1bHQgVGFicztcbmV4cG9ydCB7IFRhYlBhbmUsIFRhYkNvbnRlbnQgfTsiLCJpbXBvcnQgX2RlZmluZVByb3BlcnR5IGZyb20gJ2JhYmVsLXJ1bnRpbWUvaGVscGVycy9kZWZpbmVQcm9wZXJ0eSc7XG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuXG5leHBvcnQgZnVuY3Rpb24gdG9BcnJheShjaGlsZHJlbikge1xuICAvLyBhbGxvdyBbYyxbYSxiXV1cbiAgdmFyIGMgPSBbXTtcbiAgUmVhY3QuQ2hpbGRyZW4uZm9yRWFjaChjaGlsZHJlbiwgZnVuY3Rpb24gKGNoaWxkKSB7XG4gICAgaWYgKGNoaWxkKSB7XG4gICAgICBjLnB1c2goY2hpbGQpO1xuICAgIH1cbiAgfSk7XG4gIHJldHVybiBjO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZ2V0QWN0aXZlSW5kZXgoY2hpbGRyZW4sIGFjdGl2ZUtleSkge1xuICB2YXIgYyA9IHRvQXJyYXkoY2hpbGRyZW4pO1xuICBmb3IgKHZhciBpID0gMDsgaSA8IGMubGVuZ3RoOyBpKyspIHtcbiAgICBpZiAoY1tpXS5rZXkgPT09IGFjdGl2ZUtleSkge1xuICAgICAgcmV0dXJuIGk7XG4gICAgfVxuICB9XG4gIHJldHVybiAtMTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldEFjdGl2ZUtleShjaGlsZHJlbiwgaW5kZXgpIHtcbiAgdmFyIGMgPSB0b0FycmF5KGNoaWxkcmVuKTtcbiAgcmV0dXJuIGNbaW5kZXhdLmtleTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHNldFRyYW5zZm9ybShzdHlsZSwgdikge1xuICBzdHlsZS50cmFuc2Zvcm0gPSB2O1xuICBzdHlsZS53ZWJraXRUcmFuc2Zvcm0gPSB2O1xuICBzdHlsZS5tb3pUcmFuc2Zvcm0gPSB2O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gaXNUcmFuc2Zvcm1TdXBwb3J0ZWQoc3R5bGUpIHtcbiAgcmV0dXJuICd0cmFuc2Zvcm0nIGluIHN0eWxlIHx8ICd3ZWJraXRUcmFuc2Zvcm0nIGluIHN0eWxlIHx8ICdNb3pUcmFuc2Zvcm0nIGluIHN0eWxlO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gc2V0VHJhbnNpdGlvbihzdHlsZSwgdikge1xuICBzdHlsZS50cmFuc2l0aW9uID0gdjtcbiAgc3R5bGUud2Via2l0VHJhbnNpdGlvbiA9IHY7XG4gIHN0eWxlLk1velRyYW5zaXRpb24gPSB2O1xufVxuZXhwb3J0IGZ1bmN0aW9uIGdldFRyYW5zZm9ybVByb3BWYWx1ZSh2KSB7XG4gIHJldHVybiB7XG4gICAgdHJhbnNmb3JtOiB2LFxuICAgIFdlYmtpdFRyYW5zZm9ybTogdixcbiAgICBNb3pUcmFuc2Zvcm06IHZcbiAgfTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzVmVydGljYWwodGFiQmFyUG9zaXRpb24pIHtcbiAgcmV0dXJuIHRhYkJhclBvc2l0aW9uID09PSAnbGVmdCcgfHwgdGFiQmFyUG9zaXRpb24gPT09ICdyaWdodCc7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRUcmFuc2Zvcm1CeUluZGV4KGluZGV4LCB0YWJCYXJQb3NpdGlvbikge1xuICB2YXIgdHJhbnNsYXRlID0gaXNWZXJ0aWNhbCh0YWJCYXJQb3NpdGlvbikgPyAndHJhbnNsYXRlWScgOiAndHJhbnNsYXRlWCc7XG4gIHJldHVybiB0cmFuc2xhdGUgKyAnKCcgKyAtaW5kZXggKiAxMDAgKyAnJSkgdHJhbnNsYXRlWigwKSc7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRNYXJnaW5TdHlsZShpbmRleCwgdGFiQmFyUG9zaXRpb24pIHtcbiAgdmFyIG1hcmdpbkRpcmVjdGlvbiA9IGlzVmVydGljYWwodGFiQmFyUG9zaXRpb24pID8gJ21hcmdpblRvcCcgOiAnbWFyZ2luTGVmdCc7XG4gIHJldHVybiBfZGVmaW5lUHJvcGVydHkoe30sIG1hcmdpbkRpcmVjdGlvbiwgLWluZGV4ICogMTAwICsgJyUnKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldFN0eWxlKGVsLCBwcm9wZXJ0eSkge1xuICByZXR1cm4gK2dldENvbXB1dGVkU3R5bGUoZWwpLmdldFByb3BlcnR5VmFsdWUocHJvcGVydHkpLnJlcGxhY2UoJ3B4JywgJycpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gc2V0UHhTdHlsZShlbCwgdmFsdWUsIHZlcnRpY2FsKSB7XG4gIHZhbHVlID0gdmVydGljYWwgPyAnMHB4LCAnICsgdmFsdWUgKyAncHgsIDBweCcgOiB2YWx1ZSArICdweCwgMHB4LCAwcHgnO1xuICBzZXRUcmFuc2Zvcm0oZWwuc3R5bGUsICd0cmFuc2xhdGUzZCgnICsgdmFsdWUgKyAnKScpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZ2V0RGF0YUF0dHIocHJvcHMpIHtcbiAgcmV0dXJuIE9iamVjdC5rZXlzKHByb3BzKS5yZWR1Y2UoZnVuY3Rpb24gKHByZXYsIGtleSkge1xuICAgIGlmIChrZXkuc3Vic3RyKDAsIDUpID09PSAnYXJpYS0nIHx8IGtleS5zdWJzdHIoMCwgNSkgPT09ICdkYXRhLScgfHwga2V5ID09PSAncm9sZScpIHtcbiAgICAgIHByZXZba2V5XSA9IHByb3BzW2tleV07XG4gICAgfVxuICAgIHJldHVybiBwcmV2O1xuICB9LCB7fSk7XG59IiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gdG9BcnJheShjaGlsZHJlbikge1xuICB2YXIgcmV0ID0gW107XG4gIFJlYWN0LkNoaWxkcmVuLmZvckVhY2goY2hpbGRyZW4sIGZ1bmN0aW9uIChjKSB7XG4gICAgcmV0LnB1c2goYyk7XG4gIH0pO1xuICByZXR1cm4gcmV0O1xufSJdLCJzb3VyY2VSb290IjoiIn0=